# Fresh command results

Every command below ran now in the disposable copy unless explicitly identified as a read-only original-repository search. Full STDOUT and STDERR are retained with timestamps, actual exit codes and durations. No output from earlier sessions substitutes for a fresh run. Any private path/secret redactions are disclosed separately.

|Command run|Start UTC|Exit|Seconds|Full real output|
|---|---|---:|---:|---|
|node-version: --version|2026-10-25T03:28:01.828618+00:00|0|0.119|[node-version](02_logs/node-version.txt)|
|npm-version: --version|2026-10-25T03:28:01.949620+00:00|0|0.528|[npm-version](02_logs/npm-version.txt)|
|python-version: --version|2026-10-25T03:28:02.480621+00:00|0|0.014|[python-version](02_logs/python-version.txt)|
|install: ci|2026-10-25T03:28:02.593618+00:00|0|130.209|[install](02_logs/install.txt)|
|lint: run lint|2026-10-25T03:31:33.644676+00:00|0|8.251|[lint](02_logs/lint.txt)|
|typecheck: run typecheck|2026-10-25T03:31:41.899496+00:00|0|2.256|[typecheck](02_logs/typecheck.txt)|
|unit: test|2026-10-25T03:31:44.156555+00:00|0|13.783|[unit](02_logs/unit.txt)|
|geography: run test:geography|2026-10-25T03:31:57.940185+00:00|0|11.652|[geography](02_logs/geography.txt)|
|contrast: run test:contrast|2026-10-25T03:32:09.594130+00:00|0|0.618|[contrast](02_logs/contrast.txt)|
|build: run build|2026-10-25T03:32:01.546714+00:00|0|9.006|[build](02_logs/build.txt)|
|audit: audit --json|2026-10-25T03:32:10.213653+00:00|0|1.540|[audit](02_logs/audit.txt)|
|pwa: run test:pwa|2026-10-25T03:33:14.700522+00:00|0|25.088|[pwa](02_logs/pwa.txt)|
|evaluation: run evaluate|2026-10-25T03:31:48.540814+00:00|0|406.513|[evaluation](02_logs/evaluation.txt)|
|browser: run test:ui|2026-10-25T03:33:03.380522+00:00|1|425.163|[browser](02_logs/browser.txt)|
|browser-serial: run test:ui -- --workers=1 --global-timeout=180000|2026-10-25T03:41:23.883757+00:00|1|181.719|[browser-serial](02_logs/browser-serial.txt)|
|test-list: run test:ui -- --list|2026-10-25T03:49:17.800584+00:00|0|1.758|[test-list](02_logs/test-list.txt)|
|browser-production-subset (auxiliary/diagnostic)|2026-10-25T03:43:27.539619+00:00|1|45.859|[browser-production-subset.txt](02_logs/browser-production-subset.txt)|
|data-profile-current (auxiliary/diagnostic)|2026-10-25T03:51:03.069296+00:00|0|0.858|[data-profile-current.txt](02_logs/data-profile-current.txt)|
|data-profile (auxiliary/diagnostic)|2026-10-25T03:34:18.617855+00:00|0|1.411|[data-profile.txt](02_logs/data-profile.txt)|
|docker-availability (auxiliary/diagnostic)|2026-10-25T03:56:55.945922+00:00|1|0.100|[docker-availability.txt](02_logs/docker-availability.txt)|
|lighthouse (auxiliary/diagnostic)|2026-10-25T03:45:37.823254+00:00|0|31.167|[lighthouse.txt](02_logs/lighthouse.txt)|
|python-packages (auxiliary/diagnostic)|2026-10-25T03:56:56.076446+00:00|0|0.220|[python-packages.txt](02_logs/python-packages.txt)|
|rls-catalog (auxiliary/diagnostic)|2026-10-25T03:34:20.029816+00:00|0|2.919|[rls-catalog.txt](02_logs/rls-catalog.txt)|
|todo-search (auxiliary/diagnostic)|2026-10-25T03:56:56.045921+00:00|0|0.030|[todo-search.txt](02_logs/todo-search.txt)|
|ui-capture-attempt1 (auxiliary/diagnostic)|2026-10-25T03:40:02.897014+00:00|1|5.497|[ui-capture-attempt1.txt](02_logs/ui-capture-attempt1.txt)|
|ui-capture (auxiliary/diagnostic)|2026-10-25T03:41:11.760260+00:00|0|42.835|[ui-capture.txt](02_logs/ui-capture.txt)|

## Actual fresh test outcome

- Node unit/integration: 66 passed, 0 failed, 0 skipped (full verbose TAP in unit.txt). Includes local RLS/abuse fixtures.
- Python geographic tests: 3 passed (geography.txt).
- Complete browser suite, default 3 workers: **6 passed, 23 failed**; page navigation/heading timeouts. This does not reproduce the previously saved 29-pass result.
- Separate serial diagnostic: **8 passed, 4 failed, 17 did not run** before an explicit 180000ms global timeout. No failure is hidden by this rerun.
- Separate existing public production subset: **4 passed, 1 failed**. The failed error/retry test could not find the expected alert after intercepting an API failure. It was originally a dev-mode test; the production SW/cache may affect interception, but root cause is NOT VERIFIED. This subset does not replace the full suite.
- Production PWA: **2 passed**; these are the existing production-specific tests.

No application code, tests, original data or docs were changed to make failures pass. The initial screenshot helper failed on an SVG element lacking innerText; that helper-only failure is retained, then the helper used textContent as a fallback and captured all requested public/access-gate views.

## Warnings, skipped and interrupted tests

All warning lines are preserved in the raw logs and 02_warnings.txt. Installation reports the ESLint version deprecation and an npm update notice. Browser logs contain Node NO_COLOR/FORCE_COLOR warnings. Python geographic analysis reports a Shapely transform deprecation. Build/audit details remain in raw output. Do not treat a passing command as absence of warnings.

Explicit unit skips: none. The full browser run had no explicit skips. The serial diagnostic left 17 cases unrun because of the global timeout; their names are listed in 02_skipped_or_unrun.md. The production subset intentionally selects five existing cases and is not the complete suite.

## Evaluation and Lighthouse

Evaluation ran fresh with ENV_OFFLINE=1 from copied verified public-provider caches. Full printed JSON/results are in evaluation.txt; every complete model/fold/horizon/scenario summary table is in 04_tables. The command writes tables to files rather than printing every table as Markdown. Both numerical JSON outputs match the original SHA256 byte for byte; see 04_tables/reproduction.json. This establishes reproducibility with the same code, not scientific validity.

Fresh Lighthouse mobile scores and actual HTML/JSON are linked in 02_logs/lighthouse.txt and 09_ui_evidence/lighthouse-mobile.report.*. Saved reports under 08_docs are historical copies. Lighthouse is a local lab observation, not field performance or a complete accessibility certification.

Install used fresh npm ci in the copy and the pinned lockfile. Python packages were already installed; actual versions were freshly queried in python-packages.txt. No fresh isolated Python installation or Python vulnerability audit is claimed. npm audit is fresh and contains zero reported vulnerabilities.

Fresh Lighthouse mobile scores: {"performance": 92, "accessibility": 100, "best-practices": 100, "seo": 100}. CLS 0.002984854642923739. These are the new local run, not the archived 94/100 scores.

## Additional actual UI capture commands

- [ui-viewport-capture](02_logs/ui-viewport-capture.txt): START UTC: 2026-10-25T04:00:18.111320+00:00; EXIT CODE: 0; DURATION SECONDS: 35.079.
- [ui-detail-capture](02_logs/ui-detail-capture.txt): START UTC: 2026-10-25T04:03:07.927929+00:00; EXIT CODE: 0; DURATION SECONDS: 13.006.

The delivered JPGs are actual 900px-high viewports at 360px/1280px width, plus 8 scrolled map/chart/table/withdrawal details. Full rendered-page text (including below the viewport) is preserved separately. Authenticated staff content is NOT VERIFIED.
