# Fresh command results

Every full output, including failures, is retained in 02_logs. Commands ran in the canonical project checkout. Browser suites ran sequentially without builds, evaluation, install or scanners alongside them. No tests or safeguards were skipped or deleted.

|Command|UTC start|Seconds|Exit|Actual output|
|---|---|---:|---:|---|
|npm run test:ui|2026-10-25T05:20:07.049123+00:00|199.406|0|02_logs/baseline-ui-default.txt|
|npm run test:ui -- --workers=1|2026-10-25T05:24:30.700974+00:00|255.375|0|02_logs/baseline-ui-serial.txt|
|npm run build|2026-10-25T05:29:10.147938+00:00|18.828|1|02_logs/production-before-fix.txt|
|npm exec playwright test --config .artifacts/launch/production-repro.config.ts --grep Filipino home|2026-10-25T05:29:29.266856+00:00|22.422|1|02_logs/production-retry-before-fix.txt|
|npm run build|2026-10-25T05:30:27.968966+00:00|13.562|0|02_logs/production-before-fix-retry.txt|
|npm exec -- playwright test --config .artifacts/launch/production-repro.config.ts --grep Filipino home|2026-10-25T05:30:41.920444+00:00|4.328|1|02_logs/production-retry-before-fix-retry.txt|
|npm exec -- playwright test --config .artifacts/launch/production-repro.config.ts --grep Filipino home|2026-10-25T05:31:12.221988+00:00|18.219|1|02_logs/production-retry-trace.txt|
|npm exec -- playwright test --config .artifacts/launch/production-repro.config.ts --grep Filipino home|2026-10-25T05:32:09.407663+00:00|12.485|0|02_logs/production-retry-sw-blocked.txt|
|npm run lint|2026-10-25T05:36:03.201198+00:00|78.078|0|02_logs/initial-lint.txt|
|npm run typecheck|2026-10-25T05:37:21.579237+00:00|2.906|0|02_logs/initial-types.txt|
|npm run data:validate|2026-10-25T05:37:24.795491+00:00|0.953|0|02_logs/initial-validator.txt|
|npm run db:verify|2026-10-25T05:39:29.264638+00:00|27.031|0|02_logs/database-first.txt|
|npm run typecheck|2026-10-25T05:39:56.514218+00:00|3.344|0|02_logs/types-after-flow.txt|
|npm run test:ui -- tests/ui/reporting-flow.spec.ts tests/ui/accuracy.spec.ts --workers=1|2026-10-25T05:40:00.028584+00:00|49.312|0|02_logs/focused-auth-flow.txt|
|npm run security:secrets|2026-10-25T05:41:51.835841+00:00|30.828|1|02_logs/current-secrets.txt|
|npm test|2026-10-25T05:42:22.903841+00:00|25.547|0|02_logs/all-unit-first.txt|
|npm run build|2026-10-25T05:42:48.657707+00:00|14.828|0|02_logs/launch-build-first.txt|
|npm run security:zap -- http://127.0.0.1:43142|2026-10-25T05:43:45.466567+00:00|74.547|1|02_logs/zap-local-first.txt|
|npm run build|2026-10-25T05:46:05.193937+00:00|3.75|1|02_logs/strict-csp-build.txt|
|npm run test:pwa|2026-10-25T05:46:09.070444+00:00|3.671|1|02_logs/strict-csp-pwa.txt|
|npm run build|2026-10-25T05:47:00.624139+00:00|2.797|1|02_logs/strict-csp-build-corrected.txt|
|npm run test:pwa|2026-10-25T05:47:03.725807+00:00|4.422|1|02_logs/strict-csp-pwa-corrected.txt|
|npm run build|2026-10-25T05:47:30.214813+00:00|9.297|0|02_logs/strict-csp-build-fixed.txt|
|npm run test:pwa|2026-10-25T05:47:39.771437+00:00|15.625|0|02_logs/strict-csp-pwa-fixed.txt|
|npm run credentials:verify|2026-10-25T05:48:35.004041+00:00|0.891|1|02_logs/credentials-owner-gate.txt|
|npm run hosted:bootstrap|2026-10-25T05:48:36.206049+00:00|0.953|1|02_logs/bootstrap-owner-gate.txt|
|npm run security:zap -- http://127.0.0.1:43142|2026-10-25T05:50:10.867562+00:00|32.141|0|02_logs/zap-local-fixed.txt|
|npm run data:inventory|2026-10-25T05:52:10.596786+00:00|1.656|0|02_logs/placeholder-inventory.txt|
|npm ci|2026-10-25T05:52:24.150788+00:00|165.828|0|02_logs/install-final.txt|
|npm run lint|2026-10-25T05:55:10.180436+00:00|9.891|1|02_logs/lint-final.txt|
|npm run typecheck|2026-10-25T05:55:20.375431+00:00|5.203|0|02_logs/types-final.txt|
|npm test|2026-10-25T05:55:25.809820+00:00|24.875|1|02_logs/units-final.txt|
|npm run test:geography|2026-10-25T05:55:50.919037+00:00|25.235|0|02_logs/geography-final.txt|
|npm run test:contrast|2026-10-25T05:56:16.351110+00:00|0.656|0|02_logs/contrast-final.txt|
|npm audit --json|2026-10-25T05:56:17.198112+00:00|2.406|0|02_logs/audit-final.txt|
|npm run build|2026-10-25T05:56:19.817113+00:00|10.078|0|02_logs/build-final.txt|
|npm run lint|2026-10-25T05:58:27.329497+00:00|6.422|0|02_logs/lint-corrected.txt|
|npm test|2026-10-25T05:58:33.883497+00:00|23.797|0|02_logs/units-corrected.txt|
|npm run typecheck|2026-10-25T05:58:57.790039+00:00|1.657|0|02_logs/types-corrected.txt|
|npm run db:verify|2026-10-25T05:58:59.563422+00:00|41.39|0|02_logs/db-verify-complete.txt|
|npm run test:ui|2026-10-25T06:00:40.956118+00:00|173.016|0|02_logs/ui-final-1.txt|
|npm run test:ui|2026-10-25T06:03:34.073211+00:00|200.375|0|02_logs/ui-final-2.txt|
|npm run test:ui|2026-10-25T06:06:54.555264+00:00|204.891|0|02_logs/ui-final-3.txt|
|npm run test:production|2026-10-25T06:12:00.531412+00:00|37.578|0|02_logs/production-final.txt|
|npm run test:pwa|2026-10-25T06:12:38.256475+00:00|10.406|0|02_logs/pwa-final.txt|
|npm run data:audit|2026-10-25T06:12:48.789260+00:00|1.688|0|02_logs/data-audit-final.txt|
|npm run setup:local -- --check|2026-10-25T06:12:50.597274+00:00|3.14|1|02_logs/local-stack-prerequisites.txt|
|npm run evaluate|2026-10-25T06:12:54.014415+00:00|288.313|0|02_logs/evaluation-final.txt|
|npm run lint|2026-10-25T06:21:33.613409+00:00|6.407|0|02_logs/lint-release.txt|
|npm run typecheck|2026-10-25T06:21:40.222926+00:00|1.562|0|02_logs/types-release.txt|
|npm test|2026-10-25T06:21:41.916770+00:00|13.703|0|02_logs/units-release.txt|
|npm run build|2026-10-25T06:21:55.719179+00:00|4.578|0|02_logs/build-release.txt|
|npm run test:ui|2026-10-25T06:22:00.473027+00:00|194.5|0|02_logs/ui-release-1.txt|
|npm run test:ui|2026-10-25T06:25:15.095733+00:00|199.828|0|02_logs/ui-release-2.txt|
|npm run test:ui|2026-10-25T06:28:35.059560+00:00|182.016|0|02_logs/ui-release-3.txt|
|npm run test:production|2026-10-25T06:31:37.200663+00:00|35.953|0|02_logs/production-release.txt|
|npm run test:pwa|2026-10-25T06:32:13.260946+00:00|9.875|0|02_logs/pwa-release.txt|
|npm run lint|2026-10-25T06:33:42.618288+00:00|5.235|0|02_logs/lint-gate.txt|
|npm run typecheck|2026-10-25T06:33:47.960533+00:00|1.297|0|02_logs/types-gate.txt|
|npm test|2026-10-25T06:33:49.373268+00:00|12.157|0|02_logs/units-gate.txt|
|npm run db:verify|2026-10-25T06:34:01.636496+00:00|35.422|0|02_logs/db-gate.txt|
|npm run build|2026-10-25T06:34:37.160500+00:00|4.688|0|02_logs/build-gate.txt|
|npm run test:ui|2026-10-25T06:34:42.019771+00:00|156.203|0|02_logs/ui-gate-1.txt|
|npm run test:ui|2026-10-25T06:37:18.321964+00:00|165.796|0|02_logs/ui-gate-2.txt|
|npm run test:ui|2026-10-25T06:40:04.219636+00:00|159.484|0|02_logs/ui-gate-3.txt|
|npm run test:production|2026-10-25T06:42:43.822983+00:00|33.156|0|02_logs/production-gate.txt|
|npm run test:pwa|2026-10-25T06:43:17.081715+00:00|9.297|0|02_logs/pwa-gate.txt|
|npm test|2026-10-25T06:48:59.055233+00:00|10.609|0|02_logs/units-complete.txt|
|npm run db:verify|2026-10-25T06:49:09.755392+00:00|30.469|0|02_logs/db-complete.txt|
|npm run security:secrets|2026-10-25T06:49:40.337836+00:00|17.938|1|02_logs/secrets-archive.txt|
|node .artifacts/launch/lighthouse-final.mjs|2026-10-25T06:50:23.229430+00:00|41.047|0|02_logs/lighthouse-final.txt|
|npm run security:zap -- http://127.0.0.1:43142|2026-10-25T06:52:12.914299+00:00|43.703|0|02_logs/zap-local-final.txt|
|node node_modules/tsx/dist/cli.mjs .artifacts/launch/capture-current.ts|2026-10-25T06:53:49.011414+00:00|31.906|0|02_logs/capture-final.txt|
|node .artifacts/launch/catalog.mjs|2026-10-25T06:54:53.815104+00:00|2.39|0|02_logs/catalog-final.txt|
|node .artifacts/launch/runtime.mjs|2026-10-25T06:54:56.317105+00:00|0.296|1|02_logs/runtime-final.txt|
|npm run lint|2026-10-25T06:54:56.728104+00:00|5.078|0|02_logs/lint-complete.txt|
|npm audit --json|2026-10-25T06:55:01.915104+00:00|1.469|0|02_logs/audit-complete.txt|
|npm run data:inventory|2026-10-25T06:55:03.485950+00:00|1.657|0|02_logs/inventory-complete.txt|
|npm run lint|2026-10-25T06:55:58.787622+00:00|5.094|0|02_logs/lint-navigation.txt|
|npm run build|2026-10-25T06:56:03.988848+00:00|5.0|0|02_logs/build-navigation.txt|
|npm run test:ui|2026-10-25T06:56:09.173897+00:00|195.172|1|02_logs/ui-launch-1.txt|
|npm run test:production|2026-10-25T06:59:24.515006+00:00|36.718|0|02_logs/production-navigation.txt|
|npm run test:pwa|2026-10-25T07:00:01.345508+00:00|9.984|0|02_logs/pwa-navigation.txt|
|npm run lint|2026-10-25T07:00:18.358670+00:00|5.469|0|02_logs/lint-offline-navigation.txt|
|npm run build|2026-10-25T07:00:23.927666+00:00|4.953|0|02_logs/build-offline-navigation.txt|
|npm run test:ui|2026-10-25T07:00:29.063774+00:00|202.218|0|02_logs/ui-verified-1.txt|
|npm run test:ui|2026-10-25T07:03:51.408950+00:00|191.61|0|02_logs/ui-verified-2.txt|
|npm run test:ui|2026-10-25T07:07:03.140169+00:00|206.515|0|02_logs/ui-verified-3.txt|
|npm run test:production|2026-10-25T07:10:29.781828+00:00|36.469|0|02_logs/production-verified.txt|
|npm run test:pwa|2026-10-25T07:11:06.386668+00:00|10.781|0|02_logs/pwa-verified.txt|
|node .artifacts/launch/runtime.mjs|2026-10-25T07:11:22.287558+00:00|0.422|0|02_logs/runtime-complete.txt|
|python .artifacts/launch/verify-integrity.py|2026-10-25T07:11:22.817558+00:00|1.468|1|02_logs/original-integrity.txt|
|node .artifacts/launch/lighthouse-final.mjs|2026-10-25T07:11:42.030071+00:00|16.297|0|02_logs/lighthouse-verified.txt|
|python .artifacts/launch/verify-integrity.py|2026-10-25T07:12:25.928119+00:00|1.516|0|02_logs/original-integrity-corrected.txt|
|npm run security:zap -- http://127.0.0.1:43142|2026-10-25T07:12:27.599119+00:00|23.172|0|02_logs/zap-local-verified.txt|
|node node_modules/tsx/dist/cli.mjs .artifacts/launch/capture-current.ts|2026-10-25T07:12:50.892534+00:00|35.515|0|02_logs/capture-verified.txt|
|npm run security:secrets|2026-10-25T07:14:01.380865+00:00|19.266|1|02_logs/secrets-before-commit.txt|
|node [REDACTED]/AppData/Local/nvm/v20.19.4/node_modules/npm/bin/npm-cli.js --version|2026-10-25T07:14:53.209108+00:00|0.203|0|02_logs/npm-runtime.txt|
|python .artifacts/launch/git-command.py commit -m launch: fix release gates and document owner blockers|2026-10-25T07:15:22.408536+00:00|17.938|0|02_logs/code-commit.txt|
|python .artifacts/launch/git-command.py commit --amend --no-edit|2026-10-25T07:15:58.416969+00:00|14.922|0|02_logs/code-commit-format.txt|

Fresh failures are not overwritten by later passes. Original copied-review browser failures were not reproduced in the canonical checkout; their historical cause remains NOT VERIFIED. The production retry failure was reproduced with trace/video and fixed by blocking service workers in non-PWA tests; the app still displays and asserts an actual accessible failure/retry. PWA tests explicitly allow service workers.
