# Archived recording omitted

The pre-existing 6.13MB recording is not included under the review size cap. Fresh public/access-gate screenshots and text are in 09_ui_evidence. Source hash and exact byte size are in OMISSIONS.json. No live/authenticated workflow is claimed.
