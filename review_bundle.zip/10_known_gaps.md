# Known gaps and owner gates

Main was not merged or pushed: the owner explicitly deferred credential rotation, and every release gate must pass first.

- NEEDS OWNER: reset the database password, rotate exposed API keys if applicable, update private local/hosting/CI settings and private fingerprint guard, and run credentials:verify. Current-tree matches are removed; historical exposure remains until revocation is confirmed. No history rewrite.
- NEEDS OWNER: apply hosted migrations, create the first appointed admin, enroll/verify real TOTP, and exercise a hosted login. Local signed Auth/PostgREST test sessions and AAL2 SQL checks are not hosted Auth proof.
- NEEDS OWNER: verify actual hourly pg_cron or a matching successful retention workflow run; enable/run daily weather and weekly/manual ZAP workflows. Files are definitions, not evidence of installed schedules.
- NEEDS OWNER: run the hosted ZAP baseline against the reviewed deployment and inspect artifacts, conduct a real usability session, and obtain school/DPO privacy/consent review. No participants, scores or approvals were invented.
- Reporting remains fail-closed until explicit verified activation; one-line kill switch is reports:off. No synthetic rows were seeded into hosting or mixed into official counts/forecasts.
- The original copied-review 23 browser failures were not reproduced in the canonical checkout run alone; their historical cause is NOT VERIFIED. The production retry failure was reproduced with trace/video: cache-first service worker returned 200 and bypassed interception; blocking workers for ordinary UI tests made the same test pass. PWA tests still allow workers.
- The source-owner meaning of absent daily rows, source retrieval/formal reference and usage rights, population provenance and boundary harmonization remain unresolved. Honest unknowns remain unknown. Thermal suitability and NCR-neighbor forecasting are NOT IMPLEMENTED / NOT VERIFIED optional research. No causal or current clinical forecasting claim is justified.
- Every visible numeric occurrence has a file/context trace; exact scalar mapping remains NOT VERIFIED except the separately tested saved-MAE table. Legal/medical copy is not independent legal/clinical validation.
- No fresh full Supabase/Docker stack: Docker is absent. Fresh embedded PostgreSQL applies the actual SQL and RLS/abuse/retention tests. Real Supabase Auth/TOTP, network stack and deployment need owner checks.
- See 02_warnings.txt and all failed command attempts. The retired-command cold-import failure was fixed by rejecting before heavy imports; its original timeout was not increased. Encoding/helper failures and first Medium CSP finding are retained.
- Review copies are redacted, may not execute unchanged, and large logical files are split. Full source inputs/provider caches/per-origin arrays and the archived recording are not duplicated under the size budget. This is an audit payload, not a credentialed runnable checkout.

Marker search results are in 02_logs/placeholder-inventory.txt/json. Remaining matches are standard HTML/CSS input-hint attributes, validator identifiers, preserved applied historical SQL, historical documentation, third-party report code, or provider OSM annotations. No blocked citation/filler text remains in shipped src/public/processed data, as checked by data:validate. Applied old SQL is preserved and corrected by a new migration.

Exact owner checklist: 08_docs/ROTATE_CREDENTIALS.md and 08_docs/LAUNCH_CHECKLIST.md. Test locally and self-review the schema/auth changes before merging near the defense.
