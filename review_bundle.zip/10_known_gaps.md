# Known gaps and omitted evidence

- Fresh complete browser tests did not reproduce the archived 29-pass claim: 6 passed / 23 failed. Serial diagnostic also failed and stopped early; production subset was 4/5. Root cause is NOT VERIFIED. The source copy lives in an ignored nested folder, dependency install is fresh, and some checks ran alongside CPU-heavy evaluation; these are environmental differences, not proven explanations. Preserve failures for review rather than infer that old documentation is current evidence.
- Authenticated moderation queue and data upload screenshots are NOT VERIFIED. Captured admin subpaths show the actual signed-out gate, not a fabricated session, queue or record. No real credentials or health reports were used. No distinct moderation/upload URL implementation is asserted: the app uses a shared admin view.
- Report collection is closed/unconfigured in this isolated public demo. Screenshots show that real state; they do not demonstrate a live report submission, staff login or hosted moderation action.
- Credential exposure remains unresolved: a current local configured value matches historical public text. No private value is included. Hosted rotation and whether the old value is still active are NOT VERIFIED.
- Hosted migrations, staff appointments, MFA, retention scheduler/execution, daily weather scheduling, real withdrawals and DPO approval are NOT VERIFIED. The daily weather job exists as a filesystem command; no deployed schedule was installed or tested. Local purge/role tests are not proof of hosted execution.
- Deployed OWASP ZAP: NOT VERIFIED / NOT RUN in this task. No confirmed deployed target was supplied; the saved status is not a scan report. Fresh Docker availability is captured in 02_logs/docker-availability.txt.
- Thermal suitability and lagged NCR-neighbor forecasting were not implemented/tested. They are not reported as successful or zero-effect ablations.
- Population provenance, missing-day semantics and historical boundary harmonization remain unresolved. Geographic correlations use n=17, mixed vintages and an unverified denominator; no causal conclusion is justified. Recent weather does not make the 2023 disease observations current.
- Human usability/SUS and a clinician-reviewed response protocol: NOT VERIFIED. Templates remain blank; no invented participants or scores.
- UI number provenance is complete as an occurrence/file-level ledger, not a certified exact scalar mapping. Ambiguous derivations, SVG ticks, static legal/medical constants and omitted plotted arrays remain explicitly NOT VERIFIED. The UI's saved “full-row verification / matched” confidence badge is a snapshot claim, not a fresh hosted database comparison.
- “Community reports: opening soon” is UI copy, not evidence of a scheduled launch. Four-week model gains remain exploratory; the production baseline was not promoted to a weather model.
- The config/ directory contains areas.json and is copied. Additional configuration is copied from vite.config.ts, vercel.json, tsconfig.json, supabase/config.toml and the CI/test configs. Public JSON endpoints are static exports, not HTTP server route handlers; server-side reporting/moderation/retention behavior is in SQL RPCs.
- Full per-origin model arrays and the redundant 7.34MB full demo snapshot are not duplicated under the size limit. All model summary rows and first-five data profiles are included; relevant rendered data extracts preserve hashes and scope. Full source/cache recreation is required for an independent scientific reanalysis.
- This is a redacted review payload, not an executable credentialed checkout. Literal role markers and even synthetic credential fixtures may be masked by the requested scan. Redactions and byte-splitting exceptions are explicitly recorded.

## Fresh TODO/FIXME search (exact output)

```text
COMMAND: ["rg", "-n", "--glob", "*.ts", "--glob", "*.tsx", "--glob", "*.mjs", "--glob", "*.sql", "TODO|FIXME", "src", "scripts", "tests", "supabase"]
START UTC: 2026-10-25T03:56:56.045921+00:00
EXIT CODE: 0
DURATION SECONDS: 0.030
STDOUT
supabase\migrations\20260923000100_surveillance.sql:39:  source_citation text not null default 'TODO: exact DOH/FOI dataset citation',

scripts\lib\historical.ts:55:    source: SOURCES[type], source_citation: 'TODO: exact DOH/FOI dataset citation',


STDERR

```

## Size-limited omissions

The archived 6.13MB fallback recording is omitted (exact hash and byte length in OMISSIONS.json). Fresh 28-page UI screenshots and text replace it for review. The redundant full public demo snapshot, full origin arrays, complete NCR geometry/week export, full plotted backtest export and full area catalog are not duplicated; displayed-value extracts, source hashes, schema samples and full aggregate evaluation tables remain. Files over the per-file cap are split, with reconstruction instructions. The ZIP container is the requested transfer artifact; the 1.5MB cap applies to its individual payload members.
