# Three-page redesign status (2026-10-25)

Active work is on `feat/redesign`, based on latest main e9a3047. No redesign deployment is authorized by this branch alone. Every main push automatically deploys Vercel; review locally and inspect the preview before merging this schema/UI change near the defense.

Implemented: photographic Dashboard, local national outlook, coarse anonymous report flow and footer-linked About; optimized source-preserving AVIF/WebP; measured pixel contrast prebuild gate; explicit national crosswalk; strictly earlier-year rank validation; weather excluded after failed improvement gate; generated npm/Python credits; bilingual privacy and actual server receipt; a forward-only report-scope/rate-hash migration.

Local redesign gates are DONE: 77 unit/integration tests, 25 SQL checks plus one local authenticated UI flow, three consecutive 36-test UI runs, 10 production tests, three offline/PWA tests, 30 measured hero-text contrast targets, mobile Lighthouse 93.0/100 performance/accessibility, zero high/medium local passive ZAP alerts and zero npm audit findings. Evaluation reproduction checked 14 byte-identical outputs. Detailed commands, source/build commits, retained failures and verification limits: [redesign-checks.md](evidence/redesign-checks.md) and [redesign-status.json](evidence/redesign-status.json).

Release remains NEEDS OWNER: the secret audit reports zero current, 44 known historical and zero unexpected historical findings; rotation is deferred. No hosted deployment, successful live operation, participant collection, human usability or DPO approval is claimed. Older launch records below remain historical.

NEEDS OWNER: photo source/licence/written permission; team/school/contact fields in src/content/about.json; credential rotation; Supabase/Vercel deployment and hosted schedules/Auth/log-retention verification; validated reporting geography and population/catchment mapping; institutional DPO review before opening collection; actual usability sessions. No hosted writes or real participant records are used in this work.

---

> Publication update (2026-10-25, Asia/Manila): the owner explicitly requested publishing all committed work to main, overriding the earlier local-only instruction. Source and review bundle were pushed at 5a422d0. Earlier results below describe the pre-publication checkpoint. Credential rotation and hosted/human verification remain pending; publication does not establish deployment success or authorize reporting activation.

# Implementation status

Updated 2026-10-25T07:14:00.872864+00:00. Work is local on fix/launch. Main has not been merged or pushed; main pushes automatically deploy. The owner explicitly chose to defer credential rotation and continue locally. **The release is blocked.**

| Gate | Fresh local evidence | Status |
|---|---|---|
| Install, lint, types, geography, contrast, production build | npm ci; npm run lint; npm run typecheck; npm run test:geography (3); npm run test:contrast; npm run build: pass | DONE |
| Unit/integration | npm test: 72 passed, zero skipped | DONE |
| Fresh database | npm run db:verify: 24 SQL tests and 1 authenticated UI flow passed; all 11 forward migrations apply, migration ledger rerun is idempotent | DONE locally |
| Browser stability | npm run test:ui: 31 passed in each of ui-verified-1, ui-verified-2, ui-verified-3, sequential runs; baseline default and one-worker runs also passed 29/29 before fixes | DONE |
| Production and offline | npm run test:production: 5 passed; npm run test:pwa: 3 passed, including actual strict-CSP styles | DONE |
| Accessibility | Browser axe assertions: zero critical/serious issues, including signed staff workspace | DONE within tested routes |
| Dependency audit | npm audit --json: zero vulnerabilities | DONE |
| Shipped attribution/filler | npm run data:validate passed; full marker inventory retained | DONE |
| Evaluation and accuracy | npm run evaluate passed offline; evaluation, environmental evaluation and weekly outputs byte-identical; UI checks all 18 scenario/model/horizon MAE cells against saved output | DONE |
| Secret audit | npm run security:secrets: 0 current findings, 44 known historical blobs, 0 unexpected history findings; exit 1 because owner deferred rotation | NEEDS OWNER |
| Lighthouse mobile | Fresh 2026-10-25T07:11:46.373Z: performance 97, accessibility 100, best practices 96, SEO 100 | DONE |
| ZAP local passive baseline | Fresh 2026-10-25T07:12:50.741Z: 0 High/Medium, 2 lower alerts retained | DONE |
| Hosted verification and human approvals | No live connection, migration, reporting activation, deployed scan, usability or DPO approval claimed | NEEDS OWNER |

## Root-cause corrections

The reproduced production retry failure came from a cache-first service worker bypassing API interception: the captured network response was 200 instead of the intended 503. The same test passed when only service workers were blocked. Ordinary UI tests now block workers, while PWA tests retain them; the error/retry test asserts an actual visible accessible alert and retry. Health-URL readiness and retained failure traces/videos support diagnosis. A later navigation-status regression made external requests on the offline map; status lookup is now scoped to home/report/community, preserving the original no-network map assertion. The failed run is retained. The older copied-bundle failures were not reproduced in the canonical checkout; their historical cause remains unverified.

Forward migrations correct source citations without changing applied SQL, protect retention RPC execution, enforce AAL2 for current staff RPCs and legacy admin RLS. Staff sign-in performs real SDK MFA enrollment/challenge; hosted execution remains pending. Database policy drives public collection status and fails closed. Reports stay unverified, delayed, threshold-suppressed and separate from official observations and models. Local signed Auth/PostgREST fixtures use actual SQL and disposable synthetic records; they are clearly labeled and excluded from production builds.

The first passive ZAP run found a Medium inline-style CSP weakness. The CSP now disallows inline style attributes; production chart/style tests pass and the final passive scan has no High/Medium findings. No active or authenticated penetration test is claimed.

Manila case observations end 2023-12-02 and NCR ends 2021-01-10. These are historical research displays. Weather has its own status/date and unavailable fallback. Public charts default to complete-row scenario M; scenario Z assumes missing daily dates are zero only within coverage. The one-week forecast is last week's value; longer ridge comparisons are exploratory with wide uncertainty. Weather did not establish an operational improvement. Saved MAEs feed the visible accuracy table. Saved-checksum labels do not claim a fresh hosted full-row audit.

The retired activation command initially exceeded its unchanged five-second regression timeout because it imported database/forecast modules before rejecting the command. It now rejects before dynamically importing those modules. The original failed log and later passes are retained. No test or safeguard was skipped, deleted or weakened.

## NEEDS OWNER

1. Rotate the Supabase database password and affected server API keys in the dashboard. Privately update ignored .env.local, hosting environment variables and Actions secrets. Do not paste any values. Set CREDENTIALS_ROTATED=1 only after rotation. Configure the private exposure-guard secret using docs/ROTATE_CREDENTIALS.md.
2. Run `npm run credentials:verify`, `npm run security:secrets`, `npm run hosted:bootstrap`, then `npm run db:verify -- --hosted`. If verification requires pending migrations, bootstrap after rotation and repeat verification. The audit attestation is not proof of revoked hosted credentials.
3. Set BOOTSTRAP_ADMIN_EMAIL and BOOTSTRAP_ADMIN_PASSWORD privately; run `npm run hosted:admin`; remove the bootstrap password. Enroll/verify TOTP through the staff flow and exercise an actual hosted AAL2 login and authorized moderation. Local test JWTs are not hosted Auth proof.
4. Configure repository variables SUPABASE_URL and DEPLOYED_URL, protected retention server-key secret, the private exposure fingerprint secret, and CREDENTIALS_ROTATED. Manually run Community retention and ZAP baseline workflows; inspect successful current-code runs/artifacts. Verify pg_cron or the active hourly Actions fallback using `npm run db:verify -- --hosted`. A YAML schedule alone is not proof of execution.
5. Perform a real usability session and school/DPO review of consent, retention, withdrawal and institutional responsibility. Resolve original source retrieval dates, formal citation/redistribution terms, absence semantics and population attribution with source owners. No participants, approvals or source dates have been invented.
6. Test locally and self-review the auth/schema changes before merging near the defense. Re-run required release gates in the intended environment. Only after every gate passes, set `$env:LAUNCH_GATES_PASSED = '1'` and run `npm run hosted:bootstrap -- --enable-reporting`. Emergency closure: `npm run reports:off`. Do not enable collection merely to demonstrate a test.

Full numbered dashboard and command instructions: [ROTATE_CREDENTIALS.md](ROTATE_CREDENTIALS.md). All private configuration stays out of Git.
