# Aggregate data inventory and reconciliation

Fresh profiling output: 02_logs/data-profile-current.txt. Profiles read the original files in place without editing them. Every CSV/XLSX/JSON in data/raw and data/processed is covered in 03_data_profiles/INDEX.json, with byte hash, logical row counts, columns, per-column null counts, date ranges and full first five records for each logical table. HXL metadata is excluded from CSV data counts and reported explicitly. XLSX physical rows are not the 1,910 normalized daily records because six year blocks sit side by side.

|Original path|Logical tables and row counts|Full report|
|---|---|---|
|data/raw/Daily_Reported_Cases_of_Dengue_in_the_City_of_Manila_from_2018_to_2023.xlsx|{"worksheet_1":360}|03_data_profiles/data__raw__Daily_Reported_Cases_of_Dengue_in_the_City_of_Manila_from_2018_to_2023.xlsx.json|
|data/raw/Manila_weekly_MHD_2018_2023.csv|{"csv":308}|03_data_profiles/data__raw__Manila_weekly_MHD_2018_2023.csv.json|
|data/raw/doh-epi-dengue-data-2016-2021.csv|{"csv":32701}|03_data_profiles/data__raw__doh-epi-dengue-data-2016-2021.csv.json|
|data/raw/ncr_dengue_monthly_with_rates.csv|{"csv":1037}|03_data_profiles/data__raw__ncr_dengue_monthly_with_rates.csv.json|
|data/processed/audit.json|{"$.sourceFiles":3,"$.national.(scalar fields)":1,"$.audit.summaries":3,"$.audit.dailyYears":6,"$.audit.weeklyGaps":17,"$.audit.suspectRows":196,"$.daily.absentWithinCoverage":6,"$.daily.(scalar fields)":1,"$.suppliedWeekly.omittedFinalWeek.flags":3,"$.suppliedWeekly.omittedFinalWeek.(scalar fields)":1,"$.suppliedWeekly.(scalar fields)":1,"$.reconciliation.pairs":151,"$.reconciliation.(scalar fields)":1,"$.reconciliationZeroAssumed.pairs":156,"$.reconciliationZeroAssumed.(scalar fields)":1,"$.reconciliationCompleteRows.pairs":104,"$.reconciliationCompleteRows.(scalar fields)":1,"$.geo":8,"$.(scalar fields)":1}|03_data_profiles/data__processed__audit.json.json|
|data/processed/elevation_samples.json|{"$":2398}|03_data_profiles/data__processed__elevation_samples.json.json|
|data/processed/elevation_sources.json|{"$":24}|03_data_profiles/data__processed__elevation_sources.json.json|
|data/processed/environment_design.json|{"$.lags.Z.correlations":24,"$.lags.Z.window_correlations":4,"$.lags.Z.(scalar fields)":1,"$.lags.M.correlations":24,"$.lags.M.window_correlations":4,"$.lags.M.(scalar fields)":1,"$.comparison.(scalar fields)":1,"$.profile":24,"$.(scalar fields)":1}|03_data_profiles/data__processed__environment_design.json.json|
|data/processed/environment_evaluation.json|{"$.metadata.models":6,"$.metadata.(scalar fields)":1,"$.design.lags.Z.correlations":24,"$.design.lags.Z.window_correlations":4,"$.design.lags.Z.(scalar fields)":1,"$.design.lags.M.correlations":24,"$.design.lags.M.window_correlations":4,"$.design.lags.M.(scalar fields)":1,"$.design.comparison.(scalar fields)":1,"$.design.profile":24,"$.design.(scalar fields)":1,"$.summaries":288,"$.leads":12,"$.drivers":10,"$.exclusions.(scalar fields)":1,"$.evidence":8448,"$.(scalar fields)":1}|03_data_profiles/data__processed__environment_evaluation.json.json|
|data/processed/environment_weekly.json|{"$.rows":469,"$.(scalar fields)":1}|03_data_profiles/data__processed__environment_weekly.json.json|
|data/processed/evaluation.json|{"$.metadata.horizons":3,"$.metadata.limitations":9,"$.metadata.(scalar fields)":1,"$.selection":2,"$.summaries":756,"$.exclusions.(scalar fields)":1,"$.latest":24,"$.evidence":21332,"$.episode_leads":32,"$.drivers":8}|03_data_profiles/data__processed__evaluation.json.json|
|data/processed/geographic_context.json|{"$.metadata.(scalar fields)":1,"$.rows":17,"$.correlations":6,"$.source.(scalar fields)":1,"$.(scalar fields)":1}|03_data_profiles/data__processed__geographic_context.json.json|
|data/processed/manila_weekly.json|{"$.scenarios.Z":413,"$.scenarios.M":413,"$.(scalar fields)":1}|03_data_profiles/data__processed__manila_weekly.json.json|
|data/processed/measurements.json|{"$.national.(scalar fields)":1,"$.ncr_yearly":6,"$.autocorrelations":10,"$.baselines_2023":6,"$.(scalar fields)":1}|03_data_profiles/data__processed__measurements.json.json|
|data/processed/ncr_population.json|{"$":17}|03_data_profiles/data__processed__ncr_population.json.json|
|data/processed/ncr_weekly.json|{"$":4403}|03_data_profiles/data__processed__ncr_weekly.json.json|
|data/processed/osm-water-source.json|{"$.(scalar fields)":1}|03_data_profiles/data__processed__osm-water-source.json.json|
|data/processed/power_daily.json|{"$.provenance.(scalar fields)":1,"$.units.PRECTOTCORR.(scalar fields)":1,"$.units.T2M.(scalar fields)":1,"$.units.RH2M.(scalar fields)":1,"$.rows":3287,"$.(scalar fields)":1}|03_data_profiles/data__processed__power_daily.json.json|
|data/processed/weather_weekly.json|{"$.coordinates.(scalar fields)":1,"$.provenance":9,"$.rows":469,"$.(scalar fields)":1}|03_data_profiles/data__processed__weather_weekly.json.json|

## Both absent-day scenarios

|Scenario|Weekly audit rows|Non-null target weeks|Reliable/scorable weeks|Sum of non-null cases|Sum of reliable cases|
|---|---:|---:|---:|---:|---:|
|Z|413|406|406|19408|19408|
|M|413|312|312|18290|18290|

Z fills absent dates with zero only inside the daily-source coverage; this is an unconfirmed assumption. M keeps absence missing and excludes daily-derived weeks with fewer than seven dates having rows. Missing DOH weeks remain missing in both. Partial final daily week is retained in audit flags, excluded from scoring. Sums are scenario-specific scorable-series quantities, not duplicate source totals to add together.

## Exact stitch rule

DOH EPI weekly labels supply Manila before 2018-01-01 (2016-2017). Daily-derived Monday-Sunday weeks supply 2018 onward; first new-source ending is 2018-01-07. Join date 2018-01-01. DOH 2018-January2021 is a cross-check/alternate-source sensitivity, not added to the daily series. Sunday labeling of DOH weeks remains an operational, unconfirmed interpretation. See 05_key_source/scripts/lib/manila-data.ts and 05_key_source/scripts/prepare-manila.ts.

## Reconciliation from current processed audit

```json
{
  "duplicateWeeklyPresent": false,
  "reconciliation": {
    "n": 151,
    "dailyTotal": 8255,
    "dohTotal": 8234,
    "mae": 13.596026490066226,
    "maxDifference": 78,
    "correlation": 0.9271184433081288,
    "pairs": [
      {
        "date": "2018-01-07",
        "daily": 60,
        "doh": 69
      },
      {
        "date": "2018-01-14",
        "daily": 72,
        "doh": 52
      },
      {
        "date": "2018-01-21",
        "daily": 84,
        "doh": 79
      },
      {
        "date": "2018-01-28",
        "daily": 62,
        "doh": 73
      },
      {
        "date": "2018-02-04",
        "daily": 82,
        "doh": 67
      },
      {
        "date": "2018-02-11",
        "daily": 63,
        "doh": 84
      },
      {
        "date": "2018-02-18",
        "daily": 74,
        "doh": 67
      },
      {
        "date": "2018-02-25",
        "daily": 63,
        "doh": 72
      },
      {
        "date": "2018-03-04",
        "daily": 68,
        "doh": 63
      },
      {
        "date": "2018-03-11",
        "daily": 55,
        "doh": 29
      },
      {
        "date": "2018-03-18",
        "daily": 32,
        "doh": 41
      },
      {
        "date": "2018-03-25",
        "daily": 27,
        "doh": 24
      },
      {
        "date": "2018-04-01",
        "daily": 28,
        "doh": 29
      },
      {
        "date": "2018-04-08",
        "daily": 23,
        "doh": 30
      },
      {
        "date": "2018-04-15",
        "daily": 25,
        "doh": 20
      },
      {
        "date": "2018-04-22",
        "daily": 24,
        "doh": 24
      },
      {
        "date": "2018-04-29",
        "daily": 23,
        "doh": 27
      },
      {
        "date": "2018-05-06",
        "daily": 12,
        "doh": 24
      },
      {
        "date": "2018-05-13",
        "daily": 16,
        "doh": 9
      },
      {
        "date": "2018-05-20",
        "daily": 24,
        "doh": 18
      },
      {
        "date": "2018-05-27",
        "daily": 21,
        "doh": 26
      },
      {
        "date": "2018-06-03",
        "daily": 29,
        "doh": 15
      },
      {
        "date": "2018-06-10",
        "daily": 13,
        "doh": 30
      },
      {
        "date": "2018-06-17",
        "daily": 21,
        "doh": 10
      },
      {
        "date": "2018-06-24",
        "daily": 26,
        "doh": 24
      },
      {
        "date": "2018-07-01",
        "daily": 34,
        "doh": 29
      },
      {
        "date": "2018-07-08",
        "daily": 27,
        "doh": 26
      },
      {
        "date": "2018-07-15",
        "daily": 40,
        "doh": 38
      },
      {
        "date": "2018-07-22",
        "daily": 55,
        "doh": 47
      },
      {
        "date": "2018-07-29",
        "daily": 61,
        "doh": 53
      },
      {
        "date": "2018-08-05",
        "daily": 63,
        "doh": 61
      },
      {
        "date": "2018-08-12",
        "daily": 54,
        "doh": 58
      },
      {
        "date": "2018-08-19",
        "daily": 81,
        "doh": 68
      },
      {
        "date": "2018-08-26",
        "daily": 93,
        "doh": 79
      },
      {
        "date": "2018-09-02",
        "daily": 88,
        "doh": 98
      },
      {
        "date": "2018-09-09",
        "daily": 137,
        "doh": 99
      },
      {
        "date": "2018-09-16",
        "daily": 118,
        "doh": 129
      },
      {
        "date": "2018-09-23",
        "daily": 141,
        "doh": 122
      },
      {
        "date": "2018-09-30",
        "daily": 133,
        "doh": 151
      },
      {
        "date": "2018-10-07",
        "daily": 190,
        "doh": 159
      },
      {
        "date": "2018-10-14",
        "daily": 194,
        "doh": 189
      },
      {
        "date": "2018-10-21",
        "daily": 142,
        "doh": 179
      },
      {
        "date": "2018-10-28",
        "daily": 81,
        "doh": 104
      },
      {
        "date": "2018-11-04",
        "daily": 130,
        "doh": 119
      },
      {
        "date": "2018-11-11",
        "daily": 133,
        "doh": 128
      },
      {
        "date": "2018-11-18",
        "daily": 135,
        "doh": 137
      },
      {
        "date": "2018-11-25",
        "daily": 108,
        "doh": 118
      },
      {
        "date": "2018-12-02",
        "daily": 109,
        "doh": 95
      },
      {
        "date": "2018-12-09",
        "daily": 78,
        "doh": 101
      },
      {
        "date": "2018-12-16",
        "daily": 77,
        "doh": 75
      },
      {
        "date": "2018-12-23",
        "daily": 63,
        "doh": 72
      },
      {
        "date": "2018-12-30",
        "daily": 49,
        "doh": 80
      },
      {
        "date": "2019-01-13",
        "daily": 99,
        "doh": 55
      },
      {
        "date": "2019-01-20",
        "daily": 67,
        "doh": 99
      },
      {
        "date": "2019-01-27",
        "daily": 76,
        "doh": 91
      },
      {
        "date": "2019-02-03",
        "daily": 56,
        "doh": 75
      },
      {
        "date": "2019-02-10",
        "daily": 50,
        "doh": 64
      },
      {
        "date": "2019-02-17",
        "daily": 40,
        "doh": 55
      },
      {
        "date": "2019-02-24",
        "daily": 35,
        "doh": 40
      },
      {
        "date": "2019-03-03",
        "daily": 31,
        "doh": 34
      },
      {
        "date": "2019-03-10",
        "daily": 29,
        "doh": 34
      },
      {
        "date": "2019-03-17",
        "daily": 21,
        "doh": 31
      },
      {
        "date": "2019-03-24",
        "daily": 25,
        "doh": 27
      },
      {
        "date": "2019-03-31",
        "daily": 15,
        "doh": 21
      },
      {
        "date": "2019-04-07",
        "daily": 22,
        "doh": 20
      },
      {
        "date": "2019-04-14",
        "daily": 22,
        "doh": 19
      },
      {
        "date": "2019-04-21",
        "daily": 14,
        "doh": 23
      },
      {
        "date": "2019-04-28",
        "daily": 17,
        "doh": 1
      },
      {
        "date": "2019-05-05",
        "daily": 14,
        "doh": 17
      },
      {
        "date": "2019-05-12",
        "daily": 8,
        "doh": 17
      },
      {
        "date": "2019-05-19",
        "daily": 12,
        "doh": 10
      },
      {
        "date": "2019-05-26",
        "daily": 13,
        "doh": 5
      },
      {
        "date": "2019-06-02",
        "daily": 20,
        "doh": 10
      },
      {
        "date": "2019-06-09",
        "daily": 24,
        "doh": 12
      },
      {
        "date": "2019-06-16",
        "daily": 23,
        "doh": 28
      },
      {
        "date": "2019-06-23",
        "daily": 31,
        "doh": 18
      },
      {
        "date": "2019-06-30",
        "daily": 27,
        "doh": 28
      },
      {
        "date": "2019-07-07",
        "daily": 32,
        "doh": 32
      },
      {
        "date": "2019-07-14",
        "daily": 46,
        "doh": 25
      },
      {
        "date": "2019-07-21",
        "daily": 76,
        "doh": 41
      },
      {
        "date": "2019-07-28",
        "daily": 76,
        "doh": 55
      },
      {
        "date": "2019-08-04",
        "daily": 94,
        "doh": 75
      },
      {
        "date": "2019-08-11",
        "daily": 140,
        "doh": 76
      },
      {
        "date": "2019-08-18",
        "daily": 161,
        "doh": 114
      },
      {
        "date": "2019-08-25",
        "daily": 211,
        "doh": 144
      },
      {
        "date": "2019-09-01",
        "daily": 257,
        "doh": 179
      },
      {
        "date": "2019-09-08",
        "daily": 167,
        "doh": 240
      },
      {
        "date": "2019-09-15",
        "daily": 174,
        "doh": 211
      },
      {
        "date": "2019-09-22",
        "daily": 173,
        "doh": 196
      },
      {
        "date": "2019-09-29",
        "daily": 157,
        "doh": 171
      },
      {
        "date": "2019-10-06",
        "daily": 146,
        "doh": 178
      },
      {
        "date": "2019-10-13",
        "daily": 174,
        "doh": 135
      },
      {
        "date": "2019-10-20",
        "daily": 131,
        "doh": 163
      },
      {
        "date": "2019-10-27",
        "daily": 133,
        "doh": 163
      },
      {
        "date": "2019-11-03",
        "daily": 121,
        "doh": 128
      },
      {
        "date": "2019-11-10",
        "daily": 146,
        "doh": 108
      },
      {
        "date": "2019-11-17",
        "daily": 83,
        "doh": 143
      },
      {
        "date": "2019-11-24",
        "daily": 94,
        "doh": 123
      },
      {
        "date": "2019-12-01",
        "daily": 98,
        "doh": 85
      },
      {
        "date": "2019-12-08",
        "daily": 74,
        "doh": 101
      },
      {
        "date": "2019-12-15",
        "daily": 74,
        "doh": 74
      },
      {
        "date": "2019-12-22",
        "daily": 32,
        "doh": 61
      },
      {
        "date": "2019-12-29",
        "daily": 24,
        "doh": 46
      },
      {
        "date": "2020-01-05",
        "daily": 62,
        "doh": 11
      },
      {
        "date": "2020-01-12",
        "daily": 85,
        "doh": 53
      },
      {
        "date": "2020-01-19",
        "daily": 59,
        "doh": 92
      },
      {
        "date": "2020-01-26",
        "daily": 41,
        "doh": 63
      },
      {
        "date": "2020-02-02",
        "daily": 49,
        "doh": 46
      },
      {
        "date": "2020-02-09",
        "daily": 42,
        "doh": 49
      },
      {
        "date": "2020-02-16",
        "daily": 38,
        "doh": 43
      },
      {
        "date": "2020-02-23",
        "daily": 31,
        "doh": 40
      },
      {
        "date": "2020-03-01",
        "daily": 26,
        "doh": 32
      },
      {
        "date": "2020-03-08",
        "daily": 25,
        "doh": 30
      },
      {
        "date": "2020-03-15",
        "daily": 11,
        "doh": 27
      },
      {
        "date": "2020-03-22",
        "daily": 7,
        "doh": 16
      },
      {
        "date": "2020-03-29",
        "daily": 4,
        "doh": 8
      },
      {
        "date": "2020-04-05",
        "daily": 2,
        "doh": 5
      },
      {
        "date": "2020-04-26",
        "daily": 1,
        "doh": 0
      },
      {
        "date": "2020-05-03",
        "daily": 1,
        "doh": 1
      },
      {
        "date": "2020-05-10",
        "daily": 1,
        "doh": 0
      },
      {
        "date": "2020-05-17",
        "daily": 2,
        "doh": 2
      },
      {
        "date": "2020-05-24",
        "daily": 1,
        "doh": 1
      },
      {
        "date": "2020-05-31",
        "daily": 1,
        "doh": 0
      },
      {
        "date": "2020-06-07",
        "daily": 1,
        "doh": 2
      },
      {
        "date": "2020-06-14",
        "daily": 3,
        "doh": 0
      },
      {
        "date": "2020-06-21",
        "daily": 1,
        "doh": 4
      },
      {
        "date": "2020-07-12",
        "daily": 3,
        "doh": 0
      },
      {
        "date": "2020-07-19",
        "daily": 1,
        "doh": 1
      },
      {
        "date": "2020-07-26",
        "daily": 1,
        "doh": 2
      },
      {
        "date": "2020-08-09",
        "daily": 3,
        "doh": 1
      },
      {
        "date": "2020-08-16",
        "daily": 1,
        "doh": 1
      },
      {
        "date": "2020-08-23",
        "daily": 4,
        "doh": 4
      },
      {
        "date": "2020-08-30",
        "daily": 1,
        "doh": 0
      },
      {
        "date": "2020-09-06",
        "daily": 5,
        "doh": 0
      },
      {
        "date": "2020-09-13",
        "daily": 6,
        "doh": 4
      },
      {
        "date": "2020-09-20",
        "daily": 6,
        "doh": 0
      },
      {
        "date": "2020-09-27",
        "daily": 1,
        "doh": 7
      },
      {
        "date": "2020-10-04",
        "daily": 4,
        "doh": 0
      },
      {
        "date": "2020-10-11",
        "daily": 11,
        "doh": 1
      },
      {
        "date": "2020-10-18",
        "daily": 12,
        "doh": 0
      },
      {
        "date": "2020-10-25",
        "daily": 11,
        "doh": 16
      },
      {
        "date": "2020-11-01",
        "daily": 12,
        "doh": 0
      },
      {
        "date": "2020-11-08",
        "daily": 6,
        "doh": 19
      },
      {
        "date": "2020-11-22",
        "daily": 25,
        "doh": 7
      },
      {
        "date": "2020-11-29",
        "daily": 17,
        "doh": 15
      },
      {
        "date": "2020-12-06",
        "daily": 15,
        "doh": 21
      },
      {
        "date": "2020-12-13",
        "daily": 15,
        "doh": 17
      },
      {
        "date": "2020-12-20",
        "daily": 17,
        "doh": 19
      },
      {
        "date": "2020-12-27",
        "daily": 16,
        "doh": 19
      },
      {
        "date": "2021-01-03",
        "daily": 17,
        "doh": 21
      },
      {
        "date": "2021-01-10",
        "daily": 25,
        "doh": 13
      }
    ]
  },
  "reconciliationZeroAssumed": {
    "n": 156,
    "dailyTotal": 8255,
    "dohTotal": 8244,
    "mae": 13.224358974358974,
    "maxDifference": 78,
    "correlation": 0.9293662488094924,
    "pairs": [
      {
        "date": "2018-01-07",
        "daily": 60,
        "doh": 69
      },
      {
        "date": "2018-01-14",
        "daily": 72,
        "doh": 52
      },
      {
        "date": "2018-01-21",
        "daily": 84,
        "doh": 79
      },
      {
        "date": "2018-01-28",
        "daily": 62,
        "doh": 73
      },
      {
        "date": "2018-02-04",
        "daily": 82,
        "doh": 67
      },
      {
        "date": "2018-02-11",
        "daily": 63,
        "doh": 84
      },
      {
        "date": "2018-02-18",
        "daily": 74,
        "doh": 67
      },
      {
        "date": "2018-02-25",
        "daily": 63,
        "doh": 72
      },
      {
        "date": "2018-03-04",
        "daily": 68,
        "doh": 63
      },
      {
        "date": "2018-03-11",
        "daily": 55,
        "doh": 29
      },
      {
        "date": "2018-03-18",
        "daily": 32,
        "doh": 41
      },
      {
        "date": "2018-03-25",
        "daily": 27,
        "doh": 24
      },
      {
        "date": "2018-04-01",
        "daily": 28,
        "doh": 29
      },
      {
        "date": "2018-04-08",
        "daily": 23,
        "doh": 30
      },
      {
        "date": "2018-04-15",
        "daily": 25,
        "doh": 20
      },
      {
        "date": "2018-04-22",
        "daily": 24,
        "doh": 24
      },
      {
        "date": "2018-04-29",
        "daily": 23,
        "doh": 27
      },
      {
        "date": "2018-05-06",
        "daily": 12,
        "doh": 24
      },
      {
        "date": "2018-05-13",
        "daily": 16,
        "doh": 9
      },
      {
        "date": "2018-05-20",
        "daily": 24,
        "doh": 18
      },
      {
        "date": "2018-05-27",
        "daily": 21,
        "doh": 26
      },
      {
        "date": "2018-06-03",
        "daily": 29,
        "doh": 15
      },
      {
        "date": "2018-06-10",
        "daily": 13,
        "doh": 30
      },
      {
        "date": "2018-06-17",
        "daily": 21,
        "doh": 10
      },
      {
        "date": "2018-06-24",
        "daily": 26,
        "doh": 24
      },
      {
        "date": "2018-07-01",
        "daily": 34,
        "doh": 29
      },
      {
        "date": "2018-07-08",
        "daily": 27,
        "doh": 26
      },
      {
        "date": "2018-07-15",
        "daily": 40,
        "doh": 38
      },
      {
        "date": "2018-07-22",
        "daily": 55,
        "doh": 47
      },
      {
        "date": "2018-07-29",
        "daily": 61,
        "doh": 53
      },
      {
        "date": "2018-08-05",
        "daily": 63,
        "doh": 61
      },
      {
        "date": "2018-08-12",
        "daily": 54,
        "doh": 58
      },
      {
        "date": "2018-08-19",
        "daily": 81,
        "doh": 68
      },
      {
        "date": "2018-08-26",
        "daily": 93,
        "doh": 79
      },
      {
        "date": "2018-09-02",
        "daily": 88,
        "doh": 98
      },
      {
        "date": "2018-09-09",
        "daily": 137,
        "doh": 99
      },
      {
        "date": "2018-09-16",
        "daily": 118,
        "doh": 129
      },
      {
        "date": "2018-09-23",
        "daily": 141,
        "doh": 122
      },
      {
        "date": "2018-09-30",
        "daily": 133,
        "doh": 151
      },
      {
        "date": "2018-10-07",
        "daily": 190,
        "doh": 159
      },
      {
        "date": "2018-10-14",
        "daily": 194,
        "doh": 189
      },
      {
        "date": "2018-10-21",
        "daily": 142,
        "doh": 179
      },
      {
        "date": "2018-10-28",
        "daily": 81,
        "doh": 104
      },
      {
        "date": "2018-11-04",
        "daily": 130,
        "doh": 119
      },
      {
        "date": "2018-11-11",
        "daily": 133,
        "doh": 128
      },
      {
        "date": "2018-11-18",
        "daily": 135,
        "doh": 137
      },
      {
        "date": "2018-11-25",
        "daily": 108,
        "doh": 118
      },
      {
        "date": "2018-12-02",
        "daily": 109,
        "doh": 95
      },
      {
        "date": "2018-12-09",
        "daily": 78,
        "doh": 101
      },
      {
        "date": "2018-12-16",
        "daily": 77,
        "doh": 75
      },
      {
        "date": "2018-12-23",
        "daily": 63,
        "doh": 72
      },
      {
        "date": "2018-12-30",
        "daily": 49,
        "doh": 80
      },
      {
        "date": "2019-01-13",
        "daily": 99,
        "doh": 55
      },
      {
        "date": "2019-01-20",
        "daily": 67,
        "doh": 99
      },
      {
        "date": "2019-01-27",
        "daily": 76,
        "doh": 91
      },
      {
        "date": "2019-02-03",
        "daily": 56,
        "doh": 75
      },
      {
        "date": "2019-02-10",
        "daily": 50,
        "doh": 64
      },
      {
        "date": "2019-02-17",
        "daily": 40,
        "doh": 55
      },
      {
        "date": "2019-02-24",
        "daily": 35,
        "doh": 40
      },
      {
        "date": "2019-03-03",
        "daily": 31,
        "doh": 34
      },
      {
        "date": "2019-03-10",
        "daily": 29,
        "doh": 34
      },
      {
        "date": "2019-03-17",
        "daily": 21,
        "doh": 31
      },
      {
        "date": "2019-03-24",
        "daily": 25,
        "doh": 27
      },
      {
        "date": "2019-03-31",
        "daily": 15,
        "doh": 21
      },
      {
        "date": "2019-04-07",
        "daily": 22,
        "doh": 20
      },
      {
        "date": "2019-04-14",
        "daily": 22,
        "doh": 19
      },
      {
        "date": "2019-04-21",
        "daily": 14,
        "doh": 23
      },
      {
        "date": "2019-04-28",
        "daily": 17,
        "doh": 1
      },
      {
        "date": "2019-05-05",
        "daily": 14,
        "doh": 17
      },
      {
        "date": "2019-05-12",
        "daily": 8,
        "doh": 17
      },
      {
        "date": "2019-05-19",
        "daily": 12,
        "doh": 10
      },
      {
        "date": "2019-05-26",
        "daily": 13,
        "doh": 5
      },
      {
        "date": "2019-06-02",
        "daily": 20,
        "doh": 10
      },
      {
        "date": "2019-06-09",
        "daily": 24,
        "doh": 12
      },
      {
        "date": "2019-06-16",
        "daily": 23,
        "doh": 28
      },
      {
        "date": "2019-06-23",
        "daily": 31,
        "doh": 18
      },
      {
        "date": "2019-06-30",
        "daily": 27,
        "doh": 28
      },
      {
        "date": "2019-07-07",
        "daily": 32,
        "doh": 32
      },
      {
        "date": "2019-07-14",
        "daily": 46,
        "doh": 25
      },
      {
        "date": "2019-07-21",
        "daily": 76,
        "doh": 41
      },
      {
        "date": "2019-07-28",
        "daily": 76,
        "doh": 55
      },
      {
        "date": "2019-08-04",
        "daily": 94,
        "doh": 75
      },
      {
        "date": "2019-08-11",
        "daily": 140,
        "doh": 76
      },
      {
        "date": "2019-08-18",
        "daily": 161,
        "doh": 114
      },
      {
        "date": "2019-08-25",
        "daily": 211,
        "doh": 144
      },
      {
        "date": "2019-09-01",
        "daily": 257,
        "doh": 179
      },
      {
        "date": "2019-09-08",
        "daily": 167,
        "doh": 240
      },
      {
        "date": "2019-09-15",
        "daily": 174,
        "doh": 211
      },
      {
        "date": "2019-09-22",
        "daily": 173,
        "doh": 196
      },
      {
        "date": "2019-09-29",
        "daily": 157,
        "doh": 171
      },
      {
        "date": "2019-10-06",
        "daily": 146,
        "doh": 178
      },
      {
        "date": "2019-10-13",
        "daily": 174,
        "doh": 135
      },
      {
        "date": "2019-10-20",
        "daily": 131,
        "doh": 163
      },
      {
        "date": "2019-10-27",
        "daily": 133,
        "doh": 163
      },
      {
        "date": "2019-11-03",
        "daily": 121,
        "doh": 128
      },
      {
        "date": "2019-11-10",
        "daily": 146,
        "doh": 108
      },
      {
        "date": "2019-11-17",
        "daily": 83,
        "doh": 143
      },
      {
        "date": "2019-11-24",
        "daily": 94,
        "doh": 123
      },
      {
        "date": "2019-12-01",
        "daily": 98,
        "doh": 85
      },
      {
        "date": "2019-12-08",
        "daily": 74,
        "doh": 101
      },
      {
        "date": "2019-12-15",
        "daily": 74,
        "doh": 74
      },
      {
        "date": "2019-12-22",
        "daily": 32,
        "doh": 61
      },
      {
        "date": "2019-12-29",
        "daily": 24,
        "doh": 46
      },
      {
        "date": "2020-01-05",
        "daily": 62,
        "doh": 11
      },
      {
        "date": "2020-01-12",
        "daily": 85,
        "doh": 53
      },
      {
        "date": "2020-01-19",
        "daily": 59,
        "doh": 92
      },
      {
        "date": "2020-01-26",
        "daily": 41,
        "doh": 63
      },
      {
        "date": "2020-02-02",
        "daily": 49,
        "doh": 46
      },
      {
        "date": "2020-02-09",
        "daily": 42,
        "doh": 49
      },
      {
        "date": "2020-02-16",
        "daily": 38,
        "doh": 43
      },
      {
        "date": "2020-02-23",
        "daily": 31,
        "doh": 40
      },
      {
        "date": "2020-03-01",
        "daily": 26,
        "doh": 32
      },
      {
        "date": "2020-03-08",
        "daily": 25,
        "doh": 30
      },
      {
        "date": "2020-03-15",
        "daily": 11,
        "doh": 27
      },
      {
        "date": "2020-03-22",
        "daily": 7,
        "doh": 16
      },
      {
        "date": "2020-03-29",
        "daily": 4,
        "doh": 8
      },
      {
        "date": "2020-04-05",
        "daily": 2,
        "doh": 5
      },
      {
        "date": "2020-04-12",
        "daily": 0,
        "doh": 5
      },
      {
        "date": "2020-04-19",
        "daily": 0,
        "doh": 2
      },
      {
        "date": "2020-04-26",
        "daily": 1,
        "doh": 0
      },
      {
        "date": "2020-05-03",
        "daily": 1,
        "doh": 1
      },
      {
        "date": "2020-05-10",
        "daily": 1,
        "doh": 0
      },
      {
        "date": "2020-05-17",
        "daily": 2,
        "doh": 2
      },
      {
        "date": "2020-05-24",
        "daily": 1,
        "doh": 1
      },
      {
        "date": "2020-05-31",
        "daily": 1,
        "doh": 0
      },
      {
        "date": "2020-06-07",
        "daily": 1,
        "doh": 2
      },
      {
        "date": "2020-06-14",
        "daily": 3,
        "doh": 0
      },
      {
        "date": "2020-06-21",
        "daily": 1,
        "doh": 4
      },
      {
        "date": "2020-06-28",
        "daily": 0,
        "doh": 1
      },
      {
        "date": "2020-07-05",
        "daily": 0,
        "doh": 1
      },
      {
        "date": "2020-07-12",
        "daily": 3,
        "doh": 0
      },
      {
        "date": "2020-07-19",
        "daily": 1,
        "doh": 1
      },
      {
        "date": "2020-07-26",
        "daily": 1,
        "doh": 2
      },
      {
        "date": "2020-08-02",
        "daily": 0,
        "doh": 1
      },
      {
        "date": "2020-08-09",
        "daily": 3,
        "doh": 1
      },
      {
        "date": "2020-08-16",
        "daily": 1,
        "doh": 1
      },
      {
        "date": "2020-08-23",
        "daily": 4,
        "doh": 4
      },
      {
        "date": "2020-08-30",
        "daily": 1,
        "doh": 0
      },
      {
        "date": "2020-09-06",
        "daily": 5,
        "doh": 0
      },
      {
        "date": "2020-09-13",
        "daily": 6,
        "doh": 4
      },
      {
        "date": "2020-09-20",
        "daily": 6,
        "doh": 0
      },
      {
        "date": "2020-09-27",
        "daily": 1,
        "doh": 7
      },
      {
        "date": "2020-10-04",
        "daily": 4,
        "doh": 0
      },
      {
        "date": "2020-10-11",
        "daily": 11,
        "doh": 1
      },
      {
        "date": "2020-10-18",
        "daily": 12,
        "doh": 0
      },
      {
        "date": "2020-10-25",
        "daily": 11,
        "doh": 16
      },
      {
        "date": "2020-11-01",
        "daily": 12,
        "doh": 0
      },
      {
        "date": "2020-11-08",
        "daily": 6,
        "doh": 19
      },
      {
        "date": "2020-11-22",
        "daily": 25,
        "doh": 7
      },
      {
        "date": "2020-11-29",
        "daily": 17,
        "doh": 15
      },
      {
        "date": "2020-12-06",
        "daily": 15,
        "doh": 21
      },
      {
        "date": "2020-12-13",
        "daily": 15,
        "doh": 17
      },
      {
        "date": "2020-12-20",
        "daily": 17,
        "doh": 19
      },
      {
        "date": "2020-12-27",
        "daily": 16,
        "doh": 19
      },
      {
        "date": "2021-01-03",
        "daily": 17,
        "doh": 21
      },
      {
        "date": "2021-01-10",
        "daily": 25,
        "doh": 13
      }
    ]
  },
  "reconciliationCompleteRows": {
    "n": 104,
    "dailyTotal": 7767,
    "dohTotal": 7780,
    "mae": 17.201923076923077,
    "maxDifference": 78,
    "correlation": 0.8992807031258179,
    "pairs": [
      {
        "date": "2018-01-07",
        "daily": 60,
        "doh": 69
      },
      {
        "date": "2018-01-14",
        "daily": 72,
        "doh": 52
      },
      {
        "date": "2018-01-21",
        "daily": 84,
        "doh": 79
      },
      {
        "date": "2018-01-28",
        "daily": 62,
        "doh": 73
      },
      {
        "date": "2018-02-04",
        "daily": 82,
        "doh": 67
      },
      {
        "date": "2018-02-11",
        "daily": 63,
        "doh": 84
      },
      {
        "date": "2018-02-18",
        "daily": 74,
        "doh": 67
      },
      {
        "date": "2018-02-25",
        "daily": 63,
        "doh": 72
      },
      {
        "date": "2018-03-04",
        "daily": 68,
        "doh": 63
      },
      {
        "date": "2018-03-11",
        "daily": 55,
        "doh": 29
      },
      {
        "date": "2018-03-18",
        "daily": 32,
        "doh": 41
      },
      {
        "date": "2018-03-25",
        "daily": 27,
        "doh": 24
      },
      {
        "date": "2018-04-08",
        "daily": 23,
        "doh": 30
      },
      {
        "date": "2018-04-15",
        "daily": 25,
        "doh": 20
      },
      {
        "date": "2018-04-29",
        "daily": 23,
        "doh": 27
      },
      {
        "date": "2018-05-13",
        "daily": 16,
        "doh": 9
      },
      {
        "date": "2018-05-20",
        "daily": 24,
        "doh": 18
      },
      {
        "date": "2018-05-27",
        "daily": 21,
        "doh": 26
      },
      {
        "date": "2018-06-03",
        "daily": 29,
        "doh": 15
      },
      {
        "date": "2018-06-17",
        "daily": 21,
        "doh": 10
      },
      {
        "date": "2018-06-24",
        "daily": 26,
        "doh": 24
      },
      {
        "date": "2018-07-08",
        "daily": 27,
        "doh": 26
      },
      {
        "date": "2018-07-15",
        "daily": 40,
        "doh": 38
      },
      {
        "date": "2018-07-22",
        "daily": 55,
        "doh": 47
      },
      {
        "date": "2018-07-29",
        "daily": 61,
        "doh": 53
      },
      {
        "date": "2018-08-05",
        "daily": 63,
        "doh": 61
      },
      {
        "date": "2018-08-12",
        "daily": 54,
        "doh": 58
      },
      {
        "date": "2018-08-19",
        "daily": 81,
        "doh": 68
      },
      {
        "date": "2018-08-26",
        "daily": 93,
        "doh": 79
      },
      {
        "date": "2018-09-02",
        "daily": 88,
        "doh": 98
      },
      {
        "date": "2018-09-09",
        "daily": 137,
        "doh": 99
      },
      {
        "date": "2018-09-16",
        "daily": 118,
        "doh": 129
      },
      {
        "date": "2018-09-23",
        "daily": 141,
        "doh": 122
      },
      {
        "date": "2018-09-30",
        "daily": 133,
        "doh": 151
      },
      {
        "date": "2018-10-07",
        "daily": 190,
        "doh": 159
      },
      {
        "date": "2018-10-14",
        "daily": 194,
        "doh": 189
      },
      {
        "date": "2018-10-21",
        "daily": 142,
        "doh": 179
      },
      {
        "date": "2018-10-28",
        "daily": 81,
        "doh": 104
      },
      {
        "date": "2018-11-04",
        "daily": 130,
        "doh": 119
      },
      {
        "date": "2018-11-11",
        "daily": 133,
        "doh": 128
      },
      {
        "date": "2018-11-18",
        "daily": 135,
        "doh": 137
      },
      {
        "date": "2018-11-25",
        "daily": 108,
        "doh": 118
      },
      {
        "date": "2018-12-02",
        "daily": 109,
        "doh": 95
      },
      {
        "date": "2018-12-09",
        "daily": 78,
        "doh": 101
      },
      {
        "date": "2018-12-16",
        "daily": 77,
        "doh": 75
      },
      {
        "date": "2018-12-23",
        "daily": 63,
        "doh": 72
      },
      {
        "date": "2018-12-30",
        "daily": 49,
        "doh": 80
      },
      {
        "date": "2019-01-13",
        "daily": 99,
        "doh": 55
      },
      {
        "date": "2019-01-20",
        "daily": 67,
        "doh": 99
      },
      {
        "date": "2019-01-27",
        "daily": 76,
        "doh": 91
      },
      {
        "date": "2019-02-03",
        "daily": 56,
        "doh": 75
      },
      {
        "date": "2019-02-10",
        "daily": 50,
        "doh": 64
      },
      {
        "date": "2019-02-17",
        "daily": 40,
        "doh": 55
      },
      {
        "date": "2019-02-24",
        "daily": 35,
        "doh": 40
      },
      {
        "date": "2019-03-03",
        "daily": 31,
        "doh": 34
      },
      {
        "date": "2019-03-10",
        "daily": 29,
        "doh": 34
      },
      {
        "date": "2019-03-17",
        "daily": 21,
        "doh": 31
      },
      {
        "date": "2019-03-24",
        "daily": 25,
        "doh": 27
      },
      {
        "date": "2019-03-31",
        "daily": 15,
        "doh": 21
      },
      {
        "date": "2019-04-14",
        "daily": 22,
        "doh": 19
      },
      {
        "date": "2019-06-02",
        "daily": 20,
        "doh": 10
      },
      {
        "date": "2019-06-16",
        "daily": 23,
        "doh": 28
      },
      {
        "date": "2019-06-23",
        "daily": 31,
        "doh": 18
      },
      {
        "date": "2019-06-30",
        "daily": 27,
        "doh": 28
      },
      {
        "date": "2019-07-07",
        "daily": 32,
        "doh": 32
      },
      {
        "date": "2019-07-14",
        "daily": 46,
        "doh": 25
      },
      {
        "date": "2019-07-21",
        "daily": 76,
        "doh": 41
      },
      {
        "date": "2019-07-28",
        "daily": 76,
        "doh": 55
      },
      {
        "date": "2019-08-04",
        "daily": 94,
        "doh": 75
      },
      {
        "date": "2019-08-11",
        "daily": 140,
        "doh": 76
      },
      {
        "date": "2019-08-18",
        "daily": 161,
        "doh": 114
      },
      {
        "date": "2019-08-25",
        "daily": 211,
        "doh": 144
      },
      {
        "date": "2019-09-01",
        "daily": 257,
        "doh": 179
      },
      {
        "date": "2019-09-08",
        "daily": 167,
        "doh": 240
      },
      {
        "date": "2019-09-15",
        "daily": 174,
        "doh": 211
      },
      {
        "date": "2019-09-22",
        "daily": 173,
        "doh": 196
      },
      {
        "date": "2019-09-29",
        "daily": 157,
        "doh": 171
      },
      {
        "date": "2019-10-06",
        "daily": 146,
        "doh": 178
      },
      {
        "date": "2019-10-13",
        "daily": 174,
        "doh": 135
      },
      {
        "date": "2019-10-20",
        "daily": 131,
        "doh": 163
      },
      {
        "date": "2019-10-27",
        "daily": 133,
        "doh": 163
      },
      {
        "date": "2019-11-03",
        "daily": 121,
        "doh": 128
      },
      {
        "date": "2019-11-10",
        "daily": 146,
        "doh": 108
      },
      {
        "date": "2019-11-17",
        "daily": 83,
        "doh": 143
      },
      {
        "date": "2019-11-24",
        "daily": 94,
        "doh": 123
      },
      {
        "date": "2019-12-01",
        "daily": 98,
        "doh": 85
      },
      {
        "date": "2019-12-08",
        "daily": 74,
        "doh": 101
      },
      {
        "date": "2019-12-15",
        "daily": 74,
        "doh": 74
      },
      {
        "date": "2019-12-22",
        "daily": 32,
        "doh": 61
      },
      {
        "date": "2019-12-29",
        "daily": 24,
        "doh": 46
      },
      {
        "date": "2020-01-12",
        "daily": 85,
        "doh": 53
      },
      {
        "date": "2020-01-19",
        "daily": 59,
        "doh": 92
      },
      {
        "date": "2020-01-26",
        "daily": 41,
        "doh": 63
      },
      {
        "date": "2020-02-02",
        "daily": 49,
        "doh": 46
      },
      {
        "date": "2020-02-09",
        "daily": 42,
        "doh": 49
      },
      {
        "date": "2020-02-16",
        "daily": 38,
        "doh": 43
      },
      {
        "date": "2020-02-23",
        "daily": 31,
        "doh": 40
      },
      {
        "date": "2020-03-01",
        "daily": 26,
        "doh": 32
      },
      {
        "date": "2020-03-15",
        "daily": 11,
        "doh": 27
      },
      {
        "date": "2020-10-11",
        "daily": 11,
        "doh": 1
      },
      {
        "date": "2020-11-22",
        "daily": 25,
        "doh": 7
      },
      {
        "date": "2020-11-29",
        "daily": 17,
        "doh": 15
      },
      {
        "date": "2020-12-27",
        "daily": 16,
        "doh": 19
      },
      {
        "date": "2021-01-10",
        "daily": 25,
        "doh": 13
      }
    ]
  }
}
```

Observed-week, zero-assumed and complete-row overlap cohorts differ; their correlations and MAEs are not interchangeable. Independent scientific provenance of absent-day semantics is NOT VERIFIED. Fresh evaluator reproduced the original evaluation hashes; raw/processed profiles are current source snapshots.

Original validation report is copied to 03_validation_report.md. Its pre-existing text is not passed off as a freshly generated report; the isolated evaluation generates a fresh validation report separately at 03_validation_report_fresh.md.
