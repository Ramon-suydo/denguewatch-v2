import { execFileSync } from 'node:child_process';
import { writeFile } from 'node:fs/promises';
const python=execFileSync('python',['-c',"import platform,json,importlib.metadata as m;print(json.dumps({'python':platform.python_version(),'packages':{p:m.version(p) for p in ['numpy','scipy','matplotlib','shapely','pyproj']}}))"],{encoding:'utf8'});
const report={node:process.version,platform:process.platform,arch:process.arch,...JSON.parse(python)};await writeFile('.artifacts/launch/runtime.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
