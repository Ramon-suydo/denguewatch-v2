import { chromium,expect } from '@playwright/test';
import { mkdir,writeFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { resolve } from 'node:path';
import { reportingHarness } from '../../tests/support/reporting-harness';
const out=resolve('.artifacts/launch/ui-current');await mkdir(out,{recursive:true});
const browser=await chromium.launch({channel:'msedge',headless:true});
const routes=[['home','/','src/pages/EvidenceHome.tsx; public/api/v2/manila.json'],['trends','/trends','src/pages/EvidenceTrends.tsx; public/api/v2/manila.json'],['metro-history','/metro-manila','src/pages/MetroHistory.tsx; public/api/v2/ncr.json'],['prevention','/prevention','src/pages/Prevention.tsx; static medical copy NOT VERIFIED clinically'],['report','/report','src/pages/ReportV2.tsx; src/lib/signals.ts; DB policy unavailable in blocked-backend capture'],['community','/community','src/pages/CommunityReports.tsx; src/lib/signals.ts; no inferred groups'],['methodology','/methodology','src/pages/Methodology.tsx; public/api/v2/manila.json; public/api/v2/environment.json'],['privacy','/privacy','src/pages/Privacy.tsx; src/components/LegalDrafts.tsx; static copy'],['data-sources','/data-sources','src/pages/DataSources.tsx; public/demo-snapshot.json'],['terms','/terms','src/pages/Terms.tsx; src/components/LegalDrafts.tsx'],['legal','/legal','src/pages/Legal.tsx; src/components/LegalDrafts.tsx'],['admin-login','/admin','src/pages/Admin.tsx; signed-out gate'],['moderation-access-gate','/admin/moderation','src/pages/Admin.tsx; signed-out gate; no hosted login'],['upload-access-gate','/admin/uploads','src/pages/Admin.tsx; signed-out gate; no hosted login']];
const captures:any[]=[],texts:any[]=[];
async function redact(page:any){await page.evaluate(()=>{const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;while(n=walker.nextNode()){n.textContent=n.textContent?.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi,'[REDACTED]').replace(/(?:\+63[ -]?9\d{2}|09\d{2})[ -]?\d{3}[ -]?\d{4}/g,'[REDACTED]')??'';}});}
async function record(page:any,name:string,path:string,width:number,source:string,mode:string,detail=false){
 await page.evaluate(()=>document.fonts.ready);await redact(page);const file=name+'-'+width+'.jpg';await page.screenshot({path:out+'/'+file,type:'jpeg',quality:58,fullPage:false});
 captures.push({file,path,width,height:900,mode,utc:new Date().toISOString(),sensitive_text_redacted_before_capture:true});
 if(!detail){const content=await page.locator('body').innerText(),fields=await page.locator('[data-mae]').evaluateAll((cells:any[])=>cells.map(c=>({mae:c.getAttribute('data-mae'),model:c.closest('tr').getAttribute('data-model'),horizon:c.closest('tr').getAttribute('data-horizon')})));texts.push({file,path,width,source,mode,text:content,accuracy_fields:fields});}
}
for(const width of [360,1280]){
 const context=await browser.newContext({viewport:{width,height:900},serviceWorkers:'block',reducedMotion:'reduce'});
 await context.route('**/*',route=>['localhost','127.0.0.1'].includes(new URL(route.request().url()).hostname)?route.continue():route.abort());
 const page=await context.newPage();
 for(const [name,path,source] of routes){await page.goto('http://127.0.0.1:43142'+path);await expect(page.locator('h1')).toBeVisible({timeout:45000});await expect(page.locator('.loading-dot')).toHaveCount(0,{timeout:45000});if(path==='/data-sources')await expect(page.locator('.coverage-present').first()).toBeVisible();await record(page,name,path,width,source,'production preview; external backend blocked; hosted status NOT VERIFIED');}
 for(const [name,path,selector] of [['metro-map-detail','/metro-manila','main svg'],['trends-chart-detail','/trends','main svg'],['methodology-table-detail','/methodology','[aria-label="Forecast accuracy from saved evaluation"]'],['privacy-withdrawal-detail','/privacy','#withdraw']]){
  await page.goto('http://127.0.0.1:43142'+path);await expect(page.locator('.loading-dot')).toHaveCount(0,{timeout:45000});await page.locator(selector).first().scrollIntoViewIfNeeded();await record(page,name,path,width,'same source as base page','production preview detail',true);
 }
 await context.close();
}
// Authenticated screenshots are explicitly local synthetic test evidence, never hosted sessions.
const server=spawn(process.execPath,['node_modules/vite/bin/vite.js','--host','127.0.0.1','--port','43144','--strictPort'],{env:{...process.env,VITE_TEST_FIXTURES:'true',VITE_SUPABASE_URL:'https://denguewatch-tests.invalid',VITE_SUPABASE_ANON_KEY:'isolated-public-test-key'},stdio:'pipe'});
let serverOutput='';server.stdout?.on('data',x=>serverOutput+=x);server.stderr?.on('data',x=>serverOutput+=x);
try{
 const ready=Date.now()+120000;while(true){try{if((await fetch('http://127.0.0.1:43144/healthz.txt')).ok)break;}catch{}if(Date.now()>ready)throw Error('Local capture server not ready');await new Promise(r=>setTimeout(r,250));}
 const local=await reportingHarness('admin');
 try{
  await local.db.query("insert into public.community_signals(code_hash,onset_date,symptoms,note_text,consent_version,duplicate_hash) values(repeat('0',64),current_date,array['fever'],'LOCAL TEST DATA ONLY: synthetic interface fixture.','community-v2',repeat('0',64))");
  for(const width of [360,1280]){
   const context=await browser.newContext({viewport:{width,height:900},serviceWorkers:'block',reducedMotion:'reduce'}),page=await context.newPage();await local.attach(page);await page.goto('http://127.0.0.1:43144/admin');await page.getByLabel('Staff email').fill(local.email);await page.getByLabel('Password',{exact:true}).fill(local.password);await page.getByRole('button',{name:'Sign in',exact:true}).click();await expect(page.getByRole('heading',{name:'Moderation queue'})).toBeVisible({timeout:30000});
   await record(page,'moderation-local-test','/admin',width,'src/pages/Admin.tsx; tests/support/reporting-harness.ts; actual migrated SQL with synthetic row','LOCAL TEST DATA ONLY; signed local Auth adapter; hosted login/TOTP NOT VERIFIED');
   await page.getByRole('heading',{name:'CSV preview and versioned publication'}).scrollIntoViewIfNeeded();await record(page,'upload-local-test','/admin',width,'src/pages/Admin.tsx; disposable admin fixture; no uploaded source rows','LOCAL TEST DATA ONLY; no hosted upload',false);await context.close();
  }
 }finally{await local.close();}
}finally{server.kill();await writeFile(out+'/local-server-output.txt',serverOutput);await browser.close();}
await writeFile(out+'/capture_manifest.json',JSON.stringify(captures,null,2)+'\n');await writeFile(out+'/rendered_text.json',JSON.stringify(texts,null,2)+'\n');console.log(JSON.stringify({actual_captures:captures.length,rendered_pages:texts.length,source:'production preview and separately labeled disposable local-admin harness',no_hosted_login:true,no_real_community_records:true}));
