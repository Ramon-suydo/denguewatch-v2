import pathlib,json,re,hashlib,zipfile,io,datetime,shutil,collections
root=pathlib.Path.cwd().resolve();b=(root/'review_bundle').resolve();assert b.parent==root and b.name=='review_bundle';a=root/'.artifacts/launch'
def sha(v):return hashlib.sha256(v).hexdigest()
def dump(path,obj):p=b/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
fingerprints=set(json.loads((a/'exposure-fingerprints.json').read_text(encoding='utf-8')));private=[]
for name in ['.env','.env.local']:
 p=root/name
 if p.exists():
  for line in p.read_text(encoding='utf-8').splitlines():
   if '=' not in line or line.lstrip().startswith('#'):continue
   key,value=line.split('=',1);value=value.strip().strip('\"\'')
   if len(value)>=12 and re.search(r'PASSWORD|SECRET|TOKEN|DATABASE_URL|SERVICE_ROLE',key) and not key.startswith('VITE_'):private.append(value)
counts=collections.Counter();changes=[];nested=[]
patterns=[('jwt',r'eyJ[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+){1,2}'),('api-key',r'\b(?:sb_secret_[A-Za-z0-9_-]+|sk-[A-Za-z0-9_-]{15,}|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,}|(?:AKIA|ASIA)[A-Z0-9]{16})\b'),('privileged-role-marker',r'[REDACTED]'),('private-key',r'-----BEGIN (?:[A-Z ]+)?PRIVATE KEY-----[\s\S]*?-----END (?:[A-Z ]+)?PRIVATE KEY-----'),('credential-uri',r'postgres(?:ql)?://[^\s\"\'<>]+'),('email',r'[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}'),('phone',r'(?<!\d)(?:\+63[ -]?9\d{2}|09\d{2})[ -]?\d{3}[ -]?\d{4}(?!\d)'),('owner-identifier',r'[REDACTED](?:[ _]+[REDACTED])?|[REDACTED]|[REDACTED][REDACTED]'),('local-user-path',r'C:[/\\]+Users[/\\]+[^/\\\s\"\']+')]
compiled=[(name,re.compile(pat,re.I if name in ['email','owner-identifier','local-user-path'] else 0)) for name,pat in patterns]
def redtext(s):
 for value in private:
  n=s.count(value)
  if n:counts['configured-private-value']+=n;s=s.replace(value,'[REDACTED]')
 def fingerprint(m):
  if sha(m[0].encode()) in fingerprints:counts['known-exposure']+=1;return '[REDACTED]'
  return m[0]
 s=re.sub(r'[A-Za-z0-9_-]{8,}',fingerprint,s)
 for category,pattern in compiled:
  s,n=pattern.subn('[REDACTED]',s);counts[category]+=n
 return s
binary_suffixes={'.jpg','.jpeg','.png','.gif','.webp','.webm','.woff','.woff2','.ttf','.pdf','.ico'}
def sanitize(data,name,depth=0):
 if data.startswith(b'PK\x03\x04'):
  if depth>3:raise RuntimeError('Nested archive depth exceeded: '+name)
  out=io.BytesIO()
  with zipfile.ZipFile(io.BytesIO(data)) as source,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as target:
   for info in source.infolist():
    if info.is_dir():continue
    if prohibited(info.filename):raise RuntimeError('Prohibited nested path: '+name+'!'+info.filename)
    before=source.read(info);after=sanitize(before,name+'!'+info.filename,depth+1);target.writestr(info.filename,after)
    if before!=after:nested.append({'path':name+'!'+info.filename,'original_sha256':sha(before),'sanitized_sha256':sha(after)})
  return out.getvalue()
 if pathlib.Path(name).suffix.lower() in binary_suffixes or b'\x00' in data:
  # Binary files are byte-pattern checked; screenshots were redacted in the DOM before capture.
  for value in private:
   if value.encode() in data:raise RuntimeError('Private match in binary: '+name)
  for category,pattern in compiled:
   if category=='privileged-role-marker':continue
   if pattern.search(data.decode('latin1')):raise RuntimeError('Sensitive binary pattern in '+name+' ('+category+')')
  return data
 try:return redtext(data.decode('utf-8-sig')).encode('utf-8')
 except UnicodeDecodeError:return data

def prohibited(name):return any(x in ['.git','node_modules','certs','__pycache__'] for x in pathlib.PurePosixPath(name).parts) or any(x.startswith('.env') for x in pathlib.PurePosixPath(name).parts) or pathlib.PurePosixPath(name).name=='exposure-fingerprints.json'
for p in sorted(b.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(b).as_posix()
 if prohibited(rel):raise RuntimeError('Prohibited path: '+rel)
 before=p.read_bytes();after=sanitize(before,rel)
 if before!=after:p.write_bytes(after);changes.append({'path':rel,'original_sha256':sha(before),'sanitized_sha256':sha(after)})
# Source-copy integrity explicitly records transformed review copies.
p=b/'COPY_INTEGRITY.json';integrity=json.loads(p.read_text(encoding='utf-8'))
for row in integrity:
 q=b/row['bundle'];row['review_sha256']=sha(q.read_bytes());row['byte_identical_to_source']=row['review_sha256']==row['source_sha256']
dump('COPY_INTEGRITY.json',integrity)
dump('DOCUMENT_IDENTITY.json',[{'document':name,'original_sha256':sha((root/'docs'/name).read_bytes()),'review_sha256':sha((b/('04_'+name)).read_bytes()),'byte_identical':(root/'docs'/name).read_bytes()==(b/('04_'+name)).read_bytes()} for name in ['EVALUATION.md','ENVIRONMENT.md']])
# Split every oversized payload, preserving exact reconstructed bytes and a ledger.
splits=[]
for p in sorted(b.rglob('*')):
 if not p.is_file() or p.stat().st_size<1500000:continue
 rel=p.relative_to(b).as_posix();data=p.read_bytes();parts=[]
 if p.suffix=='.zip':raise RuntimeError('Trace container exceeded member cap: '+rel)
 if b'\x00' in data:raise RuntimeError('Oversized binary payload: '+rel)
 text=data.decode('utf-8');current='';chunks=[];size=0
 for line in text.splitlines(keepends=True):
  if len(line.encode())>1350000:
   if current:chunks.append(current);current='';size=0
   # UTF-8 text can be reconstructed exactly; not every part is independently parseable.
   for start in range(0,len(line),300000):chunks.append(line[start:start+300000])
  else:
   if size+len(line.encode())>1350000:chunks.append(current);current='';size=0
   current+=line;size+=len(line.encode())
 if current:chunks.append(current)
 for i,chunk in enumerate(chunks,1):
  q=p.with_name(p.name+'.part'+str(i).zfill(3)+'.txt');q.write_text(chunk,encoding='utf-8',newline='');parts.append({'path':q.relative_to(b).as_posix(),'bytes':q.stat().st_size,'sha256':sha(q.read_bytes())})
 assert b''.join((b/r['path']).read_bytes() for r in parts)==data
 p.unlink();splits.append({'logical_path':rel,'bytes':len(data),'sha256':sha(data),'reconstruction':'Concatenate listed parts as bytes in order; exact UTF-8 payload, including CSV header once. Parts need not independently parse.','parts':parts})
dump('SPLIT_FILES.json',splits)
dump('SANITIZATION_REPORT.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'categories':dict(counts),'changed_files':changes,'changed_nested_members':nested,'no_values_or_matching_snippets_recorded':True,'private_detection_state_excluded':True,'binary_scope':'Fresh UI DOM redaction before capture, visual sampling and byte-pattern scan; no claim of exhaustive OCR. Failure trace/video show public routes only.','post_redaction_scan':'All plain and nested text is checked again before archive creation.'})
(b/'REDACTION_NOTES.md').write_text('# Review-copy redaction\n\nCredentials, JWT-shaped strings, privileged-role markers, email/phone patterns, owner names and local user paths are replaced by [REDACTED]. Known-exposure fingerprints and private configuration are never included. Source copies may not run unchanged; use the Git branch for executable source. Actual command output is retained with mandatory redaction, including failures. Source/review hashes and changed-file categories are recorded without matched values.\n\nAll payloads are below 1,500,000 bytes; logical oversized text files are split with exact byte reconstruction in SPLIT_FILES.json. SHA256SUMS covers every payload except itself. The ZIP transfer container and external archive checksum are excluded from its own member list. Folder plus ZIP must be below 25,000,000 bytes. Archived recordings, full original source datasets, giant per-origin exports, credentials and dependency/build caches are omitted as disclosed.\n',encoding='utf-8')
dump('BUNDLE_STATUS.json',{'branch':'fix/launch','local_only':True,'main_pushed':False,'release_gate':'BLOCKED: owner deferred credential rotation; hosted/human verification pending','local_results':{'units':72,'db_sql':24,'db_ui':1,'three_ui_runs':[31,31,31],'production':5,'pwa':3},'source_commit':json.loads((b/'BUNDLE_SOURCE.json').read_text(encoding='utf-8'))['source_commit'],'see':'08_docs/LAUNCH_CHECKLIST.md'})
# Final text scan: do not print matches.
def inspect(data,name):
 if data.startswith(b'PK\x03\x04'):
  with zipfile.ZipFile(io.BytesIO(data)) as z:
   for n in z.namelist():
    if not n.endswith('/'):inspect(z.read(n),name+'!'+n)
 elif pathlib.Path(name).suffix.lower() not in binary_suffixes and b'\x00' not in data:
  try:s=data.decode('utf-8')
  except UnicodeDecodeError:return
  for value in private:
   if value in s:raise RuntimeError('Private configured value remains: '+name)
  for category,pat in compiled:
   if pat.search(s):raise RuntimeError('Sensitive text remains: '+name+' ('+category+')')
  for word in re.findall(r'[A-Za-z0-9_-]{8,}',s):
   if sha(word.encode()) in fingerprints:raise RuntimeError('Known exposure remains: '+name)
for p in sorted(b.rglob('*')):
 if p.is_file():inspect(p.read_bytes(),p.relative_to(b).as_posix())
# File list includes its own stable byte length and the fixed-width checksum file size.
files=sorted(p for p in b.rglob('*') if p.is_file());filelist=b/'FILE_LIST.txt';hashfile=b/'SHA256SUMS.txt'
for _ in range(6):
 files=sorted(p for p in b.rglob('*') if p.is_file());filelist.write_text('\n'.join(str(p.stat().st_size)+'\t'+p.relative_to(b).as_posix() for p in files)+'\n',encoding='utf-8');files=sorted(p for p in b.rglob('*') if p.is_file() and p!=hashfile);hashfile.write_text(''.join(sha(p.read_bytes())+'  '+p.relative_to(b).as_posix()+'\n' for p in files),encoding='utf-8')
# File list lists final sizes; recompute sums after list update.
files=sorted(p for p in b.rglob('*') if p.is_file());assert all(p.stat().st_size<1500000 for p in files)
for line in filelist.read_text(encoding='utf-8').splitlines():
 size,name=line.split('\t',1);assert (b/name).stat().st_size==int(size),(name,size,(b/name).stat().st_size)
for line in hashfile.read_text(encoding='utf-8').splitlines():
 digest,name=line.split('  ',1);assert sha((b/name).read_bytes())==digest,name
archive=b/'review_bundle.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,p.relative_to(b).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert len(z.infolist())==len(files)
 for info in z.infolist():
  assert info.file_size<1500000;assert z.read(info)==(b/info.filename).read_bytes();inspect(z.read(info),info.filename)
checksum=sha(archive.read_bytes());(b/'ARCHIVE_SHA256.txt').write_text(checksum+'  review_bundle.zip\n',encoding='utf-8');combined=sum(p.stat().st_size for p in b.rglob('*') if p.is_file());assert combined<25000000,combined
shutil.copy2(archive,root/'review_bundle.zip');(root/'review_bundle.zip.sha256').write_text(checksum+'  review_bundle.zip\n',encoding='utf-8')
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'members':len(files),'zip_bytes':archive.stat().st_size,'combined_folder_and_zip_bytes':combined,'largest_member_bytes':max(p.stat().st_size for p in files),'sha256':checksum,'nested_archives_scanned':True,'all_checksums_valid':True,'release_status':'BLOCKED / NEEDS OWNER'};(a/'bundle-validation.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,indent=2))
