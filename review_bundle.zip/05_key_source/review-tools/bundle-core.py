import pathlib,subprocess,json,csv,io,hashlib,re,datetime,platform,shutil,zipfile,xml.etree.ElementTree as ET,collections
root=pathlib.Path.cwd().resolve();b=(root/'review_bundle').resolve();logs=root/'.artifacts/launch'
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],text=True,encoding='utf-8').strip()
def dump(path,obj):p=b/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=str)+'\n',encoding='utf-8')
def text(path,s):p=b/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
def copy(source,target):p=b/target;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/source,p);return {'source':source,'bundle':target,'source_sha256':sha((root/source).read_bytes())}
assert b.parent==root and b.name=='review_bundle'
if b.exists():shutil.rmtree(b)
b.mkdir();now=datetime.datetime.now(datetime.timezone.utc).isoformat();head=git('rev-parse','HEAD');branch=git('branch','--show-current')
# Copy current source/docs only; no ignored credentials, raw records, packages or build outputs.
paths=set(git('ls-files').splitlines());paths.update(git('ls-files','--others','--exclude-standard').splitlines());manifest=[];omissions=[]
rootfiles={'package.json','package-lock.json','vite.config.ts','vercel.json','tsconfig.json','eslint.config.mjs','playwright.config.ts','playwright.production.config.ts','playwright.research.config.ts','requirements-environment.txt','requirements-plots.txt','LICENSE','README.md','SECURITY.md','CONTRIBUTING.md','AGENTS.md','.gitignore','public/healthz.txt'}
for name in sorted(paths):
 p=root/name
 if not p.is_file() or p.name.startswith('.env') or 'certs' in p.parts:continue
 if name.startswith('docs/'):
  if p.suffix.lower()=='.webm':omissions.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'reason':'Archived recording omitted under combined folder/archive budget; fresh current screenshots included.'});continue
  manifest.append(copy(name,'08_docs/'+name[5:]))
 elif name.startswith('supabase/migrations/') or name=='supabase/verification.sql':manifest.append(copy(name,'06_sql/'+name))
 elif name.startswith(('src/','scripts/','tests/','config/','.github/','.githooks/')) or name in rootfiles or name=='supabase/config.toml':manifest.append(copy(name,'05_key_source/'+name))
# Capture all actual command results including failures and attempts.
commands=[]
for p in sorted(logs.glob('*.txt')):
 raw=p.read_text(encoding='utf-8');text('02_logs/'+p.name,raw)
 try:meta,_=json.JSONDecoder().raw_decode(raw.lstrip());meta['log']='02_logs/'+p.name;commands.append(meta)
 except (json.JSONDecodeError,TypeError):pass
for name in ['zap-portable-setup.json','placeholder-inventory.json']:
 if (logs/name).exists():copy('.artifacts/launch/'+name,'02_logs/'+name)
for name in ['before-zap-local.html','before-zap-local.json','before-zap-local-summary.json']:
 if(logs/name).exists():copy('.artifacts/launch/'+name,'02_logs/'+name)
dump('COMMAND_MANIFEST.json',commands);dump('OMISSIONS.json',omissions);dump('COPY_INTEGRITY.json',manifest)
# Fresh structural data profiles. Original files are read in place, never copied into the bundle.
def normalize(v):
 if isinstance(v,(datetime.datetime,datetime.date)):return v.isoformat()
 return v
def profile(rows):
 rows=[r if isinstance(r,dict) else {'value':r} for r in rows];columns=list(dict.fromkeys(k for r in rows for k in r));dates={}
 for key in columns:
  values=[]
  if re.search(r'date|week|period|time|as_of|origin|target|YYYY',str(key),re.I):
   for r in rows:
    value=r.get(key)
    if isinstance(value,str):
     match=re.match(r'^(\d{4}-\d{2}-\d{2})(?:T|$)',value)
     if match:values.append(match[1])
     elif re.fullmatch(r'\d{1,2}/\d{1,2}/\d{4}',value):
      try:values.append(datetime.datetime.strptime(value,'%m/%d/%Y').date().isoformat())
      except ValueError:pass
  if values:dates[key]={'min':min(values),'max':max(values)}
 return {'rows':len(rows),'columns':columns,'null_counts':{k:sum(r.get(k) is None or r.get(k)=='' for r in rows) for k in columns},'date_ranges':dates,'first_5_rows':rows[:5]}
def json_tables(obj,path='$',out=None):
 if out is None:out={}
 if isinstance(obj,list):out[path]=profile(obj)
 elif isinstance(obj,dict):
  scalar={k:v for k,v in obj.items() if not isinstance(v,(dict,list))}
  if scalar:out[path+'.(scalar fields)']=profile([scalar])
  for key,value in obj.items():
   if isinstance(value,(dict,list)):json_tables(value,path+'.'+key,out)
 return out
def excel_tables(p):
 ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
 with zipfile.ZipFile(p) as z:
  strings=[]
  if 'xl/sharedStrings.xml' in z.namelist():strings=[''.join(si.itertext()) for si in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',ns)]
  tables={}
  for name in sorted(n for n in z.namelist() if re.fullmatch(r'xl/worksheets/sheet\d+\.xml',n)):
   physical=[]
   for row in ET.fromstring(z.read(name)).findall('.//m:sheetData/m:row',ns):
    values={}
    for cell in row.findall('m:c',ns):
     col=re.match('[A-Z]+',cell.attrib['r'])[0];position=0
     for ch in col:position=position*26+ord(ch)-64
     node=cell.find('m:v',ns);value=node.text if node is not None else None;kind=cell.attrib.get('t')
     if kind=='s' and value is not None:value=strings[int(value)]
     elif kind=='inlineStr':value=''.join(cell.find('m:is',ns).itertext())
     elif value is not None:
      try:value=float(value);value=int(value) if value.is_integer() else value
      except ValueError:pass
     values[position-1]=value
    if any(v is not None for v in values.values()):physical.append(values)
   width=max((max(r.keys(),default=-1) for r in physical),default=-1)+1;header=physical.pop(0)
   columns=[f'{header.get(i) or "blank"}__column_{i+1}' for i in range(width)];rows=[]
   for row in physical:
    result={}
    for i,key in enumerate(columns):
     value=row.get(i)
     if 'YYYY' in key and isinstance(value,(int,float)) and 40000<value<50000:value=(datetime.datetime(1899,12,30)+datetime.timedelta(days=value)).date().isoformat()
     result[key]=value
    rows.append(result)
   tables[name]=profile(rows)
  return tables
profiles=[]
for folder in ['data/raw','data/processed']:
 for p in sorted((root/folder).iterdir()):
  if not p.is_file() or p.suffix.lower() not in ['.csv','.json','.xlsx']:continue
  raw=p.read_bytes();report={'path':p.relative_to(root).as_posix(),'bytes':len(raw),'sha256':sha(raw),'profiled_utc':now}
  if p.suffix=='.json':report['tables']=json_tables(json.loads(raw))
  elif p.suffix=='.csv':
   rows=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))));hxl=[r for r in rows if any(str(v).startswith('#') for v in r.values())];rows=[r for r in rows if r not in hxl];report['excluded_hxl_metadata_rows']=len(hxl);report['tables']={'csv':profile(rows)}
  else:report['tables']=excel_tables(p);report['note']='Physical worksheet rows contain six side-by-side year blocks; not the normalized 1,910 daily observations.'
  name='03_data_profiles/'+p.relative_to(root).as_posix().replace('/','__')+'.json';dump(name,report);profiles.append({'path':report['path'],'profile':name,'sha256':report['sha256'],'tables':{k:v['rows'] for k,v in report['tables'].items()}})
dump('03_data_profiles/INDEX.json',profiles)
# Complete aggregate tables, nested confidence intervals and coefficient arrays included.
main=json.loads((root/'data/processed/evaluation.json').read_text(encoding='utf-8'));env=json.loads((root/'data/processed/environment_evaluation.json').read_text(encoding='utf-8'))
def flat(obj,prefix='',out=None):
 if out is None:out={}
 for key,value in obj.items():
  name=prefix+key
  if isinstance(value,dict):flat(value,name+'.',out)
  else:out[name]=json.dumps(value,ensure_ascii=False) if isinstance(value,list) else value
 return out
def table(name,rows):
 rows=[flat(r) for r in rows];fields=list(dict.fromkeys(k for row in rows for k in row));out=io.StringIO(newline='');w=csv.DictWriter(out,fieldnames=fields);w.writeheader();w.writerows(rows);text('04_tables/'+name+'.csv',out.getvalue());return len(rows)
counts={}
for label,data in [('main',main),('environment',env)]:
 for key,value in data.items():
  if isinstance(value,list) and key!='evidence' and value and all(isinstance(r,dict) for r in value):counts[label+'-'+key]=table(label+'-'+key,value)
 dump('04_tables/'+label+'-metadata.json',{k:v for k,v in data.items() if not isinstance(v,list)})
geo=json.loads((root/'data/processed/geographic_context.json').read_text(encoding='utf-8'));counts['city-context']=table('city-context',geo['rows']);counts['geographic-correlations']=table('geographic-correlations',geo['correlations'])
design=json.loads((root/'data/processed/environment_design.json').read_text(encoding='utf-8'));counts['monthly-profile']=table('monthly-profile',design['profile']);lagrows=[{'scenario':scenario,**row} for scenario,value in design['lags'].items() for row in value['correlations']];counts['lag-correlations']=table('lag-correlations',lagrows)
copy('docs/EVALUATION.md','04_EVALUATION.md');copy('docs/ENVIRONMENT.md','04_ENVIRONMENT.md')
# Verify exact main-table doc fields at published 3-decimal precision; qualify every other numeric line.
claims=[]
for name in ['EVALUATION.md','ENVIRONMENT.md']:
 for number,line in enumerate((root/'docs'/name).read_text(encoding='utf-8').splitlines(),1):
  if not re.search(r'\d',line):continue
  evidence='04_tables/'+('main-summaries.csv' if name=='EVALUATION.md' else 'environment-summaries.csv');verified=False;scope='NOT VERIFIED: exact narrative/source-line mapping not independently checked; inspect fresh complete tables and methods.'
  cells=[x.strip() for x in line.strip().strip('|').split('|')]
  if name=='EVALUATION.md' and len(cells)==10 and cells[0] in ['Z','M'] and cells[1] in ['1','2','4']:
   matches=[r for r in main['summaries'] if r['scenario']==cells[0] and str(r['horizon'])==cells[1] and r['model']==cells[2] and r['fold']=='test-2018-2023']
   if len(matches)==1:
    r=matches[0]
    try:
     ci=[float(x) for x in cells[8].split(' to ')];checks=[int(cells[3])==r['n']]+[abs(float(cells[i])-r[k])<=0.000500001 for i,k in [(4,'mae'),(5,'rmse'),(6,'mase'),(7,'skillPercent'),(9,'coverage80')]]+[abs(ci[0]-r['skill95']['low'])<=0.000500001,abs(ci[1]-r['skill95']['high'])<=0.000500001];verified=all(checks)
     if verified:scope='Exact scenario/horizon/model/pooled-fold N, MAE, RMSE, MASE, skill, CI and coverage compared now at documented rounding; not scientific validation.'
    except (TypeError,ValueError,KeyError):pass
  claims.append({'document':'04_'+name,'line':number,'claim':line,'evidence_file':evidence,'verified_now':'YES' if verified else 'NO','scope':scope})
out=io.StringIO(newline='');w=csv.DictWriter(out,fieldnames=list(claims[0]));w.writeheader();w.writerows(claims);text('04_tables/claim-evidence-matrix.csv',out.getvalue())
# Data reconciliation and exact missing-day/stitch definitions.
audit=json.loads((root/'data/processed/audit.json').read_text(encoding='utf-8'));weekly=json.loads((root/'data/processed/manila_weekly.json').read_text(encoding='utf-8'));scenarios=weekly['scenarios'];scenarioRows=[]
for name,rows in scenarios.items():scenarioRows.append({'scenario':name,'weekly_audit_rows':len(rows),'non_null_weeks':sum(r['cases'] is not None for r in rows),'reliable_weeks':sum(r['reliable'] for r in rows),'sum_non_null_cases':sum(r['cases'] or 0 for r in rows),'sum_reliable_cases':sum((r['cases'] or 0) for r in rows if r['reliable'])})
dump('03_scenario_totals.json',scenarioRows)
text('03_data_report.md','# Fresh aggregate-data inventory\n\nProfiles were read from current original files at '+now+'. Every CSV/XLSX/JSON in data/raw and data/processed is covered. Each profile includes hashes, columns, null counts, date ranges and full first five logical records. HXL rows are explicitly excluded from data counts. XLSX physical rows differ from the normalized daily records because year blocks are side by side.\n\n'+ '\n'.join('- '+r['path']+' -> '+r['profile']+'; rows '+json.dumps(r['tables']) for r in profiles)+'\n\n## Scenarios and stitching\n\n'+json.dumps(scenarioRows,indent=2)+'\n\nZ assumes missing daily dates are zero only inside covered periods. M keeps absence missing and excludes incomplete daily weeks. DOH gaps remain missing in both. DOH EPI labels supply 2016-2017; daily-derived Monday-Sunday weeks supply 2018 onward. Join date 2018-01-01; first daily-derived ending 2018-01-07. Overlapping DOH/daily data are compared, never added. The Sunday interpretation remains operational/unconfirmed; partial final weeks are excluded from scoring. Source acquisition and population provenance limitations remain NEEDS OWNER.\n\n## Reconciliation\n\n```json\n'+json.dumps({k:v for k,v in audit.items() if k.startswith('reconciliation') or k=='suppliedWeekly'},indent=2)+'\n```\n\nSee fresh data-audit log and 08_docs/DATA_QUALITY.md.\n')
copy('docs/DATA_QUALITY.md','03_validation_report.md')
# Repo metadata and dependency inventory.
lock=json.loads((root/'package-lock.json').read_text(encoding='utf-8'));dependencies=[{'path':p,'version':v.get('version'),'dev':v.get('dev',False),'optional':v.get('optional',False)} for p,v in lock['packages'].items() if p];dump('01_dependencies.json',dependencies)
linecounts=collections.Counter()
for name in paths:
 try:linecounts[name.split('/')[0]]+=len((root/name).read_text(encoding='utf-8').splitlines())
 except (OSError,UnicodeDecodeError):pass
tree='\n'.join(name for name in sorted(paths) if len(pathlib.PurePosixPath(name).parts)<=3 and not name.startswith(('review_bundle/','.env','certs/')))
text('01_repo_overview.txt','Fresh UTC: '+now+'\nBranch: '+branch+'\nCommit: '+head+'\n\n$ git log --oneline -30\n'+git('log','--oneline','-30')+'\n\n$ git status --short\n'+git('status','--short')+'\n\nThree-level tracked/current-source tree:\n'+tree+'\n\nLine counts by top-level path:\n'+json.dumps(linecounts,indent=2)+'\n\nResolved lockfile dependencies: 01_dependencies.json\n')
# Test names and coverage; full fresh TAP/browser logs are authoritative for actual execution.
inventory=[]
for p in sorted((root/'tests').rglob('*')):
 if not p.is_file() or p.suffix not in ['.ts','.tsx','.py','.json','.mjs']:continue
 names=re.findall(r'\btest(?:\.skip)?\s*\(\s*[\"\']([^\"\']+)',p.read_text(encoding='utf-8')) if p.suffix!='.json' else []
 inventory.append({'file':p.relative_to(root).as_posix(),'names':names,'classification':'test cases' if names else 'helper/fixture or Python unittest; inspect copied source'})
dump('07_tests_inventory.json',inventory)
areas=['ingestion','absent-day scenarios','feature leakage','risk logic','forecast/backtest','weather fallback','report validation','PII stripping','k-threshold suppression','rate limiting','staff role/MFA claims','RLS','purge/retention','accessibility','saved-evaluation UI numbers']
text('07_tests_inventory.md','# Test inventory\n\n'+ '\n'.join('## '+r['file']+'\n'+('\n'.join('- '+x for x in r['names']) if r['names'] else r['classification']) for r in inventory)+'\n\n## Coverage\n\n'+ '\n'.join('- '+area+': TESTS EXIST; see complete source inventory and fresh command logs.' for area in areas)+'\n\nReal hosted Supabase Auth/TOTP delivery, actual deployed schedule execution, hosted ZAP and human usability/DPO approval: NO VERIFIED LOCAL SUBSTITUTE / NEEDS OWNER. The signed local Auth/PostgREST adapter verifies ephemeral test JWTs and runs actual SQL roles/RPCs; it is not certification of Supabase Auth cryptography or hosted deployment. Existing legacy v1 regression tests deliberately use the five older migrations; current v2 tests and db:verify apply all eleven.\n')
text('05_key_source/README.md','# Current source copies\n\nOriginal relative paths are preserved. Mandatory sanitization may prevent execution of the review copies. The Git branch contains executable source.\n\n'+'\n'.join('- '+r['source']+': '+('reporting/auth/retention or regression coverage' if r['source'].startswith('tests/') else 'application behavior' if r['source'].startswith('src/') else 'ingestion, evaluation, operations or configuration') for r in manifest if r['bundle'].startswith('05_key_source/'))+'\n')
# Report skeletons derive current command status from logs, with no invented output.
text('02_command_results.md','# Fresh command results\n\nEvery full output, including failures, is retained in 02_logs. Commands ran in the canonical project checkout. Browser suites ran sequentially without builds, evaluation, install or scanners alongside them. No tests or safeguards were skipped or deleted.\n\n|Command|UTC start|Seconds|Exit|Actual output|\n|---|---|---:|---:|---|\n'+'\n'.join('|'+r['command']+'|'+r['started_utc']+'|'+str(r['duration_seconds'])+'|'+str(r['exit_code'])+'|'+r['log']+'|' for r in sorted(commands,key=lambda x:x['started_utc']))+'\n\nFresh failures are not overwritten by later passes. Original copied-review browser failures were not reproduced in the canonical checkout; their historical cause remains NOT VERIFIED. The production retry failure was reproduced with trace/video and fixed by blocking service workers in non-PWA tests; the app still displays and asserts an actual accessible failure/retry. PWA tests explicitly allow service workers.\n')
warningLines=[]
for p in sorted((b/'02_logs').glob('*.txt')):
 for line in p.read_text(encoding='utf-8').splitlines():
  if re.search(r'warning|deprecated|skipped|not run|NEEDS OWNER|^not ok|^# fail|error ',line,re.I):warningLines.append(p.name+': '+line)
text('02_warnings.txt','\n'.join(warningLines)+'\n');text('02_skipped_or_unrun.md','# Unrun scope\n\nNo explicit skips in final local unit or browser suites. Failed attempts are preserved in command logs. Hosted credentials/bootstrap/login/TOTP/scheduler/ZAP, a real usability session and DPO approval were not completed; owner explicitly deferred rotation. No live migration, report activation or production push occurred.\n')
text('04_evaluation_evidence.md','# Fresh evaluation evidence\n\nFresh evaluation command and reproduction hashes are in 02_logs/evaluation-final.txt and 04_tables/reproduction.json. Complete aggregate tables:\n\n'+'\n'.join('- '+key+'.csv: '+str(n)+' complete rows' for key,n in counts.items())+'\n\nAll nested CI fields and driver arrays are preserved. Null is unavailable, not zero. Both scenarios, all saved folds/horizons/models and sensitivities are included. Full per-origin arrays are not duplicated under the size budget; first-five profiles and complete aggregate tables are provided. This is not an independent scientific reanalysis. Thermal index and NCR-neighbor forecasts: NOT IMPLEMENTED / NOT VERIFIED.\n\n04_EVALUATION.md and 04_ENVIRONMENT.md are exact source copies unless mandatory redaction is required. COPY_INTEGRITY and DOCUMENT_IDENTITY record hashes. Claim-evidence-matrix.csv inventories every digit-bearing document line. YES marks exact main-table field/rounding comparison now; other narratives are explicitly NOT VERIFIED independently.\n')
text('00_INDEX.md','# Independent launch review bundle\n\nBranch: '+branch+'\nSource commit: '+head+'\nCaptured UTC: '+now+'\nOS: '+platform.platform()+'\nRuntime: Node 22.23.2; npm 10.8.2; Python '+platform.python_version()+'\n\nArchitecture: React/Vite public SPA serves frozen same-origin research JSON and a tightly scoped PWA cache. Browser clients use public Supabase configuration; reporting and staff moderation call RLS-protected PostgreSQL RPCs, with staff appointment and AAL2 checks. Offline/unknown policy fails closed. Node/Python ingestion/evaluation and hosted-operation scripts use server environment configuration. Local Auth/PostgREST tests use signed disposable sessions and actual embedded PostgreSQL; hosted behavior remains separately unverified.\n\n00-10 follow the requested review structure: repo metadata, complete fresh logs, per-file data profiles, complete model summary tables/claim matrix, current source/SQL/docs, RLS and test inventory, screenshots/text/numeric ledger, and known gaps/owner checklist.\n\nStart with 10_known_gaps.md and 08_docs/LAUNCH_CHECKLIST.md. Current release is blocked by deferred owner rotation and hosted/human gates. No main push or report activation is claimed.\n\nSHA256SUMS.txt covers all payload files except itself. The ZIP transfer container has an external checksum. Every payload member is under 1.5MB; combined folder plus ZIP is under 25MB. Oversized logical files are split with reconstruction instructions. Private config, credential fingerprints, certs, packages, build caches, real community records and the archived recording are excluded. Sanitization takes priority over executable/byte-exact source copies and is fully disclosed.\n')
dump('BUNDLE_SOURCE.json',{'source_commit':head,'branch':branch,'utc':now,'raw_files':[r for r in profiles if r['path'].startswith('data/raw/')],'local_only':True,'main_pushed':False})
print(json.dumps({'prepared_utc':now,'source_commit':head,'copied_sources_docs_sql':len(manifest),'profiled_files':len(profiles),'metric_tables':counts,'claim_rows':len(claims),'exactly_verified_claim_rows':sum(x['verified_now']=='YES' for x in claims),'commands_preserved':len(commands)},indent=2))
