# Database/security evidence

Fresh catalog: 06_rls_catalog.json; all eleven migrations are under 06_sql. db:verify applies every migration twice in an idempotence test, runs actual RLS/abuse/retention tests and a seeded local browser reporting flow. Local Auth.uid/JWT adapters are test scaffolding, not proof of hosted Auth cryptography/TOTP. No real report records were loaded.

|Table|RLS enabled|Plain-language access|Policy names|
|---|---|---|---|
|private.admin_users|True|Private appointments; no direct clients. Legacy and current admin checks require an appointed role and AAL2.||
|private.report_challenges|True|No raw client access; public challenge RPC is gated by reporting policy and issuance ceiling.||
|private.staff_roles|True|Private appointments; no client reads/writes. Staff RPCs use the authenticated identity and AAL2 claims.||
|public.barangay_risk|True|Public aggregate risk-input cache, not current patient locations; privileged writes only.|risk_public_read|
|public.city_forecasts|True|Public historical forecast cache only; clients cannot fabricate anonymous writes.|forecast_public_read|
|public.community_policy|True|Legacy public settings read only; legacy submit function remains permanently closed.|community_policy_public_read|
|public.community_reports|True|Retired v1 submission; anonymous raw reads denied. Legacy admin RLS uses the same MFA-protected admin function. Withdrawal/retention remain.|community_admin_read|
|public.community_signals|True|No direct raw client SELECT/INSERT, even for staff. Audited staff queue RPC only; role and AAL2 required.|signals_staff_read|
|public.historical_forecast_backtest|True|Public aggregate historical forecast errors; admin writes require AAL2.|backtest_admin_write, backtest_public_read|
|public.historical_surveillance|True|Public official aggregate source observations, never individual community reports; admin writes require AAL2.|historical_admin_write, historical_public_read|
|public.lgus|True|Public official aggregate geography/denominators; writes require owner/service or AAL2 admin.|lgus_admin_write, lgus_public_read|
|public.manila_barangay_catalog|True|Public coarse-area catalogue only; no individual locations or health records.|barangay_catalog_read|
|public.reporting_v2_policy|True|Public read of availability/consent settings only. Clients cannot enable collection.|v2_policy_read|
|public.staff_audit|True|Appointed AAL2 admins read audit rows; anonymous access denied; actions are server-recorded.|audit_admin_read|
|public.surveillance_uploads|True|AAL2 admin-only staging/read/publish/rollback; row schema and dates validated server-side; no automatic retraining.|uploads_admin_read|

## Environment names only

- BOOTSTRAP_ADMIN_EMAIL: server/CI/one-time operation or test configuration
- BOOTSTRAP_ADMIN_PASSWORD: server/CI/one-time operation or test configuration
- COMMUNITY_CONTACT_EMAIL: server/CI/one-time operation or test configuration
- CREDENTIALS_ROTATED: server/CI/one-time operation or test configuration
- DB_SSL_CA_FILE: server/CI/one-time operation or test configuration
- DEV: server/CI/one-time operation or test configuration
- DIRECT_DATABASE_URL: server/CI/one-time operation or test configuration
- DOCKER_HOST: server/CI/one-time operation or test configuration
- ENV_OFFLINE: server/CI/one-time operation or test configuration
- EXPOSED_CREDENTIAL_SHA256: server/CI/one-time operation or test configuration
- JAVA_BIN: server/CI/one-time operation or test configuration
- LAUNCH_GATES_PASSED: server/CI/one-time operation or test configuration
- PLAYWRIGHT_CHANNEL: server/CI/one-time operation or test configuration
- PROD: server/CI/one-time operation or test configuration
- REPORTING_ENABLED: server/CI/one-time operation or test configuration
- SUPABASE_SECRET_KEY: server/CI/one-time operation or test configuration
- SUPABASE_SERVICE_ROLE_KEY: server/CI/one-time operation or test configuration
- SUPABASE_URL: server/CI/one-time operation or test configuration
- VITE_DEMO_MODE: browser/build public configuration or forbidden-name negative-test guard
- VITE_SUPABASE_ANON_KEY: browser/build public configuration or forbidden-name negative-test guard
- VITE_SUPABASE_URL: browser/build public configuration or forbidden-name negative-test guard
- VITE_TEST_FIXTURES: browser/build public configuration or forbidden-name negative-test guard
- ZAP_JAR: server/CI/one-time operation or test configuration
- ZAP_TARGET_URL: server/CI/one-time operation or test configuration

Only public URL/publishable-or-anon key may reach the browser. Database URLs, server API keys, admin passwords and private exposure fingerprints remain in ignored/server/CI configuration. No values or private guard fingerprints are included. Current secret audit retains historical findings and blocks unconfirmed rotation. See 06_credential_history.json for path/commit metadata only and 08_docs/ROTATE_CREDENTIALS.md for exact owner steps.

The old configured database URL was cleared locally. Owner explicitly deferred rotation. Hosted revocation, new credentials, migration deployment, first staff account, real MFA login, retention execution and deployed ZAP are NEEDS OWNER / NOT VERIFIED. No history rewrite, hosted data mutation, report activation or main push occurred. Protected retention uses actual pg_cron when present, otherwise the hourly workflow/protected RPC; definition tests do not prove deployed execution.
