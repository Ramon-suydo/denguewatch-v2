# Database and security evidence

Fresh full-migration catalog: [06_rls_catalog.json](06_rls_catalog.json); fresh runner output: [02_logs/rls-catalog.txt](02_logs/rls-catalog.txt). This is a new in-memory PGlite database using the existing test auth boundary and all seven migrations. It contains no real community records and proves nothing about which migrations are installed on hosting. All SQL files are copied with original relative paths under 06_sql/.

|Table|RLS enabled|Anon SELECT / INSERT grants|Ordinary authenticated SELECT / INSERT grants|Plain-language policy boundary|
|---|---|---|---|---|
|private.admin_users|True|False / False|False / False|Private allowlist; ordinary roles have no table grant or policy. No allowing row policies: default denial applies to non-bypass roles.|
|private.report_challenges|True|False / False|False / False|Private one-use proof challenge store; access only through validated definer functions. No allowing row policies: default denial applies to non-bypass roles.|
|private.staff_roles|True|False / False|False / False|Private staff appointment map; no direct ordinary-role table access. No allowing row policies: default denial applies to non-bypass roles.|
|public.barangay_risk|True|True / False|True / False|Public read-only legacy risk cache; no browser-write policy; this is not official barangay case data or an active public forecast. Policies: risk_public_read (SELECT).|
|public.city_forecasts|True|True / False|True / False|Public read-only legacy forecast cache; no browser-write policy. Its existence does not establish current model validity. Policies: forecast_public_read (SELECT).|
|public.community_policy|True|True / False|True / False|Public read-only legacy policy; privileged operations manage it; it cannot reopen the retired legacy submit function. Policies: community_policy_public_read (SELECT).|
|public.community_reports|True|False / False|True / False|Legacy raw reports; public raw access denied; legacy submission RPC is closed by the final migrations. Policies: community_admin_read (SELECT).|
|public.community_signals|True|False / False|False / False|Sensitive raw v2 report table; ordinary and staff clients cannot select it directly; audited role-checked queue RPC only. Policies: signals_staff_read (SELECT).|
|public.historical_forecast_backtest|True|True / False|True / True|Public historical aggregate backtests; any client write requires an admin predicate plus a corresponding grant. Policies: backtest_admin_write (ALL), backtest_public_read (SELECT).|
|public.historical_surveillance|True|True / False|True / True|Public historical aggregate case observations; any client write requires an admin predicate plus a corresponding grant. Policies: historical_admin_write (ALL), historical_public_read (SELECT).|
|public.lgus|True|True / False|True / True|Public administrative reference reads; privileged project-admin write policies. Policies: lgus_admin_write (ALL), lgus_public_read (SELECT).|
|public.manila_barangay_catalog|True|True / False|True / False|Public coarse source-area labels/codes; admin-managed reference data. Policies: barangay_catalog_read (SELECT).|
|public.reporting_v2_policy|True|True / False|True / False|Readable v2 consent/rate/delay/retention policy; defaults disabled; admin edits. Policies: v2_policy_read (SELECT).|
|public.staff_audit|True|False / False|True / False|Role-restricted audit log; actions and authorized queue reads are written through definer functions, not public mutations. Policies: audit_admin_read (SELECT).|
|public.surveillance_uploads|True|False / False|True / False|Staff-role-restricted staged uploads; validated admin RPC controls publication/rollback; not automatic official/model ingestion. Policies: uploads_admin_read (SELECT).|

A table grant is not a successful row read: RLS predicates also apply. Owners/elevated backend roles can bypass normal RLS; no such key is included. Exact predicates, role lists, function definer flags and execute grants are in the catalog.

## Environment names only

Names found statically in application/scripts/config or the example template. Some are test/build guards, not required production settings. Browser names may contain only a public project URL and public anonymous credential; private credentials must stay in server tooling. Private-looking VITE names in tests are negative build-rejection cases, not a supported way to expose a secret. Mandatory blocked-marker redaction may partially mask an identifier.

|Name|Scope / caution|
|---|---|
|COMMUNITY_CONTACT_EMAIL|Server, local operations, test or tooling configuration; not a browser credential|
|DB_SSL_CA_FILE|Server, local operations, test or tooling configuration; not a browser credential|
|DEV|Server, local operations, test or tooling configuration; not a browser credential|
|DIRECT_DATABASE_URL|Server, local operations, test or tooling configuration; not a browser credential|
|DOCKER_HOST|Server, local operations, test or tooling configuration; not a browser credential|
|ENV_OFFLINE|Server, local operations, test or tooling configuration; not a browser credential|
|PLAYWRIGHT_CHANNEL|Server, local operations, test or tooling configuration; not a browser credential|
|PLAYWRIGHT_PORT|Server, local operations, test or tooling configuration; not a browser credential|
|PROD|Server, local operations, test or tooling configuration; not a browser credential|
|VITE_DEMO_MODE|Browser/build: public configuration only; inspect negative tests for forbidden-name guards|
|VITE_[REDACTED]_KEY|Browser/build: public configuration only; inspect negative tests for forbidden-name guards|
|VITE_SUPABASE_ANON_KEY|Browser/build: public configuration only; inspect negative tests for forbidden-name guards|
|VITE_SUPABASE_URL|Browser/build: public configuration only; inspect negative tests for forbidden-name guards|
|VITE_TEST_FIXTURES|Browser/build: public configuration only; inspect negative tests for forbidden-name guards|

Core public demo uses static exports and can run without hosted private configuration. Auth hashing/session verification is delegated to Supabase Auth; real hosted password policy, MFA and login are NOT VERIFIED. Staff appointment checks are server-side SQL, distinct from displaying a login page.

## Fresh RLS/abuse tests

02_logs/unit.txt contains the full fresh 66-test TAP output, including current full-migration reporting tests. The legacy v1 suite intentionally applies the five older migrations; it is a regression test of old behavior, not current permission to submit publicly. Current v2 tests apply every migration and prove the legacy submit path remains closed. PGlite stubs auth.uid using test claims; this does not verify hosted JWT cryptography, Auth email delivery or MFA.

## Credential history and rotation

Fresh pattern-only git search output and an in-memory comparison are in [06_credential_history.json](06_credential_history.json). No private value was passed to a git search or printed. The current local configured password component was found in 44 historical blobs because it matches public project text. This is an exposed/guessable configured credential even though a private environment file or full credential-bearing URL need not have been committed.

Hosted rotation: **NOT VERIFIED**. Local private configuration still uses a value found in history; no hosted connection was made to test whether it is active or revoked. Do not claim it has been rotated or remains active on hosting without owner evidence. The secret gate is unresolved.

## Not verified

Deployed ZAP scan, hosted roles/migrations, real staff login, MFA, scheduled purge execution, DPO review and deletion on the real hosted instance: NOT VERIFIED. Saved ZAP status is a NOT-RUN status artifact, not a scan report. No hosted state was changed.
