# Actual rendered text and number provenance

Captured from the isolated local production build at the exact source commit. No hosted credentials, login or report submission. Public APIs are static research exports; backend-dependent pages show their actual unconfigured/closed/error state. Admin subpaths do not constitute distinct implemented staff routes: all render the signed-out gate. Moderation queue/data upload contents are NOT VERIFIED.

Each number occurrence is listed in numbers.part*.csv with rendered context and code/data files. File-level traces identify the section loader or static generating component; exact scalar-field mapping is NOT VERIFIED unless specified. Unmapped/ambiguous origins are flagged, rather than called fabricated. SVG axis ticks are derived labels, not extra observations. Numeric constants in legal/prevention copy are not independent legal/medical verification.

## home / 360px

Route: `/`; UTC 2026-10-25T03:41:12.897Z; screenshot `home-360.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Menu
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details
English
Filipino

MANILA / DENGUEWATCH RESEARCH

Know the evidence. Take care early.

Manila dengue history, tested forecasts, and clear limits on what the data can tell us.

CURRENT STATUS

◇ Current risk unavailable

The latest reliable complete-row week ends 2023-11-26; these historical records cannot establish current risk.

Last recorded day: 2023-12-02 · Historical records only

Remove standing water, protect yourself from mosquito bites, and seek early consultation for symptoms.

Prevention & warning signs
Report a case · collection closed
Seasonal watch: context only

PAGASA defines June to November as the rainy season. Clear containers of standing water and keep up bite prevention. This is seasonal context, not a dengue prediction or alert.

Dengue observations remain historical; current weather cannot establish today's dengue risk.

In complete-row history for 2016-2023 (Scenario M), mean weekly cases ranged from 22.8 in May to 122.1 in September. This does not measure a delay from rainfall onset to rising cases.

Weather is seasonal context only; showing baseline forecast. Dengue observations remain historical. Weather as of: 2026-10-11.

PAGASA season definition
What do the forecasts show?

These are historical statistical estimates, not current alerts or outbreak predictions.

Absent-day scenario
M · absent dates remain missing
Z · absent dates assumed zero

Only weeks with seven daily rows are scored. An absent date is not a recorded zero. The final partial week is excluded in both scenarios.

Historical Manila forecast

Origin 2023-11-26 · manila-persistence-v2 · Community reports excluded

Target week	Horizon	Cases estimate	80% interval	Probability of rise
2023-12-03	1 week(s)	62	40–84	42.7%
2023-12-10	2 week(s)	62	31–93	39.1%

Persistence uses the latest available weekly count. Intervals use earlier out-of-sample errors and are not guarantees. Source: Manila daily workbook; as of 2023-11-26.

Weather was tested, not assumed.

Expanded season and weather tests did not establish a reliable one- to two-week gain over last-week persistence in either scenario. The public forecast keeps the simpler baseline.

Read the measured results and methodology →
Manila trends

2016–2023 · source bands, missing weeks, and COVID context

Explore the history →
Metro Manila history

Data ends January 2021. No live NCR forecast.

Compare the cities →
Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## trends / 360px

Route: `/trends`; UTC 2026-10-25T03:41:15.364Z; screenshot `trends-360.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Menu
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details

HISTORY / MANILA ONLY

Trends with their context.

Different source periods, missing observations, and pandemic disruption remain visible.

Absent-day scenario
M · absent dates remain missing
Z · absent dates assumed zero

Only weeks with seven daily rows are scored. An absent date is not a recorded zero. The final partial week is excluded in both scenarios.

History year
All years · 2016–2023
2016
2017
2018
2019
2020
2021
2022
2023
Weekly recorded cases
0
64
129
193
257
COVID period
2016-01-10
2023-12-03
Weekly cases · gaps remain gaps
Source changes
DOH EPI before 2018; Manila daily-derived weeks from 2018. COVID period shaded (2020–2021). Source dates end 2023-12-02; final partial week excluded. Sunday labels operationally interpreted as week-ending; source semantics unconfirmed.
Exact weekly values and quality flags
Year comparison

Totals cover available scenario-defined weeks, not necessarily complete years. Never add source representations together.

Year	Cases in available weeks	Available / calendar weeks
2016	1,990 · incomplete	45 / 51
2017	2,813	53 / 53
2018	3,530 · incomplete	47 / 52
2019	3,761 · incomplete	43 / 52
2020	451 · incomplete	13 / 52
2021	883 · incomplete	24 / 52
2022	2,516 · incomplete	42 / 52
2023	2,346 · incomplete	45 / 49

DOH EPI 2016–2017; Manila daily-derived 2018–2023. As of 2023-12-02.

Historical forecast and interval

Origin 2023-11-26. Exploratory four-week forecasts have larger error; they are not operational warnings.

1 week
2 weeks
4 weeks
Cases · historical estimates, not current alerts
0
110
Source: Manila daily-derived weekly series; origin 2023-11-26. Dot = estimate, vertical bar = nominal 80% interval. Four weeks is exploratory. Scroll the chart if needed; exact values follow.
Target	Horizon	Forecast cases	80% interval
2023-12-03	1 weeks	62	40–84
2023-12-10	2 weeks	62	31–93
2023-12-24	4 weeks · exploratory	62	14–110

Source: daily-derived Manila series. manila-persistence-v2; interval calibration uses earlier observed out-of-sample errors only. Not current risk.

Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## metro-history / 360px

Route: `/metro-manila`; UTC 2026-10-25T03:41:17.321Z; screenshot `metro-history-360.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Menu
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details

METRO MANILA / HISTORICAL

A city-level historical comparison.
Data ends January 2021. No current NCR forecast is shown. Missing weeks are not zero.
Metro Manila context, not a prediction

Aedes aegypti mainly breeds in small standing-water containers near homes: drums, tires, pots and clogged drains. Flowing rivers are not its principal breeding habitat. Geographic proxies cannot identify a household at risk.

Show exploratory city context
Comparison period
Year totals (available weeks)
One source week
Historical year
2016
2017
2018
2019
2020
2021

Population denominator unverified; confirm against PSA 2020 census. All rates use the same supplied 2020 denominator, including earlier years. No district or barangay case counts are inferred.

Recorded incidence per 100,000

Darker blue means a larger historical rate in this selection. It does not identify current risk. Gray means no source observation, not zero. Exact values appear in the ranking table.

MANILA CITY: 689 recorded cases; 37.3 per 100,000; 51 source week(s).

Cases: DOH EPI, 2020; as of 2021-01-10. Boundaries: NAMRIA/PSA via OCHA HDX, CC BY 3.0 IGO, valid 2025-02-13; not proven historical boundaries. Boundary source.

City ranking · 2020
City / municipality	Recorded cases	Per 100,000	Source weeks
PATEROS	129	197.8	51
MALABON CITY	371	97.5	51
NAVOTAS CITY	188	75.9	51
PASIG CITY	596	74.2	51
TAGUIG CITY	634	71.5	51
PARANAQUE CITY	438	63.5	51
VALENZUELA CITY	420	58.7	51
MARIKINA CITY	263	57.7	51
QUEZON CITY	1,654	55.9	51
MAKATI CITY	319	50.7	51
LAS PINAS CITY	295	48.7	51
MANDALUYONG CITY	198	46.5	51
CALOOCAN CITY	652	39.2	51
MANILA CITY	689	37.3	51
SAN JUAN CITY	46	36.4	51
MUNTINLUPA CITY	179	32.9	51
PASAY CITY	112	25.4	51

DOH EPI weekly source, ending January 2021. 2021 is January only. Calendar gaps and partial years make totals incomplete.

Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## prevention / 360px

Route: `/prevention`; UTC 2026-10-25T03:41:18.724Z; screenshot `prevention-360.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Menu
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details
English
Filipino

PREVENTION / EVERYDAY CARE

Small actions. Everyday protection.

Informational, not a diagnosis.

The DOH 4S strategy
Find and remove mosquito breeding places, including water-holding containers.
Use protective clothing and mosquito repellent.
Seek early consultation when symptoms appear.
Support fogging or spraying in identified hotspots under health-office guidance.

DOH Central Visayas · 4S guidance · Checked 2026-10-25.

Warning signs need urgent care

Go to a clinic or emergency room immediately for abdominal pain or tenderness, repeated vomiting, nose or gum bleeding, blood in vomit or stool, or extreme tiredness or restlessness. Warning signs can begin after fever subsides.

Do not wait for an app risk level or report confirmation before seeking care.

CDC · dengue symptoms and warning signs · Checked 2026-10-25.

Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## report-closed / 360px

Route: `/report`; UTC 2026-10-25T03:41:19.665Z; screenshot `report-closed-360.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Menu
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details
English
Filipino

COMMUNITY / UNVERIFIED

Share an awareness signal.

No account, name, phone number or exact address is requested. Do not put identifying details in notes. Reports never enter official counts or forecasts.

New submissions are not open yet.

Collection status could not be confirmed; reporting stays closed. Retry status

Understand and consent

Your optional health report is sensitive personal information. It supports research and coarse community awareness, not diagnosis, emergency response or validated prediction.

Only staff can review individual reports. Public counts require staff approval, a 72-hour delay and at least three reports per area/week. Reports are removed after 90 days; withdraw sooner with your private code.

Please report only your own experience. Do not include anyone’s identity or address. Privacy and withdrawal.

I voluntarily consent to this research use of my report under community-v2.
Continue to report

Controller: DengueWatch student research team. Contact: achilleslang23@gmail.com. Notice requires DPO review before collection opens.

View community aggregates · Prevention and urgent warning signs

Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## community / 360px

Route: `/community`; UTC 2026-10-25T03:41:20.919Z; screenshot `community-360.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Menu
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details

COMMUNITY / UNVERIFIED

Community reports, kept separate.

Collection remains closed. These are community-reported, unverified awareness signals, never official dengue counts or forecast inputs. Staff approval is a content review, not medical verification.

Publication requires at least three approved reports per area/week and a minimum 72-hour delay. Missing or suppressed groups do not mean zero cases. There is no validation history establishing predictive value.

The data service is not configured yet. Please try again later.

Try again
Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## methodology / 360px

Route: `/methodology`; UTC 2026-10-25T03:41:21.844Z; screenshot `methodology-360.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Menu
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details

METHODS / EVIDENCE BEFORE CLAIMS

What was tested. What remains uncertain.

We study Manila city one to two weeks ahead, compare with last-week persistence, and keep community reports outside official counts and models. Four weeks is exploratory.

Season and weather: controlled ablation

AR(2) log1p ridge, fixed L2=20, standardization from each training prefix only; >=32 training pairs. COVID indicator in all AR variants. Lag selection frozen from 2016-2017 only; no 2017 calibration scores reused.

All six methods share identical origin/target rows within scenario/horizon. M gaps remain missing. Frozen selected lags yield more M pairs than the prior 8-lag main harness: these are different comparison cohorts.

Environmental scenario
M: absent dates missing
Z: absent dates zero-assumed
Environmental fold
test-2018-2023
2018
2019
2020
2021
2022
2023
covid-2020-2021
Environmental horizon
1 week
2 week
4 week (exploratory)
Model	N	MAE	RMSE	MASE	Skill vs persistence % (95% CI)	Alert precision / recall	False positive rate	80% coverage
naive	166	14.024	20.335	1.139	0 (0 to 0)	72.1% / 68.9%	11.9%	82.9%
env-ar	166	15.072	21.994	1.23	-7.47 (-18.21 to 6.15)	75.6% / 75.6%	10.9%	83.6%
env-season	166	14.343	20.756	1.168	-2.27 (-13.29 to 9.35)	74.5% / 77.8%	11.9%	87%
env-weather	166	15.185	21.738	1.228	-8.28 (-22.97 to 3.94)	75.6% / 68.9%	9.9%	84.2%
env-season-weather	166	14.914	21.478	1.21	-6.35 (-18.58 to 5.65)	78% / 71.1%	8.9%	87.7%
env-season-weather-no-engineered	166	14.826	21.087	1.201	-5.72 (-18.59 to 5.88)	80.5% / 73.3%	7.9%	87%

Training-only choices through 2017-12-31: rainfall lag 3, temperature lag 1, humidity lag 3, rainfall window 8 weeks. Lags are before the forecast origin, never future weather. Correlations are season-confounded, not causal.

Season adds June-November flag and sin/cos; weather adds selected rainfall, temperature and humidity lags, selected rainfall window, >=1mm rain days and weekly temperature min/max at lag 1. Combined adds a fixed research cumulative-200mm onset proxy, not PAGASA onset. No-engineered combined variant drops rainfall roll/rain-day/min/max/onset engineering.

Optional thermal index omitted: no verified parameter curve is implemented; never labelled tested.

Only prior out-of-sample targets matured by each origin. Calibration starts in 2018; first 20 matured rows have unavailable probabilities and intervals.

NASA POWER cross-check

469 paired weeks: rainfall Pearson r 0.575, temperature r 0.866. Weekly rainfall MAE 35.04 mm; mean-temperature MAE 2.28 Celsius. ERA5 Asia/Manila civil days versus NASA POWER LST solar-swath days; weekly boundaries may differ. Neither source is a rain gauge. ERA5 is about 25 km; NASA meteorology about 0.5 by 0.625 degrees. One Manila point cannot resolve city or household weather.

Historical monthly profile

Sunday week-ending month, 2016-2023. This descriptive profile uses the test-period history too; it never selects forecasting lags or thresholds. It is not a measured rainy-onset response delay.

Month	Scorable weeks	Mean cases/week	Complete-row subset N	Complete-row mean
1	26	53.81	26	53.81
2	29	43.69	29	43.69
3	28	29.39	28	29.39
4	20	27.2	20	27.2
5	21	22.81	21	22.81
6	23	29.96	23	29.96
7	30	49.6	30	49.6
8	24	95.25	24	95.25
9	25	122.12	25	122.12
10	31	92.77	31	92.77
11	29	72.07	29	72.07
12	26	49.85	26	49.85
Primary threshold episode lead
Model	Eligible onsets	Detected	Mean lead (weeks)
naive	14	5	2
env-ar	14	5	2
env-season	14	6	2
env-weather	14	5	1.8
env-season-weather	14	7	1.71
env-season-weather-no-engineered	14	7	1.71

Both 1/2-week horizons; onset requires an observed previous below-threshold week. No outbreak diagnosis. Source: versioned ERA5, NASA POWER and Manila files; disease data ends December 2023. Full alert F1/AUC/Brier, coefficients and figures are in docs/ENVIRONMENT_RESULTS.md and docs/figures.

Does a date with no row mean zero cases or no report?

The workbook does not answer. Scenario Z assumes zero inside coverage; Scenario M excludes incomplete daily-row weeks. We evaluate both. No absence is silently turned into zero in M. Partial boundary weeks are excluded in both.

DOH weekly data provides 2016–2017; daily-derived weekly data begins January 2018. The Sunday week-ending interpretation of DOH labels is operational and unconfirmed. Observed-week overlap has 151 pairs and a mean absolute difference of 13.5960 cases. Including five blank weeks under Z gives 156 pairs and MAE 13.2244; seven-row weeks give 104 pairs. Close totals do not mean matching weeks.

Source citations and 2020 NCR population provenance still need owner review. Detailed source audit.

Absent-day scenario
M · absent dates remain missing
Z · absent dates assumed zero

Only weeks with seven daily rows are scored. An absent date is not a recorded zero. The final partial week is excluded in both scenarios.

Evaluation fold
All test years · 2018–2023
2018
2019
2020
2021
2022
2023
COVID years · 2020–2021
Forecast horizon
1 week
2 weeks
4 weeks · exploratory
Forecast comparison

Expanding-window rolling origins; no random split. Same scored targets for every method within each scenario. The 2017 development candidate was frozen before 2018–2023 testing. The public display conservatively uses persistence because one/two-week gains remain inconclusive; that promotion choice is post-evaluation, not preregistered.

Model	N	MAE	RMSE	MASE	Skill vs last week	95% skill CI	80% coverage
naive	116	15.474	22.419	1.271	0%	0 to 0%	75%
mean-4	116	21.97	29.328	1.789	-42%	-64.2 to -20.6%	70.7%
seasonal-naive	116	34.362	45.194	2.803	-122.1%	-193.2 to -78.1%	66.4%
endemic-channel	116	28.793	38.387	2.342	-86.1%	-144.8 to -46.7%	68.1%
ridge-cases	116	16.356	23.169	1.348	-5.7%	-22.1 to 7.2%	75.9%
ridge-weather	116	18.39	25.361	1.51	-18.8%	-40.8 to -4.7%	78.4%
ridge-no-rain	116	17.684	24.399	1.458	-14.3%	-32.9 to -0.2%	79.3%
ridge-no-temperature	116	18.755	25.556	1.539	-21.2%	-43 to -6.4%	78.4%
ridge-no-humidity	116	17.625	24.6	1.441	-13.9%	-33.5 to -0.9%	77.6%
tree-cases	116	29.267	45.359	2.403	-89.1%	-140.6 to -36.8%	78.4%
tree-weather	116	29.394	45.503	2.414	-90%	-141.2 to -38.4%	77.6%

Sources: immutable DOH / Manila daily inputs, ERA5 grid estimates. Test targets through 2023-11-26; version manila-evaluation-v2. MASE uses training-only mean adjacent-week persistence error. Bootstrap: 400 paired resamples in blocks of eight observed targets; gaps mean blocks are not always eight calendar weeks.

Did weather help?

Case-only ridge MAE: 16.356. Weather ridge MAE: 18.39. Weather did not improve this matched comparison.

Across the full 2018–2023 test, weather worsens ridge at one and two weeks in both Z and M. ERA5 is retrospective reanalysis, not station gauges or historical operational vintages. Weekly rain, temperature and humidity enter only at lags 1–8, with at least seven days of availability lag. Constants such as population and density cannot predict change within Manila.

Leave-one-driver-out ridge and cases/weather tree variants appear in the same table. Importances and correlations are not causal explanations. No deep learning: fewer than 500 weekly observations.

Descriptive driver fits
Descriptive driver model
Weather ridge coefficients
Weather tree split gains

These summarize a final training fit, not out-of-sample attribution or causal effects. Correlation and importance do not establish causation.

Origin 2023-11-26 · Coefficients on training-standardized features predicting log1p cases, descriptive only

Feature names and fitted values
Research alerts, not outbreak declarations

90th percentile of previous-year cases within ±2 ordinal calendar weeks of target; at least 5 observations, past data only. Research threshold, not a DOH outbreak declaration.

Alert probabilities use matured out-of-sample residuals. The endemic-channel rule uses the latest count crossing that threshold. These research signals do not establish current risk or replace official DOH guidance.

Model	Precision	Recall	F1	ROC-AUC	Brier	False-positive rate
naive	0.775	0.738	0.756	0.904	0.128	12.2%
endemic-channel	0.756	0.738	0.747	0.801	0.181	13.5%
ridge-weather	0.71	0.524	0.603	0.864	0.151	12.2%

Lead time is currently reported as the forecast horizon among correct positives; episode-based outbreak lead time has not been validated. Undefined metrics stay unavailable. Intervals can under-cover, especially in M and COVID years.

Research threshold-episode lead time

An eligible onset requires an above-threshold scored week preceded by an observed, consecutive calendar week at/below threshold. Gaps do not establish onset. Only one/two-week forecasts are counted here; this is not a medically confirmed outbreak measure. Missed eligible onsets remain in the denominator.

Model	Eligible onsets	Detected	Mean lead (weeks)
naive	9	3	2
mean-4	9	3	2
seasonal-naive	9	3	2
endemic-channel	9	5	2
ridge-cases	9	3	2
ridge-weather	9	5	2
tree-cases	9	3	1.7
tree-weather	9	3	1.7
Known limits
Daily zero/missing ambiguity unresolved
DOH week-ending semantics unconfirmed
Retrospective reanalysis is not real-time vintage data
Sparse alert events can make AUC/precision undefined
Probability of rise and alerts use empirical past residuals, not a separately validated clinical classifier
Mean lead is correct-positive forecast horizon, not episode-based outbreak lead time
Deaths anomalies flagged and excluded in DOH case training under existing policy
No deep learning: fewer than 500 weekly observations per scenario
No current 2026 surveillance; all forecasts historical

Training-only standardization, fixed L2=20, log1p target, no lognormal bias correction, >=32 training examples. Rain uses log1p(mm); temperature Celsius; humidity percent; lags 1-8 before origin; case lags 0-3 and annual harmonics + COVID indicator.

24 gradient-boosted stumps, learning rate .05, minimum leaf 16, 7 training-only quantile split candidates, L2 leaf=10, log1p target. Fixed, no tuning on test folds.

80% absolute-residual conformal radius with finite-sample rank; at least 20 matured out-of-sample targets by origin. No coverage guarantee under drift.

Community reports are an unverified awareness layer only. Their predictive value is future work; there is no validation history.

Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## privacy / 360px

Route: `/privacy`; UTC 2026-10-25T03:41:23.214Z; screenshot `privacy-360.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Menu
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details

YOUR INFORMATION

Privacy, in plain language.

Voluntary participation, minimal collection, and a clear way to withdraw.

Collection remains closed. The v2 notice describes coarse area, symptom-onset date, optional symptoms and a sanitized note, with 90-day retention. Only approved groups of at least three are eligible for publication after 72 hours. Provider logs and backups require separate DPO review.

Draft for review. Not legal advice. Version legal-v2 · 2026-10-25

Privacy Notice
What happens today

Public browsing does not require an account. Community submissions are closed. No analytics or advertising SDKs are installed. The app sets no cookies. Only a language preference is stored in localStorage; reports and withdrawal codes are never stored in browser storage. Fonts and app code are served with the app; the dated official-data snapshot is fetched from the same site and held in memory. Your browser may cache public files.

Public research pages and the NCR map use same-origin files with self-hosted fonts. Reporting, withdrawal and legacy source auditing can send requests to Supabase. No external map tiles are requested. These providers can receive IP addresses, browser/request information, requested paths and timestamps. The provider-default labels below do not establish a verified duration. Their logging settings, processing locations and retention require provider/owner verification; we do not promise that no technical logs exist. Technical-log retention: Per hosting provider default (Vercel/Supabase). Provider backup retention: Per provider default (Supabase). Offline mode blocks report mutations; previously cached public research files can remain available.

Supabase access uses a public anonymous API key, not a user account. Session persistence and automatic auth refresh are disabled. The withdrawal form can send a private code to Supabase when online; it is not a public lookup and returns the same result regardless of a matching report. Offline withdrawal is unavailable.

If reporting opens after review

The v2 form collects an optional coarse Manila area, symptom-onset date, optional symptoms and a short sanitized note, consent/version and submission time. No name, contact field, precise location or application IP field is collected. Pattern-based PII removal is imperfect; do not include identifying information. The database records consent, moderation/withdrawal state and a one-way hash of the private DW2- withdrawal code. Do not provide names, exact addresses, patient identifiers or someone else's information.

Individual health information is sensitive personal information under RA 10173 §3(l)(2). Intended purposes are voluntary research into broad community patterns; reports are not verified clinical records, medical advice or official surveillance. The consent text and lawful basis require lawyer/school DPO review before collection opens. RA 10173, published by the NPC.

Sharing and retention

Appointed moderators and administrators can review individual reports. Supabase processes the records for the app; no individual report content is intended for sale, advertising or third parties' own use. The v2 public area/week counts require at least three approved reports and a minimum 72-hour publication delay. Legacy submission entrypoints are closed by the pending v2 migration. Suppression reduces exposure but does not guarantee anonymity. Community reports are excluded from official series, forecasts and the public demo snapshot.

Community-report launch retention: Not applicable, form closed. The existing database is configured for 90 days, with an hourly expiry purge; that earlier setting must be reconfirmed in the launch review. V2 withdrawal immediately removes a matching active report from aggregates and clears note, symptoms and area; legacy DW- withdrawal clears optional contact and barangay text. Remaining structured fields persist until expiry/purge. Provider backups follow a separate lifecycle; application deletion does not promise immediate backup deletion.

Your rights and contact

You may request information/access, correction, objection, erasure or withdrawal, subject to applicable law and appropriate identity verification. Save your DW- or DW2- code: it permits withdrawal, not record retrieval. There is no public code recovery. Lost-code access/correction requests need a DPO-reviewed process that avoids exposing another person's record. Withdrawal by code.

Personal information controller: DengueWatch student research team, University Perpetual Help College of Manila. Controller contact: achilleslang23@gmail.com. This is the owner-supplied research contact; a DPO appointment is not confirmed. You can also review your rights and complaint options with the National Privacy Commission.

Withdraw a report

Enter your reference code to request deletion. You do not need an account.

Reference code

Do not include a name, contact address, or report details.

Request withdrawal
Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## data-sources / 360px

Route: `/data-sources`; UTC 2026-10-25T03:41:24.509Z; screenshot `data-sources-360.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Menu
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details

PUBLISHED DATA, CHECKED

Data confidence

Trace Manila’s records from source files to charts and tested estimates.

Environmental and geographic providers

Open-Meteo Historical API: CC BY 4.0; contains modified Copernicus Climate Change Service information. ERA5 / ECMWF / Copernicus C3S reanalysis, about 0.25 degrees, not station gauges. One Manila point only.

NASA POWER acknowledgement: This data was obtained from the NASA Langley Research Center (LaRC) POWER Project funded through the NASA Earth Science/Applied Science Program.

NASA GMAO MERRA-2 supplies POWER meteorology. The daily cross-check uses solar LST, which differs from a civil timezone. No per-city weather is presented as real.

Copyright OpenStreetMap contributors; Open Database License (ODbL). City water proximity is a contemporary mapped-water proxy, not a breeding-site survey. NASA/USGS SRTM90m via Open Topo Data, public-domain USGS data; 500m systematic sample, not a flood model.

City boundaries: NAMRIA / OCHA HDX COD-AB, CC BY 3.0 IGO, geometry dated February 2025. Derived polygon areas are checked geodesically; 2020 population provenance remains unverified. Flood hazard and thermal-suitability curves are omitted because a usable licensed layer or verified parameterization was not established.

PAGASA climate definition: rainy June-November; dry December-May. CDC Aedes life cycle: container-breeding biology. These are context, not a prediction. Exact requests, retrieval dates and hashes: data/external/SOURCES.md.

Verified work, visible evidence

Audit snapshot: Oct 3, 2026. These figures describe checked records, not live conditions or unique cases.

Manila rows audited

2,230

Weekly, derived monthly and separate daily records; case totals are never added across sources.

Full-row verification

Matched

Snapshot verification compares every official row with audited source files.

Years represented

2016–2023

Source labels with gaps and partial periods preserved.

Latest data period

Dec 2, 2023

Historical source label, not a real-time update.

Manila coverage

Weekly records span Jan 10, 2016 to Jan 10, 2021; the separate daily series extends to Dec 2, 2023.

Weekly
2016–2021
Daily
2018–2023

ⓘ Hatching means no source row; zero versus missing is unconfirmed; blank track lies outside that source’s coverage. Exact dates and counts follow.

Records	First label	Last label	Rows
Monthly (derived from weekly)	Jan 1, 2016	Jan 1, 2021	61
Weekly	Jan 10, 2016	Jan 10, 2021	259
Manila daily	Jan 1, 2018	Dec 2, 2023	1,910
Evaluation under both absent-day scenarios

The replacement Manila harness uses 2016–2023 history, persistence, regularized models and lagged weather. Both zero-assumed and missing-day scenarios are evaluated. Weather did not improve the matched one/two-week ridge comparisons.

Read the model evidence and limits
Data notes · 5 notes
Source attribution awaiting review

DOH/FOI citation fields still require source-owner review where marked unavailable, unconfirmed or pending. This is a research application, not an official DOH service.

Manila monthly (derived)

[exact citation pending]

Title
NCR Dengue Monthly with Rates (ncr_dengue_monthly_with_rates.csv)
Issuing office
Derived from the NCR weekly DOH file; not an independent source
Date obtained
Not available
FOI request ID
Not available
URL
not public
Usage terms
Not stated
Data & Sources
Source checksum (SHA-256)
Manila weekly

[exact citation pending]

Title
DOH EPI Dengue Data 2016-2021 (doh-epi-dengue-data-2016-2021.csv), filtered to National Capital Region
Issuing office
Department of Health (specific office not confirmed)
Date obtained
Not available
FOI request ID
Not available
URL
not public
Usage terms
Not stated
Data & Sources
Source checksum (SHA-256)
Manila daily

[exact citation pending]

Title
Daily Reported Cases of Dengue in the City of Manila, 2018 to 2023 (workbook)
Issuing office
City of Manila (specific office not confirmed)
Date obtained
Not available
FOI request ID
Not available
URL
not public
Usage terms
Not stated
Data & Sources
Source checksum (SHA-256)
Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## terms / 360px

Route: `/terms`; UTC 2026-10-25T03:41:26.515Z; screenshot `terms-360.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Menu
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details

USING DENGUEWATCH

Terms with a clear purpose.

Educational/research prototype; draft for review.

Draft for review. Not legal advice. Version legal-v2 · 2026-10-25

Terms of Use

DengueWatch is an educational/research prototype, not an official DOH service. Published histories, forecasts and legacy risk labels may be incomplete, delayed or unavailable. Estimates describe historical source labels; they do not establish current conditions.

Do not rely on the app for diagnosis, treatment, emergency decisions or outbreak declarations. Follow DOH/local health-office guidance and qualified clinical advice. Community reports, if collection later opens, remain unverified and separate from official records.

Acceptable use

Do not submit fabricated or repeated reports, other people's personal information, attempt to identify people from aggregates, probe private records, bypass access controls or disrupt the service. Reporting requires voluntary consent and truthful self-reporting. No medical monitoring or personal reply is promised.

Availability and liability — lawyer review required

The prototype is provided without a promise of uninterrupted availability, completeness or fitness for a particular purpose. Proposed limitation of liability: to the extent permitted by applicable law, the research operators would limit responsibility for losses arising from reliance on the prototype. This proposed clause requires lawyer review; it does not waive statutory rights or establish an enforceable liability limit.

Respect source usage terms and attribution; permission to redistribute or reuse supplied files has not been established by a placeholder citation. Data Sources & Attribution · Privacy Notice.

Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## legal / 360px

Route: `/legal`; UTC 2026-10-25T03:41:27.923Z; screenshot `legal-360.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Menu
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details

REVIEW DRAFTS

Legal and privacy notices

Draft notices describing this research prototype and its current closed collection.

Privacy · Terms · Forecast disclaimer · Sources · Model transparency · Cookies/storage

Draft for review. Not legal advice. Version legal-v2 · 2026-10-25

Privacy Notice
What happens today

Public browsing does not require an account. Community submissions are closed. No analytics or advertising SDKs are installed. The app sets no cookies. Only a language preference is stored in localStorage; reports and withdrawal codes are never stored in browser storage. Fonts and app code are served with the app; the dated official-data snapshot is fetched from the same site and held in memory. Your browser may cache public files.

Public research pages and the NCR map use same-origin files with self-hosted fonts. Reporting, withdrawal and legacy source auditing can send requests to Supabase. No external map tiles are requested. These providers can receive IP addresses, browser/request information, requested paths and timestamps. The provider-default labels below do not establish a verified duration. Their logging settings, processing locations and retention require provider/owner verification; we do not promise that no technical logs exist. Technical-log retention: Per hosting provider default (Vercel/Supabase). Provider backup retention: Per provider default (Supabase). Offline mode blocks report mutations; previously cached public research files can remain available.

Supabase access uses a public anonymous API key, not a user account. Session persistence and automatic auth refresh are disabled. The withdrawal form can send a private code to Supabase when online; it is not a public lookup and returns the same result regardless of a matching report. Offline withdrawal is unavailable.

If reporting opens after review

The v2 form collects an optional coarse Manila area, symptom-onset date, optional symptoms and a short sanitized note, consent/version and submission time. No name, contact field, precise location or application IP field is collected. Pattern-based PII removal is imperfect; do not include identifying information. The database records consent, moderation/withdrawal state and a one-way hash of the private DW2- withdrawal code. Do not provide names, exact addresses, patient identifiers or someone else's information.

Individual health information is sensitive personal information under RA 10173 §3(l)(2). Intended purposes are voluntary research into broad community patterns; reports are not verified clinical records, medical advice or official surveillance. The consent text and lawful basis require lawyer/school DPO review before collection opens. RA 10173, published by the NPC.

Sharing and retention

Appointed moderators and administrators can review individual reports. Supabase processes the records for the app; no individual report content is intended for sale, advertising or third parties' own use. The v2 public area/week counts require at least three approved reports and a minimum 72-hour publication delay. Legacy submission entrypoints are closed by the pending v2 migration. Suppression reduces exposure but does not guarantee anonymity. Community reports are excluded from official series, forecasts and the public demo snapshot.

Community-report launch retention: Not applicable, form closed. The existing database is configured for 90 days, with an hourly expiry purge; that earlier setting must be reconfirmed in the launch review. V2 withdrawal immediately removes a matching active report from aggregates and clears note, symptoms and area; legacy DW- withdrawal clears optional contact and barangay text. Remaining structured fields persist until expiry/purge. Provider backups follow a separate lifecycle; application deletion does not promise immediate backup deletion.

Your rights and contact

You may request information/access, correction, objection, erasure or withdrawal, subject to applicable law and appropriate identity verification. Save your DW- or DW2- code: it permits withdrawal, not record retrieval. There is no public code recovery. Lost-code access/correction requests need a DPO-reviewed process that avoids exposing another person's record. Withdrawal by code.

Personal information controller: DengueWatch student research team, University Perpetual Help College of Manila. Controller contact: achilleslang23@gmail.com. This is the owner-supplied research contact; a DPO appointment is not confirmed. You can also review your rights and complaint options with the National Privacy Commission.

Draft for review. Not legal advice. Version legal-v2 · 2026-10-25

Terms of Use

DengueWatch is an educational/research prototype, not an official DOH service. Published histories, forecasts and legacy risk labels may be incomplete, delayed or unavailable. Estimates describe historical source labels; they do not establish current conditions.

Do not rely on the app for diagnosis, treatment, emergency decisions or outbreak declarations. Follow DOH/local health-office guidance and qualified clinical advice. Community reports, if collection later opens, remain unverified and separate from official records.

Acceptable use

Do not submit fabricated or repeated reports, other people's personal information, attempt to identify people from aggregates, probe private records, bypass access controls or disrupt the service. Reporting requires voluntary consent and truthful self-reporting. No medical monitoring or personal reply is promised.

Availability and liability — lawyer review required

The prototype is provided without a promise of uninterrupted availability, completeness or fitness for a particular purpose. Proposed limitation of liability: to the extent permitted by applicable law, the research operators would limit responsibility for losses arising from reliance on the prototype. This proposed clause requires lawyer review; it does not waive statutory rights or establish an enforceable liability limit.

Respect source usage terms and attribution; permission to redistribute or reuse supplied files has not been established by a placeholder citation. Data Sources & Attribution · Privacy Notice.

Draft for review. Not legal advice. Version legal-v2 · 2026-10-25

Forecast & Medical Disclaimer

Forecasts are statistical estimates from historical published data. They are not medical advice, emergency or outbreak alerts, diagnoses, individual infection probabilities, or substitutes for DOH/local health-office guidance. Seek qualified clinical care for health concerns; do not wait for an app forecast.

The Manila research harness evaluates one, two and exploratory four-week case estimates through 2023 under both absent-day scenarios. The public historical forecast uses persistence; weather did not improve the matched 1–2 week ridge comparisons. Nominal prediction intervals are imperfectly calibrated and do not guarantee coverage. COVID-period reporting is distorted; 2020–2021 are reported separately, alongside 2018, 2019, 2022 and 2023 test folds. Model comparisons do not establish present-day performance or season-level outbreak prediction.

Archived monthly risk labels are historical distribution categories, not clinical warning thresholds in the current public site. Monthly and weekly sources overlap and must not be added; Manila daily observations are a separate series. Raw absence remains unknown; Scenario M preserves missing values and Scenario Z explicitly assumes zero within coverage. Community reports are unverified and never part of official data or model training.

Draft for review. Not legal advice. Version legal-v2 · 2026-10-25

Data Sources & Attribution

DOH/FOI attribution fields await source-owner verification. Pending fields do not establish reuse permission.

NCR monthly

[exact citation pending]

Title
NCR Dengue Monthly with Rates (ncr_dengue_monthly_with_rates.csv)
Issuing office
Derived from the NCR weekly DOH file; not an independent source
Date obtained
Not available
FOI request ID
Not available
URL
not public
Usage terms
Not stated
Data & Sources
NCR weekly

[exact citation pending]

Title
DOH EPI Dengue Data 2016-2021 (doh-epi-dengue-data-2016-2021.csv), filtered to National Capital Region
Issuing office
Department of Health (specific office not confirmed)
Date obtained
Not available
FOI request ID
Not available
URL
not public
Usage terms
Not stated
Data & Sources
Manila daily only

[exact citation pending]

Title
Daily Reported Cases of Dengue in the City of Manila, 2018 to 2023 (workbook)
Issuing office
City of Manila (specific office not confirmed)
Date obtained
Not available
FOI request ID
Not available
URL
not public
Usage terms
Not stated
Data & Sources

Draft for review. Not legal advice. Version legal-v2 · 2026-10-25

Model Transparency

Both absent-day scenarios, rolling-origin results and negative weather findings are available in the methodology.

Open the model methodology and evidence

Draft for review. Not legal advice. Version legal-v2 · 2026-10-25

Cookie/Storage Notice

The app sets no cookies. A language preference is stored in localStorage; no reports, contact details or withdrawal codes are stored there or in sessionStorage. The browser may cache public fonts, scripts and the demo snapshot. Report inputs and the original withdrawal code remain in memory for the current page/session; copying the code uses the clipboard only at your request. No tracking or consent banner is added. Provider technical logs are described in the Privacy Notice.

Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## admin-login / 360px

Route: `/admin`; UTC 2026-10-25T03:41:29.444Z; screenshot `admin-login-360.jpg`. Actual isolated local production page

Skip to admin content
DengueWatch / Staff
Staff sign in

Separate from public pages. Collection remains closed until the owner separately authorizes launch.

Staff email
Password
Sign in

No shared demo password or public self-enrollment. An owner-appointed server role is required.

## moderation-access-gate / 360px

Route: `/admin/moderation`; UTC 2026-10-25T03:41:30.794Z; screenshot `moderation-access-gate-360.jpg`. NOT VERIFIED: requested staff workflow is protected; actual captured screen is signed-out login. No session or records invented.

Skip to admin content
DengueWatch / Staff
Staff sign in

Separate from public pages. Collection remains closed until the owner separately authorizes launch.

Staff email
Password
Sign in

No shared demo password or public self-enrollment. An owner-appointed server role is required.

## upload-access-gate / 360px

Route: `/admin/data`; UTC 2026-10-25T03:41:32.108Z; screenshot `upload-access-gate-360.jpg`. NOT VERIFIED: requested staff workflow is protected; actual captured screen is signed-out login. No session or records invented.

Skip to admin content
DengueWatch / Staff
Staff sign in

Separate from public pages. Collection remains closed until the owner separately authorizes launch.

Staff email
Password
Sign in

No shared demo password or public self-enrollment. An owner-appointed server role is required.

## home / 1280px

Route: `/`; UTC 2026-10-25T03:41:33.703Z; screenshot `home-1280.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Home
Trends
Metro Manila
Prevention
Methodology
Community reports: opening soon
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details
English
Filipino

MANILA / DENGUEWATCH RESEARCH

Know the evidence. Take care early.

Manila dengue history, tested forecasts, and clear limits on what the data can tell us.

CURRENT STATUS

◇ Current risk unavailable

The latest reliable complete-row week ends 2023-11-26; these historical records cannot establish current risk.

Last recorded day: 2023-12-02 · Historical records only

Remove standing water, protect yourself from mosquito bites, and seek early consultation for symptoms.

Prevention & warning signs
Report a case · collection closed
Seasonal watch: context only

PAGASA defines June to November as the rainy season. Clear containers of standing water and keep up bite prevention. This is seasonal context, not a dengue prediction or alert.

Dengue observations remain historical; current weather cannot establish today's dengue risk.

In complete-row history for 2016-2023 (Scenario M), mean weekly cases ranged from 22.8 in May to 122.1 in September. This does not measure a delay from rainfall onset to rising cases.

Weather is seasonal context only; showing baseline forecast. Dengue observations remain historical. Weather as of: 2026-10-11.

PAGASA season definition
What do the forecasts show?

These are historical statistical estimates, not current alerts or outbreak predictions.

Absent-day scenario
M · absent dates remain missing
Z · absent dates assumed zero

Only weeks with seven daily rows are scored. An absent date is not a recorded zero. The final partial week is excluded in both scenarios.

Historical Manila forecast

Origin 2023-11-26 · manila-persistence-v2 · Community reports excluded

Target week	Horizon	Cases estimate	80% interval	Probability of rise
2023-12-03	1 week(s)	62	40–84	42.7%
2023-12-10	2 week(s)	62	31–93	39.1%

Persistence uses the latest available weekly count. Intervals use earlier out-of-sample errors and are not guarantees. Source: Manila daily workbook; as of 2023-11-26.

Weather was tested, not assumed.

Expanded season and weather tests did not establish a reliable one- to two-week gain over last-week persistence in either scenario. The public forecast keeps the simpler baseline.

Read the measured results and methodology →
Manila trends

2016–2023 · source bands, missing weeks, and COVID context

Explore the history →
Metro Manila history

Data ends January 2021. No live NCR forecast.

Compare the cities →
Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## trends / 1280px

Route: `/trends`; UTC 2026-10-25T03:41:35.425Z; screenshot `trends-1280.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Home
Trends
Metro Manila
Prevention
Methodology
Community reports: opening soon
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details

HISTORY / MANILA ONLY

Trends with their context.

Different source periods, missing observations, and pandemic disruption remain visible.

Absent-day scenario
M · absent dates remain missing
Z · absent dates assumed zero

Only weeks with seven daily rows are scored. An absent date is not a recorded zero. The final partial week is excluded in both scenarios.

History year
All years · 2016–2023
2016
2017
2018
2019
2020
2021
2022
2023
Weekly recorded cases
0
64
129
193
257
COVID period
2016-01-10
2023-12-03
Weekly cases · gaps remain gaps
Source changes
DOH EPI before 2018; Manila daily-derived weeks from 2018. COVID period shaded (2020–2021). Source dates end 2023-12-02; final partial week excluded. Sunday labels operationally interpreted as week-ending; source semantics unconfirmed.
Exact weekly values and quality flags
Year comparison

Totals cover available scenario-defined weeks, not necessarily complete years. Never add source representations together.

Year	Cases in available weeks	Available / calendar weeks
2016	1,990 · incomplete	45 / 51
2017	2,813	53 / 53
2018	3,530 · incomplete	47 / 52
2019	3,761 · incomplete	43 / 52
2020	451 · incomplete	13 / 52
2021	883 · incomplete	24 / 52
2022	2,516 · incomplete	42 / 52
2023	2,346 · incomplete	45 / 49

DOH EPI 2016–2017; Manila daily-derived 2018–2023. As of 2023-12-02.

Historical forecast and interval

Origin 2023-11-26. Exploratory four-week forecasts have larger error; they are not operational warnings.

1 week
2 weeks
4 weeks
Cases · historical estimates, not current alerts
0
110
Source: Manila daily-derived weekly series; origin 2023-11-26. Dot = estimate, vertical bar = nominal 80% interval. Four weeks is exploratory. Scroll the chart if needed; exact values follow.
Target	Horizon	Forecast cases	80% interval
2023-12-03	1 weeks	62	40–84
2023-12-10	2 weeks	62	31–93
2023-12-24	4 weeks · exploratory	62	14–110

Source: daily-derived Manila series. manila-persistence-v2; interval calibration uses earlier observed out-of-sample errors only. Not current risk.

Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## metro-history / 1280px

Route: `/metro-manila`; UTC 2026-10-25T03:41:37.106Z; screenshot `metro-history-1280.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Home
Trends
Metro Manila
Prevention
Methodology
Community reports: opening soon
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details

METRO MANILA / HISTORICAL

A city-level historical comparison.
Data ends January 2021. No current NCR forecast is shown. Missing weeks are not zero.
Metro Manila context, not a prediction

Aedes aegypti mainly breeds in small standing-water containers near homes: drums, tires, pots and clogged drains. Flowing rivers are not its principal breeding habitat. Geographic proxies cannot identify a household at risk.

Show exploratory city context
Comparison period
Year totals (available weeks)
One source week
Historical year
2016
2017
2018
2019
2020
2021

Population denominator unverified; confirm against PSA 2020 census. All rates use the same supplied 2020 denominator, including earlier years. No district or barangay case counts are inferred.

Recorded incidence per 100,000

Darker blue means a larger historical rate in this selection. It does not identify current risk. Gray means no source observation, not zero. Exact values appear in the ranking table.

MANILA CITY: 689 recorded cases; 37.3 per 100,000; 51 source week(s).

Cases: DOH EPI, 2020; as of 2021-01-10. Boundaries: NAMRIA/PSA via OCHA HDX, CC BY 3.0 IGO, valid 2025-02-13; not proven historical boundaries. Boundary source.

City ranking · 2020
City / municipality	Recorded cases	Per 100,000	Source weeks
PATEROS	129	197.8	51
MALABON CITY	371	97.5	51
NAVOTAS CITY	188	75.9	51
PASIG CITY	596	74.2	51
TAGUIG CITY	634	71.5	51
PARANAQUE CITY	438	63.5	51
VALENZUELA CITY	420	58.7	51
MARIKINA CITY	263	57.7	51
QUEZON CITY	1,654	55.9	51
MAKATI CITY	319	50.7	51
LAS PINAS CITY	295	48.7	51
MANDALUYONG CITY	198	46.5	51
CALOOCAN CITY	652	39.2	51
MANILA CITY	689	37.3	51
SAN JUAN CITY	46	36.4	51
MUNTINLUPA CITY	179	32.9	51
PASAY CITY	112	25.4	51

DOH EPI weekly source, ending January 2021. 2021 is January only. Calendar gaps and partial years make totals incomplete.

Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## prevention / 1280px

Route: `/prevention`; UTC 2026-10-25T03:41:38.683Z; screenshot `prevention-1280.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Home
Trends
Metro Manila
Prevention
Methodology
Community reports: opening soon
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details
English
Filipino

PREVENTION / EVERYDAY CARE

Small actions. Everyday protection.

Informational, not a diagnosis.

The DOH 4S strategy
Find and remove mosquito breeding places, including water-holding containers.
Use protective clothing and mosquito repellent.
Seek early consultation when symptoms appear.
Support fogging or spraying in identified hotspots under health-office guidance.

DOH Central Visayas · 4S guidance · Checked 2026-10-25.

Warning signs need urgent care

Go to a clinic or emergency room immediately for abdominal pain or tenderness, repeated vomiting, nose or gum bleeding, blood in vomit or stool, or extreme tiredness or restlessness. Warning signs can begin after fever subsides.

Do not wait for an app risk level or report confirmation before seeking care.

CDC · dengue symptoms and warning signs · Checked 2026-10-25.

Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## report-closed / 1280px

Route: `/report`; UTC 2026-10-25T03:41:40.052Z; screenshot `report-closed-1280.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Home
Trends
Metro Manila
Prevention
Methodology
Community reports: opening soon
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details
English
Filipino

COMMUNITY / UNVERIFIED

Share an awareness signal.

No account, name, phone number or exact address is requested. Do not put identifying details in notes. Reports never enter official counts or forecasts.

New submissions are not open yet.

Collection status could not be confirmed; reporting stays closed. Retry status

Understand and consent

Your optional health report is sensitive personal information. It supports research and coarse community awareness, not diagnosis, emergency response or validated prediction.

Only staff can review individual reports. Public counts require staff approval, a 72-hour delay and at least three reports per area/week. Reports are removed after 90 days; withdraw sooner with your private code.

Please report only your own experience. Do not include anyone’s identity or address. Privacy and withdrawal.

I voluntarily consent to this research use of my report under community-v2.
Continue to report

Controller: DengueWatch student research team. Contact: achilleslang23@gmail.com. Notice requires DPO review before collection opens.

View community aggregates · Prevention and urgent warning signs

Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## community / 1280px

Route: `/community`; UTC 2026-10-25T03:41:41.343Z; screenshot `community-1280.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Home
Trends
Metro Manila
Prevention
Methodology
Community reports: opening soon
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details

COMMUNITY / UNVERIFIED

Community reports, kept separate.

Collection remains closed. These are community-reported, unverified awareness signals, never official dengue counts or forecast inputs. Staff approval is a content review, not medical verification.

Publication requires at least three approved reports per area/week and a minimum 72-hour delay. Missing or suppressed groups do not mean zero cases. There is no validation history establishing predictive value.

The data service is not configured yet. Please try again later.

Try again
Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## methodology / 1280px

Route: `/methodology`; UTC 2026-10-25T03:41:42.682Z; screenshot `methodology-1280.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Home
Trends
Metro Manila
Prevention
Methodology
Community reports: opening soon
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details

METHODS / EVIDENCE BEFORE CLAIMS

What was tested. What remains uncertain.

We study Manila city one to two weeks ahead, compare with last-week persistence, and keep community reports outside official counts and models. Four weeks is exploratory.

Season and weather: controlled ablation

AR(2) log1p ridge, fixed L2=20, standardization from each training prefix only; >=32 training pairs. COVID indicator in all AR variants. Lag selection frozen from 2016-2017 only; no 2017 calibration scores reused.

All six methods share identical origin/target rows within scenario/horizon. M gaps remain missing. Frozen selected lags yield more M pairs than the prior 8-lag main harness: these are different comparison cohorts.

Environmental scenario
M: absent dates missing
Z: absent dates zero-assumed
Environmental fold
test-2018-2023
2018
2019
2020
2021
2022
2023
covid-2020-2021
Environmental horizon
1 week
2 week
4 week (exploratory)
Model	N	MAE	RMSE	MASE	Skill vs persistence % (95% CI)	Alert precision / recall	False positive rate	80% coverage
naive	166	14.024	20.335	1.139	0 (0 to 0)	72.1% / 68.9%	11.9%	82.9%
env-ar	166	15.072	21.994	1.23	-7.47 (-18.21 to 6.15)	75.6% / 75.6%	10.9%	83.6%
env-season	166	14.343	20.756	1.168	-2.27 (-13.29 to 9.35)	74.5% / 77.8%	11.9%	87%
env-weather	166	15.185	21.738	1.228	-8.28 (-22.97 to 3.94)	75.6% / 68.9%	9.9%	84.2%
env-season-weather	166	14.914	21.478	1.21	-6.35 (-18.58 to 5.65)	78% / 71.1%	8.9%	87.7%
env-season-weather-no-engineered	166	14.826	21.087	1.201	-5.72 (-18.59 to 5.88)	80.5% / 73.3%	7.9%	87%

Training-only choices through 2017-12-31: rainfall lag 3, temperature lag 1, humidity lag 3, rainfall window 8 weeks. Lags are before the forecast origin, never future weather. Correlations are season-confounded, not causal.

Season adds June-November flag and sin/cos; weather adds selected rainfall, temperature and humidity lags, selected rainfall window, >=1mm rain days and weekly temperature min/max at lag 1. Combined adds a fixed research cumulative-200mm onset proxy, not PAGASA onset. No-engineered combined variant drops rainfall roll/rain-day/min/max/onset engineering.

Optional thermal index omitted: no verified parameter curve is implemented; never labelled tested.

Only prior out-of-sample targets matured by each origin. Calibration starts in 2018; first 20 matured rows have unavailable probabilities and intervals.

NASA POWER cross-check

469 paired weeks: rainfall Pearson r 0.575, temperature r 0.866. Weekly rainfall MAE 35.04 mm; mean-temperature MAE 2.28 Celsius. ERA5 Asia/Manila civil days versus NASA POWER LST solar-swath days; weekly boundaries may differ. Neither source is a rain gauge. ERA5 is about 25 km; NASA meteorology about 0.5 by 0.625 degrees. One Manila point cannot resolve city or household weather.

Historical monthly profile

Sunday week-ending month, 2016-2023. This descriptive profile uses the test-period history too; it never selects forecasting lags or thresholds. It is not a measured rainy-onset response delay.

Month	Scorable weeks	Mean cases/week	Complete-row subset N	Complete-row mean
1	26	53.81	26	53.81
2	29	43.69	29	43.69
3	28	29.39	28	29.39
4	20	27.2	20	27.2
5	21	22.81	21	22.81
6	23	29.96	23	29.96
7	30	49.6	30	49.6
8	24	95.25	24	95.25
9	25	122.12	25	122.12
10	31	92.77	31	92.77
11	29	72.07	29	72.07
12	26	49.85	26	49.85
Primary threshold episode lead
Model	Eligible onsets	Detected	Mean lead (weeks)
naive	14	5	2
env-ar	14	5	2
env-season	14	6	2
env-weather	14	5	1.8
env-season-weather	14	7	1.71
env-season-weather-no-engineered	14	7	1.71

Both 1/2-week horizons; onset requires an observed previous below-threshold week. No outbreak diagnosis. Source: versioned ERA5, NASA POWER and Manila files; disease data ends December 2023. Full alert F1/AUC/Brier, coefficients and figures are in docs/ENVIRONMENT_RESULTS.md and docs/figures.

Does a date with no row mean zero cases or no report?

The workbook does not answer. Scenario Z assumes zero inside coverage; Scenario M excludes incomplete daily-row weeks. We evaluate both. No absence is silently turned into zero in M. Partial boundary weeks are excluded in both.

DOH weekly data provides 2016–2017; daily-derived weekly data begins January 2018. The Sunday week-ending interpretation of DOH labels is operational and unconfirmed. Observed-week overlap has 151 pairs and a mean absolute difference of 13.5960 cases. Including five blank weeks under Z gives 156 pairs and MAE 13.2244; seven-row weeks give 104 pairs. Close totals do not mean matching weeks.

Source citations and 2020 NCR population provenance still need owner review. Detailed source audit.

Absent-day scenario
M · absent dates remain missing
Z · absent dates assumed zero

Only weeks with seven daily rows are scored. An absent date is not a recorded zero. The final partial week is excluded in both scenarios.

Evaluation fold
All test years · 2018–2023
2018
2019
2020
2021
2022
2023
COVID years · 2020–2021
Forecast horizon
1 week
2 weeks
4 weeks · exploratory
Forecast comparison

Expanding-window rolling origins; no random split. Same scored targets for every method within each scenario. The 2017 development candidate was frozen before 2018–2023 testing. The public display conservatively uses persistence because one/two-week gains remain inconclusive; that promotion choice is post-evaluation, not preregistered.

Model	N	MAE	RMSE	MASE	Skill vs last week	95% skill CI	80% coverage
naive	116	15.474	22.419	1.271	0%	0 to 0%	75%
mean-4	116	21.97	29.328	1.789	-42%	-64.2 to -20.6%	70.7%
seasonal-naive	116	34.362	45.194	2.803	-122.1%	-193.2 to -78.1%	66.4%
endemic-channel	116	28.793	38.387	2.342	-86.1%	-144.8 to -46.7%	68.1%
ridge-cases	116	16.356	23.169	1.348	-5.7%	-22.1 to 7.2%	75.9%
ridge-weather	116	18.39	25.361	1.51	-18.8%	-40.8 to -4.7%	78.4%
ridge-no-rain	116	17.684	24.399	1.458	-14.3%	-32.9 to -0.2%	79.3%
ridge-no-temperature	116	18.755	25.556	1.539	-21.2%	-43 to -6.4%	78.4%
ridge-no-humidity	116	17.625	24.6	1.441	-13.9%	-33.5 to -0.9%	77.6%
tree-cases	116	29.267	45.359	2.403	-89.1%	-140.6 to -36.8%	78.4%
tree-weather	116	29.394	45.503	2.414	-90%	-141.2 to -38.4%	77.6%

Sources: immutable DOH / Manila daily inputs, ERA5 grid estimates. Test targets through 2023-11-26; version manila-evaluation-v2. MASE uses training-only mean adjacent-week persistence error. Bootstrap: 400 paired resamples in blocks of eight observed targets; gaps mean blocks are not always eight calendar weeks.

Did weather help?

Case-only ridge MAE: 16.356. Weather ridge MAE: 18.39. Weather did not improve this matched comparison.

Across the full 2018–2023 test, weather worsens ridge at one and two weeks in both Z and M. ERA5 is retrospective reanalysis, not station gauges or historical operational vintages. Weekly rain, temperature and humidity enter only at lags 1–8, with at least seven days of availability lag. Constants such as population and density cannot predict change within Manila.

Leave-one-driver-out ridge and cases/weather tree variants appear in the same table. Importances and correlations are not causal explanations. No deep learning: fewer than 500 weekly observations.

Descriptive driver fits
Descriptive driver model
Weather ridge coefficients
Weather tree split gains

These summarize a final training fit, not out-of-sample attribution or causal effects. Correlation and importance do not establish causation.

Origin 2023-11-26 · Coefficients on training-standardized features predicting log1p cases, descriptive only

Feature names and fitted values
Research alerts, not outbreak declarations

90th percentile of previous-year cases within ±2 ordinal calendar weeks of target; at least 5 observations, past data only. Research threshold, not a DOH outbreak declaration.

Alert probabilities use matured out-of-sample residuals. The endemic-channel rule uses the latest count crossing that threshold. These research signals do not establish current risk or replace official DOH guidance.

Model	Precision	Recall	F1	ROC-AUC	Brier	False-positive rate
naive	0.775	0.738	0.756	0.904	0.128	12.2%
endemic-channel	0.756	0.738	0.747	0.801	0.181	13.5%
ridge-weather	0.71	0.524	0.603	0.864	0.151	12.2%

Lead time is currently reported as the forecast horizon among correct positives; episode-based outbreak lead time has not been validated. Undefined metrics stay unavailable. Intervals can under-cover, especially in M and COVID years.

Research threshold-episode lead time

An eligible onset requires an above-threshold scored week preceded by an observed, consecutive calendar week at/below threshold. Gaps do not establish onset. Only one/two-week forecasts are counted here; this is not a medically confirmed outbreak measure. Missed eligible onsets remain in the denominator.

Model	Eligible onsets	Detected	Mean lead (weeks)
naive	9	3	2
mean-4	9	3	2
seasonal-naive	9	3	2
endemic-channel	9	5	2
ridge-cases	9	3	2
ridge-weather	9	5	2
tree-cases	9	3	1.7
tree-weather	9	3	1.7
Known limits
Daily zero/missing ambiguity unresolved
DOH week-ending semantics unconfirmed
Retrospective reanalysis is not real-time vintage data
Sparse alert events can make AUC/precision undefined
Probability of rise and alerts use empirical past residuals, not a separately validated clinical classifier
Mean lead is correct-positive forecast horizon, not episode-based outbreak lead time
Deaths anomalies flagged and excluded in DOH case training under existing policy
No deep learning: fewer than 500 weekly observations per scenario
No current 2026 surveillance; all forecasts historical

Training-only standardization, fixed L2=20, log1p target, no lognormal bias correction, >=32 training examples. Rain uses log1p(mm); temperature Celsius; humidity percent; lags 1-8 before origin; case lags 0-3 and annual harmonics + COVID indicator.

24 gradient-boosted stumps, learning rate .05, minimum leaf 16, 7 training-only quantile split candidates, L2 leaf=10, log1p target. Fixed, no tuning on test folds.

80% absolute-residual conformal radius with finite-sample rank; at least 20 matured out-of-sample targets by origin. No coverage guarantee under drift.

Community reports are an unverified awareness layer only. Their predictive value is future work; there is no validation history.

Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## privacy / 1280px

Route: `/privacy`; UTC 2026-10-25T03:41:44.179Z; screenshot `privacy-1280.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Home
Trends
Metro Manila
Prevention
Methodology
Community reports: opening soon
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details

YOUR INFORMATION

Privacy, in plain language.

Voluntary participation, minimal collection, and a clear way to withdraw.

Collection remains closed. The v2 notice describes coarse area, symptom-onset date, optional symptoms and a sanitized note, with 90-day retention. Only approved groups of at least three are eligible for publication after 72 hours. Provider logs and backups require separate DPO review.

Draft for review. Not legal advice. Version legal-v2 · 2026-10-25

Privacy Notice
What happens today

Public browsing does not require an account. Community submissions are closed. No analytics or advertising SDKs are installed. The app sets no cookies. Only a language preference is stored in localStorage; reports and withdrawal codes are never stored in browser storage. Fonts and app code are served with the app; the dated official-data snapshot is fetched from the same site and held in memory. Your browser may cache public files.

Public research pages and the NCR map use same-origin files with self-hosted fonts. Reporting, withdrawal and legacy source auditing can send requests to Supabase. No external map tiles are requested. These providers can receive IP addresses, browser/request information, requested paths and timestamps. The provider-default labels below do not establish a verified duration. Their logging settings, processing locations and retention require provider/owner verification; we do not promise that no technical logs exist. Technical-log retention: Per hosting provider default (Vercel/Supabase). Provider backup retention: Per provider default (Supabase). Offline mode blocks report mutations; previously cached public research files can remain available.

Supabase access uses a public anonymous API key, not a user account. Session persistence and automatic auth refresh are disabled. The withdrawal form can send a private code to Supabase when online; it is not a public lookup and returns the same result regardless of a matching report. Offline withdrawal is unavailable.

If reporting opens after review

The v2 form collects an optional coarse Manila area, symptom-onset date, optional symptoms and a short sanitized note, consent/version and submission time. No name, contact field, precise location or application IP field is collected. Pattern-based PII removal is imperfect; do not include identifying information. The database records consent, moderation/withdrawal state and a one-way hash of the private DW2- withdrawal code. Do not provide names, exact addresses, patient identifiers or someone else's information.

Individual health information is sensitive personal information under RA 10173 §3(l)(2). Intended purposes are voluntary research into broad community patterns; reports are not verified clinical records, medical advice or official surveillance. The consent text and lawful basis require lawyer/school DPO review before collection opens. RA 10173, published by the NPC.

Sharing and retention

Appointed moderators and administrators can review individual reports. Supabase processes the records for the app; no individual report content is intended for sale, advertising or third parties' own use. The v2 public area/week counts require at least three approved reports and a minimum 72-hour publication delay. Legacy submission entrypoints are closed by the pending v2 migration. Suppression reduces exposure but does not guarantee anonymity. Community reports are excluded from official series, forecasts and the public demo snapshot.

Community-report launch retention: Not applicable, form closed. The existing database is configured for 90 days, with an hourly expiry purge; that earlier setting must be reconfirmed in the launch review. V2 withdrawal immediately removes a matching active report from aggregates and clears note, symptoms and area; legacy DW- withdrawal clears optional contact and barangay text. Remaining structured fields persist until expiry/purge. Provider backups follow a separate lifecycle; application deletion does not promise immediate backup deletion.

Your rights and contact

You may request information/access, correction, objection, erasure or withdrawal, subject to applicable law and appropriate identity verification. Save your DW- or DW2- code: it permits withdrawal, not record retrieval. There is no public code recovery. Lost-code access/correction requests need a DPO-reviewed process that avoids exposing another person's record. Withdrawal by code.

Personal information controller: DengueWatch student research team, University Perpetual Help College of Manila. Controller contact: achilleslang23@gmail.com. This is the owner-supplied research contact; a DPO appointment is not confirmed. You can also review your rights and complaint options with the National Privacy Commission.

Withdraw a report

Enter your reference code to request deletion. You do not need an account.

Reference code

Do not include a name, contact address, or report details.

Request withdrawal
Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## data-sources / 1280px

Route: `/data-sources`; UTC 2026-10-25T03:41:45.507Z; screenshot `data-sources-1280.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Home
Trends
Metro Manila
Prevention
Methodology
Community reports: opening soon
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details

PUBLISHED DATA, CHECKED

Data confidence

Trace Manila’s records from source files to charts and tested estimates.

Environmental and geographic providers

Open-Meteo Historical API: CC BY 4.0; contains modified Copernicus Climate Change Service information. ERA5 / ECMWF / Copernicus C3S reanalysis, about 0.25 degrees, not station gauges. One Manila point only.

NASA POWER acknowledgement: This data was obtained from the NASA Langley Research Center (LaRC) POWER Project funded through the NASA Earth Science/Applied Science Program.

NASA GMAO MERRA-2 supplies POWER meteorology. The daily cross-check uses solar LST, which differs from a civil timezone. No per-city weather is presented as real.

Copyright OpenStreetMap contributors; Open Database License (ODbL). City water proximity is a contemporary mapped-water proxy, not a breeding-site survey. NASA/USGS SRTM90m via Open Topo Data, public-domain USGS data; 500m systematic sample, not a flood model.

City boundaries: NAMRIA / OCHA HDX COD-AB, CC BY 3.0 IGO, geometry dated February 2025. Derived polygon areas are checked geodesically; 2020 population provenance remains unverified. Flood hazard and thermal-suitability curves are omitted because a usable licensed layer or verified parameterization was not established.

PAGASA climate definition: rainy June-November; dry December-May. CDC Aedes life cycle: container-breeding biology. These are context, not a prediction. Exact requests, retrieval dates and hashes: data/external/SOURCES.md.

Verified work, visible evidence

Audit snapshot: Oct 3, 2026. These figures describe checked records, not live conditions or unique cases.

Manila rows audited

2,230

Weekly, derived monthly and separate daily records; case totals are never added across sources.

Full-row verification

Matched

Snapshot verification compares every official row with audited source files.

Years represented

2016–2023

Source labels with gaps and partial periods preserved.

Latest data period

Dec 2, 2023

Historical source label, not a real-time update.

Manila coverage

Weekly records span Jan 10, 2016 to Jan 10, 2021; the separate daily series extends to Dec 2, 2023.

Weekly
2016–2021
Daily
2018–2023

ⓘ Hatching means no source row; zero versus missing is unconfirmed; blank track lies outside that source’s coverage. Exact dates and counts follow.

Records	First label	Last label	Rows
Monthly (derived from weekly)	Jan 1, 2016	Jan 1, 2021	61
Weekly	Jan 10, 2016	Jan 10, 2021	259
Manila daily	Jan 1, 2018	Dec 2, 2023	1,910
Evaluation under both absent-day scenarios

The replacement Manila harness uses 2016–2023 history, persistence, regularized models and lagged weather. Both zero-assumed and missing-day scenarios are evaluated. Weather did not improve the matched one/two-week ridge comparisons.

Read the model evidence and limits
Data notes · 5 notes
Source attribution awaiting review

DOH/FOI citation fields still require source-owner review where marked unavailable, unconfirmed or pending. This is a research application, not an official DOH service.

Manila monthly (derived)

[exact citation pending]

Title
NCR Dengue Monthly with Rates (ncr_dengue_monthly_with_rates.csv)
Issuing office
Derived from the NCR weekly DOH file; not an independent source
Date obtained
Not available
FOI request ID
Not available
URL
not public
Usage terms
Not stated
Data & Sources
Source checksum (SHA-256)
Manila weekly

[exact citation pending]

Title
DOH EPI Dengue Data 2016-2021 (doh-epi-dengue-data-2016-2021.csv), filtered to National Capital Region
Issuing office
Department of Health (specific office not confirmed)
Date obtained
Not available
FOI request ID
Not available
URL
not public
Usage terms
Not stated
Data & Sources
Source checksum (SHA-256)
Manila daily

[exact citation pending]

Title
Daily Reported Cases of Dengue in the City of Manila, 2018 to 2023 (workbook)
Issuing office
City of Manila (specific office not confirmed)
Date obtained
Not available
FOI request ID
Not available
URL
not public
Usage terms
Not stated
Data & Sources
Source checksum (SHA-256)
Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## terms / 1280px

Route: `/terms`; UTC 2026-10-25T03:41:47.112Z; screenshot `terms-1280.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Home
Trends
Metro Manila
Prevention
Methodology
Community reports: opening soon
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details

USING DENGUEWATCH

Terms with a clear purpose.

Educational/research prototype; draft for review.

Draft for review. Not legal advice. Version legal-v2 · 2026-10-25

Terms of Use

DengueWatch is an educational/research prototype, not an official DOH service. Published histories, forecasts and legacy risk labels may be incomplete, delayed or unavailable. Estimates describe historical source labels; they do not establish current conditions.

Do not rely on the app for diagnosis, treatment, emergency decisions or outbreak declarations. Follow DOH/local health-office guidance and qualified clinical advice. Community reports, if collection later opens, remain unverified and separate from official records.

Acceptable use

Do not submit fabricated or repeated reports, other people's personal information, attempt to identify people from aggregates, probe private records, bypass access controls or disrupt the service. Reporting requires voluntary consent and truthful self-reporting. No medical monitoring or personal reply is promised.

Availability and liability — lawyer review required

The prototype is provided without a promise of uninterrupted availability, completeness or fitness for a particular purpose. Proposed limitation of liability: to the extent permitted by applicable law, the research operators would limit responsibility for losses arising from reliance on the prototype. This proposed clause requires lawyer review; it does not waive statutory rights or establish an enforceable liability limit.

Respect source usage terms and attribution; permission to redistribute or reuse supplied files has not been established by a placeholder citation. Data Sources & Attribution · Privacy Notice.

Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## legal / 1280px

Route: `/legal`; UTC 2026-10-25T03:41:48.431Z; screenshot `legal-1280.jpg`. Actual isolated local production page

Skip to content
DengueWatch
Home
Trends
Metro Manila
Prevention
Methodology
Community reports: opening soon
Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily). Details

REVIEW DRAFTS

Legal and privacy notices

Draft notices describing this research prototype and its current closed collection.

Privacy · Terms · Forecast disclaimer · Sources · Model transparency · Cookies/storage

Draft for review. Not legal advice. Version legal-v2 · 2026-10-25

Privacy Notice
What happens today

Public browsing does not require an account. Community submissions are closed. No analytics or advertising SDKs are installed. The app sets no cookies. Only a language preference is stored in localStorage; reports and withdrawal codes are never stored in browser storage. Fonts and app code are served with the app; the dated official-data snapshot is fetched from the same site and held in memory. Your browser may cache public files.

Public research pages and the NCR map use same-origin files with self-hosted fonts. Reporting, withdrawal and legacy source auditing can send requests to Supabase. No external map tiles are requested. These providers can receive IP addresses, browser/request information, requested paths and timestamps. The provider-default labels below do not establish a verified duration. Their logging settings, processing locations and retention require provider/owner verification; we do not promise that no technical logs exist. Technical-log retention: Per hosting provider default (Vercel/Supabase). Provider backup retention: Per provider default (Supabase). Offline mode blocks report mutations; previously cached public research files can remain available.

Supabase access uses a public anonymous API key, not a user account. Session persistence and automatic auth refresh are disabled. The withdrawal form can send a private code to Supabase when online; it is not a public lookup and returns the same result regardless of a matching report. Offline withdrawal is unavailable.

If reporting opens after review

The v2 form collects an optional coarse Manila area, symptom-onset date, optional symptoms and a short sanitized note, consent/version and submission time. No name, contact field, precise location or application IP field is collected. Pattern-based PII removal is imperfect; do not include identifying information. The database records consent, moderation/withdrawal state and a one-way hash of the private DW2- withdrawal code. Do not provide names, exact addresses, patient identifiers or someone else's information.

Individual health information is sensitive personal information under RA 10173 §3(l)(2). Intended purposes are voluntary research into broad community patterns; reports are not verified clinical records, medical advice or official surveillance. The consent text and lawful basis require lawyer/school DPO review before collection opens. RA 10173, published by the NPC.

Sharing and retention

Appointed moderators and administrators can review individual reports. Supabase processes the records for the app; no individual report content is intended for sale, advertising or third parties' own use. The v2 public area/week counts require at least three approved reports and a minimum 72-hour publication delay. Legacy submission entrypoints are closed by the pending v2 migration. Suppression reduces exposure but does not guarantee anonymity. Community reports are excluded from official series, forecasts and the public demo snapshot.

Community-report launch retention: Not applicable, form closed. The existing database is configured for 90 days, with an hourly expiry purge; that earlier setting must be reconfirmed in the launch review. V2 withdrawal immediately removes a matching active report from aggregates and clears note, symptoms and area; legacy DW- withdrawal clears optional contact and barangay text. Remaining structured fields persist until expiry/purge. Provider backups follow a separate lifecycle; application deletion does not promise immediate backup deletion.

Your rights and contact

You may request information/access, correction, objection, erasure or withdrawal, subject to applicable law and appropriate identity verification. Save your DW- or DW2- code: it permits withdrawal, not record retrieval. There is no public code recovery. Lost-code access/correction requests need a DPO-reviewed process that avoids exposing another person's record. Withdrawal by code.

Personal information controller: DengueWatch student research team, University Perpetual Help College of Manila. Controller contact: achilleslang23@gmail.com. This is the owner-supplied research contact; a DPO appointment is not confirmed. You can also review your rights and complaint options with the National Privacy Commission.

Draft for review. Not legal advice. Version legal-v2 · 2026-10-25

Terms of Use

DengueWatch is an educational/research prototype, not an official DOH service. Published histories, forecasts and legacy risk labels may be incomplete, delayed or unavailable. Estimates describe historical source labels; they do not establish current conditions.

Do not rely on the app for diagnosis, treatment, emergency decisions or outbreak declarations. Follow DOH/local health-office guidance and qualified clinical advice. Community reports, if collection later opens, remain unverified and separate from official records.

Acceptable use

Do not submit fabricated or repeated reports, other people's personal information, attempt to identify people from aggregates, probe private records, bypass access controls or disrupt the service. Reporting requires voluntary consent and truthful self-reporting. No medical monitoring or personal reply is promised.

Availability and liability — lawyer review required

The prototype is provided without a promise of uninterrupted availability, completeness or fitness for a particular purpose. Proposed limitation of liability: to the extent permitted by applicable law, the research operators would limit responsibility for losses arising from reliance on the prototype. This proposed clause requires lawyer review; it does not waive statutory rights or establish an enforceable liability limit.

Respect source usage terms and attribution; permission to redistribute or reuse supplied files has not been established by a placeholder citation. Data Sources & Attribution · Privacy Notice.

Draft for review. Not legal advice. Version legal-v2 · 2026-10-25

Forecast & Medical Disclaimer

Forecasts are statistical estimates from historical published data. They are not medical advice, emergency or outbreak alerts, diagnoses, individual infection probabilities, or substitutes for DOH/local health-office guidance. Seek qualified clinical care for health concerns; do not wait for an app forecast.

The Manila research harness evaluates one, two and exploratory four-week case estimates through 2023 under both absent-day scenarios. The public historical forecast uses persistence; weather did not improve the matched 1–2 week ridge comparisons. Nominal prediction intervals are imperfectly calibrated and do not guarantee coverage. COVID-period reporting is distorted; 2020–2021 are reported separately, alongside 2018, 2019, 2022 and 2023 test folds. Model comparisons do not establish present-day performance or season-level outbreak prediction.

Archived monthly risk labels are historical distribution categories, not clinical warning thresholds in the current public site. Monthly and weekly sources overlap and must not be added; Manila daily observations are a separate series. Raw absence remains unknown; Scenario M preserves missing values and Scenario Z explicitly assumes zero within coverage. Community reports are unverified and never part of official data or model training.

Draft for review. Not legal advice. Version legal-v2 · 2026-10-25

Data Sources & Attribution

DOH/FOI attribution fields await source-owner verification. Pending fields do not establish reuse permission.

NCR monthly

[exact citation pending]

Title
NCR Dengue Monthly with Rates (ncr_dengue_monthly_with_rates.csv)
Issuing office
Derived from the NCR weekly DOH file; not an independent source
Date obtained
Not available
FOI request ID
Not available
URL
not public
Usage terms
Not stated
Data & Sources
NCR weekly

[exact citation pending]

Title
DOH EPI Dengue Data 2016-2021 (doh-epi-dengue-data-2016-2021.csv), filtered to National Capital Region
Issuing office
Department of Health (specific office not confirmed)
Date obtained
Not available
FOI request ID
Not available
URL
not public
Usage terms
Not stated
Data & Sources
Manila daily only

[exact citation pending]

Title
Daily Reported Cases of Dengue in the City of Manila, 2018 to 2023 (workbook)
Issuing office
City of Manila (specific office not confirmed)
Date obtained
Not available
FOI request ID
Not available
URL
not public
Usage terms
Not stated
Data & Sources

Draft for review. Not legal advice. Version legal-v2 · 2026-10-25

Model Transparency

Both absent-day scenarios, rolling-origin results and negative weather findings are available in the methodology.

Open the model methodology and evidence

Draft for review. Not legal advice. Version legal-v2 · 2026-10-25

Cookie/Storage Notice

The app sets no cookies. A language preference is stored in localStorage; no reports, contact details or withdrawal codes are stored there or in sessionStorage. The browser may cache public fonts, scripts and the demo snapshot. Report inputs and the original withdrawal code remain in memory for the current page/session; copying the code uses the clipboard only at your request. No tracking or consent banner is added. Provider technical logs are described in the Privacy Notice.

Estimates, not alerts

Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.

DengueWatch / Community health, in focus.
Thesis / research · Not an official DOH service
Data attribution: DOH/FOI [exact citation pending]
Last data period: Dec 2, 2023 (Manila daily workbook). DOH EPI weekly: Jan 10, 2021. Source date labels, not real-time data.
Data & Sources · Legal & privacy drafts · Terms · Privacy & withdrawal

## admin-login / 1280px

Route: `/admin`; UTC 2026-10-25T03:41:50.180Z; screenshot `admin-login-1280.jpg`. Actual isolated local production page

Skip to admin content
DengueWatch / Staff
Staff sign in

Separate from public pages. Collection remains closed until the owner separately authorizes launch.

Staff email
Password
Sign in

No shared demo password or public self-enrollment. An owner-appointed server role is required.

## moderation-access-gate / 1280px

Route: `/admin/moderation`; UTC 2026-10-25T03:41:51.467Z; screenshot `moderation-access-gate-1280.jpg`. NOT VERIFIED: requested staff workflow is protected; actual captured screen is signed-out login. No session or records invented.

Skip to admin content
DengueWatch / Staff
Staff sign in

Separate from public pages. Collection remains closed until the owner separately authorizes launch.

Staff email
Password
Sign in

No shared demo password or public self-enrollment. An owner-appointed server role is required.

## upload-access-gate / 1280px

Route: `/admin/data`; UTC 2026-10-25T03:41:52.804Z; screenshot `upload-access-gate-1280.jpg`. NOT VERIFIED: requested staff workflow is protected; actual captured screen is signed-out login. No session or records invented.

Skip to admin content
DengueWatch / Staff
Staff sign in

Separate from public pages. Collection remains closed until the owner separately authorizes launch.

Staff email
Password
Sign in

No shared demo password or public self-enrollment. An owner-appointed server role is required.

Oversized-file reconstruction and row counts: see ../SPLIT_FILES.json. CSV parts repeat the header; keep one header and append all data rows in numbered order. JSON byte parts concatenate exactly.
