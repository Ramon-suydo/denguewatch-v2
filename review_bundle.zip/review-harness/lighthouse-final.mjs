import {spawnSync} from 'node:child_process';
process.env.CHROME_PATH='C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const cli='[REDACTED]/AppData/Local/npm-cache/_npx/431df3554b6c2fea/node_modules/lighthouse/cli/index.js';
const r=spawnSync(process.execPath,[cli,'http://127.0.0.1:43142/','--output=html','--output=json','--output-path=docs/evidence/lighthouse-mobile','--chrome-flags=--headless --no-sandbox --disable-gpu','--only-categories=performance,accessibility,best-practices,seo','--form-factor=mobile'],{stdio:'inherit',env:process.env});
if(r.error)throw r.error; if(r.status)process.exit(r.status);
const {readFile}=await import('node:fs/promises');const report=JSON.parse(await readFile('docs/evidence/lighthouse-mobile.report.json','utf8'));const scores=Object.fromEntries(Object.entries(report.categories).map(([k,v])=>[k,v.score*100]));console.log(JSON.stringify({fetchTime:report.fetchTime,scores}));if(scores.performance<90||scores.accessibility!==100)process.exitCode=1;
