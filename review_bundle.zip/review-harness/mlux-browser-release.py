import pathlib,subprocess,sys,json
root=pathlib.Path.cwd();a=root/'.artifacts/launch';runs=[]
sequence=[('mlux-verified-pwa',['run','test:pwa','--','--workers=1']),('mlux-verified-production',['run','test:production','--','--workers=1']),('mlux-verified-ui-1',['run','test:ui','--','--workers=1']),('mlux-verified-ui-2',['run','test:ui','--','--workers=1']),('mlux-verified-ui-3',['run','test:ui','--','--workers=1'])]
for name,args in (sequence[:2] if len(sys.argv)>1 and sys.argv[1]=='contracts' else sequence[2:]):
 p=subprocess.run([sys.executable,str(a/'run.py'),name,*args]);runs.append({'name':name,'exit_code':p.returncode});(a/'mlux-browser-sequence.json').write_text(json.dumps(runs,indent=2)+'\n')
 if p.returncode:sys.exit(p.returncode)
