import pathlib,subprocess,os,sys,time,datetime,json,re,hashlib,shutil
sys.stdout.reconfigure(encoding='utf-8',errors='replace')
root=pathlib.Path.cwd();logs=root/'.artifacts/launch';logs.mkdir(parents=True,exist_ok=True)
node=pathlib.Path(r'[REDACTED]\AppData\Local\npm-cache\_npx\52027bd8fc0022aa\node_modules\node\bin\node.exe');npm=pathlib.Path(r'[REDACTED]\AppData\Local\nvm\v20.19.4\node_modules\npm\bin\npm-cli.js')
env=os.environ.copy();env['PATH']=str(node.parent)+os.pathsep+env['PATH'];env['PLAYWRIGHT_CHANNEL']='msedge';env['PLAYWRIGHT_PORT']='43140';env['ENV_OFFLINE']='1'
name=sys.argv[1];args=sys.argv[2:];cmd=([str(node),*args[1:]] if args[0]=='--node' else [sys.executable,*args[1:]] if args[0]=='--python' else [str(node),str(npm),*args]);display=('node '+' '.join(args[1:]) if args[0]=='--node' else 'python '+' '.join(args[1:]) if args[0]=='--python' else 'npm '+' '.join(args));started=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
# Keep complete output while exposing only safe test progress to the tool session.
import threading
p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace',env=env)
collected_out=[];collected_err=[]
def collect(stream,target):
 for line in stream:
  target.append(line)
  if re.match(r'\s*(?:ok \d|not ok \d|ok +\d|\d+ passed|\d+ failed|Running \d)',line):
   fingerprints_now=set(json.loads((logs/'exposure-fingerprints.json').read_text()))
   safe=re.sub(r'[A-Za-z0-9_-]{8,}',lambda m:'[REDACTED]' if hashlib.sha256(m[0].encode()).hexdigest() in fingerprints_now else m[0],line)
   print(safe.rstrip(),flush=True)
threads=[threading.Thread(target=collect,args=(p.stdout,collected_out)),threading.Thread(target=collect,args=(p.stderr,collected_err))]
for thread in threads:thread.start()
p.wait()
for thread in threads:thread.join()
p.stdout=''.join(collected_out);p.stderr=''.join(collected_err)
fingerprints=json.loads((logs/'exposure-fingerprints.json').read_text())
def scrub(text):
 return re.sub(r'[A-Za-z0-9_-]{8,}',lambda m:'[REDACTED]' if hashlib.sha256(m[0].encode()).hexdigest() in fingerprints else m[0],text)
p.stdout=scrub(p.stdout);p.stderr=scrub(p.stderr)
meta={'command':display,'started_utc':started,'duration_seconds':round(time.monotonic()-tick,3),'exit_code':p.returncode}
(logs/(name+'.txt')).write_text(json.dumps(meta,indent=2)+'\nSTDOUT\n'+p.stdout+'\nSTDERR\n'+p.stderr,encoding='utf-8')
with (logs/'commands.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(meta)+'\n')
if p.returncode and 'test:ui' in args:
 source=root/'.artifacts/playwright'
 if source.exists():shutil.copytree(source,logs/'browser-failures'/name,dirs_exist_ok=True)
print(json.dumps(meta));print((p.stdout+'\n'+p.stderr)[-9000:]);sys.exit(p.returncode)
