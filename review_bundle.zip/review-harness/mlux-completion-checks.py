import pathlib,subprocess,sys,json,os
root=pathlib.Path.cwd();a=root/'.artifacts/launch';results=[]
def run(name,args,expected=0,env=None):
 p=subprocess.run([sys.executable,str(a/'run.py'),name,*args],env=env);results.append({'name':name,'exit_code':p.returncode,'expected_exit':expected});(a/'mlux-completion-sequence.json').write_text(json.dumps(results,indent=2)+'\n')
 if p.returncode!=expected:sys.exit(p.returncode or 1)
run('mlux-final-units',['test'])
run('mlux-final-secrets',['run','security:secrets'],1)
lines=(a/'mlux-final-secrets.txt').read_text(encoding='utf-8').splitlines();guard=next(json.loads(line) for line in lines if line.startswith('{"private_guard_configured"'));assert guard['current_findings']==0 and guard['unexpected_historical_findings']==0 and guard['historical_findings']==44 and guard['rotation_status']=='NEEDS OWNER'
run('mlux-final-lighthouse',['--node','.artifacts/launch/lighthouse-final.mjs'])
env=os.environ.copy();env['JAVA_BIN']=str(root/'.artifacts/launch/tools/jdk-17.0.20.1+1-jre/bin/java.exe');env['ZAP_JAR']=str(root/'.artifacts/launch/tools/ZAP_2.17.0/zap-2.17.0.jar');run('mlux-final-zap',['run','security:zap','--','http://127.0.0.1:43142'],env=env)
run('mlux-primary-final',['--node','.artifacts/launch/mlux-online.mjs'])
run('mlux-motion-final',['--node','.artifacts/launch/mlux-motion.mjs'])
for phase in ['contracts','ui']:
 p=subprocess.run([sys.executable,str(a/'mlux-browser-release.py'),phase])
 if p.returncode:sys.exit(p.returncode)
print('PASS: final local checks and three full browser suites. Secret rotation remains NEEDS OWNER.',flush=True)
