import pathlib,subprocess,os,sys,json,hashlib,time,datetime
root=pathlib.Path.cwd().resolve();a=root/'.artifacts/launch';target=(root/'.artifacts/mlux-clean-checkout').resolve();assert target.parent==root/'.artifacts' and target.name=='mlux-clean-checkout';assert not target.exists()
subprocess.run(['git','worktree','add','--detach',str(target),'HEAD'],check=True,capture_output=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=target,text=True).strip()
node=pathlib.Path(r'[REDACTED]\AppData\Local\npm-cache\_npx\52027bd8fc0022aa\node_modules\node\bin\node.exe');env=os.environ.copy();env['ML_PYTHON']=str(root/'.artifacts/ml-venv/Scripts/python.exe');env['PATH']=str(node.parent)+os.pathsep+env['PATH'];runs=[]
paths=[*sorted((root/'data/processed/ml').glob('*.json')),*sorted((root/'public/ml').glob('*.json')),root/'tests/fixtures/ml-parity.json',root/'docs/ML_EVALUATION.md',*sorted((root/'docs/evidence/ml').glob('*.png'))]
def hashes():return {p.relative_to(root).as_posix():hashlib.sha256((target/p.relative_to(root)).read_bytes()).hexdigest() for p in paths}
first_export=None
for label in ['train','evaluate','export','test','repeat-export']:
 task='export' if label=='repeat-export' else label
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic();p=subprocess.run([str(node),'scripts/ml-run.mjs',task],cwd=target,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace');meta={'command':'node scripts/ml-run.mjs '+task,'checkout_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=target,text=True).strip(),'checkout_initially_clean':True,'started_utc':start,'duration_seconds':round(time.monotonic()-tick,3),'exit_code':p.returncode};(a/('mlux-clean-'+label+'.txt')).write_text(json.dumps(meta,indent=2)+'\nSTDOUT\n'+p.stdout+'\nSTDERR\n'+p.stderr,encoding='utf-8');print(json.dumps(meta),flush=True);runs.append(meta)
 if p.returncode:sys.exit(p.returncode)
 if label=='export':first_export=hashes()
second_export=hashes();assert first_export==second_export,'Repeated export must be byte-identical'
rows=[]
for p in paths:
 rel=p.relative_to(root);left=p.read_bytes();right=(target/rel).read_bytes();rows.append({'path':rel.as_posix(),'previous_parallel_sha256':hashlib.sha256(left).hexdigest(),'clean_checkout_sha256':hashlib.sha256(right).hexdigest(),'changed_by_deterministic_scoring':left!=right});p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(right)
report={'runs':runs,'artifacts':rows,'repeat_export_all_byte_identical':True,'repeat_export_hashes':second_export,'scope':'Fresh detached committed checkout, no fitted cache copied. Pinned ML venv shared as interpreter only. All generated artifacts copied back after successful repeated-export equality. Previous parallel-scoring references are profiled, not treated as serial-scoring expected bytes.'};(root/'docs/evidence/ml-clean-checkout.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({'artifacts':len(rows),'repeat_export_all_byte_identical':True}))
