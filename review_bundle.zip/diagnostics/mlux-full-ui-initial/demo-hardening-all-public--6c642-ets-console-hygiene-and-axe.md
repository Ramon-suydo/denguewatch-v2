# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: demo-hardening.spec.ts >> all public routes retain mobile targets, console hygiene and axe
- Location: tests\ui\demo-hardening.spec.ts:26:1

# Error details

```
Error: page.evaluate: Execution context was destroyed, most likely because of a navigation
```

# Page snapshot

```yaml
- generic [ref=f44e2]:
  - generic [ref=f44e3]:
    - link "Skip to content" [ref=f44e5] [cursor=pointer]:
      - /url: "#main"
    - banner [ref=f44e6]:
      - link "DengueWatch home" [ref=f44e7] [cursor=pointer]:
        - /url: /
        - text: DENGUE
        - generic [ref=f44e8]: WATCH
      - navigation "Main navigation" [ref=f44e9]:
        - link "Dashboard" [ref=f44e10] [cursor=pointer]:
          - /url: /
        - link "Risk Map" [ref=f44e11] [cursor=pointer]:
          - /url: /risk-map
        - link "Community Report" [ref=f44e12] [cursor=pointer]:
          - /url: /report
      - generic "Page language" [ref=f44e13]:
        - button "English" [pressed] [ref=f44e14] [cursor=pointer]
        - button "Filipino" [ref=f44e15] [cursor=pointer]
    - main [ref=f44e16]:
      - generic [ref=f44e18]:
        - paragraph [ref=f44e19]: COMMUNITY / UNVERIFIED
        - heading "Share an awareness signal." [level=1] [ref=f44e20]
        - paragraph [ref=f44e21]: Report a suspected case in your household or an unusual cluster you noticed. Choose only a coarse area; no GPS or free-text address is collected. Barangay selection is available only for the verified Manila catalogue; other units stay at province/city level. The onset day may be approximate.
        - paragraph [ref=f44e22]: We do not ask for your name or contact details, do not store your IP address or precise location, and use no trackers. No system can promise perfect anonymity, so do not include details that identify you or others. Reports never enter official counts, forecasts or the Outlook Index.
        - generic [ref=f44e23]:
          - paragraph [ref=f44e24]: An IP address, when provided by the trusted hosting proxy, is used transiently to derive a rotating salted rate-limit hash. Raw IPs are never stored. Hashes expire after a 15-minute window and are physically removed on a successful request or the hourly retention job (up to 75 minutes). Automated note filters cannot detect every identifying detail. Retention and consent require DPO review before collection opens.
          - status [ref=f44e25]: Checking collection status…
          - heading "Understand and consent" [level=2] [ref=f44e26]
          - paragraph [ref=f44e27]: Your optional health report is sensitive personal information. It supports research and coarse community awareness, not diagnosis, emergency response or validated prediction.
          - paragraph [ref=f44e28]: Only staff can review individual reports. Public counts require staff approval, a 72-hour delay and at least three reports per area/week. Reports are removed after 90 days; withdraw sooner with your private code.
          - paragraph [ref=f44e29]:
            - text: Please report only your own household experience or a coarse, non-identifying cluster observation. Do not include anyone’s identity or address.
            - link "Privacy and withdrawal" [ref=f44e30] [cursor=pointer]:
              - /url: /report?drawer=privacy
            - text: .
          - generic [ref=f44e32] [cursor=pointer]:
            - checkbox "I voluntarily consent to this research use of my report under community-v2." [ref=f44e33]
            - generic [ref=f44e34]: I voluntarily consent to this research use of my report under community-v2.
          - button "Continue to report" [disabled] [ref=f44e35]
          - paragraph [ref=f44e36]: "Controller: DengueWatch student research team. Contact: [REDACTED]. Notice requires DPO review before collection opens."
        - paragraph [ref=f44e37]:
          - link "View community aggregates" [ref=f44e38] [cursor=pointer]:
            - /url: /community
          - text: ·
          - link "Prevention and urgent warning signs" [ref=f44e39] [cursor=pointer]:
            - /url: /prevention
      - complementary [ref=f44e40]:
        - heading "Estimates, not alerts" [level=2] [ref=f44e41]
        - paragraph [ref=f44e42]: Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.
    - contentinfo [ref=f44e43]:
      - generic [ref=f44e44]:
        - link "About & Credits" [ref=f44e45] [cursor=pointer]:
          - /url: /about
        - button "About the data & methods" [ref=f44e46] [cursor=pointer]
        - button "Privacy notice" [ref=f44e47] [cursor=pointer]
      - paragraph [ref=f44e48]:
        - text: Bundled source periods.
        - time [ref=f44e49]: Dec 2, 2023
        - text: ·
        - time [ref=f44e50]: Dec 27, 2020
        - text: . Replay uses historical records. Live needs reviewed recent counts.
      - paragraph [ref=f44e51]: Community reports are unverified; not medical advice.
      - paragraph [ref=f44e52]: Background photograph by Sumarie Slabber
      - paragraph [ref=f44e53]: Thesis research · Not an official DOH product · Historical records, not a live warning.
    - dialog [ref=f44e54]:
      - generic [ref=f44e55]:
        - heading "Privacy notice" [level=2] [ref=f44e56]
        - button "Close dialog" [active] [ref=f44e57] [cursor=pointer]: ✕
      - generic [ref=f44e58]:
        - heading "Privacy & withdrawal" [level=1] [ref=f44e59]
        - paragraph [ref=f44e60]: Data Privacy Act of 2012 (RA 10173) · Draft for school/DPO review before collection opens. This notice is not a claim of legal approval.
        - link "Read RA 10173 at the National Privacy Commission" [ref=f44e61] [cursor=pointer]:
          - /url: https://privacy.gov.ph/data-privacy-act/
        - heading "Map privacy" [level=2] [ref=f44e62]
        - paragraph [ref=f44e63]: Only Risk Map loads OpenFreeMap tiles. That provider receives your IP address, browser headers and viewed map area. No community report is sent to the map provider. The Community Report page makes no map requests. Local offline tiles avoid that third-party connection.
        - heading "What is collected and why" [level=2] [ref=f44e64]
        - paragraph [ref=f44e65]: Only report type, a province/city reporting unit, an optional validated Manila barangay, approximate onset day, number-affected range, optional symptoms, a filtered note, consent version/time and moderation status. This sensitive information supports coarse community awareness and research, never diagnosis, emergency dispatch or validated prediction.
        - heading "Privacy limits and safeguards" [level=2] [ref=f44e66]
        - paragraph [ref=f44e67]: We do not ask for your name or contact details, do not store your IP address or precise location, and use no trackers. No system can promise perfect anonymity, so do not include details that identify you or others. Automated PII filters are imperfect.
        - paragraph [ref=f44e68]: A hosting-proxy IP, when available, is used transiently for a rotating salted hash and never stored raw. Rate-limit windows last 15 minutes; expired hashes are deleted on a successful request or by hourly retention, at most 75 minutes. There is no device fingerprinting. Hosting/API providers may process connection metadata in their own logs; deployment settings and retention need owner verification.
        - paragraph [ref=f44e69]: Appointed staff with MFA review coarse reports. Approval is content review, not medical verification. Public aggregates require at least 3 approved reports per area/week and a minimum 72-hour delay. Reports never enter official counts, forecasts or the Outlook Index. Missing/suppressed groups do not mean zero cases.
        - heading "Choice, retention and rights" [level=2] [ref=f44e70]
        - paragraph [ref=f44e71]: Participation is optional and requires explicit consent. Records are retained for up to 90 days under the server policy; actual hosted purge execution must be verified before collection opens. Save the random withdrawal code shown once. The database stores its hash, not a recoverable code. Withdrawal removes the report from public aggregates and clears its sensitive fields. You may request access, correction, objection or erasure through the project controller once the owner supplies a verified contact. We cannot find a report by a name or phone we never collected.
        - paragraph [ref=f44e72]: Collection must stay closed until a verified project controller, contact channel and institutional privacy review are in place.
        - generic [ref=f44e74]:
          - heading "Withdraw a report" [level=2] [ref=f44e75]
          - paragraph [ref=f44e76]: The response does not reveal whether a code exists. No report details are returned.
          - generic [ref=f44e77]:
            - generic [ref=f44e78]:
              - generic [ref=f44e79]: Reference code
              - textbox "Reference code" [ref=f44e80]
            - button "Request withdrawal" [ref=f44e81] [cursor=pointer]
  - status
```

# Test source

```ts
  1   | import {goto,ready,activeView} from '../support/active-view';
  2   | import { test, expect } from "@playwright/test";
  3   | import AxeBuilder from "@axe-core/playwright";
  4   | import { mockPublicApi } from "../fixtures/public-fixtures";
  5   | const routes = [
  6   |   "/",
  7   |   "/trends",
  8   |   "/metro-manila",
  9   |   "/methodology",
  10  |   "/prevention",
  11  |   "/community",
  12  |   "/report",
  13  |   "/privacy",
  14  |   "/terms",
  15  |   "/legal",
  16  |   "/data-sources",
  17  |   "/not-found",
  18  | ];
  19  | async function navigate(page: import("@playwright/test").Page, path: string) {
  20  |   await page.evaluate((p) => {
  21  |     history.pushState({}, "", p);
  22  |     dispatchEvent(new PopStateEvent("popstate"));
  23  |   }, path);
  24  |   await ready(page,path);
  25  | }
  26  | test("all public routes retain mobile targets, console hygiene and axe", async ({
  27  |   page,
  28  | }) => {
  29  |   test.setTimeout(240000);
  30  |   const errors: string[] = [];
  31  |   page.on("pageerror", (e) => errors.push(e.message));
  32  |   page.on("console", (message) => {
  33  |     if (["warning", "error"].includes(message.type()))
  34  |       errors.push(message.text());
  35  |   });
  36  |   await mockPublicApi(page, { open: false });
  37  |   for (const width of [320, 390, 768, 1280])
  38  |     for (const route of routes) {
  39  |       await page.setViewportSize({ width, height: 900 });
  40  |       await goto(page, route);
  41  |       await expect(activeView(page).getByRole("heading", { level: 1 })).toBeVisible();
  42  |       expect(
  43  |         await page.evaluate(
  44  |           () => document.documentElement.scrollWidth <= innerWidth,
  45  |         ),
  46  |       ).toBe(true);
  47  |       const violations = (
> 48  |         await new AxeBuilder({ page }).analyze()
      |         ^ Error: page.evaluate: Execution context was destroyed, most likely because of a navigation
  49  |       ).violations.filter((v) =>
  50  |         ["serious", "critical"].includes(v.impact ?? ""),
  51  |       );
  52  |       expect(violations, route + " " + width).toEqual([]);
  53  |       const small = await page
  54  |         .locator(
  55  |           "button:visible:not([disabled]),select:visible,summary:visible,a:visible:not(.skip-link)",
  56  |         )
  57  |         .evaluateAll((elements) =>
  58  |           elements
  59  |             .filter((e) => e.getBoundingClientRect().height < 43.5)
  60  |             .map((e) => e.textContent?.trim().slice(0, 45)),
  61  |         );
  62  |       expect(small, route + " " + width).toEqual([]);
  63  |     }
  64  |   expect(errors).toEqual([]);
  65  | });
  66  | test("blocked external services leave static historical pages and closed reporting usable", async ({
  67  |   page,
  68  |   context,
  69  | }) => {
  70  |   const external: string[] = [];
  71  |   await page.addInitScript(() =>
  72  |     Object.defineProperty(navigator, "onLine", { get: () => false }),
  73  |   );
  74  |   await context.route("**/*", (r) => {
  75  |     if (
  76  |       ["localhost", "127.0.0.1"].includes(new URL(r.request().url()).hostname)
  77  |     )
  78  |       return r.continue();
  79  |     external.push(r.request().url());
  80  |     return r.abort();
  81  |   });
  82  |   for (const route of [
  83  |     "/",
  84  |     "/trends",
  85  |     "/metro-manila",
  86  |     "/methodology",
  87  |     "/prevention",
  88  |     "/report",
  89  |   ]) {
  90  |     await goto(page, route);
  91  |     await expect(activeView(page).getByRole("heading", { level: 1 })).toBeVisible();
  92  |     await expect(
  93  |       page.locator("main>.evidence-banner"),
  94  |     ).toBeVisible();
  95  |   }
  96  |   await expect(
  97  |     activeView(page).getByText("New submissions are closed.", { exact: false }),
  98  |   ).toBeVisible();
  99  |   expect(external).toEqual([]);
  100 | });
  101 | test("warmed routes and validated datasets remain available with the browser fully offline", async ({
  102 |   page,
  103 |   context,
  104 | }) => {
  105 |   const errors: string[] = [];
  106 |   page.on("pageerror", (e) => errors.push(e.message));
  107 |   await goto(page, "/");
  108 |   await expect(
  109 |     activeView(page).getByRole("heading", { name: "Cities to watch" }),
  110 |   ).toBeVisible();
  111 |   for (const route of [
  112 |     "/trends",
  113 |     "/metro-manila",
  114 |     "/methodology",
  115 |     "/prevention",
  116 |     "/",
  117 |   ])
  118 |     await navigate(page, route);
  119 |   await context.setOffline(true);
  120 |   for (const route of [
  121 |     "/trends",
  122 |     "/metro-manila",
  123 |     "/methodology",
  124 |     "/prevention",
  125 |     "/",
  126 |   ]) {
  127 |     await navigate(page, route);
  128 |     await expect(
  129 |       page.locator("main>.evidence-banner"),
  130 |     ).toBeVisible();
  131 |   }
  132 |   expect(errors).toEqual([]);
  133 | });
  134 | test("slow research reads show loading without inventing a current risk, then resolve", async ({
  135 |   page,
  136 | }) => {
  137 |   let release!: () => void;
  138 |   const gate = new Promise<void>((r) => (release = r));
  139 |   await page.route("**/api/v2/manila.json", async (r) => {
  140 |     await gate;
  141 |     await r.continue();
  142 |   });
  143 |   await goto(page, "/about?drawer=methods&section=dashboard");
  144 |   await expect(activeView(page).getByText("Loading data…", { exact: true })).toBeVisible();
  145 |   await expect(
  146 |     activeView(page).getByRole("heading", { name: "Current risk unavailable" }),
  147 |   ).toHaveCount(0);
  148 |   release();
```