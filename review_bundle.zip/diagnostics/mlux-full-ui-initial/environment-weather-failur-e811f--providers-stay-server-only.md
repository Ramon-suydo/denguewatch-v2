# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: environment.spec.ts >> weather failure leaves historical persistence usable and providers stay server-only
- Location: tests\ui\environment.spec.ts:4:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('body:has(dialog[open]) dialog[open], body:not(:has(dialog[open]))').getByRole('button', { name: 'Filipino', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - link "Skip to content" [ref=e5] [cursor=pointer]:
      - /url: "#main"
    - banner [ref=e6]:
      - link "DengueWatch home" [ref=e7] [cursor=pointer]:
        - /url: /
        - text: DENGUE
        - generic [ref=e8]: WATCH
      - navigation "Main navigation" [ref=e9]:
        - link "Dashboard" [ref=e10] [cursor=pointer]:
          - /url: /
        - link "Risk Map" [ref=e11] [cursor=pointer]:
          - /url: /risk-map
        - link "Community Report" [ref=e12] [cursor=pointer]:
          - /url: /report
      - generic "Page language" [ref=e13]:
        - button "English" [pressed] [ref=e14] [cursor=pointer]
        - button "Filipino" [ref=e15] [cursor=pointer]
    - main [ref=e16]:
      - generic [ref=e17]:
        - paragraph [ref=e18]: THESIS PROJECT / ATTRIBUTION
        - heading "ABOUT & CREDITS" [level=1] [ref=e19]
        - paragraph [ref=e20]: The people, records and tools behind this research.
        - navigation "About sections" [ref=e21]:
          - link "Project" [ref=e22] [cursor=pointer]:
            - /url: "#project"
          - link "Data" [ref=e23] [cursor=pointer]:
            - /url: "#data-credits"
          - link "Software" [ref=e24] [cursor=pointer]:
            - /url: "#software"
          - link "Photograph" [ref=e25] [cursor=pointer]:
            - /url: "#image-credit"
        - generic [ref=e27]:
          - heading "About the project" [level=2] [ref=e28]
          - paragraph [ref=e29]: DengueWatch asks whether historical dengue patterns can support earlier awareness while making uncertainty visible. It combines a retrospective Manila case-forecast evaluation, a national seasonal outlook and a separate, privacy-conscious community reporting channel.
          - paragraph [ref=e30]: This is not medical advice, a diagnosis, an official DOH product or evidence of institutional affiliation. Old case records cannot establish current risk.
        - generic [ref=e32]:
          - heading "Data credits" [level=2] [ref=e33]
          - article [ref=e34]:
            - heading "DOH Epidemiology Bureau weekly surveillance (EPI)" [level=3] [ref=e35]
            - paragraph [ref=e36]: NCR city-week classification, plus archived historical analyses; raw input remains unchanged.
            - generic [ref=e37]:
              - term [ref=e38]: Coverage
              - definition [ref=e39]: 2016-01-10 to 2021-01-10
              - term [ref=e40]: Licence / terms
              - definition [ref=e41]: unknown; data-owner confirmation required
              - term [ref=e42]: Retrieval
              - definition [ref=e43]: unknown
            - paragraph [ref=e44]: doh-epi-dengue-data-2016-2021.csv
          - article [ref=e45]:
            - heading "City of Manila health department" [level=3] [ref=e46]
            - paragraph [ref=e47]: Daily case data provided to the project team; formal citation pending data owner
            - generic [ref=e48]:
              - term [ref=e49]: Coverage
              - definition [ref=e50]: 2018-01-01 to 2023-12-02
              - term [ref=e51]: Licence / terms
              - definition [ref=e52]: unknown; attribution and permission required
              - term [ref=e53]: Retrieval
              - definition [ref=e54]: unknown
            - paragraph [ref=e55]: Daily_Reported_Cases_of_Dengue_in_the_City_of_Manila_from_2018_to_2023.xlsx
          - article [ref=e56]:
            - heading "Philippine Statistics Authority (PSA)" [level=3] [ref=e57]
            - paragraph [ref=e58]: Existing NCR 2020 denominators; national unit-aligned denominators unverified, so outlook uses count ranks and discloses population confounding
            - generic [ref=e59]:
              - term [ref=e60]: Coverage
              - definition [ref=e61]: 2020 census
              - term [ref=e62]: Licence / terms
              - definition [ref=e63]: source-specific terms; no blanket government-data licence assumed
              - term [ref=e64]: Retrieval
              - definition [ref=e65]: 2026-10-25 (reference checked); original supplied denominators unknown
            - link "Source and attribution" [ref=e66] [cursor=pointer]:
              - /url: https://psa.gov.ph/content/highlights-philippine-population-2020-census-population-and-housing-2020-cph
          - article [ref=e67]:
            - heading "geoBoundaries / NAMRIA / PSA / OCHA Philippines" [level=3] [ref=e68]
            - paragraph [ref=e69]: Local Philippines province display geometry; simplified from geoBoundaries ADM2, plus existing NCR city shapes
            - generic [ref=e70]:
              - term [ref=e71]: Coverage
              - definition [ref=e72]: ADM2 represents 2020; existing NCR ADM3 valid 2025-02-13, not historical boundary proof
              - term [ref=e73]: Licence / terms
              - definition [ref=e74]: CC BY 3.0 IGO; retain NAMRIA/PSA/OCHA attribution; simplification changes geometry
              - term [ref=e75]: Retrieval
              - definition [ref=e76]: 2026-10-25
            - link "Source and attribution" [ref=e77] [cursor=pointer]:
              - /url: https://www.geoboundaries.org/api/current/gbOpen/PHL/ADM2/
          - article [ref=e78]:
            - heading "Open-Meteo / Copernicus C3S / ECMWF ERA5" [level=3] [ref=e79]
            - paragraph [ref=e80]: Historical centroid weather validation and separately labeled forecast context; weather excluded from outlook unless validated
            - generic [ref=e81]:
              - term [ref=e82]: Coverage
              - definition [ref=e83]: History 2016-2020; dated cached forecast context
              - term [ref=e84]: Licence / terms
              - definition [ref=e85]: CC BY 4.0 data; free hosted API is for non-commercial use within fair-use limits
              - term [ref=e86]: Retrieval
              - definition [ref=e87]: See cache receipts; documentation verified 2026-10-25
            - link "Source and attribution" [ref=e88] [cursor=pointer]:
              - /url: https://open-meteo.com/
          - article [ref=e89]:
            - heading "NASA POWER / NASA Langley Research Center" [level=3] [ref=e90]
            - paragraph [ref=e91]: Historical weather cross-check for four polygon centroids, 2018–2020. NASA POWER is funded by the NASA Applied Sciences Program within the Earth Science Division of the Science Mission Directorate; web services collaborate with the NASA Langley Research Center Atmospheric Science Data Center (ASDC).
            - generic [ref=e92]:
              - term [ref=e93]: Coverage
              - definition [ref=e94]: See cached provenance; existing Manila historical cross-check
              - term [ref=e95]: Licence / terms
              - definition [ref=e96]: NASA POWER data access/acknowledgement terms; see original receipts
              - term [ref=e97]: Retrieval
              - definition [ref=e98]: 2026-10-25
            - link "Source and attribution" [ref=e99] [cursor=pointer]:
              - /url: https://power.larc.nasa.gov/docs/
          - article [ref=e100]:
            - heading "OpenStreetMap contributors" [level=3] [ref=e101]
            - paragraph [ref=e102]: Existing exploratory water/geography context; community data never enters official forecasts
            - generic [ref=e103]:
              - term [ref=e104]: Coverage
              - definition [ref=e105]: Provider snapshot dates in cache receipts
              - term [ref=e106]: Licence / terms
              - definition [ref=e107]: ODbL; OpenStreetMap contributors
              - term [ref=e108]: Retrieval
              - definition [ref=e109]: See cache receipts
            - link "Source and attribution" [ref=e110] [cursor=pointer]:
              - /url: https://www.openstreetmap.org/copyright
          - article [ref=e111]:
            - heading "NASA SRTM / Open-Meteo elevation service" [level=3] [ref=e112]
            - paragraph [ref=e113]: Existing exploratory terrain context; not household risk
            - generic [ref=e114]:
              - term [ref=e115]: Coverage
              - definition [ref=e116]: SRTM mission elevation / provider cache dates
              - term [ref=e117]: Licence / terms
              - definition [ref=e118]: Provider-specific attribution recorded in receipts
              - term [ref=e119]: Retrieval
              - definition [ref=e120]: See cache receipts
            - link "Source and attribution" [ref=e121] [cursor=pointer]:
              - /url: https://open-meteo.com/en/docs/elevation-api
          - article [ref=e122]:
            - heading "DOH regional offices / MOH BARMM; National Privacy Commission; CDC; WHO" [level=3] [ref=e123]
            - paragraph [ref=e124]: 4S prevention, urgent warning signs and RA 10173 notice drafting; DPO/clinical review still required
            - generic [ref=e125]:
              - term [ref=e126]: Coverage
              - definition [ref=e127]: Guidance references checked 2026-10-25
              - term [ref=e128]: Licence / terms
              - definition [ref=e129]: Links and paraphrased guidance; no agency affiliation
              - term [ref=e130]: Retrieval
              - definition [ref=e131]: 2026-10-25
            - link "Source and attribution" [ref=e132] [cursor=pointer]:
              - /url: https://bangsamoro.gov.ph/news/latest-news/moh-urges-public-to-observe-4s-strategy-against-dengue/
          - article [ref=e133]:
            - heading "PAGASA" [level=3] [ref=e134]
            - paragraph [ref=e135]: Existing rainy-season contextual guidance; not an outbreak prediction
            - generic [ref=e136]:
              - term [ref=e137]: Coverage
              - definition [ref=e138]: Guidance reference in source manifest
              - term [ref=e139]: Licence / terms
              - definition [ref=e140]: Source-specific government guidance; attribution retained
              - term [ref=e141]: Retrieval
              - definition [ref=e142]: See original source manifest
            - link "Source and attribution" [ref=e143] [cursor=pointer]:
              - /url: https://www.pagasa.dost.gov.ph/
          - article [ref=e144]:
            - heading "OpenTopoData / NASA SRTM" [level=3] [ref=e145]
            - paragraph [ref=e146]: Elevation service considered by the existing terrain pipeline; original cache provenance identifies actual provider
            - generic [ref=e147]:
              - term [ref=e148]: Coverage
              - definition [ref=e149]: SRTM mission / cached provider date
              - term [ref=e150]: Licence / terms
              - definition [ref=e151]: Underlying dataset and service-specific terms; see provenance
              - term [ref=e152]: Retrieval
              - definition [ref=e153]: See original receipts
            - link "Source and attribution" [ref=e154] [cursor=pointer]:
              - /url: https://www.opentopodata.org/
          - article [ref=e155]:
            - heading "UP NOAH, UP DREAM/LiPAD and MGB" [level=3] [ref=e156]
            - paragraph [ref=e157]: Portals checked in the prior research; no licensed national analytical flood extract used
            - generic [ref=e158]:
              - term [ref=e159]: Coverage
              - definition [ref=e160]: Reference checks only; no derived flood layer
              - term [ref=e161]: Licence / terms
              - definition [ref=e162]: No flood dataset redistributed or represented as validated
              - term [ref=e163]: Retrieval
              - definition [ref=e164]: See source manifest
            - link "Source and attribution" [ref=e165] [cursor=pointer]:
              - /url: https://noah.up.edu.ph/noah-studio
          - article [ref=e166]:
            - heading "OpenFreeMap / OpenMapTiles / OpenStreetMap contributors" [level=3] [ref=e167]
            - paragraph [ref=e168]: Online Risk Map basemap only; no API key; third-party server sees IP and viewed map area
            - generic [ref=e169]:
              - term [ref=e170]: Coverage
              - definition [ref=e171]: Current basemap service; model case data are separate
              - term [ref=e172]: Licence / terms
              - definition [ref=e173]: OpenFreeMap service as-is; map data OpenStreetMap contributors, ODbL; preserve provider attribution
              - term [ref=e174]: Retrieval
              - definition [ref=e175]: 2026-10-26
            - link "Source and attribution" [ref=e176] [cursor=pointer]:
              - /url: https://openfreemap.org/quick_start/
          - article [ref=e177]:
            - heading "Protomaps / OpenStreetMap contributors" [level=3] [ref=e178]
            - paragraph [ref=e179]: Self-hosted Metro Manila PMTiles and styles; local glyphs/sprites
            - generic [ref=e180]:
              - term [ref=e181]: Coverage
              - definition [ref=e182]: 2026-10-25 planet extract; max zoom 13
              - term [ref=e183]: Licence / terms
              - definition [ref=e184]: OSM ODbL produced work; styles BSD-3-Clause; Noto glyphs OFL-1.1; tangrams/icons sprites MIT
              - term [ref=e185]: Retrieval
              - definition [ref=e186]: 2026-10-26
            - link "Source and attribution" [ref=e187] [cursor=pointer]:
              - /url: https://docs.protomaps.com/basemaps/downloads
          - article [ref=e188]:
            - heading "Sarma et al. (2020), Dengue Prediction using Machine Learning Algorithms" [level=3] [ref=e189]
            - paragraph [ref=e190]: Owner-requested protocol context only; patient-level study accuracy does not transfer to city-week labels
            - generic [ref=e191]:
              - term [ref=e192]: Coverage
              - definition [ref=e193]: IEEE R10-HTC 2020; document 9357035
              - term [ref=e194]: Licence / terms
              - definition [ref=e195]: Bibliographic citation only; publisher full text access-blocked; metadata verified with Crossref
              - term [ref=e196]: Retrieval
              - definition [ref=e197]: 2026-10-26
            - link "Source and attribution" [ref=e198] [cursor=pointer]:
              - /url: https://ieeexplore.ieee.org/document/9357035
          - article [ref=e199]:
            - heading "W3C SVG / XML namespace specification" [level=3] [ref=e200]
            - paragraph [ref=e201]: Inline city-thumbnail SVG syntax; namespace identifiers cause no network requests
            - generic [ref=e202]:
              - term [ref=e203]: Coverage
              - definition [ref=e204]: SVG namespace
              - term [ref=e205]: Licence / terms
              - definition [ref=e206]: Specification reference only; no copied specification text
              - term [ref=e207]: Retrieval
              - definition [ref=e208]: 2026-10-26
            - link "Source and attribution" [ref=e209] [cursor=pointer]:
              - /url: https://www.w3.org/TR/SVG2/
        - generic [ref=e211]:
          - heading "Methods and evidence" [level=2] [ref=e212]
          - paragraph [ref=e213]: We classify next-week research threshold events for 17 Metro Manila areas.
          - paragraph [ref=e214]: The areas are 16 cities and Pateros municipality. No barangay estimates are produced.
          - paragraph [ref=e215]: An event means next week exceeds the city’s past mean plus one standard deviation. The minimum cutoff is 10 cases. These are research labels, not official outbreak declarations.
          - paragraph [ref=e216]: All thresholds and features use only information available by the forecast origin. Missing weeks stay missing. Live requires reviewed counts for all cities within 21 days.
          - group [ref=e217]:
            - generic "Definitions and limitations" [ref=e218] [cursor=pointer]
          - heading "Study that informed the protocol" [level=3] [ref=e219]
          - paragraph [ref=e220]:
            - text: Dhiman Sarma, Sohrab Hossain, Tanni Mittra, Md. Abdul Motaleb Bhuiya, Ishita Saha, Ravina Chakma. Dengue Prediction using Machine Learning Algorithms. 2020 IEEE 8th R10 Humanitarian Technology Conference (R10-HTC), 2020.
            - link "IEEE document 9357035" [ref=e221] [cursor=pointer]:
              - /url: https://ieeexplore.ieee.org/document/9357035
            - text: ". DOI:"
            - link "10.1109/r10-htc49770.2020.9357035" [ref=e222] [cursor=pointer]:
              - /url: https://doi.org/10.1109/r10-htc49770.2020.9357035
            - text: .
          - paragraph [ref=e223]: That study classifies patients. Its reported accuracy is not our city-week accuracy. The owner supplied its protocol; citation metadata was verified with Crossref. Full text remains access-blocked.
          - generic [ref=e224]:
            - heading "Chronological 70:30 results" [level=3] [ref=e225]
            - paragraph [ref=e226]: 2016-07-17–2019-08-25 / 2019-09-01–2020-11-08
            - paragraph [ref=e227]: Confidence limits below are 95% block-bootstrap intervals.
            - region "Chronological headline results" [ref=e228]:
              - table [ref=e229]:
                - caption [ref=e230]: Chronological headline results
                - rowgroup [ref=e231]:
                  - row [ref=e232]:
                    - columnheader "Model" [ref=e233]
                    - columnheader "N / positive" [ref=e234]
                    - columnheader "accuracy" [ref=e235]
                    - columnheader "balanced accuracy" [ref=e236]
                    - columnheader "precision" [ref=e237]
                    - columnheader "recall" [ref=e238]
                    - columnheader "f1" [ref=e239]
                    - columnheader "roc auc" [ref=e240]
                    - columnheader "pr auc" [ref=e241]
                    - columnheader "brier" [ref=e242]
                - rowgroup [ref=e243]:
                  - row [ref=e244]:
                    - rowheader "majority" [ref=e245]
                    - cell "1071 / 225" [ref=e246]
                    - cell "0.7899 [0.6050, 0.9300]" [ref=e247]:
                      - text: "0.7899"
                      - generic [ref=e248]: "[0.6050, 0.9300]"
                    - cell "0.5000 [0.5000, 0.5000]" [ref=e249]:
                      - text: "0.5000"
                      - generic [ref=e250]: "[0.5000, 0.5000]"
                    - cell "0.0000 [0.0000, 0.0000]" [ref=e251]:
                      - text: "0.0000"
                      - generic [ref=e252]: "[0.0000, 0.0000]"
                    - cell "0.0000 [0.0000, 0.0000]" [ref=e253]:
                      - text: "0.0000"
                      - generic [ref=e254]: "[0.0000, 0.0000]"
                    - cell "0.0000 [0.0000, 0.0000]" [ref=e255]:
                      - text: "0.0000"
                      - generic [ref=e256]: "[0.0000, 0.0000]"
                    - cell "0.5000 [0.5000, 0.5000]" [ref=e257]:
                      - text: "0.5000"
                      - generic [ref=e258]: "[0.5000, 0.5000]"
                    - cell "0.2101 [0.0700, 0.3950]" [ref=e259]:
                      - text: "0.2101"
                      - generic [ref=e260]: "[0.0700, 0.3950]"
                    - cell "0.1711 [0.1098, 0.2518]" [ref=e261]:
                      - text: "0.1711"
                      - generic [ref=e262]: "[0.1098, 0.2518]"
                  - row [ref=e263]:
                    - rowheader "persistence" [ref=e264]
                    - cell "1071 / 225" [ref=e265]
                    - cell "0.9505 [0.9047, 0.9841]" [ref=e266]:
                      - text: "0.9505"
                      - generic [ref=e267]: "[0.9047, 0.9841]"
                    - cell "0.9361 [0.8513, 0.9799]" [ref=e268]:
                      - text: "0.9361"
                      - generic [ref=e269]: "[0.8513, 0.9799]"
                    - cell "0.8613 [0.6309, 0.9608]" [ref=e270]:
                      - text: "0.8613"
                      - generic [ref=e271]: "[0.6309, 0.9608]"
                    - cell "0.9111 [0.7374, 0.9730]" [ref=e272]:
                      - text: "0.9111"
                      - generic [ref=e273]: "[0.7374, 0.9730]"
                    - cell "0.8855 [0.7049, 0.9630]" [ref=e274]:
                      - text: "0.8855"
                      - generic [ref=e275]: "[0.7049, 0.9630]"
                    - cell "0.9865 [0.9540, 0.9984]" [ref=e276]:
                      - text: "0.9865"
                      - generic [ref=e277]: "[0.9540, 0.9984]"
                    - cell "0.9593 [0.7999, 0.9944]" [ref=e278]:
                      - text: "0.9593"
                      - generic [ref=e279]: "[0.7999, 0.9944]"
                    - cell "0.0388 [0.0131, 0.0699]" [ref=e280]:
                      - text: "0.0388"
                      - generic [ref=e281]: "[0.0131, 0.0699]"
                  - row [ref=e282]:
                    - rowheader "seasonal" [ref=e283]
                    - cell "1071 / 225" [ref=e284]
                    - cell "0.6937 [0.5349, 0.8229]" [ref=e285]:
                      - text: "0.6937"
                      - generic [ref=e286]: "[0.5349, 0.8229]"
                    - cell "0.4636 [0.3927, 0.5376]" [ref=e287]:
                      - text: "0.4636"
                      - generic [ref=e288]: "[0.3927, 0.5376]"
                    - cell "0.1128 [0.0000, 0.4724]" [ref=e289]:
                      - text: "0.1128"
                      - generic [ref=e290]: "[0.0000, 0.4724]"
                    - cell "0.0667 [0.0000, 0.1621]" [ref=e291]:
                      - text: "0.0667"
                      - generic [ref=e292]: "[0.0000, 0.1621]"
                    - cell "0.0838 [0.0000, 0.1936]" [ref=e293]:
                      - text: "0.0838"
                      - generic [ref=e294]: "[0.0000, 0.1936]"
                    - cell "0.6986 [0.5339, 0.8631]" [ref=e295]:
                      - text: "0.6986"
                      - generic [ref=e296]: "[0.5339, 0.8631]"
                    - cell "0.2808 [0.0891, 0.5941]" [ref=e297]:
                      - text: "0.2808"
                      - generic [ref=e298]: "[0.0891, 0.5941]"
                    - cell "0.2063 [0.1131, 0.2924]" [ref=e299]:
                      - text: "0.2063"
                      - generic [ref=e300]: "[0.1131, 0.2924]"
                  - row [ref=e301]:
                    - rowheader "DT" [ref=e302]
                    - cell "1071 / 225" [ref=e303]
                    - cell "0.6144 [0.4669, 0.7443]" [ref=e304]:
                      - text: "0.6144"
                      - generic [ref=e305]: "[0.4669, 0.7443]"
                    - cell "0.7282 [0.6233, 0.8136]" [ref=e306]:
                      - text: "0.7282"
                      - generic [ref=e307]: "[0.6233, 0.8136]"
                    - cell "0.3444 [0.1290, 0.5809]" [ref=e308]:
                      - text: "0.3444"
                      - generic [ref=e309]: "[0.1290, 0.5809]"
                    - cell "0.9244 [0.7650, 0.9906]" [ref=e310]:
                      - text: "0.9244"
                      - generic [ref=e311]: "[0.7650, 0.9906]"
                    - cell "0.5018 [0.2258, 0.7225]" [ref=e312]:
                      - text: "0.5018"
                      - generic [ref=e313]: "[0.2258, 0.7225]"
                    - cell "0.9334 [0.8270, 0.9826]" [ref=e314]:
                      - text: "0.9334"
                      - generic [ref=e315]: "[0.8270, 0.9826]"
                    - cell "0.8366 [0.5427, 0.9479]" [ref=e316]:
                      - text: "0.8366"
                      - generic [ref=e317]: "[0.5427, 0.9479]"
                    - cell "0.1449 [0.1186, 0.1711]" [ref=e318]:
                      - text: "0.1449"
                      - generic [ref=e319]: "[0.1186, 0.1711]"
                  - row [ref=e320]:
                    - rowheader "RF" [ref=e321]
                    - cell "1071 / 225" [ref=e322]
                    - cell "0.9094 [0.8243, 0.9720]" [ref=e323]:
                      - text: "0.9094"
                      - generic [ref=e324]: "[0.8243, 0.9720]"
                    - cell "0.9247 [0.8334, 0.9791]" [ref=e325]:
                      - text: "0.9247"
                      - generic [ref=e326]: "[0.8334, 0.9791]"
                    - cell "0.7133 [0.4161, 0.8984]" [ref=e327]:
                      - text: "0.7133"
                      - generic [ref=e328]: "[0.4161, 0.8984]"
                    - cell "0.9511 [0.7924, 1.0000]" [ref=e329]:
                      - text: "0.9511"
                      - generic [ref=e330]: "[0.7924, 1.0000]"
                    - cell "0.8152 [0.5307, 0.9401]" [ref=e331]:
                      - text: "0.8152"
                      - generic [ref=e332]: "[0.5307, 0.9401]"
                    - cell "0.9803 [0.9292, 0.9984]" [ref=e333]:
                      - text: "0.9803"
                      - generic [ref=e334]: "[0.9292, 0.9984]"
                    - cell "0.9523 [0.7024, 0.9937]" [ref=e335]:
                      - text: "0.9523"
                      - generic [ref=e336]: "[0.7024, 0.9937]"
                    - cell "0.0445 [0.0133, 0.0856]" [ref=e337]:
                      - text: "0.0445"
                      - generic [ref=e338]: "[0.0133, 0.0856]"
            - paragraph [ref=e339]: Persistence clearly improves F1 over RF in this comparison.
            - paragraph [ref=e340]: "RF minus rule F1, 95% CI: -0.1538 to -0.0157."
            - group [ref=e341]:
              - 'generic "Onset: early-warning subset" [ref=e342] [cursor=pointer]'
            - group [ref=e343]:
              - generic "Random stratified 70:30 comparison" [ref=e344] [cursor=pointer]
            - group [ref=e345]:
              - generic "Per-city results, including Manila" [ref=e346] [cursor=pointer]
            - group [ref=e347]:
              - generic "Yearly robustness and label sensitivity" [ref=e348] [cursor=pointer]
            - group [ref=e349]:
              - generic "Confusion matrices and feature importance" [ref=e350] [cursor=pointer]
            - paragraph [ref=e351]: "Missing calendar weeks: 2016-11-13, 2019-01-06, 2020-11-15."
            - paragraph [ref=e352]:
              - text: "Data SHA-256:"
              - code [ref=e353]: 4e993553f10081b4e6b35a0d4b3c9bd0cc271765645a123fcb2e0c5d7084633c
            - link "Download the complete evaluation" [ref=e354] [cursor=pointer]:
              - /url: /ml/evaluation.json
        - generic [ref=e356]:
          - heading "Software, fonts & icons" [level=2] [ref=e357]
          - paragraph [ref=e358]: Generated from the committed lockfile and installed package licence metadata. Both runtime and build tools are included.
          - paragraph [ref=e359]:
            - text: Montserrat · OFL-1.1 ·
            - link "Font source" [ref=e360] [cursor=pointer]:
              - /url: https://fonts.google.com/specimen/Montserrat
          - paragraph [ref=e361]:
            - text: Roboto · OFL-1.1 ·
            - link "Font source" [ref=e362] [cursor=pointer]:
              - /url: https://fonts.google.com/specimen/Roboto
          - paragraph [ref=e363]:
            - text: Fraunces · OFL-1.1 ·
            - link "Font source" [ref=e364] [cursor=pointer]:
              - /url: https://fonts.google.com/specimen/Fraunces
          - paragraph [ref=e365]:
            - text: DejaVu Sans (evaluation figures) · Bitstream Vera / DejaVu font licence ·
            - link "Font source" [ref=e366] [cursor=pointer]:
              - /url: /THIRD_PARTY_LICENSES.md
          - paragraph [ref=e367]:
            - text: Noto Sans Regular (local map glyphs) · OFL-1.1 ·
            - link "Font source" [ref=e368] [cursor=pointer]:
              - /url: https://github.com/protomaps/basemaps-assets/tree/main/fonts
          - paragraph [ref=e369]: Project SVG line symbols and text glyphs · MIT project code; no third-party icon library
          - paragraph [ref=e370]: Protomaps sprites derived from tangrams/icons · MIT
          - paragraph [ref=e371]:
            - link "THIRD_PARTY_LICENSES.md" [ref=e372] [cursor=pointer]:
              - /url: /THIRD_PARTY_LICENSES.md
          - group [ref=e373]:
            - generic "Open dependency licence inventory" [ref=e374] [cursor=pointer]
        - generic [ref=e375]:
          - generic [ref=e376]:
            - heading "The photograph" [level=2] [ref=e377]
            - paragraph [ref=e378]: Background photograph by Sumarie Slabber
          - generic [ref=e379]:
            - heading "Responsible use & privacy" [level=2] [ref=e380]
            - paragraph [ref=e381]: Community signals are unverified and never enter official counts, forecasts or city model estimates. A tracking code supports withdrawal. No system can promise perfect anonymity.
            - link "Read the privacy notice" [ref=e382] [cursor=pointer]:
              - /url: /report?drawer=privacy
            - text: ·
            - link "About the data & methods" [ref=e383] [cursor=pointer]:
              - /url: /about?drawer=methods
          - generic [ref=e384]:
            - heading "Feedback & security" [level=2] [ref=e385]
            - paragraph [ref=e386]:
              - link "SECURITY.md" [ref=e387] [cursor=pointer]:
                - /url: /SECURITY.md
          - generic [ref=e388]:
            - heading "Version & evidence" [level=2] [ref=e389]
            - generic [ref=e390]:
              - term [ref=e391]: Version
              - definition [ref=e392]: 0.1.0
              - term [ref=e393]: Commit
              - definition [ref=e394]: 01a68fd
              - term [ref=e395]: Map evaluation date
              - definition [ref=e396]: 2026-10-26
              - term [ref=e397]: Manila data as of
              - definition [ref=e398]: 2023-12-02
      - complementary [ref=e399]:
        - heading "Estimates, not alerts" [level=2] [ref=e400]
        - paragraph [ref=e401]: Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.
    - contentinfo [ref=e402]:
      - generic [ref=e403]:
        - link "About & Credits" [ref=e404] [cursor=pointer]:
          - /url: /about
        - button "About the data & methods" [ref=e405] [cursor=pointer]
      - paragraph [ref=e406]:
        - text: Bundled source periods.
        - time [ref=e407]: Dec 2, 2023
        - text: ·
        - time [ref=e408]: Dec 27, 2020
        - text: . Replay uses historical records. Live needs reviewed recent counts.
      - paragraph [ref=e409]: Community reports are unverified; not medical advice.
      - paragraph [ref=e410]: Background photograph by Sumarie Slabber
      - paragraph [ref=e411]: Thesis research · Not an official DOH product · Historical records, not a live warning.
    - dialog [ref=e412]:
      - generic [ref=e413]:
        - heading "About the data & methods" [level=2] [ref=e414]
        - button "Close dialog" [active] [ref=e415] [cursor=pointer]: ✕
      - generic [ref=e416]:
        - paragraph [ref=e417]: Current city models use historical NCR data through 2020-12-27. Replay is the default. Older Manila research remains below as an archive.
        - link "About & Credits" [ref=e418] [cursor=pointer]:
          - /url: /about
        - generic [ref=e419]:
          - generic [ref=e420]: Research detail
          - combobox "Research detail" [ref=e421] [cursor=pointer]:
            - 'option "City classification: methods and evidence"'
            - option "Archived Manila analytics" [selected]
            - option "Separate community aggregates"
            - option "Evaluation and limitations"
            - option "Source coverage and integrity"
            - option "Complete historical tables"
            - option "NCR historical city archive"
            - option "Full prevention and warning signs"
            - option "Terms of Use"
            - option "Legal and privacy notices"
            - option "Prior research summary"
        - generic [ref=e422]:
          - heading "Archived Manila research" [level=1] [ref=e423]
          - paragraph [ref=e424]: This earlier case-forecast research does not drive the current city classification map.
          - complementary [ref=e425]: Manila case data ends 2023-12-02. Province/city case data ends 2021-01-10. Neither is live.
          - generic [ref=e426]:
            - generic [ref=e427]:
              - paragraph [ref=e428]: THE QUESTION BEHIND THE THESIS
              - heading "Can better awareness begin with honest data?" [level=2] [ref=e429]
            - generic [ref=e430]:
              - paragraph [ref=e431]: Dengue is a mosquito-borne illness. This thesis asks whether historical cases and environmental context can support earlier awareness without overstating what the data can predict.
              - paragraph [ref=e432]: "We compare forecasts with a simple last-week baseline, make missing observations visible, and keep unverified community reports separate from official records. Objectives: describe patterns, test predictive skill, and provide a privacy-conscious awareness channel."
              - status [ref=e433]: Community reporting is closed.
          - generic [ref=e434]:
            - generic [ref=e435]:
              - generic [ref=e436]: Absent-day scenario
              - combobox "Absent-day scenario" [ref=e437] [cursor=pointer]:
                - option "M · absent dates remain missing" [selected]
                - option "Z · absent dates assumed zero"
            - paragraph [ref=e438]: Only weeks with seven daily rows are scored. An absent date is not a recorded zero. The final partial week is excluded in both scenarios.
          - generic [ref=e439]:
            - paragraph [ref=e440]: MANILA / HISTORICAL CASE FORECAST
            - heading "Current risk unavailable" [level=2] [ref=e441]
            - paragraph [ref=e442]: The case record is too old to establish current risk. This is the only case-forecast panel; the national map is a relative outlook.
            - paragraph [ref=e443]:
              - text: Data as of
              - time [ref=e444]: 2023-12-02
              - text: · Forecast origin 2023-11-26 · Scenario M
            - heading "Historical Manila forecast" [level=3] [ref=e445]
            - generic [ref=e446]:
              - article [ref=e447]:
                - heading "1 week(s) ahead" [level=3] [ref=e448]
                - paragraph [ref=e449]: 62 estimated cases
                - paragraph [ref=e450]: "Historical target: 2023-12-03"
                - paragraph [ref=e451]: "80% interval: 40–84"
              - article [ref=e452]:
                - heading "2 week(s) ahead" [level=3] [ref=e453]
                - paragraph [ref=e454]: 62 estimated cases
                - paragraph [ref=e455]: "Historical target: 2023-12-10"
                - paragraph [ref=e456]: "80% interval: 31–93"
            - paragraph [ref=e457]:
              - text: "Measured historical error (MAE, cases):"
              - generic [ref=e458]: "1 week(s): 15.47."
              - generic [ref=e459]: "2 week(s): 22.90."
            - paragraph [ref=e460]: One-week persistence means last week's value. These are retrospective estimates, not a warning for the coming days.
            - paragraph [ref=e461]: Remove standing water, protect against bites and seek early consultation for symptoms.
          - generic [ref=e462]:
            - 'heading "Seasonal watch: context only" [level=2] [ref=e463]'
            - paragraph [ref=e464]: PAGASA defines June to November as the rainy season. Clear containers of standing water and keep up bite prevention. This is seasonal context, not a dengue prediction or alert.
            - paragraph [ref=e465]: Dengue observations remain historical; current weather cannot establish today's dengue risk.
            - paragraph [ref=e466]: In complete-row history for 2016-2023 (Scenario M), mean weekly cases ranged from 22.8 in May to 122.1 in September. This does not measure a delay from rainfall onset to rising cases.
            - status [ref=e467]: Weather data unavailable; showing baseline forecast.
            - link "PAGASA season definition" [ref=e468] [cursor=pointer]:
              - /url: https://www.pagasa.dost.gov.ph/information/climate-philippines
          - generic [ref=e469]:
            - paragraph [ref=e470]: ANALYTICS / RECORDED EVIDENCE
            - heading "The story in the weekly record" [level=2] [ref=e471]
            - generic [ref=e472]:
              - heading "Manila weekly cases, with source boundaries" [level=3] [ref=e473]
              - figure "Scrollable Manila history chart" [ref=e474]:
                - img "Manila weekly case history 312 observed or scenario-defined weeks. Peak 257 cases. Gaps break the line. Shading marks the COVID period. Exact data appears in the table below." [ref=e475]:
                  - generic [ref=e477]: "0"
                  - generic [ref=e479]: "64"
                  - generic [ref=e481]: "129"
                  - generic [ref=e483]: "193"
                  - generic [ref=e485]: "257"
                  - generic [ref=e487]: COVID period
                  - generic [ref=e509]: 2016-01-10
                  - generic [ref=e510]: 2023-12-03
                  - generic [ref=e511]: Weekly cases · gaps remain gaps
                  - generic [ref=e512]: Source changes
                - generic [ref=e513]: DOH EPI before 2018; Manila daily-derived weeks from 2018. COVID period shaded (2020–2021). Source dates end 2023-12-02; final partial week excluded. Sunday labels operationally interpreted as week-ending; source semantics unconfirmed.
              - group [ref=e514]:
                - generic "Exact weekly values and quality flags" [ref=e515] [cursor=pointer]
            - generic [ref=e516]:
              - generic [ref=e517]:
                - heading "Year comparison" [level=3] [ref=e518]
                - paragraph [ref=e519]: Available weeks only; incomplete years are not annual totals.
                - region "Year comparison" [ref=e520]:
                  - table [ref=e521]:
                    - rowgroup [ref=e522]:
                      - row [ref=e523]:
                        - columnheader "Year" [ref=e524]
                        - columnheader "Recorded cases" [ref=e525]
                        - columnheader "Weeks" [ref=e526]
                    - rowgroup [ref=e527]:
                      - row [ref=e528]:
                        - rowheader "2016" [ref=e529]
                        - cell "1,990 · incomplete" [ref=e530]
                        - cell "45 / 51" [ref=e531]
                      - row [ref=e532]:
                        - rowheader "2017" [ref=e533]
                        - cell "2,813" [ref=e534]
                        - cell "53 / 53" [ref=e535]
                      - row [ref=e536]:
                        - rowheader "2018" [ref=e537]
                        - cell "3,530 · incomplete" [ref=e538]
                        - cell "47 / 52" [ref=e539]
                      - row [ref=e540]:
                        - rowheader "2019" [ref=e541]
                        - cell "3,761 · incomplete" [ref=e542]
                        - cell "43 / 52" [ref=e543]
                      - row [ref=e544]:
                        - rowheader "2020" [ref=e545]
                        - cell "451 · incomplete" [ref=e546]
                        - cell "13 / 52" [ref=e547]
                      - row [ref=e548]:
                        - rowheader "2021" [ref=e549]
                        - cell "883 · incomplete" [ref=e550]
                        - cell "24 / 52" [ref=e551]
                      - row [ref=e552]:
                        - rowheader "2022" [ref=e553]
                        - cell "2,516 · incomplete" [ref=e554]
                        - cell "42 / 52" [ref=e555]
                      - row [ref=e556]:
                        - rowheader "2023" [ref=e557]
                        - cell "2,346 · incomplete" [ref=e558]
                        - cell "45 / 49" [ref=e559]
              - generic [ref=e560]:
                - heading "Seasonal profile" [level=3] [ref=e561]
                - paragraph [ref=e562]: Mean weekly cases by month of week ending; observed/scenario-defined weeks only, not monthly totals.
                - generic [ref=e563]:
                  - generic [ref=e564]:
                    - generic [ref=e565]: Jan
                    - 'meter "Month 1: 53.8" [ref=e566]'
                    - generic [ref=e567]: "53.8"
                  - generic [ref=e568]:
                    - generic [ref=e569]: Feb
                    - 'meter "Month 2: 43.7" [ref=e570]'
                    - generic [ref=e571]: "43.7"
                  - generic [ref=e572]:
                    - generic [ref=e573]: Mar
                    - 'meter "Month 3: 29.4" [ref=e574]'
                    - generic [ref=e575]: "29.4"
                  - generic [ref=e576]:
                    - generic [ref=e577]: Apr
                    - 'meter "Month 4: 27.2" [ref=e578]'
                    - generic [ref=e579]: "27.2"
                  - generic [ref=e580]:
                    - generic [ref=e581]: May
                    - 'meter "Month 5: 22.8" [ref=e582]'
                    - generic [ref=e583]: "22.8"
                  - generic [ref=e584]:
                    - generic [ref=e585]: Jun
                    - 'meter "Month 6: 30" [ref=e586]'
                    - generic [ref=e587]: "30"
                  - generic [ref=e588]:
                    - generic [ref=e589]: Jul
                    - 'meter "Month 7: 49.6" [ref=e590]'
                    - generic [ref=e591]: "49.6"
                  - generic [ref=e592]:
                    - generic [ref=e593]: Aug
                    - 'meter "Month 8: 95.3" [ref=e594]'
                    - generic [ref=e595]: "95.3"
                  - generic [ref=e596]:
                    - generic [ref=e597]: Sep
                    - 'meter "Month 9: 122.1" [ref=e598]'
                    - generic [ref=e599]: "122.1"
                  - generic [ref=e600]:
                    - generic [ref=e601]: Oct
                    - 'meter "Month 10: 92.8" [ref=e602]'
                    - generic [ref=e603]: "92.8"
                  - generic [ref=e604]:
                    - generic [ref=e605]: Nov
                    - 'meter "Month 11: 72.1" [ref=e606]'
                    - generic [ref=e607]: "72.1"
                  - generic [ref=e608]:
                    - generic [ref=e609]: Dec
                    - 'meter "Month 12: 49.8" [ref=e610]'
                    - generic [ref=e611]: "49.8"
            - generic [ref=e612]:
              - 'heading "Forecast versus actual: held-out 2023" [level=3] [ref=e613]'
              - img "Saved one-week persistence predictions versus actual held-out cases" [ref=e614]
              - paragraph [ref=e617]: "Solid: recorded values. Dashed: one-week persistence. Each origin precedes its target."
              - group [ref=e618]:
                - generic "Backtest data table" [ref=e619] [cursor=pointer]
              - paragraph [ref=e620]: "Source: data/processed/evaluation.json · public/api/v2/dashboard.json."
            - generic [ref=e621]:
              - heading "How accurate is this?" [level=2] [ref=e622]
              - paragraph [ref=e623]: The public chart starts with Scenario M (only complete daily-row weeks). Scenario Z assumes absent dates are zero within coverage. Both are evaluated. The one-week public forecast is last week's value. Weather did not improve the predeclared one/two-week comparison. Two- to four-week ridge improvements are exploratory with wide uncertainty, not a validated operational warning.
              - paragraph [ref=e624]: Mean absolute error (MAE) is the average error in weekly case counts, from the saved 2018–2023 held-out evaluation. It does not establish accuracy for current conditions.
              - region "Forecast accuracy from saved evaluation" [ref=e625]:
                - table [ref=e626]:
                  - rowgroup [ref=e627]:
                    - row [ref=e628]:
                      - columnheader "Model" [ref=e629]
                      - columnheader "Weeks ahead" [ref=e630]
                      - columnheader "MAE (cases)" [ref=e631]
                      - columnheader "Evaluated targets" [ref=e632]
                  - rowgroup [ref=e633]:
                    - row [ref=e634]:
                      - rowheader "naive" [ref=e635]
                      - cell "1" [ref=e636]
                      - cell "15.47" [ref=e637]
                      - cell "116" [ref=e638]
                    - row [ref=e639]:
                      - rowheader "ridge-cases" [ref=e640]
                      - cell "1" [ref=e641]
                      - cell "16.36" [ref=e642]
                      - cell "116" [ref=e643]
                    - row [ref=e644]:
                      - rowheader "ridge-weather" [ref=e645]
                      - cell "1" [ref=e646]
                      - cell "18.39" [ref=e647]
                      - cell "116" [ref=e648]
                    - row [ref=e649]:
                      - rowheader "naive" [ref=e650]
                      - cell "2" [ref=e651]
                      - cell "22.90" [ref=e652]
                      - cell "117" [ref=e653]
                    - row [ref=e654]:
                      - rowheader "ridge-cases" [ref=e655]
                      - cell "2" [ref=e656]
                      - cell "22.17" [ref=e657]
                      - cell "117" [ref=e658]
                    - row [ref=e659]:
                      - rowheader "ridge-weather" [ref=e660]
                      - cell "2" [ref=e661]
                      - cell "23.17" [ref=e662]
                      - cell "117" [ref=e663]
                    - row [ref=e664]:
                      - rowheader "naive" [ref=e665]
                      - cell "4" [ref=e666]
                      - cell "31.63" [ref=e667]
                      - cell "112" [ref=e668]
                    - row [ref=e669]:
                      - rowheader "ridge-cases" [ref=e670]
                      - cell "4" [ref=e671]
                      - cell "27.43" [ref=e672]
                      - cell "112" [ref=e673]
                    - row [ref=e674]:
                      - rowheader "ridge-weather" [ref=e675]
                      - cell "4" [ref=e676]
                      - cell "28.42" [ref=e677]
                      - cell "112" [ref=e678]
          - region [ref=e680]:
            - paragraph [ref=e681]: TAKE CARE / ACT EARLY
            - heading "Know when to seek care" [level=2] [ref=e682]
            - paragraph [ref=e683]: Seek urgent medical care for severe abdominal pain, persistent vomiting, bleeding, difficulty breathing, unusual drowsiness or extreme weakness. Do not wait for a report review.
            - 'link "Source: CDC dengue warning signs" [ref=e684] [cursor=pointer]':
              - /url: https://www.cdc.gov/dengue/hcp/clinical-care/
            - heading "Make the DOH 4S a habit" [level=3] [ref=e685]
            - list [ref=e686]:
              - listitem [ref=e687]: "Search and destroy mosquito breeding places: empty and clean standing-water containers."
              - listitem [ref=e688]: "Self-protection: use repellent as directed and wear protective clothing."
              - listitem [ref=e689]: Seek early consultation for fever or dengue-like symptoms.
              - listitem [ref=e690]: Support health-authority fogging or spraying in identified hotspot/outbreak areas.
            - 'link "Source: Ministry of Health 4S guidance" [ref=e691] [cursor=pointer]':
              - /url: https://bangsamoro.gov.ph/news/latest-news/moh-urges-public-to-observe-4s-strategy-against-dengue/
            - paragraph [ref=e692]:
              - strong [ref=e693]: Informational, not a diagnosis. Not an official DOH product.
  - status
```

# Test source

```ts
  1   | import {goto,activeView} from '../support/active-view';
  2   | import { test, expect } from "@playwright/test";
  3   | import AxeBuilder from "@axe-core/playwright";
  4   | test("weather failure leaves historical persistence usable and providers stay server-only", async ({
  5   |   page,
  6   | }) => {
  7   |   const providerCalls: string[] = [];
  8   |   page.on("request", (r) => {
  9   |     if (
  10  |       /archive-api\.open-meteo|power\.larc|overpass|opentopodata/.test(r.url())
  11  |     )
  12  |       providerCalls.push(r.url());
  13  |   });
  14  |   await page.route("**/api/v2/weather.json", (route) =>
  15  |     route.fulfill({ status: 503, body: "unavailable" }),
  16  |   );
  17  |   await goto(page, "/about?drawer=methods&section=dashboard");
  18  |   await expect(
  19  |     activeView(page).getByRole("heading", { name: "Current risk unavailable" }),
  20  |   ).toBeVisible();
  21  |   await expect(
  22  |     activeView(page).getByText("Weather data unavailable; showing baseline forecast.", {
  23  |       exact: true,
  24  |     }),
  25  |   ).toBeVisible();
  26  |   await expect(activeView(page).getByText(/In complete-row history/)).toContainText(
  27  |     "122.1",
  28  |   );
  29  |   await expect(
  30  |     activeView(page).getByRole("heading", { name: "Historical Manila forecast" }),
  31  |   ).toBeVisible();
  32  |   const data = await (await page.request.get("/api/v2/manila.json")).json();
  33  |   expect(data.snapshots.every((s: any) => s.model === "naive")).toBe(true);
> 34  |   await activeView(page).getByRole("button", { name: "Filipino", exact: true }).click();
      |                                                                                 ^ Error: locator.click: Test timeout of 30000ms exceeded.
  35  |   await expect(
  36  |     activeView(page).getByRole("heading", { name: "Bantay-panahon: konteksto lamang" }),
  37  |   ).toBeVisible();
  38  |   await expect(
  39  |     activeView(page).getByText(
  40  |       "Hindi makuha ang datos ng panahon; batayang pagtataya ang ipinapakita.",
  41  |       { exact: true },
  42  |     ),
  43  |   ).toBeVisible();
  44  |   expect(providerCalls).toEqual([]);
  45  | });
  46  | test("environment ablation and exploratory city context remain accessible at 360px", async ({
  47  |   page,
  48  | }) => {
  49  |   test.setTimeout(120000);
  50  |   await page.setViewportSize({ width: 360, height: 900 });
  51  |   await goto(page, "/methodology");
  52  |   const table = activeView(page).getByRole("region", {
  53  |     name: "Season and weather ablation metrics",
  54  |   });
  55  |   await expect(table).toBeVisible();
  56  |   await expect(table.getByRole("row")).toHaveCount(7);
  57  |   await activeView(page).getByLabel("Environmental scenario", { exact: true })
  58  |     .selectOption("Z");
  59  |   await activeView(page).getByLabel("Environmental fold", { exact: true })
  60  |     .selectOption("2023");
  61  |   await activeView(page).getByLabel("Environmental horizon", { exact: true })
  62  |     .selectOption("2");
  63  |   await expect(
  64  |     table.getByRole("rowheader", { name: "env-season", exact: true }),
  65  |   ).toBeVisible();
  66  |   await expect(activeView(page).getByText(/469 paired weeks/)).toBeVisible();
  67  |   await goto(page, "/metro-manila");
  68  |   await activeView(page).getByRole("button", { name: "Show exploratory city context" })
  69  |     .click();
  70  |   const values = activeView(page).getByRole("region", {
  71  |     name: "City geographic context values",
  72  |   });
  73  |   await expect(values.getByRole("row")).toHaveCount(18);
  74  |   await expect(
  75  |     activeView(page).getByRole("region", { name: "Exploratory geographic effect sizes" })
  76  |       .getByRole("row"),
  77  |   ).toHaveCount(7);
  78  |   const axe = await new AxeBuilder({ page })
  79  |     .withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"])
  80  |     .analyze();
  81  |   expect(
  82  |     axe.violations.filter((v) =>
  83  |       ["critical", "serious"].includes(v.impact ?? ""),
  84  |     ),
  85  |   ).toEqual([]);
  86  |   expect(
  87  |     await page.evaluate(
  88  |       () => document.documentElement.scrollWidth <= innerWidth + 1,
  89  |     ),
  90  |   ).toBe(true);
  91  |   await goto(page, "/data-sources");
  92  |   await expect(
  93  |     activeView(page).getByRole("heading", {
  94  |       name: "Environmental and geographic providers",
  95  |     }),
  96  |   ).toBeVisible();
  97  |   await expect(
  98  |     activeView(page).getByText(/This data was obtained from the NASA Langley/),
  99  |   ).toBeVisible();
  100 | });
  101 | 
```