# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: staff-reporting.spec.ts >> v2 open-policy preview collects coarse fields only and strips identifying note patterns
- Location: tests\ui\staff-reporting.spec.ts:60:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 93

- Array []
+ Array [
+   Object {
+     "description": "Ensure the contrast between foreground and background colors meets WCAG 2 AA minimum contrast ratio thresholds",
+     "help": "Elements must meet minimum color contrast ratio thresholds",
+     "helpUrl": "https://dequeuniversity.com/rules/axe/4.13/color-contrast?application=playwright",
+     "id": "color-contrast",
+     "impact": "serious",
+     "nodes": Array [
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "bgColor": "#071b2b",
+               "contrastRatio": 1.57,
+               "expectedContrastRatio": "4.5:1",
+               "fgColor": "#24396f",
+               "fontSize": "12.0pt (16px)",
+               "fontWeight": "normal",
+               "messageKey": null,
+             },
+             "id": "color-contrast",
+             "impact": "serious",
+             "message": "Element has insufficient color contrast of 1.57 (foreground color: #24396f, background color: #071b2b, font size: 12.0pt (16px), font weight: normal). Expected contrast ratio of 4.5:1",
+             "relatedNodes": Array [
+               Object {
+                 "html": "<div class=\"photo-app inner-page\">",
+                 "target": Array [
+                   ".photo-app",
+                 ],
+               },
+             ],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Element has insufficient color contrast of 1.57 (foreground color: #24396f, background color: #071b2b, font size: 12.0pt (16px), font weight: normal). Expected contrast ratio of 4.5:1",
+         "html": "<a class=\"text-link\" href=\"/community\" data-discover=\"true\">View community aggregates</a>",
+         "impact": "serious",
+         "none": Array [],
+         "target": Array [
+           "a[href$=\"community\"]",
+         ],
+       },
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "bgColor": "#071b2b",
+               "contrastRatio": 1.57,
+               "expectedContrastRatio": "4.5:1",
+               "fgColor": "#24396f",
+               "fontSize": "12.0pt (16px)",
+               "fontWeight": "normal",
+               "messageKey": null,
+             },
+             "id": "color-contrast",
+             "impact": "serious",
+             "message": "Element has insufficient color contrast of 1.57 (foreground color: #24396f, background color: #071b2b, font size: 12.0pt (16px), font weight: normal). Expected contrast ratio of 4.5:1",
+             "relatedNodes": Array [
+               Object {
+                 "html": "<div class=\"photo-app inner-page\">",
+                 "target": Array [
+                   ".photo-app",
+                 ],
+               },
+             ],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Element has insufficient color contrast of 1.57 (foreground color: #24396f, background color: #071b2b, font size: 12.0pt (16px), font weight: normal). Expected contrast ratio of 4.5:1",
+         "html": "<a class=\"text-link\" href=\"/prevention\" data-discover=\"true\">Prevention and urgent warning signs</a>",
+         "impact": "serious",
+         "none": Array [],
+         "target": Array [
+           "a[href$=\"prevention\"]",
+         ],
+       },
+     ],
+     "tags": Array [
+       "cat.color",
+       "wcag2aa",
+       "wcag143",
+       "TTv5",
+       "TT13.c",
+       "EN-301-549",
+       "EN-9.1.4.3",
+       "ACT",
+       "RGAAv4",
+       "RGAA-3.2.1",
+     ],
+   },
+ ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - link "Skip to content" [ref=e5] [cursor=pointer]:
      - /url: "#main"
    - banner [ref=e6]:
      - link "DengueWatch home" [ref=e7] [cursor=pointer]:
        - /url: /
        - text: DENGUE
        - generic [ref=e8]: WATCH
      - button "Menu" [ref=e9] [cursor=pointer]
      - generic "Page language" [ref=e10]:
        - button "English" [pressed] [ref=e11] [cursor=pointer]
        - button "Filipino" [ref=e12] [cursor=pointer]
    - main [ref=e13]:
      - generic [ref=e15]:
        - paragraph [ref=e16]: COMMUNITY / UNVERIFIED
        - heading "Share an awareness signal." [level=1] [ref=e17]
        - paragraph [ref=e18]: Report a suspected case in your household or an unusual cluster you noticed. Choose only a coarse area; no GPS or free-text address is collected. Barangay selection is available only for the verified Manila catalogue; other units stay at province/city level. The onset day may be approximate.
        - paragraph [ref=e19]: We do not ask for your name or contact details, do not store your IP address or precise location, and use no trackers. No system can promise perfect anonymity, so do not include details that identify you or others. Reports never enter official counts, forecasts or the Outlook Index.
        - generic [ref=e20]:
          - paragraph [ref=e21]: An IP address, when provided by the trusted hosting proxy, is used transiently to derive a rotating salted rate-limit hash. Raw IPs are never stored. Hashes expire after a 15-minute window and are physically removed on a successful request or the hourly retention job (up to 75 minutes). Automated note filters cannot detect every identifying detail. Retention and consent require DPO review before collection opens.
          - generic [ref=e22]:
            - heading "Your report" [level=2] [ref=e23]
            - generic [ref=e24]:
              - generic [ref=e25]: Report type
              - combobox "Report type" [ref=e26] [cursor=pointer]:
                - option "Suspected household / family case" [selected]
                - option "Unusual cluster in the area"
            - generic [ref=e27]:
              - generic [ref=e28]: Province / city (coarse reporting unit)
              - combobox "Province / city (coarse reporting unit)" [ref=e29] [cursor=pointer]:
                - option "ABRA"
                - option "AGUSAN DEL NORTE"
                - option "AGUSAN DEL SUR"
                - option "AKLAN"
                - option "ALBAY"
                - option "ANGELES CITY"
                - option "ANTIQUE"
                - option "APAYAO"
                - option "AURORA"
                - option "BACOLOD CITY"
                - option "BAGUIO CITY"
                - option "BASILAN"
                - option "BASILIG CITY"
                - option "BATAAN"
                - option "BATANES"
                - option "BATANGAS"
                - option "BAYUGAN CITY"
                - option "BENGUET"
                - option "BILIRAN"
                - option "BOHOL"
                - option "BUKIDNON"
                - option "BULACAN"
                - option "BUTUAN CITY"
                - option "CABADBARAN CITY"
                - option "CAGAYAN"
                - option "CAGAYAN DE ORO CITY"
                - option "CALOOCAN CITY"
                - option "CAMARINES NORTE"
                - option "CAMARINES SUR"
                - option "CAMIGUIN"
                - option "CAPIZ"
                - option "CATANDUANES"
                - option "CAVITE"
                - option "CEBU"
                - option "CEBU CITY"
                - option "COTABATO CITY"
                - option "DAGUPAN CITY"
                - option "DAVAO CITY"
                - option "DAVAO DE ORO"
                - option "DAVAO DEL NORTE"
                - option "DAVAO DEL SUR"
                - option "DAVAO OCCIDENTAL"
                - option "DAVAO ORIENTAL"
                - option "DINAGAT ISLANDS"
                - option "EASTERN SAMAR"
                - option "GENERAL SANTOS CITY"
                - option "GUIMARAS"
                - option "IFUGAO"
                - option "ILIGAN CITY"
                - option "ILOCOS NORTE"
                - option "ILOCOS SUR"
                - option "ILOILO"
                - option "ILOILO CITY"
                - option "ISABELA"
                - option "ISABELA CITY"
                - option "KALINGA"
                - option "LA UNION"
                - option "LAGUNA"
                - option "LANAO DEL NORTE"
                - option "LANAO DEL SUR"
                - option "LAPU-LAPU CITY"
                - option "LAS PINAS CITY"
                - option "LEYTE"
                - option "LUCENA CITY"
                - option "MAGUINDANAO"
                - option "MAKATI CITY"
                - option "MALABON CITY"
                - option "MANDALUYONG CITY"
                - option "MANDAUE CITY"
                - option "MANILA CITY" [selected]
                - option "MARIKINA CITY"
                - option "MARINDUQUE"
                - option "MASBATE"
                - option "MISAMIS OCCIDENTAL"
                - option "MISAMIS ORIENTAL"
                - option "MOUNTAIN PROVINCE"
                - option "MUNTINLUPA CITY"
                - option "NAGA CITY"
                - option "NAVOTAS CITY"
                - option "NEGROS OCCIDENTAL"
                - option "NEGROS ORIENTAL"
                - option "NORTH COTABATO"
                - option "NORTHERN SAMAR"
                - option "NUEVA ECIJA"
                - option "NUEVA VISCAYA"
                - option "OCCIDENTAL MINDORO"
                - option "OLONGAPO CITY"
                - option "ORIENTAL MINDORO"
                - option "ORMOC CITY"
                - option "PALAWAN"
                - option "PAMPANGA"
                - option "PANGASINAN"
                - option "PARANAQUE CITY"
                - option "PASAY CITY"
                - option "PASIG CITY"
                - option "PATEROS"
                - option "PUERTO PRINCESA CITY"
                - option "QUEZON"
                - option "QUEZON CITY"
                - option "QUIRINO"
                - option "RIZAL"
                - option "ROMBLON"
                - option "SAMAR"
                - option "SAN JUAN CITY"
                - option "SANTIAGO CITY"
                - option "SARANGANI"
                - option "SISQUIJOR"
                - option "SORSOGON"
                - option "SOUTH COTABATO"
                - option "SOUTHERN LEYTE"
                - option "SULTAN KUDARAT"
                - option "SULU"
                - option "SURIGAO CITY"
                - option "SURIGAO DEL NORTE"
                - option "SURIGAO DEL SUR"
                - option "TACLOBAN"
                - option "TAGUIG CITY"
                - option "TANDAG CITY"
                - option "TARLAC"
                - option "TAWI-TAWI"
                - option "VALENZUELA CITY"
                - option "ZAMBALES"
                - option "ZAMBOANGA CITY"
                - option "ZAMBOANGA DEL NORTE"
                - option "ZAMBOANGA DEL SUR"
                - option "ZAMBOANGA SIBUGAY"
            - generic [ref=e30]:
              - generic [ref=e31]: People affected (approximate range)
              - combobox "People affected (approximate range)" [ref=e32] [cursor=pointer]:
                - option "1" [selected]
                - option "2-4"
                - option "5-9"
                - option "10+"
            - generic [ref=e33]:
              - generic [ref=e34]: Barangay (coarse area only)
              - combobox "Barangay (coarse area only)" [ref=e35] [cursor=pointer]:
                - option "Manila city · area not listed / prefer not to specify" [selected]
                - option "Barangay 1"
                - option "Barangay 2"
                - option "Barangay 3"
                - option "Barangay 4"
                - option "Barangay 5"
                - option "Barangay 6"
                - option "Barangay 7"
                - option "Barangay 8"
                - option "Barangay 9"
                - option "Barangay 10"
                - option "Barangay 11"
                - option "Barangay 12"
                - option "Barangay 13"
                - option "Barangay 14"
                - option "Barangay 15"
                - option "Barangay 16"
                - option "Barangay 17"
                - option "Barangay 18"
                - option "Barangay 19"
                - option "Barangay 20"
                - option "Barangay 25"
                - option "Barangay 26"
                - option "Barangay 28"
                - option "Barangay 29"
                - option "Barangay 30"
                - option "Barangay 31"
                - option "Barangay 32"
                - option "Barangay 33"
                - option "Barangay 34"
                - option "Barangay 35"
                - option "Barangay 36"
                - option "Barangay 37"
                - option "Barangay 38"
                - option "Barangay 39"
                - option "Barangay 41"
                - option "Barangay 42"
                - option "Barangay 43"
                - option "Barangay 44"
                - option "Barangay 45"
                - option "Barangay 46"
                - option "Barangay 47"
                - option "Barangay 48"
                - option "Barangay 49"
                - option "Barangay 50"
                - option "Barangay 51"
                - option "Barangay 52"
                - option "Barangay 53"
                - option "Barangay 54"
                - option "Barangay 55"
                - option "Barangay 56"
                - option "Barangay 57"
                - option "Barangay 58"
                - option "Barangay 59"
                - option "Barangay 60"
                - option "Barangay 61"
                - option "Barangay 62"
                - option "Barangay 63"
                - option "Barangay 64"
                - option "Barangay 65"
                - option "Barangay 66"
                - option "Barangay 67"
                - option "Barangay 68"
                - option "Barangay 69"
                - option "Barangay 70"
                - option "Barangay 71"
                - option "Barangay 72"
                - option "Barangay 73"
                - option "Barangay 74"
                - option "Barangay 75"
                - option "Barangay 76"
                - option "Barangay 77"
                - option "Barangay 78"
                - option "Barangay 79"
                - option "Barangay 80"
                - option "Barangay 81"
                - option "Barangay 82"
                - option "Barangay 83"
                - option "Barangay 84"
                - option "Barangay 85"
                - option "Barangay 86"
                - option "Barangay 87"
                - option "Barangay 88"
                - option "Barangay 89"
                - option "Barangay 90"
                - option "Barangay 91"
                - option "Barangay 92"
                - option "Barangay 93"
                - option "Barangay 94"
                - option "Barangay 95"
                - option "Barangay 96"
                - option "Barangay 97"
                - option "Barangay 98"
                - option "Barangay 99"
                - option "Barangay 100"
                - option "Barangay 101"
                - option "Barangay 102"
                - option "Barangay 103"
                - option "Barangay 104"
                - option "Barangay 105"
                - option "Barangay 106"
                - option "Barangay 107"
                - option "Barangay 108"
                - option "Barangay 109"
                - option "Barangay 110"
                - option "Barangay 111"
                - option "Barangay 112"
                - option "Barangay 116"
                - option "Barangay 117"
                - option "Barangay 118"
                - option "Barangay 119"
                - option "Barangay 120"
                - option "Barangay 121"
                - option "Barangay 122"
                - option "Barangay 123"
                - option "Barangay 124"
                - option "Barangay 125"
                - option "Barangay 126"
                - option "Barangay 127"
                - option "Barangay 128"
                - option "Barangay 129"
                - option "Barangay 130"
                - option "Barangay 131"
                - option "Barangay 132"
                - option "Barangay 133"
                - option "Barangay 134"
                - option "Barangay 135"
                - option "Barangay 136"
                - option "Barangay 137"
                - option "Barangay 138"
                - option "Barangay 139"
                - option "Barangay 140"
                - option "Barangay 141"
                - option "Barangay 142"
                - option "Barangay 143"
                - option "Barangay 144"
                - option "Barangay 145"
                - option "Barangay 146"
                - option "Barangay 147"
                - option "Barangay 148"
                - option "Barangay 149"
                - option "Barangay 150"
                - option "Barangay 151"
                - option "Barangay 152"
                - option "Barangay 153"
                - option "Barangay 154"
                - option "Barangay 155"
                - option "Barangay 156"
                - option "Barangay 157"
                - option "Barangay 158"
                - option "Barangay 159"
                - option "Barangay 160"
                - option "Barangay 161"
                - option "Barangay 162"
                - option "Barangay 163"
                - option "Barangay 164"
                - option "Barangay 165"
                - option "Barangay 166"
                - option "Barangay 167"
                - option "Barangay 168"
                - option "Barangay 169"
                - option "Barangay 170"
                - option "Barangay 171"
                - option "Barangay 172"
                - option "Barangay 173"
                - option "Barangay 174"
                - option "Barangay 175"
                - option "Barangay 176"
                - option "Barangay 177"
                - option "Barangay 178"
                - option "Barangay 179"
                - option "Barangay 180"
                - option "Barangay 181"
                - option "Barangay 182"
                - option "Barangay 183"
                - option "Barangay 184"
                - option "Barangay 185"
                - option "Barangay 186"
                - option "Barangay 187"
                - option "Barangay 188"
                - option "Barangay 189"
                - option "Barangay 190"
                - option "Barangay 191"
                - option "Barangay 192"
                - option "Barangay 193"
                - option "Barangay 194"
                - option "Barangay 195"
                - option "Barangay 196"
                - option "Barangay 197"
                - option "Barangay 198"
                - option "Barangay 199"
                - option "Barangay 200"
                - option "Barangay 201"
                - option "Barangay 202"
                - option "Barangay 202-A"
                - option "Barangay 203"
                - option "Barangay 204"
                - option "Barangay 205"
                - option "Barangay 206"
                - option "Barangay 207"
                - option "Barangay 208"
                - option "Barangay 209"
                - option "Barangay 210"
                - option "Barangay 211"
                - option "Barangay 212"
                - option "Barangay 213"
                - option "Barangay 214"
                - option "Barangay 215"
                - option "Barangay 216"
                - option "Barangay 217"
                - option "Barangay 218"
                - option "Barangay 219"
                - option "Barangay 220"
                - option "Barangay 221"
                - option "Barangay 222"
                - option "Barangay 223"
                - option "Barangay 224"
                - option "Barangay 225"
                - option "Barangay 226"
                - option "Barangay 227"
                - option "Barangay 228"
                - option "Barangay 229"
                - option "Barangay 230"
                - option "Barangay 231"
                - option "Barangay 232"
                - option "Barangay 233"
                - option "Barangay 234"
                - option "Barangay 235"
                - option "Barangay 236"
                - option "Barangay 237"
                - option "Barangay 238"
                - option "Barangay 239"
                - option "Barangay 240"
                - option "Barangay 241"
                - option "Barangay 242"
                - option "Barangay 243"
                - option "Barangay 244"
                - option "Barangay 245"
                - option "Barangay 246"
                - option "Barangay 247"
                - option "Barangay 248"
                - option "Barangay 249"
                - option "Barangay 250"
                - option "Barangay 251"
                - option "Barangay 252"
                - option "Barangay 253"
                - option "Barangay 254"
                - option "Barangay 255"
                - option "Barangay 256"
                - option "Barangay 257"
                - option "Barangay 258"
                - option "Barangay 259"
                - option "Barangay 260"
                - option "Barangay 261"
                - option "Barangay 262"
                - option "Barangay 263"
                - option "Barangay 264"
                - option "Barangay 265"
                - option "Barangay 266"
                - option "Barangay 267"
                - option "Barangay 268"
                - option "Barangay 269"
                - option "Barangay 270"
                - option "Barangay 271"
                - option "Barangay 272"
                - option "Barangay 273"
                - option "Barangay 274"
                - option "Barangay 275"
                - option "Barangay 276"
                - option "Barangay 281"
                - option "Barangay 282"
                - option "Barangay 283"
                - option "Barangay 284"
                - option "Barangay 285"
                - option "Barangay 286"
                - option "Barangay 287"
                - option "Barangay 288"
                - option "Barangay 289"
                - option "Barangay 290"
                - option "Barangay 291"
                - option "Barangay 292"
                - option "Barangay 293"
                - option "Barangay 294"
                - option "Barangay 295"
                - option "Barangay 296"
                - option "Barangay 297"
                - option "Barangay 298"
                - option "Barangay 299"
                - option "Barangay 300"
                - option "Barangay 301"
                - option "Barangay 302"
                - option "Barangay 303"
                - option "Barangay 304"
                - option "Barangay 305"
                - option "Barangay 306"
                - option "Barangay 307"
                - option "Barangay 308"
                - option "Barangay 309"
                - option "Barangay 310"
                - option "Barangay 311"
                - option "Barangay 312"
                - option "Barangay 313"
                - option "Barangay 314"
                - option "Barangay 315"
                - option "Barangay 316"
                - option "Barangay 317"
                - option "Barangay 318"
                - option "Barangay 319"
                - option "Barangay 320"
                - option "Barangay 321"
                - option "Barangay 322"
                - option "Barangay 323"
                - option "Barangay 324"
                - option "Barangay 325"
                - option "Barangay 326"
                - option "Barangay 327"
                - option "Barangay 328"
                - option "Barangay 329"
                - option "Barangay 330"
                - option "Barangay 331"
                - option "Barangay 332"
                - option "Barangay 333"
                - option "Barangay 334"
                - option "Barangay 335"
                - option "Barangay 336"
                - option "Barangay 337"
                - option "Barangay 338"
                - option "Barangay 339"
                - option "Barangay 340"
                - option "Barangay 341"
                - option "Barangay 342"
                - option "Barangay 343"
                - option "Barangay 344"
                - option "Barangay 345"
                - option "Barangay 346"
                - option "Barangay 347"
                - option "Barangay 348"
                - option "Barangay 349"
                - option "Barangay 350"
                - option "Barangay 351"
                - option "Barangay 352"
                - option "Barangay 353"
                - option "Barangay 354"
                - option "Barangay 355"
                - option "Barangay 356"
                - option "Barangay 357"
                - option "Barangay 358"
                - option "Barangay 359"
                - option "Barangay 360"
                - option "Barangay 361"
                - option "Barangay 362"
                - option "Barangay 363"
                - option "Barangay 364"
                - option "Barangay 365"
                - option "Barangay 366"
                - option "Barangay 367"
                - option "Barangay 368"
                - option "Barangay 369"
                - option "Barangay 370"
                - option "Barangay 371"
                - option "Barangay 372"
                - option "Barangay 373"
                - option "Barangay 374"
                - option "Barangay 375"
                - option "Barangay 376"
                - option "Barangay 377"
                - option "Barangay 378"
                - option "Barangay 379"
                - option "Barangay 380"
                - option "Barangay 381"
                - option "Barangay 382"
                - option "Barangay 383"
                - option "Barangay 384"
                - option "Barangay 385"
                - option "Barangay 386"
                - option "Barangay 387"
                - option "Barangay 388"
                - option "Barangay 389"
                - option "Barangay 390"
                - option "Barangay 391"
                - option "Barangay 392"
                - option "Barangay 393"
                - option "Barangay 394"
                - option "Barangay 395"
                - option "Barangay 396"
                - option "Barangay 397"
                - option "Barangay 398"
                - option "Barangay 399"
                - option "Barangay 400"
                - option "Barangay 401"
                - option "Barangay 402"
                - option "Barangay 403"
                - option "Barangay 404"
                - option "Barangay 405"
                - option "Barangay 406"
                - option "Barangay 407"
                - option "Barangay 408"
                - option "Barangay 409"
                - option "Barangay 410"
                - option "Barangay 411"
                - option "Barangay 412"
                - option "Barangay 413"
                - option "Barangay 414"
                - option "Barangay 415"
                - option "Barangay 416"
                - option "Barangay 417"
                - option "Barangay 418"
                - option "Barangay 419"
                - option "Barangay 420"
                - option "Barangay 421"
                - option "Barangay 422"
                - option "Barangay 423"
                - option "Barangay 424"
                - option "Barangay 425"
                - option "Barangay 426"
                - option "Barangay 427"
                - option "Barangay 428"
                - option "Barangay 429"
                - option "Barangay 430"
                - option "Barangay 431"
                - option "Barangay 432"
                - option "Barangay 433"
                - option "Barangay 434"
                - option "Barangay 435"
                - option "Barangay 436"
                - option "Barangay 437"
                - option "Barangay 438"
                - option "Barangay 439"
                - option "Barangay 440"
                - option "Barangay 441"
                - option "Barangay 442"
                - option "Barangay 443"
                - option "Barangay 444"
                - option "Barangay 445"
                - option "Barangay 446"
                - option "Barangay 447"
                - option "Barangay 448"
                - option "Barangay 449"
                - option "Barangay 450"
                - option "Barangay 451"
                - option "Barangay 452"
                - option "Barangay 453"
                - option "Barangay 454"
                - option "Barangay 455"
                - option "Barangay 456"
                - option "Barangay 457"
                - option "Barangay 458"
                - option "Barangay 459"
                - option "Barangay 460"
                - option "Barangay 461"
                - option "Barangay 462"
                - option "Barangay 463"
                - option "Barangay 464"
                - option "Barangay 465"
                - option "Barangay 466"
                - option "Barangay 467"
                - option "Barangay 468"
                - option "Barangay 469"
                - option "Barangay 470"
                - option "Barangay 471"
                - option "Barangay 472"
                - option "Barangay 473"
                - option "Barangay 474"
                - option "Barangay 475"
                - option "Barangay 476"
                - option "Barangay 477"
                - option "Barangay 478"
                - option "Barangay 479"
                - option "Barangay 480"
                - option "Barangay 481"
                - option "Barangay 482"
                - option "Barangay 483"
                - option "Barangay 484"
                - option "Barangay 485"
                - option "Barangay 486"
                - option "Barangay 487"
                - option "Barangay 488"
                - option "Barangay 489"
                - option "Barangay 490"
                - option "Barangay 491"
                - option "Barangay 492"
                - option "Barangay 493"
                - option "Barangay 494"
                - option "Barangay 495"
                - option "Barangay 496"
                - option "Barangay 497"
                - option "Barangay 498"
                - option "Barangay 499"
                - option "Barangay 500"
                - option "Barangay 501"
                - option "Barangay 502"
                - option "Barangay 503"
                - option "Barangay 504"
                - option "Barangay 505"
                - option "Barangay 506"
                - option "Barangay 507"
                - option "Barangay 508"
                - option "Barangay 509"
                - option "Barangay 510"
                - option "Barangay 511"
                - option "Barangay 512"
                - option "Barangay 513"
                - option "Barangay 514"
                - option "Barangay 515"
                - option "Barangay 516"
                - option "Barangay 517"
                - option "Barangay 518"
                - option "Barangay 519"
                - option "Barangay 520"
                - option "Barangay 521"
                - option "Barangay 522"
                - option "Barangay 523"
                - option "Barangay 524"
                - option "Barangay 525"
                - option "Barangay 526"
                - option "Barangay 527"
                - option "Barangay 528"
                - option "Barangay 529"
                - option "Barangay 530"
                - option "Barangay 531"
                - option "Barangay 532"
                - option "Barangay 533"
                - option "Barangay 534"
                - option "Barangay 535"
                - option "Barangay 536"
                - option "Barangay 537"
                - option "Barangay 538"
                - option "Barangay 539"
                - option "Barangay 540"
                - option "Barangay 541"
                - option "Barangay 542"
                - option "Barangay 543"
                - option "Barangay 544"
                - option "Barangay 545"
                - option "Barangay 546"
                - option "Barangay 547"
                - option "Barangay 548"
                - option "Barangay 549"
                - option "Barangay 550"
                - option "Barangay 551"
                - option "Barangay 552"
                - option "Barangay 553"
                - option "Barangay 554"
                - option "Barangay 555"
                - option "Barangay 556"
                - option "Barangay 557"
                - option "Barangay 558"
                - option "Barangay 559"
                - option "Barangay 560"
                - option "Barangay 561"
                - option "Barangay 562"
                - option "Barangay 563"
                - option "Barangay 564"
                - option "Barangay 565"
                - option "Barangay 566"
                - option "Barangay 567"
                - option "Barangay 568"
                - option "Barangay 569"
                - option "Barangay 570"
                - option "Barangay 571"
                - option "Barangay 572"
                - option "Barangay 573"
                - option "Barangay 574"
                - option "Barangay 575"
                - option "Barangay 576"
                - option "Barangay 577"
                - option "Barangay 578"
                - option "Barangay 579"
                - option "Barangay 580"
                - option "Barangay 581"
                - option "Barangay 582"
                - option "Barangay 583"
                - option "Barangay 584"
                - option "Barangay 585"
                - option "Barangay 586"
                - option "Barangay 587"
                - option "Barangay 587-A"
                - option "Barangay 588"
                - option "Barangay 589"
                - option "Barangay 590"
                - option "Barangay 591"
                - option "Barangay 592"
                - option "Barangay 593"
                - option "Barangay 594"
                - option "Barangay 595"
                - option "Barangay 596"
                - option "Barangay 597"
                - option "Barangay 598"
                - option "Barangay 599"
                - option "Barangay 600"
                - option "Barangay 601"
                - option "Barangay 602"
                - option "Barangay 603"
                - option "Barangay 604"
                - option "Barangay 605"
                - option "Barangay 606"
                - option "Barangay 607"
                - option "Barangay 608"
                - option "Barangay 609"
                - option "Barangay 610"
                - option "Barangay 611"
                - option "Barangay 612"
                - option "Barangay 613"
                - option "Barangay 614"
                - option "Barangay 615"
                - option "Barangay 616"
                - option "Barangay 617"
                - option "Barangay 618"
                - option "Barangay 619"
                - option "Barangay 620"
                - option "Barangay 621"
                - option "Barangay 622"
                - option "Barangay 623"
                - option "Barangay 624"
                - option "Barangay 625"
                - option "Barangay 626"
                - option "Barangay 627"
                - option "Barangay 628"
                - option "Barangay 629"
                - option "Barangay 630"
                - option "Barangay 631"
                - option "Barangay 632"
                - option "Barangay 633"
                - option "Barangay 634"
                - option "Barangay 635"
                - option "Barangay 636"
                - option "Barangay 637"
                - option "Barangay 638"
                - option "Barangay 639"
                - option "Barangay 640"
                - option "Barangay 641"
                - option "Barangay 642"
                - option "Barangay 643"
                - option "Barangay 644"
                - option "Barangay 645"
                - option "Barangay 646"
                - option "Barangay 647"
                - option "Barangay 648"
                - option "Barangay 649"
                - option "Barangay 650"
                - option "Barangay 651"
                - option "Barangay 652"
                - option "Barangay 653"
                - option "Barangay 654"
                - option "Barangay 655"
                - option "Barangay 656"
                - option "Barangay 657"
                - option "Barangay 658"
                - option "Barangay 659"
                - option "Barangay 659-A"
                - option "Barangay 660"
                - option "Barangay 660-A"
                - option "Barangay 661"
                - option "Barangay 662"
                - option "Barangay 663"
                - option "Barangay 663-A"
                - option "Barangay 664"
                - option "Barangay 664-A"
                - option "Barangay 666"
                - option "Barangay 667"
                - option "Barangay 668"
                - option "Barangay 669"
                - option "Barangay 670"
                - option "Barangay 671"
                - option "Barangay 672"
                - option "Barangay 673"
                - option "Barangay 674"
                - option "Barangay 675"
                - option "Barangay 676"
                - option "Barangay 677"
                - option "Barangay 678"
                - option "Barangay 679"
                - option "Barangay 680"
                - option "Barangay 681"
                - option "Barangay 682"
                - option "Barangay 683"
                - option "Barangay 684"
                - option "Barangay 685"
                - option "Barangay 686"
                - option "Barangay 687"
                - option "Barangay 688"
                - option "Barangay 689"
                - option "Barangay 690"
                - option "Barangay 691"
                - option "Barangay 692"
                - option "Barangay 693"
                - option "Barangay 694"
                - option "Barangay 695"
                - option "Barangay 696"
                - option "Barangay 697"
                - option "Barangay 698"
                - option "Barangay 699"
                - option "Barangay 700"
                - option "Barangay 701"
                - option "Barangay 702"
                - option "Barangay 703"
                - option "Barangay 704"
                - option "Barangay 705"
                - option "Barangay 706"
                - option "Barangay 707"
                - option "Barangay 708"
                - option "Barangay 709"
                - option "Barangay 710"
                - option "Barangay 711"
                - option "Barangay 712"
                - option "Barangay 713"
                - option "Barangay 714"
                - option "Barangay 715"
                - option "Barangay 716"
                - option "Barangay 717"
                - option "Barangay 718"
                - option "Barangay 719"
                - option "Barangay 720"
                - option "Barangay 721"
                - option "Barangay 722"
                - option "Barangay 723"
                - option "Barangay 724"
                - option "Barangay 725"
                - option "Barangay 726"
                - option "Barangay 727"
                - option "Barangay 728"
                - option "Barangay 729"
                - option "Barangay 730"
                - option "Barangay 731"
                - option "Barangay 732"
                - option "Barangay 733"
                - option "Barangay 734"
                - option "Barangay 735"
                - option "Barangay 736"
                - option "Barangay 737"
                - option "Barangay 738"
                - option "Barangay 739"
                - option "Barangay 740"
                - option "Barangay 741"
                - option "Barangay 742"
                - option "Barangay 743"
                - option "Barangay 744"
                - option "Barangay 745"
                - option "Barangay 746"
                - option "Barangay 747"
                - option "Barangay 748"
                - option "Barangay 749"
                - option "Barangay 750"
                - option "Barangay 751"
                - option "Barangay 752"
                - option "Barangay 753"
                - option "Barangay 754"
                - option "Barangay 755"
                - option "Barangay 756"
                - option "Barangay 757"
                - option "Barangay 758"
                - option "Barangay 759"
                - option "Barangay 760"
                - option "Barangay 761"
                - option "Barangay 762"
                - option "Barangay 763"
                - option "Barangay 764"
                - option "Barangay 765"
                - option "Barangay 766"
                - option "Barangay 767"
                - option "Barangay 768"
                - option "Barangay 769"
                - option "Barangay 770"
                - option "Barangay 771"
                - option "Barangay 772"
                - option "Barangay 773"
                - option "Barangay 774"
                - option "Barangay 775"
                - option "Barangay 776"
                - option "Barangay 777"
                - option "Barangay 778"
                - option "Barangay 779"
                - option "Barangay 780"
                - option "Barangay 781"
                - option "Barangay 782"
                - option "Barangay 783"
                - option "Barangay 784"
                - option "Barangay 785"
                - option "Barangay 786"
                - option "Barangay 787"
                - option "Barangay 788"
                - option "Barangay 789"
                - option "Barangay 790"
                - option "Barangay 791"
                - option "Barangay 792"
                - option "Barangay 793"
                - option "Barangay 794"
                - option "Barangay 795"
                - option "Barangay 796"
                - option "Barangay 797"
                - option "Barangay 798"
                - option "Barangay 799"
                - option "Barangay 800"
                - option "Barangay 801"
                - option "Barangay 802"
                - option "Barangay 803"
                - option "Barangay 804"
                - option "Barangay 805"
                - option "Barangay 806"
                - option "Barangay 807"
                - option "Barangay 808"
                - option "Barangay 809"
                - option "Barangay 810"
                - option "Barangay 811"
                - option "Barangay 812"
                - option "Barangay 813"
                - option "Barangay 814"
                - option "Barangay 815"
                - option "Barangay 816"
                - option "Barangay 817"
                - option "Barangay 818"
                - option "Barangay 818-A"
                - option "Barangay 819"
                - option "Barangay 820"
                - option "Barangay 821"
                - option "Barangay 822"
                - option "Barangay 823"
                - option "Barangay 824"
                - option "Barangay 825"
                - option "Barangay 826"
                - option "Barangay 827"
                - option "Barangay 828"
                - option "Barangay 829"
                - option "Barangay 830"
                - option "Barangay 831"
                - option "Barangay 832"
                - option "Barangay 833"
                - option "Barangay 834"
                - option "Barangay 835"
                - option "Barangay 836"
                - option "Barangay 837"
                - option "Barangay 838"
                - option "Barangay 839"
                - option "Barangay 840"
                - option "Barangay 841"
                - option "Barangay 842"
                - option "Barangay 843"
                - option "Barangay 844"
                - option "Barangay 845"
                - option "Barangay 846"
                - option "Barangay 847"
                - option "Barangay 848"
                - option "Barangay 849"
                - option "Barangay 850"
                - option "Barangay 851"
                - option "Barangay 852"
                - option "Barangay 853"
                - option "Barangay 855"
                - option "Barangay 856"
                - option "Barangay 857"
                - option "Barangay 858"
                - option "Barangay 859"
                - option "Barangay 860"
                - option "Barangay 861"
                - option "Barangay 862"
                - option "Barangay 863"
                - option "Barangay 864"
                - option "Barangay 865"
                - option "Barangay 866"
                - option "Barangay 867"
                - option "Barangay 868"
                - option "Barangay 869"
                - option "Barangay 870"
                - option "Barangay 871"
                - option "Barangay 872"
                - option "Barangay 873"
                - option "Barangay 874"
                - option "Barangay 875"
                - option "Barangay 876"
                - option "Barangay 877"
                - option "Barangay 878"
                - option "Barangay 879"
                - option "Barangay 880"
                - option "Barangay 881"
                - option "Barangay 882"
                - option "Barangay 883"
                - option "Barangay 884"
                - option "Barangay 885"
                - option "Barangay 886"
                - option "Barangay 887"
                - option "Barangay 888"
                - option "Barangay 889"
                - option "Barangay 890"
                - option "Barangay 891"
                - option "Barangay 892"
                - option "Barangay 893"
                - option "Barangay 894"
                - option "Barangay 895"
                - option "Barangay 896"
                - option "Barangay 897"
                - option "Barangay 898"
                - option "Barangay 899"
                - option "Barangay 900"
                - option "Barangay 901"
                - option "Barangay 902"
                - option "Barangay 903"
                - option "Barangay 904"
                - option "Barangay 905"
            - generic [ref=e36]:
              - generic [ref=e37]: Symptom-onset date (required)
              - textbox "Symptom-onset date (required)" [ref=e38]: 2026-10-25
            - group "Symptoms (optional; not a diagnosis)" [ref=e39]:
              - generic [ref=e42] [cursor=pointer]:
                - checkbox "Fever" [ref=e43]
                - generic [ref=e44]: Fever
              - generic [ref=e46] [cursor=pointer]:
                - checkbox "Headache" [ref=e47]
                - generic [ref=e48]: Headache
              - generic [ref=e50] [cursor=pointer]:
                - checkbox "Body ache" [ref=e51]
                - generic [ref=e52]: Body ache
              - generic [ref=e54] [cursor=pointer]:
                - checkbox "Nausea" [ref=e55]
                - generic [ref=e56]: Nausea
              - generic [ref=e58] [cursor=pointer]:
                - checkbox "Rash" [ref=e59]
                - generic [ref=e60]: Rash
              - generic [ref=e62] [cursor=pointer]:
                - checkbox "Other symptoms" [ref=e63]
                - generic [ref=e64]: Other symptoms
            - text: Short note (optional, 250 characters)
            - textbox "Short note (optional, 250 characters)" [active] [ref=e65]: Reach [REDACTED] or [REDACTED]
            - paragraph [ref=e66]: "Email and phone patterns are removed. Address-like notes are discarded. Detection is imperfect: do not include names or identifying details."
            - paragraph [ref=e67]: "Sanitized note: Reach [email removed] or [phone removed]"
            - button "Submit community report" [ref=e68] [cursor=pointer]
            - button "Back" [ref=e69] [cursor=pointer]
        - paragraph [ref=e70]:
          - link "View community aggregates" [ref=e71] [cursor=pointer]:
            - /url: /community
          - text: ·
          - link "Prevention and urgent warning signs" [ref=e72] [cursor=pointer]:
            - /url: /prevention
    - contentinfo [ref=e73]:
      - generic [ref=e74]:
        - link "About & Credits" [ref=e75] [cursor=pointer]:
          - /url: /about
        - button "About the data & methods" [ref=e76] [cursor=pointer]
        - button "Privacy notice" [ref=e77] [cursor=pointer]
      - paragraph [ref=e78]:
        - text: Bundled source periods.
        - time [ref=e79]: Dec 2, 2023
        - text: "?"
        - time [ref=e80]: Jan 10, 2021
        - text: . Historical, not live.
      - paragraph [ref=e81]: Background photograph by Sumarie Slabber
      - paragraph [ref=e82]: Thesis research ? Not an official DOH product ? Historical records, not a live warning.
  - status
```

# Test source

```ts
  1  | ﻿import { test, expect } from "@playwright/test";
  2  | import AxeBuilder from "@axe-core/playwright";
  3  | test("unauthenticated staff paths expose only sign-in and no public navigation or queue", async ({
  4  |   page,
  5  | }) => {
  6  |   let queueReads = 0;
  7  |   await page.route("**/rest/v1/rpc/staff_signal_queue**", (r) => {
  8  |     queueReads++;
  9  |     return r.fulfill({ status: 403, body: "denied" });
  10 |   });
  11 |   for (const path of ["/admin", "/admin/moderation", "/admin/uploads"]) {
  12 |     await page.goto(path);
  13 |     await expect(
  14 |       page.getByRole("heading", { name: "Staff sign in" }),
  15 |     ).toBeVisible();
  16 |     await expect(page.getByLabel("Staff email")).toBeVisible();
  17 |     await expect(
  18 |       page.getByRole("heading", { name: "Moderation queue" }),
  19 |     ).toHaveCount(0);
  20 |     await expect(
  21 |       page.getByRole("navigation", { name: "Main navigation" }),
  22 |     ).toHaveCount(0);
  23 |   }
  24 |   expect(queueReads).toBe(0);
  25 |   await page.setViewportSize({ width: 360, height: 900 });
  26 |   expect(
  27 |     (await new AxeBuilder({ page }).analyze()).violations.filter((v) =>
  28 |       ["critical", "serious"].includes(v.impact ?? ""),
  29 |     ),
  30 |   ).toEqual([]);
  31 | });
  32 | test("v2 reporting is closed by default, opt-in and bilingual without storing health fields", async ({
  33 |   page,
  34 | }) => {
  35 |   await page.route("**/rest/v1/reporting_v2_policy**", (r) =>
  36 |     r.fulfill({
  37 |       status: 200,
  38 |       contentType: "application/json",
  39 |       body: JSON.stringify({ enabled: false, consent_version: "community-v2" }),
  40 |     }),
  41 |   );
  42 |   await page.goto("/report");
  43 |   await expect(
  44 |     page.getByText("New submissions are not open yet.", { exact: false }),
  45 |   ).toBeVisible();
  46 |   await expect(page.getByRole("checkbox")).not.toBeChecked();
  47 |   await page.getByRole("checkbox").check();
  48 |   await expect(
  49 |     page.getByRole("button", { name: "Continue to report" }),
  50 |   ).toBeDisabled();
  51 |   await page.getByRole("button", { name: "Filipino", exact: true }).click();
  52 |   await expect(
  53 |     page.getByRole("heading", { name: "Unawain at pumayag" }),
  54 |   ).toBeVisible();
  55 |   await expect(page.locator("html")).toHaveAttribute("lang", "fil");
  56 |   expect(await page.evaluate(() => JSON.stringify(localStorage))).not.toContain(
  57 |     "DW2-",
  58 |   );
  59 | });
  60 | test("v2 open-policy preview collects coarse fields only and strips identifying note patterns", async ({
  61 |   page,
  62 | }) => {
  63 |   await page.route("**/rest/v1/reporting_v2_policy**", (r) =>
  64 |     r.fulfill({
  65 |       status: 200,
  66 |       contentType: "application/json",
  67 |       body: JSON.stringify({ enabled: true, consent_version: "community-v2" }),
  68 |     }),
  69 |   );
  70 |   await page.goto("/report");
  71 |   await page.getByRole("checkbox").check();
  72 |   await page.getByRole("button", { name: "Continue to report" }).click();
  73 |   await expect(page.getByLabel("Barangay (coarse area only)")).toBeVisible();
  74 |   await expect(page.getByLabel("Symptom-onset date (required)")).toBeVisible();
  75 |   await page
  76 |     .getByLabel("Short note (optional, 250 characters)")
  77 |     .fill("Reach [REDACTED] or [REDACTED]");
  78 |   await expect(
  79 |     page.getByText("Sanitized note:", { exact: false }),
  80 |   ).not.toContainText("[REDACTED]");
  81 |   await expect(
  82 |     page.getByText("Sanitized note:", { exact: false }),
  83 |   ).toContainText("[email removed]");
  84 |   await expect(page.getByLabel("Email address or phone number")).toHaveCount(0);
  85 |   await expect(page.getByLabel("Full name")).toHaveCount(0);
  86 |   await page.setViewportSize({ width: 360, height: 900 });
  87 |   expect(
  88 |     (await new AxeBuilder({ page }).analyze()).violations.filter((v) =>
  89 |       ["critical", "serious"].includes(v.impact ?? ""),
  90 |     ),
> 91 |   ).toEqual([]);
     |     ^ Error: expect(received).toEqual(expected) // deep equality
  92 | });
  93 | 
```