# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: reporting-flow.spec.ts >> local seeded MFA staff reviews real SQL reports; threshold, delay, PII, raw denial and withdrawal hold
- Location: tests\ui\reporting-flow.spec.ts:4:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('.community-link')
Expected substring: "Community reports: open"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" locator('.community-link') with timeout 5000ms
  - waiting for locator('.community-link')

```

```yaml
- link "Skip to content":
  - /url: "#main"
- banner:
  - link "DengueWatch home":
    - /url: /
    - text: DENGUE WATCH
  - navigation "Main navigation":
    - link "Dashboard":
      - /url: /
    - link "Risk Map":
      - /url: /risk-map
    - link "Community Report":
      - /url: /report
  - button "English" [pressed]
  - button "Filipino"
- main:
  - paragraph: COMMUNITY / UNVERIFIED
  - heading "Share an awareness signal." [level=1]
  - paragraph: Report a suspected case in your household or an unusual cluster you noticed. Choose only a coarse area; no GPS or free-text address is collected. Barangay selection is available only for the verified Manila catalogue; other units stay at province/city level. The onset day may be approximate.
  - paragraph: We do not ask for your name or contact details, do not store your IP address or precise location, and use no trackers. No system can promise perfect anonymity, so do not include details that identify you or others. Reports never enter official counts, forecasts or the Outlook Index.
  - paragraph: An IP address, when provided by the trusted hosting proxy, is used transiently to derive a rotating salted rate-limit hash. Raw IPs are never stored. Hashes expire after a 15-minute window and are physically removed on a successful request or the hourly retention job (up to 75 minutes). Automated note filters cannot detect every identifying detail. Retention and consent require DPO review before collection opens.
  - heading "Understand and consent" [level=2]
  - paragraph: Your optional health report is sensitive personal information. It supports research and coarse community awareness, not diagnosis, emergency response or validated prediction.
  - paragraph: Only staff can review individual reports. Public counts require staff approval, a 72-hour delay and at least three reports per area/week. Reports are removed after 90 days; withdraw sooner with your private code.
  - paragraph:
    - text: Please report only your own household experience or a coarse, non-identifying cluster observation. Do not include anyone’s identity or address.
    - link "Privacy and withdrawal":
      - /url: /report?drawer=privacy
    - text: .
  - checkbox "I voluntarily consent to this research use of my report under community-v2."
  - text: I voluntarily consent to this research use of my report under community-v2.
  - button "Continue to report" [disabled]
  - paragraph: "Controller: DengueWatch student research team. Contact: [REDACTED]. Notice requires DPO review before collection opens."
  - paragraph:
    - link "View community aggregates":
      - /url: /community
    - text: ·
    - link "Prevention and urgent warning signs":
      - /url: /prevention
- contentinfo:
  - link "About & Credits":
    - /url: /about
  - button "About the data & methods"
  - button "Privacy notice"
  - paragraph:
    - text: Bundled source periods.
    - time: Dec 2, 2023
    - text: "?"
    - time: Jan 10, 2021
    - text: . Historical, not live.
  - paragraph: Background photograph by Sumarie Slabber
  - paragraph: Thesis research ? Not an official DOH product ? Historical records, not a live warning.
- status
```

# Test source

```ts
  1  | import { test,expect } from '@playwright/test';
  2  | import AxeBuilder from '@axe-core/playwright';
  3  | import { reportingHarness } from '../support/reporting-harness';
  4  | test('local seeded MFA staff reviews real SQL reports; threshold, delay, PII, raw denial and withdrawal hold',async({page,context})=>{
  5  |  test.setTimeout(180000);const local=await reportingHarness();
  6  |  try{
  7  |  expect(local.dataset).toBe('LOCAL TEST DATA ONLY');await local.attach(page);
  8  |  const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Manila',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
  9  |  const codes:string[]=[];
  10 |  for(const symptom of ['Fever','Headache','Nausea']){
> 11 |   await page.goto('/report');await expect(page.locator('.community-link')).toContainText('Community reports: open');await page.getByRole('checkbox').check();await page.getByRole('button',{name:'Continue to report'}).click();
     |                                                                            ^ Error: expect(locator).toContainText(expected) failed
  12 |   await page.getByLabel('Symptom-onset date (required)').fill(today);await page.getByRole('checkbox',{name:symptom,exact:true}).check();
  13 |   await page.getByLabel('Short note (optional, 250 characters)').fill('LOCAL TEST DATA ONLY <img src=x onerror="window.__xss=1"> contact [REDACTED] [REDACTED]');
  14 |   await page.getByRole('button',{name:'Submit community report'}).click();await expect(page.getByRole('heading',{name:'Report received for review'})).toBeVisible({timeout:90000});
  15 |   const code=await page.locator('.tracking-code code').innerText();expect(code).toMatch(/^DW2-[A-F0-9]{32}$/);codes.push(code);
  16 |  }
  17 |  const stored=(await local.db.query<{note_text:string}>('select note_text from public.community_signals')).rows;
  18 |  expect(stored).toHaveLength(3);for(const row of stored){expect(row.note_text).not.toMatch(/@|\+63|<img|onerror/);}
  19 |  let releaseStaff!:()=>void;const staffReady=new Promise<void>(resolve=>{releaseStaff=resolve;});
  20 |  await page.route('**/rest/v1/rpc/staff_signal_queue',async route=>{await staffReady;await route.fallback();});
  21 |  await page.goto('/admin');await page.getByLabel('Staff email').fill(local.email);await page.getByLabel('Password',{exact:true}).fill(local.password);await page.getByRole('button',{name:'Sign in',exact:true}).click();await expect(page.getByRole('heading',{name:'Verify staff authenticator'})).toBeVisible();await expect(page.getByRole('button',{name:'Cancel staff sign in'})).toBeDisabled();releaseStaff();await expect(page.getByRole('heading',{name:'Moderation queue'})).toBeVisible();
  22 |  await expect(page.locator('.staff-report')).toHaveCount(3);
  23 |  const accessibility=await new AxeBuilder({page}).analyze();expect(accessibility.violations.filter(v=>['critical','serious'].includes(v.impact??''))).toEqual([]);expect(await page.evaluate(()=>Reflect.get(window,'__xss'))).toBeUndefined();
  24 |  const publicPage=await context.newPage();await local.attach(publicPage);
  25 |  async function groups(){await publicPage.goto('/community');return publicPage.getByRole('region',{name:'Unverified community aggregates'});}
  26 |  await groups();await expect(publicPage.getByText('No publishable groups.',{exact:false})).toBeVisible();
  27 |  for(let i=0;i<2;i++){await page.getByRole('button',{name:'Approve',exact:true}).nth(i).click();await expect(page.locator('.staff-report').nth(i)).toContainText('approved');}
  28 |  await local.ageReports();await groups();await expect(publicPage.getByText('No publishable groups.',{exact:false})).toBeVisible();
  29 |  await page.getByRole('button',{name:'Approve',exact:true}).nth(2).click();await expect(page.locator('.staff-report').nth(2)).toContainText('approved');
  30 |  await expect(await groups()).toBeVisible();await expect(publicPage.getByRole('region',{name:'Unverified community aggregates'}).locator('tbody tr')).toHaveCount(1);
  31 |  const publicData=(await local.db.query<Record<string,unknown>>('select * from public.community_signal_aggregates()')).rows;
  32 |  expect(Object.keys(publicData[0]).sort()).toEqual(['area_label','report_count','week_start']);expect(Number(publicData[0].report_count)).toBe(3);
  33 |  for(const resource of ['community_signals','community_reports']){
  34 |   const result=await publicPage.evaluate(async resource=>{const response=await fetch('https://denguewatch-tests.invalid/rest/v1/'+resource+'?select=*');return {status:response.status,text:await response.text()};},resource);
  35 |   expect(result.status).toBe(403);expect(result.text).not.toMatch(/note_text|contact_value|code_hash|onset_date|ip_address/);
  36 |  }
  37 |  await publicPage.goto('/privacy');await publicPage.getByLabel('Reference code').fill(codes[0]);await publicPage.getByRole('button',{name:'Request withdrawal',exact:true}).click();await expect(publicPage.getByText('Request processed.',{exact:false})).toBeVisible();
  38 |  await groups();await expect(publicPage.getByText('No publishable groups.',{exact:false})).toBeVisible();await publicPage.close();
  39 |  }finally{await local.close();}
  40 | });
  41 | 
```