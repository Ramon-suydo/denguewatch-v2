# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: evidence.spec.ts >> scenario and year changes keep absence explicit; NCR remains historical
- Location: tests\ui\evidence.spec.ts:61:1

# Error details

```
Error: locator.selectOption: Error: strict mode violation: getByLabel('Absent-day scenario') resolved to 2 elements:
    1) <select id="_r_1_">…</select> aka locator('[id="_r_1_"]')
    2) <select id="_r_2_">…</select> aka getByRole('dialog', { name: 'About the data & methods' }).getByLabel('Absent-day scenario')

Call log:
  - waiting for getByLabel('Absent-day scenario')

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - link "Skip to content" [ref=e5] [cursor=pointer]:
      - /url: "#main"
    - banner [ref=e6]:
      - link "DengueWatch home" [ref=e7] [cursor=pointer]:
        - /url: /
        - text: DENGUE
        - generic [ref=e8]: WATCH
      - navigation "Main navigation" [ref=e9]:
        - link "Dashboard" [ref=e10] [cursor=pointer]:
          - /url: /
        - link "Risk Map" [ref=e11] [cursor=pointer]:
          - /url: /risk-map
        - link "Community Report" [ref=e12] [cursor=pointer]:
          - /url: /report
      - generic "Page language" [ref=e13]:
        - button "English" [pressed] [ref=e14] [cursor=pointer]
        - button "Filipino" [ref=e15] [cursor=pointer]
    - main [ref=e16]:
      - region [ref=e17]:
        - generic [ref=e20]:
          - generic [ref=e21]: THESIS PROJECT
          - generic [ref=e22]: DATA AS OF 2023-12-02
        - generic [ref=e23]:
          - paragraph [ref=e24]: Understand the patterns. Take care of each other.
          - heading "DENGUE WATCH MANILA" [level=1] [ref=e25]: DENGUE WATCHMANILA
          - generic [ref=e26]:
            - link "View Risk Map" [ref=e27] [cursor=pointer]:
              - /url: /risk-map
            - link "Report a Case" [ref=e28] [cursor=pointer]:
              - /url: /report
          - paragraph [ref=e29]: Historical evidence. Everyday awareness. No live case surveillance.
      - generic [ref=e30]:
        - complementary [ref=e31]: Manila case data ends 2023-12-02. Province/city case data ends 2021-01-10. Neither is live.
        - generic [ref=e32]:
          - generic [ref=e33]:
            - paragraph [ref=e34]: THE QUESTION BEHIND THE THESIS
            - heading "Can better awareness begin with honest data?" [level=2] [ref=e35]
          - generic [ref=e36]:
            - paragraph [ref=e37]: Dengue is a mosquito-borne illness. This thesis asks whether historical cases and environmental context can support earlier awareness without overstating what the data can predict.
            - paragraph [ref=e38]: "We compare forecasts with a simple last-week baseline, make missing observations visible, and keep unverified community reports separate from official records. Objectives: describe patterns, test predictive skill, and provide a privacy-conscious awareness channel."
            - status [ref=e39]: Checking reporting status…
        - generic [ref=e40]:
          - generic [ref=e41]: Absent-day scenario
          - combobox "Absent-day scenario" [ref=e42] [cursor=pointer]:
            - option "M · absent dates remain missing" [selected]
            - option "Z · absent dates assumed zero"
        - paragraph [ref=e43]: Only weeks with seven daily rows are scored. An absent date is not a recorded zero. The final partial week is excluded in both scenarios.
        - generic [ref=e44]:
          - paragraph [ref=e45]: MANILA / HISTORICAL CASE FORECAST
          - heading "Current risk unavailable" [level=2] [ref=e46]
          - paragraph [ref=e47]: The case record is too old to establish current risk. This is the only case-forecast panel; the national map is a relative outlook.
          - paragraph [ref=e48]:
            - text: Data as of
            - time [ref=e49]: 2023-12-02
            - text: "? Forecast origin 2023-11-26 ? Scenario M"
          - generic [ref=e50]:
            - article [ref=e51]:
              - heading "1 week(s) ahead" [level=3] [ref=e52]
              - paragraph [ref=e53]: 62 estimated cases
              - paragraph [ref=e54]: "Historical target: 2023-12-03"
              - paragraph [ref=e55]: "80% interval: 40?84"
            - article [ref=e56]:
              - heading "2 week(s) ahead" [level=3] [ref=e57]
              - paragraph [ref=e58]: 62 estimated cases
              - paragraph [ref=e59]: "Historical target: 2023-12-10"
              - paragraph [ref=e60]: "80% interval: 31?93"
          - paragraph [ref=e61]: One-week persistence means last week's value. These are retrospective estimates, not a warning for the coming days.
          - paragraph [ref=e62]: Remove standing water, protect against bites and seek early consultation for symptoms.
        - generic [ref=e63]:
          - 'heading "Seasonal watch: context only" [level=2] [ref=e64]'
          - paragraph [ref=e65]: PAGASA defines June to November as the rainy season. Clear containers of standing water and keep up bite prevention. This is seasonal context, not a dengue prediction or alert.
          - paragraph [ref=e66]: Dengue observations remain historical; current weather cannot establish today's dengue risk.
          - paragraph [ref=e67]: In complete-row history for 2016-2023 (Scenario M), mean weekly cases ranged from 22.8 in May to 122.1 in September. This does not measure a delay from rainfall onset to rising cases.
          - status [ref=e68]: "Weather is seasonal context only; showing baseline forecast. Dengue observations remain historical. Weather as of: 2026-10-11."
          - link "PAGASA season definition" [ref=e69] [cursor=pointer]:
            - /url: https://www.pagasa.dost.gov.ph/information/climate-philippines
        - generic [ref=e70]:
          - paragraph [ref=e71]: ANALYTICS / RECORDED EVIDENCE
          - heading "The story in the weekly record" [level=2] [ref=e72]
          - generic [ref=e73]:
            - heading "Manila weekly cases, with source boundaries" [level=3] [ref=e74]
            - figure "Scrollable Manila history chart" [ref=e75]:
              - img "Manila weekly case history 312 observed or scenario-defined weeks. Peak 257 cases. Gaps break the line. Shading marks the COVID period. Exact data appears in the table below." [ref=e76]:
                - generic [ref=e78]: "0"
                - generic [ref=e80]: "64"
                - generic [ref=e82]: "129"
                - generic [ref=e84]: "193"
                - generic [ref=e86]: "257"
                - generic [ref=e88]: COVID period
                - generic [ref=e110]: 2016-01-10
                - generic [ref=e111]: 2023-12-03
                - generic [ref=e112]: Weekly cases · gaps remain gaps
                - generic [ref=e113]: Source changes
              - generic [ref=e114]: DOH EPI before 2018; Manila daily-derived weeks from 2018. COVID period shaded (2020–2021). Source dates end 2023-12-02; final partial week excluded. Sunday labels operationally interpreted as week-ending; source semantics unconfirmed.
            - group [ref=e115]:
              - generic "Exact weekly values and quality flags" [ref=e116] [cursor=pointer]
          - generic [ref=e117]:
            - generic [ref=e118]:
              - heading "Year comparison" [level=3] [ref=e119]
              - paragraph [ref=e120]: Available weeks only; incomplete years are not annual totals.
              - region "Year comparison" [ref=e121]:
                - table [ref=e122]:
                  - rowgroup [ref=e123]:
                    - row [ref=e124]:
                      - columnheader "Year" [ref=e125]
                      - columnheader "Recorded cases" [ref=e126]
                      - columnheader "Weeks" [ref=e127]
                  - rowgroup [ref=e128]:
                    - row [ref=e129]:
                      - rowheader "2016" [ref=e130]
                      - cell "1,990 ? incomplete" [ref=e131]
                      - cell "45 / 51" [ref=e132]
                    - row [ref=e133]:
                      - rowheader "2017" [ref=e134]
                      - cell "2,813" [ref=e135]
                      - cell "53 / 53" [ref=e136]
                    - row [ref=e137]:
                      - rowheader "2018" [ref=e138]
                      - cell "3,530 ? incomplete" [ref=e139]
                      - cell "47 / 52" [ref=e140]
                    - row [ref=e141]:
                      - rowheader "2019" [ref=e142]
                      - cell "3,761 ? incomplete" [ref=e143]
                      - cell "43 / 52" [ref=e144]
                    - row [ref=e145]:
                      - rowheader "2020" [ref=e146]
                      - cell "451 ? incomplete" [ref=e147]
                      - cell "13 / 52" [ref=e148]
                    - row [ref=e149]:
                      - rowheader "2021" [ref=e150]
                      - cell "883 ? incomplete" [ref=e151]
                      - cell "24 / 52" [ref=e152]
                    - row [ref=e153]:
                      - rowheader "2022" [ref=e154]
                      - cell "2,516 ? incomplete" [ref=e155]
                      - cell "42 / 52" [ref=e156]
                    - row [ref=e157]:
                      - rowheader "2023" [ref=e158]
                      - cell "2,346 ? incomplete" [ref=e159]
                      - cell "45 / 49" [ref=e160]
            - generic [ref=e161]:
              - heading "Seasonal profile" [level=3] [ref=e162]
              - paragraph [ref=e163]: Mean weekly cases by month of week ending; observed/scenario-defined weeks only, not monthly totals.
              - generic [ref=e164]:
                - generic [ref=e165]:
                  - generic [ref=e166]: Jan
                  - 'meter "Month 1: 53.8" [ref=e167]'
                  - generic [ref=e168]: "53.8"
                - generic [ref=e169]:
                  - generic [ref=e170]: Feb
                  - 'meter "Month 2: 43.7" [ref=e171]'
                  - generic [ref=e172]: "43.7"
                - generic [ref=e173]:
                  - generic [ref=e174]: Mar
                  - 'meter "Month 3: 29.4" [ref=e175]'
                  - generic [ref=e176]: "29.4"
                - generic [ref=e177]:
                  - generic [ref=e178]: Apr
                  - 'meter "Month 4: 27.2" [ref=e179]'
                  - generic [ref=e180]: "27.2"
                - generic [ref=e181]:
                  - generic [ref=e182]: May
                  - 'meter "Month 5: 22.8" [ref=e183]'
                  - generic [ref=e184]: "22.8"
                - generic [ref=e185]:
                  - generic [ref=e186]: Jun
                  - 'meter "Month 6: 30" [ref=e187]'
                  - generic [ref=e188]: "30"
                - generic [ref=e189]:
                  - generic [ref=e190]: Jul
                  - 'meter "Month 7: 49.6" [ref=e191]'
                  - generic [ref=e192]: "49.6"
                - generic [ref=e193]:
                  - generic [ref=e194]: Aug
                  - 'meter "Month 8: 95.3" [ref=e195]'
                  - generic [ref=e196]: "95.3"
                - generic [ref=e197]:
                  - generic [ref=e198]: Sep
                  - 'meter "Month 9: 122.1" [ref=e199]'
                  - generic [ref=e200]: "122.1"
                - generic [ref=e201]:
                  - generic [ref=e202]: Oct
                  - 'meter "Month 10: 92.8" [ref=e203]'
                  - generic [ref=e204]: "92.8"
                - generic [ref=e205]:
                  - generic [ref=e206]: Nov
                  - 'meter "Month 11: 72.1" [ref=e207]'
                  - generic [ref=e208]: "72.1"
                - generic [ref=e209]:
                  - generic [ref=e210]: Dec
                  - 'meter "Month 12: 49.8" [ref=e211]'
                  - generic [ref=e212]: "49.8"
          - generic [ref=e213]:
            - 'heading "Forecast versus actual: held-out 2023" [level=3] [ref=e214]'
            - img "Saved one-week persistence predictions versus actual held-out cases" [ref=e215]
            - paragraph [ref=e218]: "Solid: recorded values. Dashed: one-week persistence. Each origin precedes its target."
            - group [ref=e219]:
              - generic "Backtest data table" [ref=e220] [cursor=pointer]
            - paragraph [ref=e221]: "Source: data/processed/evaluation.json ? public/api/v2/dashboard.json."
          - generic [ref=e222]:
            - heading "How accurate is this?" [level=2] [ref=e223]
            - paragraph [ref=e224]: The public chart starts with Scenario M (only complete daily-row weeks). Scenario Z assumes absent dates are zero within coverage. Both are evaluated. The one-week public forecast is last week's value. Weather did not improve the predeclared one/two-week comparison. Two- to four-week ridge improvements are exploratory with wide uncertainty, not a validated operational warning.
            - paragraph [ref=e225]: Mean absolute error (MAE) is the average error in weekly case counts, from the saved 2018–2023 held-out evaluation. It does not establish accuracy for current conditions.
            - region "Forecast accuracy from saved evaluation" [ref=e226]:
              - table [ref=e227]:
                - rowgroup [ref=e228]:
                  - row [ref=e229]:
                    - columnheader "Model" [ref=e230]
                    - columnheader "Weeks ahead" [ref=e231]
                    - columnheader "MAE (cases)" [ref=e232]
                    - columnheader "Evaluated targets" [ref=e233]
                - rowgroup [ref=e234]:
                  - row [ref=e235]:
                    - rowheader "naive" [ref=e236]
                    - cell "1" [ref=e237]
                    - cell "15.47" [ref=e238]
                    - cell "116" [ref=e239]
                  - row [ref=e240]:
                    - rowheader "ridge-cases" [ref=e241]
                    - cell "1" [ref=e242]
                    - cell "16.36" [ref=e243]
                    - cell "116" [ref=e244]
                  - row [ref=e245]:
                    - rowheader "ridge-weather" [ref=e246]
                    - cell "1" [ref=e247]
                    - cell "18.39" [ref=e248]
                    - cell "116" [ref=e249]
                  - row [ref=e250]:
                    - rowheader "naive" [ref=e251]
                    - cell "2" [ref=e252]
                    - cell "22.90" [ref=e253]
                    - cell "117" [ref=e254]
                  - row [ref=e255]:
                    - rowheader "ridge-cases" [ref=e256]
                    - cell "2" [ref=e257]
                    - cell "22.17" [ref=e258]
                    - cell "117" [ref=e259]
                  - row [ref=e260]:
                    - rowheader "ridge-weather" [ref=e261]
                    - cell "2" [ref=e262]
                    - cell "23.17" [ref=e263]
                    - cell "117" [ref=e264]
                  - row [ref=e265]:
                    - rowheader "naive" [ref=e266]
                    - cell "4" [ref=e267]
                    - cell "31.63" [ref=e268]
                    - cell "112" [ref=e269]
                  - row [ref=e270]:
                    - rowheader "ridge-cases" [ref=e271]
                    - cell "4" [ref=e272]
                    - cell "27.43" [ref=e273]
                    - cell "112" [ref=e274]
                  - row [ref=e275]:
                    - rowheader "ridge-weather" [ref=e276]
                    - cell "4" [ref=e277]
                    - cell "28.42" [ref=e278]
                    - cell "112" [ref=e279]
        - region [ref=e281]:
          - paragraph [ref=e282]: TAKE CARE / ACT EARLY
          - heading "Know when to seek care" [level=2] [ref=e283]
          - paragraph [ref=e284]: Seek urgent medical care for severe abdominal pain, persistent vomiting, bleeding, difficulty breathing, unusual drowsiness or extreme weakness. Do not wait for a report review.
          - 'link "Source: CDC dengue warning signs" [ref=e285] [cursor=pointer]':
            - /url: https://www.cdc.gov/dengue/hcp/clinical-care/
          - heading "Make the DOH 4S a habit" [level=3] [ref=e286]
          - list [ref=e287]:
            - listitem [ref=e288]: "Search and destroy mosquito breeding places: empty and clean standing-water containers."
            - listitem [ref=e289]: "Self-protection: use repellent as directed and wear protective clothing."
            - listitem [ref=e290]: Seek early consultation for fever or dengue-like symptoms.
            - listitem [ref=e291]: Support health-authority fogging or spraying in identified hotspot/outbreak areas.
          - 'link "Source: Ministry of Health 4S guidance" [ref=e292] [cursor=pointer]':
            - /url: https://bangsamoro.gov.ph/news/latest-news/moh-urges-public-to-observe-4s-strategy-against-dengue/
          - paragraph [ref=e293]:
            - strong [ref=e294]: Informational, not a diagnosis. Not an official DOH product.
    - contentinfo [ref=e295]:
      - generic [ref=e296]:
        - link "About & Credits" [ref=e297] [cursor=pointer]:
          - /url: /about
        - button "About the data & methods" [ref=e298] [cursor=pointer]
      - paragraph [ref=e299]:
        - text: Bundled source periods.
        - time [ref=e300]: Dec 2, 2023
        - text: "?"
        - time [ref=e301]: Jan 10, 2021
        - text: . Historical, not live.
      - paragraph [ref=e302]: Background photograph by Sumarie Slabber
      - paragraph [ref=e303]: Thesis research ? Not an official DOH product ? Historical records, not a live warning.
    - dialog [ref=e304]:
      - generic [ref=e305]:
        - heading "About the data & methods" [level=2] [ref=e306]
        - button "Close dialog" [active] [ref=e307] [cursor=pointer]: ✕
      - generic [ref=e308]:
        - paragraph [ref=e309]: Manila cases end 2023-12-02; national cases end 2021-01-10. M keeps absent dates missing; Z assumes zero only inside source coverage. Neither assumption is confirmed by the data owner. The public chart defaults to M.
        - paragraph [ref=e310]: The national outlook is relative season + historical burden, not predicted case counts or current disease risk. Population-adjusted rates and reporting/boundary equivalence are not verified. Community signals never enter either model.
        - link "About & Credits" [ref=e311] [cursor=pointer]:
          - /url: /about
        - generic [ref=e312]:
          - generic [ref=e313]: Research detail
          - combobox "Research detail" [ref=e314] [cursor=pointer]:
            - option "Evaluation and limitations"
            - option "Source coverage and integrity"
            - option "Complete historical tables" [selected]
            - option "NCR historical city archive"
            - option "Full prevention and warning signs"
            - option "Prior research summary"
        - generic [ref=e315]:
          - paragraph [ref=e316]: HISTORY / MANILA ONLY
          - heading "Trends with their context." [level=1] [ref=e317]
          - paragraph [ref=e318]: Different source periods, missing observations, and pandemic disruption remain visible.
          - generic [ref=e319]:
            - generic [ref=e320]: Absent-day scenario
            - combobox "Absent-day scenario" [ref=e321] [cursor=pointer]:
              - option "M · absent dates remain missing" [selected]
              - option "Z · absent dates assumed zero"
          - paragraph [ref=e322]: Only weeks with seven daily rows are scored. An absent date is not a recorded zero. The final partial week is excluded in both scenarios.
          - generic [ref=e323]:
            - generic [ref=e324]: History year
            - combobox "History year" [ref=e325] [cursor=pointer]:
              - option "All years · 2016–2023" [selected]
              - option "2016"
              - option "2017"
              - option "2018"
              - option "2019"
              - option "2020"
              - option "2021"
              - option "2022"
              - option "2023"
          - generic [ref=e326]:
            - heading "Weekly recorded cases" [level=2] [ref=e327]
            - figure "Scrollable Manila history chart" [ref=e328]:
              - img "Manila weekly case history 312 observed or scenario-defined weeks. Peak 257 cases. Gaps break the line. Shading marks the COVID period. Exact data appears in the table below." [ref=e329]:
                - generic [ref=e331]: "0"
                - generic [ref=e333]: "64"
                - generic [ref=e335]: "129"
                - generic [ref=e337]: "193"
                - generic [ref=e339]: "257"
                - generic [ref=e341]: COVID period
                - generic [ref=e363]: 2016-01-10
                - generic [ref=e364]: 2023-12-03
                - generic [ref=e365]: Weekly cases · gaps remain gaps
                - generic [ref=e366]: Source changes
              - generic [ref=e367]: DOH EPI before 2018; Manila daily-derived weeks from 2018. COVID period shaded (2020–2021). Source dates end 2023-12-02; final partial week excluded. Sunday labels operationally interpreted as week-ending; source semantics unconfirmed.
            - group [ref=e368]:
              - generic "Exact weekly values and quality flags" [ref=e369] [cursor=pointer]
          - generic [ref=e370]:
            - heading "Year comparison" [level=2] [ref=e371]
            - paragraph [ref=e372]: Totals cover available scenario-defined weeks, not necessarily complete years. Never add source representations together.
            - region "Year comparison" [ref=e373]:
              - table [ref=e374]:
                - rowgroup [ref=e375]:
                  - row [ref=e376]:
                    - columnheader "Year" [ref=e377]
                    - columnheader "Cases in available weeks" [ref=e378]
                    - columnheader "Available / calendar weeks" [ref=e379]
                - rowgroup [ref=e380]:
                  - row [ref=e381]:
                    - rowheader "2016" [ref=e382]
                    - cell "1,990 · incomplete" [ref=e383]
                    - cell "45 / 51" [ref=e384]
                  - row [ref=e385]:
                    - rowheader "2017" [ref=e386]
                    - cell "2,813" [ref=e387]
                    - cell "53 / 53" [ref=e388]
                  - row [ref=e389]:
                    - rowheader "2018" [ref=e390]
                    - cell "3,530 · incomplete" [ref=e391]
                    - cell "47 / 52" [ref=e392]
                  - row [ref=e393]:
                    - rowheader "2019" [ref=e394]
                    - cell "3,761 · incomplete" [ref=e395]
                    - cell "43 / 52" [ref=e396]
                  - row [ref=e397]:
                    - rowheader "2020" [ref=e398]
                    - cell "451 · incomplete" [ref=e399]
                    - cell "13 / 52" [ref=e400]
                  - row [ref=e401]:
                    - rowheader "2021" [ref=e402]
                    - cell "883 · incomplete" [ref=e403]
                    - cell "24 / 52" [ref=e404]
                  - row [ref=e405]:
                    - rowheader "2022" [ref=e406]
                    - cell "2,516 · incomplete" [ref=e407]
                    - cell "42 / 52" [ref=e408]
                  - row [ref=e409]:
                    - rowheader "2023" [ref=e410]
                    - cell "2,346 · incomplete" [ref=e411]
                    - cell "45 / 49" [ref=e412]
            - paragraph [ref=e413]: DOH EPI 2016–2017; Manila daily-derived 2018–2023. As of 2023-12-02.
          - generic [ref=e414]:
            - heading "Historical forecast and interval" [level=2] [ref=e415]
            - paragraph [ref=e416]: Origin 2023-11-26. Exploratory four-week forecasts have larger error; they are not operational warnings.
            - figure "Scrollable historical forecast chart" [ref=e417]:
              - img "Historical persistence forecasts with 80% intervals Origin 2023-11-26. One and two weeks are primary; four weeks is exploratory. Vertical bars show nominal 80% intervals from earlier observed forecast errors. Exact estimates and ranges are in the following table." [ref=e418]:
                - generic [ref=e419]: 1 week
                - generic [ref=e422]: 2 weeks
                - generic [ref=e425]: 4 weeks
                - generic [ref=e428]: Cases · historical estimates, not current alerts
                - generic [ref=e429]: "0"
                - generic [ref=e430]: "110"
              - generic [ref=e431]: "Source: Manila daily-derived weekly series; origin 2023-11-26. Dot = estimate, vertical bar = nominal 80% interval. Four weeks is exploratory. Scroll the chart if needed; exact values follow."
            - region "Forecast intervals" [ref=e432]:
              - table [ref=e433]:
                - rowgroup [ref=e434]:
                  - row [ref=e435]:
                    - columnheader "Target" [ref=e436]
                    - columnheader "Horizon" [ref=e437]
                    - columnheader "Forecast cases" [ref=e438]
                    - columnheader "80% interval" [ref=e439]
                - rowgroup [ref=e440]:
                  - row [ref=e441]:
                    - rowheader "2023-12-03" [ref=e442]
                    - cell "1 weeks" [ref=e443]
                    - cell "62" [ref=e444]
                    - cell "40–84" [ref=e445]
                  - row [ref=e446]:
                    - rowheader "2023-12-10" [ref=e447]
                    - cell "2 weeks" [ref=e448]
                    - cell "62" [ref=e449]
                    - cell "31–93" [ref=e450]
                  - row [ref=e451]:
                    - rowheader "2023-12-24" [ref=e452]
                    - cell "4 weeks · exploratory" [ref=e453]
                    - cell "62" [ref=e454]
                    - cell "14–110" [ref=e455]
            - paragraph [ref=e456]: "Source: daily-derived Manila series. manila-persistence-v2; interval calibration uses earlier observed out-of-sample errors only. Not current risk."
  - status
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | import AxeBuilder from "@axe-core/playwright";
  3   | import { mkdir } from "node:fs/promises";
  4   | test("research pages: mobile/desktop, no overflow, no critical or serious axe issues", async ({
  5   |   page,
  6   | }) => {
  7   |   test.setTimeout(180000);
  8   |   const errors: string[] = [];
  9   |   page.on("pageerror", (e) => errors.push(e.message));
  10  |   for (const width of [360, 768, 1280])
  11  |     for (const route of [
  12  |       "/",
  13  |       "/trends",
  14  |       "/metro-manila",
  15  |       "/methodology",
  16  |       "/prevention",
  17  |     ]) {
  18  |       await page.setViewportSize({ width, height: 900 });
  19  |       await page.goto(route);
  20  |       await expect(page.locator("h1")).toBeVisible();
  21  |       if (route === "/")
  22  |         await expect(
  23  |           page.getByRole("heading", { name: "Current risk unavailable" }),
  24  |         ).toBeVisible();
  25  |       if (route === "/metro-manila")
  26  |         await expect(page.locator(".ncr-city-map path")).toHaveCount(17);
  27  |       if (route === "/methodology")
  28  |         await expect(
  29  |           page.getByRole("heading", { name: "Forecast comparison" }),
  30  |         ).toBeVisible();
  31  |       expect(
  32  |         await page.evaluate(
  33  |           () => document.documentElement.scrollWidth <= window.innerWidth,
  34  |         ),
  35  |       ).toBe(true);
  36  |       const a = await new AxeBuilder({ page }).analyze();
  37  |       expect(
  38  |         a.violations.filter((v) =>
  39  |           ["critical", "serious"].includes(v.impact ?? ""),
  40  |         ),
  41  |         JSON.stringify(a.violations),
  42  |       ).toEqual([]);
  43  |     }
  44  |   expect(errors).toEqual([]);
  45  |   await mkdir(".artifacts/evidence-ui", { recursive: true });
  46  |   await page.goto("/");
  47  |   await expect(
  48  |     page.getByRole("heading", { name: "Current risk unavailable" }),
  49  |   ).toBeVisible();
  50  |   await page.evaluate(() => document.fonts.ready);
  51  |   await page.screenshot({
  52  |     path: ".artifacts/evidence-ui/home-1280.png",
  53  |     fullPage: true,
  54  |   });
  55  |   await page.setViewportSize({ width: 360, height: 900 });
  56  |   await page.screenshot({
  57  |     path: ".artifacts/evidence-ui/home-360.png",
  58  |     fullPage: true,
  59  |   });
  60  | });
  61  | test("scenario and year changes keep absence explicit; NCR remains historical", async ({
  62  |   page,
  63  | }) => {
  64  |   await page.goto("/trends");
  65  |   await expect(
  66  |     page.getByRole("heading", { name: "Weekly recorded cases" }),
  67  |   ).toBeVisible();
> 68  |   await page.getByLabel("Absent-day scenario").selectOption("Z");
      |                                                ^ Error: locator.selectOption: Error: strict mode violation: getByLabel('Absent-day scenario') resolved to 2 elements:
  69  |   await expect(
  70  |     page.getByText("Zero is assumed only", { exact: false }),
  71  |   ).toBeVisible();
  72  |   await page.getByLabel("History year").selectOption("2020");
  73  |   await page.getByText("Exact weekly values and quality flags").click();
  74  |   await expect(
  75  |     page.getByRole("region", { name: "Weekly history data table" }),
  76  |   ).toBeVisible();
  77  |   await page.goto("/metro-manila");
  78  |   await expect(
  79  |     page.getByText("Data ends January 2021.", { exact: true }),
  80  |   ).toBeVisible();
  81  |   await page.getByLabel("Comparison period").selectOption("week");
  82  |   await page.getByLabel("Week label").selectOption("2016-11-06");
  83  |   await expect(page.locator(".ncr-city-map path")).toHaveCount(17);
  84  | });
  85  | test("Filipino home/prevention, missing API retry, and legacy forecasts isolated", async ({
  86  |   page,
  87  | }) => {
  88  |   await page.goto("/");
  89  |   await page.getByRole("button", { name: "Filipino", exact: true }).click();
  90  |   await expect(
  91  |     page.getByRole("heading", { name: "Kulang ang kasalukuyang datos" }),
  92  |   ).toBeVisible();
  93  |   await page.goto("/prevention");
  94  |   await expect(page.getByRole("heading", { name: "4S ng DOH" })).toBeVisible();
  95  |   await page.goto("/city/old-id");
  96  |   await expect(page).toHaveURL(/\/trends$/);
  97  |   let failedRequests = 0;
  98  |   await page.route("**/api/v2/manila.json", (route) => {
  99  |     failedRequests++;
  100 |     return route.fulfill({ status: 503, body: "Unavailable" });
  101 |   });
  102 |   await page.goto("/");
  103 |   await expect(page.getByRole("alert")).toContainText("could not load");
  104 |   expect(failedRequests).toBeGreaterThan(0);
  105 |   await expect(page.getByRole("button", { name: "Try again" })).toBeVisible();
  106 |   await page.unroute("**/api/v2/manila.json");
  107 |   await page.getByRole("button", { name: "Try again" }).click();
  108 |   await expect(
  109 |     page.getByRole("heading", { name: "Kulang ang kasalukuyang datos" }),
  110 |   ).toBeVisible();
  111 | });
  112 | 
```