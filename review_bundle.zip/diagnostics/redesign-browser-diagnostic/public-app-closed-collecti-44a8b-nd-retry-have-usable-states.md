# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: public-app.spec.ts >> closed collection, legacy redirect, service errors and retry have usable states
- Location: tests\ui\public-app.spec.ts:91:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('New submissions are not open yet.')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('New submissions are not open yet.') with timeout 5000ms
  - waiting for getByText('New submissions are not open yet.')

```

```yaml
- link "Skip to content":
  - /url: "#main"
- banner:
  - link "DengueWatch home":
    - /url: /
    - text: DENGUE WATCH
  - navigation "Main navigation":
    - link "Dashboard":
      - /url: /
    - link "Risk Map":
      - /url: /risk-map
    - link "Community Report":
      - /url: /report
  - button "English" [pressed]
  - button "Filipino"
- main:
  - paragraph: COMMUNITY / UNVERIFIED
  - heading "Share an awareness signal." [level=1]
  - paragraph: Report a suspected case in your household or an unusual cluster you noticed. Choose only a coarse area; no GPS or free-text address is collected. Barangay selection is available only for the verified Manila catalogue; other units stay at province/city level. The onset day may be approximate.
  - paragraph: We do not ask for your name or contact details, do not store your IP address or precise location, and use no trackers. No system can promise perfect anonymity, so do not include details that identify you or others. Reports never enter official counts, forecasts or the Outlook Index.
  - paragraph: An IP address, when provided by the trusted hosting proxy, is used transiently to derive a rotating salted rate-limit hash. Raw IPs are never stored. Hashes expire after a 15-minute window and are physically removed on a successful request or the hourly retention job (up to 75 minutes). Automated note filters cannot detect every identifying detail. Retention and consent require DPO review before collection opens.
  - status: New submissions are closed.
  - heading "Understand and consent" [level=2]
  - paragraph: Your optional health report is sensitive personal information. It supports research and coarse community awareness, not diagnosis, emergency response or validated prediction.
  - paragraph: Only staff can review individual reports. Public counts require staff approval, a 72-hour delay and at least three reports per area/week. Reports are removed after 90 days; withdraw sooner with your private code.
  - paragraph:
    - text: Please report only your own household experience or a coarse, non-identifying cluster observation. Do not include anyone’s identity or address.
    - link "Privacy and withdrawal":
      - /url: /report?drawer=privacy
    - text: .
  - checkbox "I voluntarily consent to this research use of my report under community-v2."
  - text: I voluntarily consent to this research use of my report under community-v2.
  - button "Continue to report" [disabled]
  - paragraph: "Controller: DengueWatch student research team. Contact: [REDACTED]. Notice requires DPO review before collection opens."
  - paragraph:
    - link "View community aggregates":
      - /url: /community
    - text: ·
    - link "Prevention and urgent warning signs":
      - /url: /prevention
- contentinfo:
  - link "About & Credits":
    - /url: /about
  - button "About the data & methods"
  - button "Privacy notice"
  - paragraph:
    - text: Bundled source periods.
    - time: Dec 2, 2023
    - text: "?"
    - time: Jan 10, 2021
    - text: . Historical, not live.
  - paragraph: Background photograph by Sumarie Slabber
  - paragraph: Thesis research ? Not an official DOH product ? Historical records, not a live warning.
- status
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | import AxeBuilder from "@axe-core/playwright";
  3   | import { readFile } from "node:fs/promises";
  4   | import { mockPublicApi } from "../fixtures/public-fixtures";
  5   | const evidence = JSON.parse(
  6   |   await readFile("public/api/v2/manila.json", "utf8"),
  7   | );
  8   | 
  9   | test("Manila stitched history preserves exact recorded values and source boundaries", async ({
  10  |   page,
  11  | }) => {
  12  |   await page.goto("/trends");
  13  |   await page.getByText("Exact weekly values and quality flags").click();
  14  |   const table = page.getByRole("region", { name: "Weekly history data table" });
  15  |   await expect(table.locator("tbody tr")).toHaveCount(evidence.series.M.length);
  16  |   await expect(table).toContainText("Missing / excluded");
  17  |   await expect(table).toContainText("2016-11-13");
  18  |   await expect(table).toContainText("DOH EPI");
  19  |   await expect(table).toContainText("Manila daily");
  20  |   await page.getByLabel("Absent-day scenario").selectOption("Z");
  21  |   await expect(table.locator("tbody tr")).toHaveCount(evidence.series.Z.length);
  22  |   expect(
  23  |     (await new AxeBuilder({ page }).analyze()).violations.filter((v) =>
  24  |       ["critical", "serious"].includes(v.impact ?? ""),
  25  |     ),
  26  |   ).toEqual([]);
  27  | });
  28  | test("consent is opt-in, contact is optional, submission uses only RPC, and withdrawal hides code existence", async ({
  29  |   page,
  30  | }) => {
  31  |   const data = await mockPublicApi(page);
  32  |   await page.goto("/dev/legacy-report");
  33  |   const consent = page.getByRole("checkbox");
  34  |   await expect(consent).not.toBeChecked();
  35  |   await expect(
  36  |     page.getByRole("button", { name: "Continue to report" }),
  37  |   ).toBeDisabled();
  38  |   await consent.check();
  39  |   await page.getByRole("button", { name: "Continue to report" }).click();
  40  |   await expect(page.getByLabel("City / municipality (required)")).toHaveValue(
  41  |     "MANILA CITY",
  42  |   );
  43  |   await expect(page.getByLabel("Email address or phone number")).toHaveCount(0);
  44  |   await page.getByRole("checkbox").check();
  45  |   await page
  46  |     .getByLabel("Email address or phone number")
  47  |     .fill("[REDACTED]");
  48  |   await page.getByRole("checkbox").uncheck();
  49  |   await expect(page.getByLabel("Email address or phone number")).toHaveCount(0);
  50  |   const date = page.getByLabel("Report date (required)");
  51  |   await date.fill("2099-01-01");
  52  |   await page.getByRole("button", { name: "Submit community report" }).click();
  53  |   expect(data.submissions).toHaveLength(0);
  54  |   await date.fill("2026-01-01");
  55  |   expect(
  56  |     (
  57  |       await new AxeBuilder({ page })
  58  |         .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
  59  |         .analyze()
  60  |     ).violations,
  61  |   ).toEqual([]);
  62  |   await page.getByRole("button", { name: "Submit community report" }).click();
  63  |   await expect(
  64  |     page.getByRole("heading", { name: "Report received" }),
  65  |   ).toBeVisible();
  66  |   expect(data.submissions).toHaveLength(1);
  67  |   expect(data.submissions[0]).toMatchObject({
  68  |     p_consent_given: true,
  69  |     p_consent_version: "community-v1",
  70  |     p_contact_opt_in: false,
  71  |     p_contact_value: null,
  72  |   });
  73  |   expect(await page.evaluate(() => JSON.stringify(localStorage))).not.toContain(
  74  |     "DW-",
  75  |   );
  76  |   expect(page.url()).not.toContain("DW-");
  77  |   await page.getByRole("link", { name: "Privacy → Withdraw a report" }).click();
  78  |   await page
  79  |     .getByLabel("Reference code", { exact: true })
  80  |     .fill("DW-AAAAAAAAAAAAAAAAAAAAAAAA");
  81  |   await page.getByRole("button", { name: "Request withdrawal" }).click();
  82  |   await expect(
  83  |     page.getByText("Request processed.", { exact: false }),
  84  |   ).toBeVisible();
  85  |   expect(data.deletions).toHaveLength(1);
  86  |   await expect(page.getByLabel("Reference code", { exact: true })).toHaveValue(
  87  |     "",
  88  |   );
  89  | });
  90  | 
  91  | test("closed collection, legacy redirect, service errors and retry have usable states", async ({
  92  |   page,
  93  | }) => {
  94  |   await mockPublicApi(page, { open: false });
  95  |   await page.goto("/report");
  96  |   await expect(
  97  |     page.getByText("New submissions are not open yet.", { exact: false }),
> 98  |   ).toBeVisible();
      |     ^ Error: expect(locator).toBeVisible() failed
  99  |   await page.getByRole("checkbox").check();
  100 |   await expect(
  101 |     page.getByRole("button", { name: "Continue to report" }),
  102 |   ).toBeDisabled();
  103 |   await page.goto("/city/not-a-city");
  104 |   await expect(page).toHaveURL(/\/trends$/);
  105 |   await page.route("**/api/v2/manila.json", (r) =>
  106 |     r.fulfill({ status: 503, body: "Unavailable" }),
  107 |   );
  108 |   await page.reload();
  109 |   await expect(page.getByRole("alert")).toBeVisible();
  110 |   await page.unroute("**/api/v2/manila.json");
  111 |   await page.getByRole("button", { name: "Try again" }).click();
  112 |   await expect(
  113 |     page.getByRole("heading", { name: "Weekly recorded cases" }),
  114 |   ).toBeVisible();
  115 | });
  116 | test("historical NCR map distinguishes missing source weeks from zero", async ({
  117 |   page,
  118 | }) => {
  119 |   await page.goto("/map");
  120 |   await page.getByLabel("Comparison period").selectOption("week");
  121 |   await page.getByLabel("Week label").selectOption("2016-11-13");
  122 |   await expect(page.locator(".ncr-city-map path")).toHaveCount(17);
  123 |   await expect(
  124 |     page.getByRole("region", { name: "Historical NCR city ranking" }),
  125 |   ).toContainText("Unavailable");
  126 |   await expect(
  127 |     page.getByText("Data ends January 2021.", { exact: true }),
  128 |   ).toBeVisible();
  129 |   await expect(
  130 |     page.getByText("No district or barangay case counts are inferred.", {
  131 |       exact: false,
  132 |     }),
  133 |   ).toBeVisible();
  134 |   expect(await page.locator(".barangay-svg").count()).toBe(0);
  135 | });
  136 | test("public routes retain disclaimers and legal access on phones", async ({
  137 |   page,
  138 | }) => {
  139 |   test.setTimeout(120000);
  140 |   await mockPublicApi(page, { open: false });
  141 |   for (const width of [320, 390, 768])
  142 |     for (const route of [
  143 |       "/",
  144 |       "/trends",
  145 |       "/map",
  146 |       "/report",
  147 |       "/privacy",
  148 |       "/terms",
  149 |       "/data-sources",
  150 |       "/dev",
  151 |       "/not-found",
  152 |     ]) {
  153 |       await page.setViewportSize({ width, height: 844 });
  154 |       await page.goto(route);
  155 |       await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
  156 |       await expect(
  157 |         page.getByRole("complementary", { name: "Estimates, not alerts" }),
  158 |       ).toHaveCount(1);
  159 |       await expect(page.getByRole("contentinfo")).toContainText("Dec 2, 2023");
  160 |       expect(
  161 |         await page.evaluate(
  162 |           () => document.documentElement.scrollWidth <= innerWidth,
  163 |         ),
  164 |       ).toBe(true);
  165 |     }
  166 | });
  167 | test("publishable community aggregates remain delayed, unverified and separate", async ({
  168 |   page,
  169 | }) => {
  170 |   await mockPublicApi(page, { open: false });
  171 |   await page.route("**/rest/v1/rpc/community_signal_aggregates**", (r) =>
  172 |     r.fulfill({
  173 |       status: 200,
  174 |       contentType: "application/json",
  175 |       body: JSON.stringify([
  176 |         {
  177 |           area_label: "Manila city (area not specified)",
  178 |           week_start: "2026-09-21",
  179 |           report_count: 7,
  180 |         },
  181 |       ]),
  182 |     }),
  183 |   );
  184 |   await page.goto("/community");
  185 |   const section = page.getByRole("region", {
  186 |     name: "Unverified community aggregates",
  187 |   });
  188 |   await expect(section).toContainText("7");
  189 |   await expect(
  190 |     page.getByText("minimum 72-hour delay", { exact: false }),
  191 |   ).toBeVisible();
  192 |   await expect(
  193 |     page.locator('[aria-label="Historical forecast table"]'),
  194 |   ).toHaveCount(0);
  195 | });
  196 | test("loading resolves to an explicit empty snapshot without fabricated values", async ({
  197 |   page,
  198 | }) => {
```