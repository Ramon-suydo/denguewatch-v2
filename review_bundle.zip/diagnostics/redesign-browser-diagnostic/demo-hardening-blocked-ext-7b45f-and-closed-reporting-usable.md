# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: demo-hardening.spec.ts >> blocked external services leave static historical pages and closed reporting usable
- Location: tests\ui\demo-hardening.spec.ts:66:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Offline · showing previously loaded historical research data.')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('Offline · showing previously loaded historical research data.') with timeout 5000ms
  - waiting for getByText('Offline · showing previously loaded historical research data.')

```

```yaml
- link "Skip to content":
  - /url: "#main"
- banner:
  - link "DengueWatch home":
    - /url: /
    - text: DENGUE WATCH
  - navigation "Main navigation":
    - link "Dashboard":
      - /url: /
    - link "Risk Map":
      - /url: /risk-map
    - link "Community Report":
      - /url: /report
  - button "English" [pressed]
  - button "Filipino"
- main:
  - region "DENGUE WATCH MANILA":
    - text: THESIS PROJECT DATA AS OF 2023-12-02
    - paragraph: Understand the patterns. Take care of each other.
    - heading "DENGUE WATCH MANILA" [level=1]
    - link "View Risk Map":
      - /url: /risk-map
    - link "Report a Case":
      - /url: /report
    - paragraph: Historical evidence. Everyday awareness. No live case surveillance.
  - complementary: Manila case data ends 2023-12-02. Province/city case data ends 2021-01-10. Neither is live.
  - paragraph: THE QUESTION BEHIND THE THESIS
  - heading "Can better awareness begin with honest data?" [level=2]
  - paragraph: Dengue is a mosquito-borne illness. This thesis asks whether historical cases and environmental context can support earlier awareness without overstating what the data can predict.
  - paragraph: "We compare forecasts with a simple last-week baseline, make missing observations visible, and keep unverified community reports separate from official records. Objectives: describe patterns, test predictive skill, and provide a privacy-conscious awareness channel."
  - status: Community reporting is closed.
  - text: Absent-day scenario
  - combobox "Absent-day scenario":
    - option "M · absent dates remain missing" [selected]
    - option "Z · absent dates assumed zero"
  - paragraph: Only weeks with seven daily rows are scored. An absent date is not a recorded zero. The final partial week is excluded in both scenarios.
  - paragraph: MANILA / HISTORICAL CASE FORECAST
  - heading "Current risk unavailable" [level=2]
  - paragraph: The case record is too old to establish current risk. This is the only case-forecast panel; the national map is a relative outlook.
  - paragraph:
    - text: Data as of
    - time: 2023-12-02
    - text: "? Forecast origin 2023-11-26 ? Scenario M"
  - article:
    - heading "1 week(s) ahead" [level=3]
    - paragraph: 62 estimated cases
    - paragraph: "Historical target: 2023-12-03"
    - paragraph: "80% interval: 40?84"
  - article:
    - heading "2 week(s) ahead" [level=3]
    - paragraph: 62 estimated cases
    - paragraph: "Historical target: 2023-12-10"
    - paragraph: "80% interval: 31?93"
  - paragraph: One-week persistence means last week's value. These are retrospective estimates, not a warning for the coming days.
  - paragraph: Remove standing water, protect against bites and seek early consultation for symptoms.
  - 'heading "Seasonal watch: context only" [level=2]'
  - paragraph: PAGASA defines June to November as the rainy season. Clear containers of standing water and keep up bite prevention. This is seasonal context, not a dengue prediction or alert.
  - paragraph: Dengue observations remain historical; current weather cannot establish today's dengue risk.
  - paragraph: In complete-row history for 2016-2023 (Scenario M), mean weekly cases ranged from 22.8 in May to 122.1 in September. This does not measure a delay from rainfall onset to rising cases.
  - status: "Weather is seasonal context only; showing baseline forecast. Dengue observations remain historical. Weather as of: 2026-10-11."
  - link "PAGASA season definition":
    - /url: https://www.pagasa.dost.gov.ph/information/climate-philippines
  - paragraph: ANALYTICS / RECORDED EVIDENCE
  - heading "The story in the weekly record" [level=2]
  - heading "Manila weekly cases, with source boundaries" [level=3]
  - figure "Scrollable Manila history chart":
    - img "Manila weekly case history 312 observed or scenario-defined weeks. Peak 257 cases. Gaps break the line. Shading marks the COVID period. Exact data appears in the table below.": 0 64 129 193 257 COVID period 2016-01-10 2023-12-03 Weekly cases · gaps remain gaps Source changes
    - text: DOH EPI before 2018; Manila daily-derived weeks from 2018. COVID period shaded (2020–2021). Source dates end 2023-12-02; final partial week excluded. Sunday labels operationally interpreted as week-ending; source semantics unconfirmed.
  - group: Exact weekly values and quality flags
  - heading "Year comparison" [level=3]
  - paragraph: Available weeks only; incomplete years are not annual totals.
  - region "Year comparison":
    - table:
      - rowgroup:
        - row "Year Recorded cases Weeks":
          - columnheader "Year"
          - columnheader "Recorded cases"
          - columnheader "Weeks"
      - rowgroup:
        - row "2016 1,990 ? incomplete 45 / 51":
          - rowheader "2016"
          - cell "1,990 ? incomplete"
          - cell "45 / 51"
        - row "2017 2,813 53 / 53":
          - rowheader "2017"
          - cell "2,813"
          - cell "53 / 53"
        - row "2018 3,530 ? incomplete 47 / 52":
          - rowheader "2018"
          - cell "3,530 ? incomplete"
          - cell "47 / 52"
        - row "2019 3,761 ? incomplete 43 / 52":
          - rowheader "2019"
          - cell "3,761 ? incomplete"
          - cell "43 / 52"
        - row "2020 451 ? incomplete 13 / 52":
          - rowheader "2020"
          - cell "451 ? incomplete"
          - cell "13 / 52"
        - row "2021 883 ? incomplete 24 / 52":
          - rowheader "2021"
          - cell "883 ? incomplete"
          - cell "24 / 52"
        - row "2022 2,516 ? incomplete 42 / 52":
          - rowheader "2022"
          - cell "2,516 ? incomplete"
          - cell "42 / 52"
        - row "2023 2,346 ? incomplete 45 / 49":
          - rowheader "2023"
          - cell "2,346 ? incomplete"
          - cell "45 / 49"
  - heading "Seasonal profile" [level=3]
  - paragraph: Mean weekly cases by month of week ending; observed/scenario-defined weeks only, not monthly totals.
  - text: Jan
  - 'meter "Month 1: 53.8"'
  - text: 53.8 Feb
  - 'meter "Month 2: 43.7"'
  - text: 43.7 Mar
  - 'meter "Month 3: 29.4"'
  - text: 29.4 Apr
  - 'meter "Month 4: 27.2"'
  - text: 27.2 May
  - 'meter "Month 5: 22.8"'
  - text: 22.8 Jun
  - 'meter "Month 6: 30"'
  - text: 30 Jul
  - 'meter "Month 7: 49.6"'
  - text: 49.6 Aug
  - 'meter "Month 8: 95.3"'
  - text: 95.3 Sep
  - 'meter "Month 9: 122.1"'
  - text: 122.1 Oct
  - 'meter "Month 10: 92.8"'
  - text: 92.8 Nov
  - 'meter "Month 11: 72.1"'
  - text: 72.1 Dec
  - 'meter "Month 12: 49.8"'
  - text: "49.8"
  - 'heading "Forecast versus actual: held-out 2023" [level=3]'
  - img "Saved one-week persistence predictions versus actual held-out cases"
  - paragraph: "Solid: recorded values. Dashed: one-week persistence. Each origin precedes its target."
  - group: Backtest data table
  - paragraph: "Source: data/processed/evaluation.json ? public/api/v2/dashboard.json."
  - heading "How accurate is this?" [level=2]
  - paragraph: The public chart starts with Scenario M (only complete daily-row weeks). Scenario Z assumes absent dates are zero within coverage. Both are evaluated. The one-week public forecast is last week's value. Weather did not improve the predeclared one/two-week comparison. Two- to four-week ridge improvements are exploratory with wide uncertainty, not a validated operational warning.
  - paragraph: Mean absolute error (MAE) is the average error in weekly case counts, from the saved 2018–2023 held-out evaluation. It does not establish accuracy for current conditions.
  - region "Forecast accuracy from saved evaluation":
    - table:
      - rowgroup:
        - row "Model Weeks ahead MAE (cases) Evaluated targets":
          - columnheader "Model"
          - columnheader "Weeks ahead"
          - columnheader "MAE (cases)"
          - columnheader "Evaluated targets"
      - rowgroup:
        - row "naive 1 15.47 116":
          - rowheader "naive"
          - cell "1"
          - cell "15.47"
          - cell "116"
        - row "ridge-cases 1 16.36 116":
          - rowheader "ridge-cases"
          - cell "1"
          - cell "16.36"
          - cell "116"
        - row "ridge-weather 1 18.39 116":
          - rowheader "ridge-weather"
          - cell "1"
          - cell "18.39"
          - cell "116"
        - row "naive 2 22.90 117":
          - rowheader "naive"
          - cell "2"
          - cell "22.90"
          - cell "117"
        - row "ridge-cases 2 22.17 117":
          - rowheader "ridge-cases"
          - cell "2"
          - cell "22.17"
          - cell "117"
        - row "ridge-weather 2 23.17 117":
          - rowheader "ridge-weather"
          - cell "2"
          - cell "23.17"
          - cell "117"
        - row "naive 4 31.63 112":
          - rowheader "naive"
          - cell "4"
          - cell "31.63"
          - cell "112"
        - row "ridge-cases 4 27.43 112":
          - rowheader "ridge-cases"
          - cell "4"
          - cell "27.43"
          - cell "112"
        - row "ridge-weather 4 28.42 112":
          - rowheader "ridge-weather"
          - cell "4"
          - cell "28.42"
          - cell "112"
  - region "Know when to seek care":
    - paragraph: TAKE CARE / ACT EARLY
    - heading "Know when to seek care" [level=2]
    - paragraph: Seek urgent medical care for severe abdominal pain, persistent vomiting, bleeding, difficulty breathing, unusual drowsiness or extreme weakness. Do not wait for a report review.
    - 'link "Source: CDC dengue warning signs"':
      - /url: https://www.cdc.gov/dengue/hcp/clinical-care/
    - heading "Make the DOH 4S a habit" [level=3]
    - list:
      - listitem: "Search and destroy mosquito breeding places: empty and clean standing-water containers."
      - listitem: "Self-protection: use repellent as directed and wear protective clothing."
      - listitem: Seek early consultation for fever or dengue-like symptoms.
      - listitem: Support health-authority fogging or spraying in identified hotspot/outbreak areas.
    - 'link "Source: Ministry of Health 4S guidance"':
      - /url: https://bangsamoro.gov.ph/news/latest-news/moh-urges-public-to-observe-4s-strategy-against-dengue/
    - paragraph:
      - strong: Informational, not a diagnosis. Not an official DOH product.
- contentinfo:
  - link "About & Credits":
    - /url: /about
  - button "About the data & methods"
  - paragraph:
    - text: Bundled source periods.
    - time: Dec 2, 2023
    - text: "?"
    - time: Jan 10, 2021
    - text: . Historical, not live.
  - paragraph: Background photograph by Sumarie Slabber
  - paragraph: Thesis research ? Not an official DOH product ? Historical records, not a live warning.
- status
```

# Test source

```ts
  1   | ﻿import { test, expect } from "@playwright/test";
  2   | import AxeBuilder from "@axe-core/playwright";
  3   | import { mockPublicApi } from "../fixtures/public-fixtures";
  4   | const routes = [
  5   |   "/",
  6   |   "/trends",
  7   |   "/metro-manila",
  8   |   "/methodology",
  9   |   "/prevention",
  10  |   "/community",
  11  |   "/report",
  12  |   "/privacy",
  13  |   "/terms",
  14  |   "/legal",
  15  |   "/data-sources",
  16  |   "/not-found",
  17  | ];
  18  | async function navigate(page: import("@playwright/test").Page, path: string) {
  19  |   await page.evaluate((p) => {
  20  |     history.pushState({}, "", p);
  21  |     dispatchEvent(new PopStateEvent("popstate"));
  22  |   }, path);
  23  |   await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
  24  |   await expect(page.getByText("Loading data…", { exact: true })).toHaveCount(0);
  25  | }
  26  | test("all public routes retain mobile targets, console hygiene and axe", async ({
  27  |   page,
  28  | }) => {
  29  |   test.setTimeout(240000);
  30  |   const errors: string[] = [];
  31  |   page.on("pageerror", (e) => errors.push(e.message));
  32  |   page.on("console", (message) => {
  33  |     if (["warning", "error"].includes(message.type()))
  34  |       errors.push(message.text());
  35  |   });
  36  |   await mockPublicApi(page, { open: false });
  37  |   for (const width of [320, 390, 768, 1280])
  38  |     for (const route of routes) {
  39  |       await page.setViewportSize({ width, height: 900 });
  40  |       await page.goto(route);
  41  |       await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
  42  |       expect(
  43  |         await page.evaluate(
  44  |           () => document.documentElement.scrollWidth <= innerWidth,
  45  |         ),
  46  |       ).toBe(true);
  47  |       const violations = (
  48  |         await new AxeBuilder({ page }).analyze()
  49  |       ).violations.filter((v) =>
  50  |         ["serious", "critical"].includes(v.impact ?? ""),
  51  |       );
  52  |       expect(violations, route + " " + width).toEqual([]);
  53  |       const small = await page
  54  |         .locator(
  55  |           "button:visible:not([disabled]),select:visible,summary:visible,a:visible:not(.skip-link)",
  56  |         )
  57  |         .evaluateAll((elements) =>
  58  |           elements
  59  |             .filter((e) => e.getBoundingClientRect().height < 43.5)
  60  |             .map((e) => e.textContent?.trim().slice(0, 45)),
  61  |         );
  62  |       expect(small, route + " " + width).toEqual([]);
  63  |     }
  64  |   expect(errors).toEqual([]);
  65  | });
  66  | test("blocked external services leave static historical pages and closed reporting usable", async ({
  67  |   page,
  68  |   context,
  69  | }) => {
  70  |   const external: string[] = [];
  71  |   await page.addInitScript(() =>
  72  |     Object.defineProperty(navigator, "onLine", { get: () => false }),
  73  |   );
  74  |   await context.route("**/*", (r) => {
  75  |     if (
  76  |       ["localhost", "127.0.0.1"].includes(new URL(r.request().url()).hostname)
  77  |     )
  78  |       return r.continue();
  79  |     external.push(r.request().url());
  80  |     return r.abort();
  81  |   });
  82  |   for (const route of [
  83  |     "/",
  84  |     "/trends",
  85  |     "/metro-manila",
  86  |     "/methodology",
  87  |     "/prevention",
  88  |     "/report",
  89  |   ]) {
  90  |     await page.goto(route);
  91  |     await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
  92  |     await expect(
  93  |       page.getByText(
  94  |         "Offline · showing previously loaded historical research data.",
  95  |         { exact: false },
  96  |       ),
> 97  |     ).toBeVisible();
      |       ^ Error: expect(locator).toBeVisible() failed
  98  |   }
  99  |   await expect(
  100 |     page.getByText("New submissions are not open yet.", { exact: false }),
  101 |   ).toBeVisible();
  102 |   expect(external).toEqual([]);
  103 | });
  104 | test("warmed routes and validated datasets remain available with the browser fully offline", async ({
  105 |   page,
  106 |   context,
  107 | }) => {
  108 |   const errors: string[] = [];
  109 |   page.on("pageerror", (e) => errors.push(e.message));
  110 |   await page.goto("/");
  111 |   await expect(
  112 |     page.getByRole("heading", { name: "Current risk unavailable" }),
  113 |   ).toBeVisible();
  114 |   for (const route of [
  115 |     "/trends",
  116 |     "/metro-manila",
  117 |     "/methodology",
  118 |     "/prevention",
  119 |     "/",
  120 |   ])
  121 |     await navigate(page, route);
  122 |   await context.setOffline(true);
  123 |   for (const route of [
  124 |     "/trends",
  125 |     "/metro-manila",
  126 |     "/methodology",
  127 |     "/prevention",
  128 |     "/",
  129 |   ]) {
  130 |     await navigate(page, route);
  131 |     await expect(
  132 |       page.getByText(
  133 |         "Offline · showing previously loaded historical research data.",
  134 |         { exact: false },
  135 |       ),
  136 |     ).toBeVisible();
  137 |   }
  138 |   expect(errors).toEqual([]);
  139 | });
  140 | test("slow research reads show loading without inventing a current risk, then resolve", async ({
  141 |   page,
  142 | }) => {
  143 |   let release!: () => void;
  144 |   const gate = new Promise<void>((r) => (release = r));
  145 |   await page.route("**/api/v2/manila.json", async (r) => {
  146 |     await gate;
  147 |     await r.continue();
  148 |   });
  149 |   await page.goto("/");
  150 |   await expect(page.getByText("Loading data…", { exact: true })).toBeVisible();
  151 |   await expect(
  152 |     page.getByRole("heading", { name: "Current risk unavailable" }),
  153 |   ).toHaveCount(0);
  154 |   release();
  155 |   await expect(
  156 |     page.getByRole("heading", { name: "Current risk unavailable" }),
  157 |   ).toBeVisible();
  158 | });
  159 | 
```