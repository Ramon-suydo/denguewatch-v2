# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: evidence.spec.ts >> research pages: mobile/desktop, no overflow, no critical or serious axe issues
- Location: tests\ui\evidence.spec.ts:4:1

# Error details

```
Error: [{"id":"color-contrast","impact":"serious","tags":["cat.color","wcag2aa","wcag143","TTv5","TT13.c","EN-301-549","EN-9.1.4.3","ACT","RGAAv4","RGAA-3.2.1"],"description":"Ensure the contrast between foreground and background colors meets WCAG 2 AA minimum contrast ratio thresholds","help":"Elements must meet minimum color contrast ratio thresholds","helpUrl":"https://dequeuniversity.com/rules/axe/4.13/color-contrast?application=playwright","nodes":[{"any":[{"id":"color-contrast","data":{"fgColor":"#374151","bgColor":"#071b2b","contrastRatio":1.69,"fontSize":"12.0pt (16px)","fontWeight":"normal","messageKey":null,"expectedContrastRatio":"4.5:1"},"relatedNodes":[{"html":"<div class=\"photo-app dashboard-page\">","target":[".photo-app"]}],"impact":"serious","message":"Element has insufficient color contrast of 1.69 (foreground color: #374151, background color: #071b2b, font size: 12.0pt (16px), font weight: normal). Expected contrast ratio of 4.5:1"}],"all":[],"none":[],"impact":"serious","html":"<label for=\"_r_1_\">Absent-day scenario</label>","target":["label"],"failureSummary":"Fix any of the following:\n  Element has insufficient color contrast of 1.69 (foreground color: #374151, background color: #071b2b, font size: 12.0pt (16px), font weight: normal). Expected contrast ratio of 4.5:1"},{"any":[{"id":"color-contrast","data":{"fgColor":"#4b5563","bgColor":"#071b2b","contrastRatio":2.31,"fontSize":"13.5pt (18px)","fontWeight":"normal","messageKey":null,"expectedContrastRatio":"4.5:1"},"relatedNodes":[{"html":"<div class=\"photo-app dashboard-page\">","target":[".photo-app"]}],"impact":"serious","message":"Element has insufficient color contrast of 2.31 (foreground color: #4b5563, background color: #071b2b, font size: 13.5pt (18px), font weight: normal). Expected contrast ratio of 4.5:1"}],"all":[],"none":[],"impact":"serious","html":"<p class=\"muted\">Only weeks with seven daily rows are scored. An absent date is not a recorded zero. The final partial week is excluded in both scenarios.</p>","target":[".muted"],"failureSummary":"Fix any of the following:\n  Element has insufficient color contrast of 2.31 (foreground color: #4b5563, background color: #071b2b, font size: 13.5pt (18px), font weight: normal). Expected contrast ratio of 4.5:1"},{"any":[{"id":"color-contrast","data":{"fgColor":"#0f1a3d","bgColor":"#071b2b","contrastRatio":1.02,"fontSize":"20.4pt (27.2px)","fontWeight":"bold","messageKey":null,"expectedContrastRatio":"3:1"},"relatedNodes":[{"html":"<div class=\"photo-app dashboard-page\">","target":[".photo-app"]}],"impact":"serious","message":"Element has insufficient color contrast of 1.02 (foreground color: #0f1a3d, background color: #071b2b, font size: 20.4pt (27.2px), font weight: bold). Expected contrast ratio of 3:1"}],"all":[],"none":[],"impact":"serious","html":"<h2>The story in the weekly record</h2>","target":["#analytics > h2"],"failureSummary":"Fix any of the following:\n  Element has insufficient color contrast of 1.02 (foreground color: #0f1a3d, background color: #071b2b, font size: 20.4pt (27.2px), font weight: bold). Expected contrast ratio of 3:1"}]}]

expect(received).toEqual(expected) // deep equality

- Expected  -   1
+ Received  + 128

- Array []
+ Array [
+   Object {
+     "description": "Ensure the contrast between foreground and background colors meets WCAG 2 AA minimum contrast ratio thresholds",
+     "help": "Elements must meet minimum color contrast ratio thresholds",
+     "helpUrl": "https://dequeuniversity.com/rules/axe/4.13/color-contrast?application=playwright",
+     "id": "color-contrast",
+     "impact": "serious",
+     "nodes": Array [
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "bgColor": "#071b2b",
+               "contrastRatio": 1.69,
+               "expectedContrastRatio": "4.5:1",
+               "fgColor": "#374151",
+               "fontSize": "12.0pt (16px)",
+               "fontWeight": "normal",
+               "messageKey": null,
+             },
+             "id": "color-contrast",
+             "impact": "serious",
+             "message": "Element has insufficient color contrast of 1.69 (foreground color: #374151, background color: #071b2b, font size: 12.0pt (16px), font weight: normal). Expected contrast ratio of 4.5:1",
+             "relatedNodes": Array [
+               Object {
+                 "html": "<div class=\"photo-app dashboard-page\">",
+                 "target": Array [
+                   ".photo-app",
+                 ],
+               },
+             ],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Element has insufficient color contrast of 1.69 (foreground color: #374151, background color: #071b2b, font size: 12.0pt (16px), font weight: normal). Expected contrast ratio of 4.5:1",
+         "html": "<label for=\"_r_1_\">Absent-day scenario</label>",
+         "impact": "serious",
+         "none": Array [],
+         "target": Array [
+           "label",
+         ],
+       },
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "bgColor": "#071b2b",
+               "contrastRatio": 2.31,
+               "expectedContrastRatio": "4.5:1",
+               "fgColor": "#4b5563",
+               "fontSize": "13.5pt (18px)",
+               "fontWeight": "normal",
+               "messageKey": null,
+             },
+             "id": "color-contrast",
+             "impact": "serious",
+             "message": "Element has insufficient color contrast of 2.31 (foreground color: #4b5563, background color: #071b2b, font size: 13.5pt (18px), font weight: normal). Expected contrast ratio of 4.5:1",
+             "relatedNodes": Array [
+               Object {
+                 "html": "<div class=\"photo-app dashboard-page\">",
+                 "target": Array [
+                   ".photo-app",
+                 ],
+               },
+             ],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Element has insufficient color contrast of 2.31 (foreground color: #4b5563, background color: #071b2b, font size: 13.5pt (18px), font weight: normal). Expected contrast ratio of 4.5:1",
+         "html": "<p class=\"muted\">Only weeks with seven daily rows are scored. An absent date is not a recorded zero. The final partial week is excluded in both scenarios.</p>",
+         "impact": "serious",
+         "none": Array [],
+         "target": Array [
+           ".muted",
+         ],
+       },
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "bgColor": "#071b2b",
+               "contrastRatio": 1.02,
+               "expectedContrastRatio": "3:1",
+               "fgColor": "#0f1a3d",
+               "fontSize": "20.4pt (27.2px)",
+               "fontWeight": "bold",
+               "messageKey": null,
+             },
+             "id": "color-contrast",
+             "impact": "serious",
+             "message": "Element has insufficient color contrast of 1.02 (foreground color: #0f1a3d, background color: #071b2b, font size: 20.4pt (27.2px), font weight: bold). Expected contrast ratio of 3:1",
+             "relatedNodes": Array [
+               Object {
+                 "html": "<div class=\"photo-app dashboard-page\">",
+                 "target": Array [
+                   ".photo-app",
+                 ],
+               },
+             ],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Element has insufficient color contrast of 1.02 (foreground color: #0f1a3d, background color: #071b2b, font size: 20.4pt (27.2px), font weight: bold). Expected contrast ratio of 3:1",
+         "html": "<h2>The story in the weekly record</h2>",
+         "impact": "serious",
+         "none": Array [],
+         "target": Array [
+           "#analytics > h2",
+         ],
+       },
+     ],
+     "tags": Array [
+       "cat.color",
+       "wcag2aa",
+       "wcag143",
+       "TTv5",
+       "TT13.c",
+       "EN-301-549",
+       "EN-9.1.4.3",
+       "ACT",
+       "RGAAv4",
+       "RGAA-3.2.1",
+     ],
+   },
+ ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - link "Skip to content" [ref=e5] [cursor=pointer]:
      - /url: "#main"
    - banner [ref=e6]:
      - link "DengueWatch home" [ref=e7] [cursor=pointer]:
        - /url: /
        - text: DENGUE
        - generic [ref=e8]: WATCH
      - button "Menu" [ref=e9] [cursor=pointer]
      - generic "Page language" [ref=e10]:
        - button "English" [pressed] [ref=e11] [cursor=pointer]
        - button "Filipino" [ref=e12] [cursor=pointer]
    - main [ref=e13]:
      - region [ref=e14]:
        - generic [ref=e17]:
          - generic [ref=e18]: THESIS PROJECT
          - generic [ref=e19]: DATA AS OF 2023-12-02
        - generic [ref=e20]:
          - paragraph [ref=e21]: Understand the patterns. Take care of each other.
          - heading "DENGUE WATCH MANILA" [level=1] [ref=e22]: DENGUE WATCHMANILA
          - generic [ref=e23]:
            - link "View Risk Map" [ref=e24] [cursor=pointer]:
              - /url: /risk-map
            - link "Report a Case" [ref=e25] [cursor=pointer]:
              - /url: /report
          - paragraph [ref=e26]: Historical evidence. Everyday awareness. No live case surveillance.
      - generic [ref=e27]:
        - complementary [ref=e28]: Manila case data ends 2023-12-02. Province/city case data ends 2021-01-10. Neither is live.
        - generic [ref=e29]:
          - generic [ref=e30]:
            - paragraph [ref=e31]: THE QUESTION BEHIND THE THESIS
            - heading "Can better awareness begin with honest data?" [level=2] [ref=e32]
          - generic [ref=e33]:
            - paragraph [ref=e34]: Dengue is a mosquito-borne illness. This thesis asks whether historical cases and environmental context can support earlier awareness without overstating what the data can predict.
            - paragraph [ref=e35]: "We compare forecasts with a simple last-week baseline, make missing observations visible, and keep unverified community reports separate from official records. Objectives: describe patterns, test predictive skill, and provide a privacy-conscious awareness channel."
            - status [ref=e36]: Checking reporting status…
        - generic [ref=e37]:
          - generic [ref=e38]: Absent-day scenario
          - combobox "Absent-day scenario" [ref=e39] [cursor=pointer]:
            - option "M · absent dates remain missing" [selected]
            - option "Z · absent dates assumed zero"
        - paragraph [ref=e40]: Only weeks with seven daily rows are scored. An absent date is not a recorded zero. The final partial week is excluded in both scenarios.
        - generic [ref=e41]:
          - paragraph [ref=e42]: MANILA / HISTORICAL CASE FORECAST
          - heading "Current risk unavailable" [level=2] [ref=e43]
          - paragraph [ref=e44]: The case record is too old to establish current risk. This is the only case-forecast panel; the national map is a relative outlook.
          - paragraph [ref=e45]:
            - text: Data as of
            - time [ref=e46]: 2023-12-02
            - text: "? Forecast origin 2023-11-26 ? Scenario M"
          - generic [ref=e47]:
            - article [ref=e48]:
              - heading "1 week(s) ahead" [level=3] [ref=e49]
              - paragraph [ref=e50]: 62 estimated cases
              - paragraph [ref=e51]: "Historical target: 2023-12-03"
              - paragraph [ref=e52]: "80% interval: 40?84"
            - article [ref=e53]:
              - heading "2 week(s) ahead" [level=3] [ref=e54]
              - paragraph [ref=e55]: 62 estimated cases
              - paragraph [ref=e56]: "Historical target: 2023-12-10"
              - paragraph [ref=e57]: "80% interval: 31?93"
          - paragraph [ref=e58]: One-week persistence means last week's value. These are retrospective estimates, not a warning for the coming days.
          - paragraph [ref=e59]: Remove standing water, protect against bites and seek early consultation for symptoms.
        - generic [ref=e60]:
          - 'heading "Seasonal watch: context only" [level=2] [ref=e61]'
          - paragraph [ref=e62]: PAGASA defines June to November as the rainy season. Clear containers of standing water and keep up bite prevention. This is seasonal context, not a dengue prediction or alert.
          - paragraph [ref=e63]: Dengue observations remain historical; current weather cannot establish today's dengue risk.
          - paragraph [ref=e64]: In complete-row history for 2016-2023 (Scenario M), mean weekly cases ranged from 22.8 in May to 122.1 in September. This does not measure a delay from rainfall onset to rising cases.
          - status [ref=e65]: "Weather is seasonal context only; showing baseline forecast. Dengue observations remain historical. Weather as of: 2026-10-11."
          - link "PAGASA season definition" [ref=e66] [cursor=pointer]:
            - /url: https://www.pagasa.dost.gov.ph/information/climate-philippines
        - generic [ref=e67]:
          - paragraph [ref=e68]: ANALYTICS / RECORDED EVIDENCE
          - heading "The story in the weekly record" [level=2] [ref=e69]
          - generic [ref=e70]:
            - heading "Manila weekly cases, with source boundaries" [level=3] [ref=e71]
            - figure "Scrollable Manila history chart" [ref=e72]:
              - img "Manila weekly case history 312 observed or scenario-defined weeks. Peak 257 cases. Gaps break the line. Shading marks the COVID period. Exact data appears in the table below." [ref=e73]:
                - generic [ref=e75]: "0"
                - generic [ref=e77]: "64"
                - generic [ref=e79]: "129"
                - generic [ref=e81]: "193"
                - generic [ref=e83]: "257"
                - generic [ref=e85]: COVID period
                - generic [ref=e107]: 2016-01-10
                - generic [ref=e108]: 2023-12-03
                - generic [ref=e109]: Weekly cases · gaps remain gaps
                - generic [ref=e110]: Source changes
              - generic [ref=e111]: DOH EPI before 2018; Manila daily-derived weeks from 2018. COVID period shaded (2020–2021). Source dates end 2023-12-02; final partial week excluded. Sunday labels operationally interpreted as week-ending; source semantics unconfirmed.
            - group [ref=e112]:
              - generic "Exact weekly values and quality flags" [ref=e113] [cursor=pointer]
          - generic [ref=e114]:
            - generic [ref=e115]:
              - heading "Year comparison" [level=3] [ref=e116]
              - paragraph [ref=e117]: Available weeks only; incomplete years are not annual totals.
              - region "Year comparison" [ref=e118]:
                - table [ref=e119]:
                  - rowgroup [ref=e120]:
                    - row [ref=e121]:
                      - columnheader "Year" [ref=e122]
                      - columnheader "Recorded cases" [ref=e123]
                      - columnheader "Weeks" [ref=e124]
                  - rowgroup [ref=e125]:
                    - row [ref=e126]:
                      - rowheader "2016" [ref=e127]
                      - cell "1,990 ? incomplete" [ref=e128]
                      - cell "45 / 51" [ref=e129]
                    - row [ref=e130]:
                      - rowheader "2017" [ref=e131]
                      - cell "2,813" [ref=e132]
                      - cell "53 / 53" [ref=e133]
                    - row [ref=e134]:
                      - rowheader "2018" [ref=e135]
                      - cell "3,530 ? incomplete" [ref=e136]
                      - cell "47 / 52" [ref=e137]
                    - row [ref=e138]:
                      - rowheader "2019" [ref=e139]
                      - cell "3,761 ? incomplete" [ref=e140]
                      - cell "43 / 52" [ref=e141]
                    - row [ref=e142]:
                      - rowheader "2020" [ref=e143]
                      - cell "451 ? incomplete" [ref=e144]
                      - cell "13 / 52" [ref=e145]
                    - row [ref=e146]:
                      - rowheader "2021" [ref=e147]
                      - cell "883 ? incomplete" [ref=e148]
                      - cell "24 / 52" [ref=e149]
                    - row [ref=e150]:
                      - rowheader "2022" [ref=e151]
                      - cell "2,516 ? incomplete" [ref=e152]
                      - cell "42 / 52" [ref=e153]
                    - row [ref=e154]:
                      - rowheader "2023" [ref=e155]
                      - cell "2,346 ? incomplete" [ref=e156]
                      - cell "45 / 49" [ref=e157]
            - generic [ref=e158]:
              - heading "Seasonal profile" [level=3] [ref=e159]
              - paragraph [ref=e160]: Mean weekly cases by month of week ending; observed/scenario-defined weeks only, not monthly totals.
              - generic [ref=e161]:
                - generic [ref=e162]:
                  - generic [ref=e163]: Jan
                  - 'meter "Month 1: 53.8" [ref=e164]'
                  - generic [ref=e165]: "53.8"
                - generic [ref=e166]:
                  - generic [ref=e167]: Feb
                  - 'meter "Month 2: 43.7" [ref=e168]'
                  - generic [ref=e169]: "43.7"
                - generic [ref=e170]:
                  - generic [ref=e171]: Mar
                  - 'meter "Month 3: 29.4" [ref=e172]'
                  - generic [ref=e173]: "29.4"
                - generic [ref=e174]:
                  - generic [ref=e175]: Apr
                  - 'meter "Month 4: 27.2" [ref=e176]'
                  - generic [ref=e177]: "27.2"
                - generic [ref=e178]:
                  - generic [ref=e179]: May
                  - 'meter "Month 5: 22.8" [ref=e180]'
                  - generic [ref=e181]: "22.8"
                - generic [ref=e182]:
                  - generic [ref=e183]: Jun
                  - 'meter "Month 6: 30" [ref=e184]'
                  - generic [ref=e185]: "30"
                - generic [ref=e186]:
                  - generic [ref=e187]: Jul
                  - 'meter "Month 7: 49.6" [ref=e188]'
                  - generic [ref=e189]: "49.6"
                - generic [ref=e190]:
                  - generic [ref=e191]: Aug
                  - 'meter "Month 8: 95.3" [ref=e192]'
                  - generic [ref=e193]: "95.3"
                - generic [ref=e194]:
                  - generic [ref=e195]: Sep
                  - 'meter "Month 9: 122.1" [ref=e196]'
                  - generic [ref=e197]: "122.1"
                - generic [ref=e198]:
                  - generic [ref=e199]: Oct
                  - 'meter "Month 10: 92.8" [ref=e200]'
                  - generic [ref=e201]: "92.8"
                - generic [ref=e202]:
                  - generic [ref=e203]: Nov
                  - 'meter "Month 11: 72.1" [ref=e204]'
                  - generic [ref=e205]: "72.1"
                - generic [ref=e206]:
                  - generic [ref=e207]: Dec
                  - 'meter "Month 12: 49.8" [ref=e208]'
                  - generic [ref=e209]: "49.8"
          - generic [ref=e210]:
            - 'heading "Forecast versus actual: held-out 2023" [level=3] [ref=e211]'
            - img "Saved one-week persistence predictions versus actual held-out cases" [ref=e212]
            - paragraph [ref=e215]: "Solid: recorded values. Dashed: one-week persistence. Each origin precedes its target."
            - group [ref=e216]:
              - generic "Backtest data table" [ref=e217] [cursor=pointer]
            - paragraph [ref=e218]: "Source: data/processed/evaluation.json ? public/api/v2/dashboard.json."
          - generic [ref=e219]:
            - heading "How accurate is this?" [level=2] [ref=e220]
            - paragraph [ref=e221]: The public chart starts with Scenario M (only complete daily-row weeks). Scenario Z assumes absent dates are zero within coverage. Both are evaluated. The one-week public forecast is last week's value. Weather did not improve the predeclared one/two-week comparison. Two- to four-week ridge improvements are exploratory with wide uncertainty, not a validated operational warning.
            - paragraph [ref=e222]: Mean absolute error (MAE) is the average error in weekly case counts, from the saved 2018–2023 held-out evaluation. It does not establish accuracy for current conditions.
            - region "Forecast accuracy from saved evaluation" [ref=e223]:
              - table [ref=e224]:
                - rowgroup [ref=e225]:
                  - row [ref=e226]:
                    - columnheader "Model" [ref=e227]
                    - columnheader "Weeks ahead" [ref=e228]
                    - columnheader "MAE (cases)" [ref=e229]
                    - columnheader "Evaluated targets" [ref=e230]
                - rowgroup [ref=e231]:
                  - row [ref=e232]:
                    - rowheader "naive" [ref=e233]
                    - cell "1" [ref=e234]
                    - cell "15.47" [ref=e235]
                    - cell "116" [ref=e236]
                  - row [ref=e237]:
                    - rowheader "ridge-cases" [ref=e238]
                    - cell "1" [ref=e239]
                    - cell "16.36" [ref=e240]
                    - cell "116" [ref=e241]
                  - row [ref=e242]:
                    - rowheader "ridge-weather" [ref=e243]
                    - cell "1" [ref=e244]
                    - cell "18.39" [ref=e245]
                    - cell "116" [ref=e246]
                  - row [ref=e247]:
                    - rowheader "naive" [ref=e248]
                    - cell "2" [ref=e249]
                    - cell "22.90" [ref=e250]
                    - cell "117" [ref=e251]
                  - row [ref=e252]:
                    - rowheader "ridge-cases" [ref=e253]
                    - cell "2" [ref=e254]
                    - cell "22.17" [ref=e255]
                    - cell "117" [ref=e256]
                  - row [ref=e257]:
                    - rowheader "ridge-weather" [ref=e258]
                    - cell "2" [ref=e259]
                    - cell "23.17" [ref=e260]
                    - cell "117" [ref=e261]
                  - row [ref=e262]:
                    - rowheader "naive" [ref=e263]
                    - cell "4" [ref=e264]
                    - cell "31.63" [ref=e265]
                    - cell "112" [ref=e266]
                  - row [ref=e267]:
                    - rowheader "ridge-cases" [ref=e268]
                    - cell "4" [ref=e269]
                    - cell "27.43" [ref=e270]
                    - cell "112" [ref=e271]
                  - row [ref=e272]:
                    - rowheader "ridge-weather" [ref=e273]
                    - cell "4" [ref=e274]
                    - cell "28.42" [ref=e275]
                    - cell "112" [ref=e276]
        - region [ref=e278]:
          - paragraph [ref=e279]: TAKE CARE / ACT EARLY
          - heading "Know when to seek care" [level=2] [ref=e280]
          - paragraph [ref=e281]: Seek urgent medical care for severe abdominal pain, persistent vomiting, bleeding, difficulty breathing, unusual drowsiness or extreme weakness. Do not wait for a report review.
          - 'link "Source: CDC dengue warning signs" [ref=e282] [cursor=pointer]':
            - /url: https://www.cdc.gov/dengue/hcp/clinical-care/
          - heading "Make the DOH 4S a habit" [level=3] [ref=e283]
          - list [ref=e284]:
            - listitem [ref=e285]: "Search and destroy mosquito breeding places: empty and clean standing-water containers."
            - listitem [ref=e286]: "Self-protection: use repellent as directed and wear protective clothing."
            - listitem [ref=e287]: Seek early consultation for fever or dengue-like symptoms.
            - listitem [ref=e288]: Support health-authority fogging or spraying in identified hotspot/outbreak areas.
          - 'link "Source: Ministry of Health 4S guidance" [ref=e289] [cursor=pointer]':
            - /url: https://bangsamoro.gov.ph/news/latest-news/moh-urges-public-to-observe-4s-strategy-against-dengue/
          - paragraph [ref=e290]:
            - strong [ref=e291]: Informational, not a diagnosis. Not an official DOH product.
    - contentinfo [ref=e292]:
      - generic [ref=e293]:
        - link "About & Credits" [ref=e294] [cursor=pointer]:
          - /url: /about
        - button "About the data & methods" [ref=e295] [cursor=pointer]
      - paragraph [ref=e296]:
        - text: Bundled source periods.
        - time [ref=e297]: Dec 2, 2023
        - text: "?"
        - time [ref=e298]: Jan 10, 2021
        - text: . Historical, not live.
      - paragraph [ref=e299]: Background photograph by Sumarie Slabber
      - paragraph [ref=e300]: Thesis research ? Not an official DOH product ? Historical records, not a live warning.
  - status
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | import AxeBuilder from "@axe-core/playwright";
  3   | import { mkdir } from "node:fs/promises";
  4   | test("research pages: mobile/desktop, no overflow, no critical or serious axe issues", async ({
  5   |   page,
  6   | }) => {
  7   |   test.setTimeout(180000);
  8   |   const errors: string[] = [];
  9   |   page.on("pageerror", (e) => errors.push(e.message));
  10  |   for (const width of [360, 768, 1280])
  11  |     for (const route of [
  12  |       "/",
  13  |       "/trends",
  14  |       "/metro-manila",
  15  |       "/methodology",
  16  |       "/prevention",
  17  |     ]) {
  18  |       await page.setViewportSize({ width, height: 900 });
  19  |       await page.goto(route);
  20  |       await expect(page.locator("h1")).toBeVisible();
  21  |       if (route === "/")
  22  |         await expect(
  23  |           page.getByRole("heading", { name: "Current risk unavailable" }),
  24  |         ).toBeVisible();
  25  |       if (route === "/metro-manila")
  26  |         await expect(page.locator(".ncr-city-map path")).toHaveCount(17);
  27  |       if (route === "/methodology")
  28  |         await expect(
  29  |           page.getByRole("heading", { name: "Forecast comparison" }),
  30  |         ).toBeVisible();
  31  |       expect(
  32  |         await page.evaluate(
  33  |           () => document.documentElement.scrollWidth <= window.innerWidth,
  34  |         ),
  35  |       ).toBe(true);
  36  |       const a = await new AxeBuilder({ page }).analyze();
  37  |       expect(
  38  |         a.violations.filter((v) =>
  39  |           ["critical", "serious"].includes(v.impact ?? ""),
  40  |         ),
  41  |         JSON.stringify(a.violations),
> 42  |       ).toEqual([]);
      |         ^ Error: [{"id":"color-contrast","impact":"serious","tags":["cat.color","wcag2aa","wcag143","TTv5","TT13.c","EN-301-549","EN-9.1.4.3","ACT","RGAAv4","RGAA-3.2.1"],"description":"Ensure the contrast between foreground and background colors meets WCAG 2 AA minimum contrast ratio thresholds","help":"Elements must meet minimum color contrast ratio thresholds","helpUrl":"https://dequeuniversity.com/rules/axe/4.13/color-contrast?application=playwright","nodes":[{"any":[{"id":"color-contrast","data":{"fgColor":"#374151","bgColor":"#071b2b","contrastRatio":1.69,"fontSize":"12.0pt (16px)","fontWeight":"normal","messageKey":null,"expectedContrastRatio":"4.5:1"},"relatedNodes":[{"html":"<div class=\"photo-app dashboard-page\">","target":[".photo-app"]}],"impact":"serious","message":"Element has insufficient color contrast of 1.69 (foreground color: #374151, background color: #071b2b, font size: 12.0pt (16px), font weight: normal). Expected contrast ratio of 4.5:1"}],"all":[],"none":[],"impact":"serious","html":"<label for=\"_r_1_\">Absent-day scenario</label>","target":["label"],"failureSummary":"Fix any of the following:\n  Element has insufficient color contrast of 1.69 (foreground color: #374151, background color: #071b2b, font size: 12.0pt (16px), font weight: normal). Expected contrast ratio of 4.5:1"},{"any":[{"id":"color-contrast","data":{"fgColor":"#4b5563","bgColor":"#071b2b","contrastRatio":2.31,"fontSize":"13.5pt (18px)","fontWeight":"normal","messageKey":null,"expectedContrastRatio":"4.5:1"},"relatedNodes":[{"html":"<div class=\"photo-app dashboard-page\">","target":[".photo-app"]}],"impact":"serious","message":"Element has insufficient color contrast of 2.31 (foreground color: #4b5563, background color: #071b2b, font size: 13.5pt (18px), font weight: normal). Expected contrast ratio of 4.5:1"}],"all":[],"none":[],"impact":"serious","html":"<p class=\"muted\">Only weeks with seven daily rows are scored. An absent date is not a recorded zero. The final partial week is excluded in both scenarios.</p>","target":[".muted"],"failureSummary":"Fix any of the following:\n  Element has insufficient color contrast of 2.31 (foreground color: #4b5563, background color: #071b2b, font size: 13.5pt (18px), font weight: normal). Expected contrast ratio of 4.5:1"},{"any":[{"id":"color-contrast","data":{"fgColor":"#0f1a3d","bgColor":"#071b2b","contrastRatio":1.02,"fontSize":"20.4pt (27.2px)","fontWeight":"bold","messageKey":null,"expectedContrastRatio":"3:1"},"relatedNodes":[{"html":"<div class=\"photo-app dashboard-page\">","target":[".photo-app"]}],"impact":"serious","message":"Element has insufficient color contrast of 1.02 (foreground color: #0f1a3d, background color: #071b2b, font size: 20.4pt (27.2px), font weight: bold). Expected contrast ratio of 3:1"}],"all":[],"none":[],"impact":"serious","html":"<h2>The story in the weekly record</h2>","target":["#analytics > h2"],"failureSummary":"Fix any of the following:\n  Element has insufficient color contrast of 1.02 (foreground color: #0f1a3d, background color: #071b2b, font size: 20.4pt (27.2px), font weight: bold). Expected contrast ratio of 3:1"}]}]
  43  |     }
  44  |   expect(errors).toEqual([]);
  45  |   await mkdir(".artifacts/evidence-ui", { recursive: true });
  46  |   await page.goto("/");
  47  |   await expect(
  48  |     page.getByRole("heading", { name: "Current risk unavailable" }),
  49  |   ).toBeVisible();
  50  |   await page.evaluate(() => document.fonts.ready);
  51  |   await page.screenshot({
  52  |     path: ".artifacts/evidence-ui/home-1280.png",
  53  |     fullPage: true,
  54  |   });
  55  |   await page.setViewportSize({ width: 360, height: 900 });
  56  |   await page.screenshot({
  57  |     path: ".artifacts/evidence-ui/home-360.png",
  58  |     fullPage: true,
  59  |   });
  60  | });
  61  | test("scenario and year changes keep absence explicit; NCR remains historical", async ({
  62  |   page,
  63  | }) => {
  64  |   await page.goto("/trends");
  65  |   await expect(
  66  |     page.getByRole("heading", { name: "Weekly recorded cases" }),
  67  |   ).toBeVisible();
  68  |   await page.getByLabel("Absent-day scenario").selectOption("Z");
  69  |   await expect(
  70  |     page.getByText("Zero is assumed only", { exact: false }),
  71  |   ).toBeVisible();
  72  |   await page.getByLabel("History year").selectOption("2020");
  73  |   await page.getByText("Exact weekly values and quality flags").click();
  74  |   await expect(
  75  |     page.getByRole("region", { name: "Weekly history data table" }),
  76  |   ).toBeVisible();
  77  |   await page.goto("/metro-manila");
  78  |   await expect(
  79  |     page.getByText("Data ends January 2021.", { exact: true }),
  80  |   ).toBeVisible();
  81  |   await page.getByLabel("Comparison period").selectOption("week");
  82  |   await page.getByLabel("Week label").selectOption("2016-11-06");
  83  |   await expect(page.locator(".ncr-city-map path")).toHaveCount(17);
  84  | });
  85  | test("Filipino home/prevention, missing API retry, and legacy forecasts isolated", async ({
  86  |   page,
  87  | }) => {
  88  |   await page.goto("/");
  89  |   await page.getByRole("button", { name: "Filipino", exact: true }).click();
  90  |   await expect(
  91  |     page.getByRole("heading", { name: "Kulang ang kasalukuyang datos" }),
  92  |   ).toBeVisible();
  93  |   await page.goto("/prevention");
  94  |   await expect(page.getByRole("heading", { name: "4S ng DOH" })).toBeVisible();
  95  |   await page.goto("/city/old-id");
  96  |   await expect(page).toHaveURL(/\/trends$/);
  97  |   let failedRequests = 0;
  98  |   await page.route("**/api/v2/manila.json", (route) => {
  99  |     failedRequests++;
  100 |     return route.fulfill({ status: 503, body: "Unavailable" });
  101 |   });
  102 |   await page.goto("/");
  103 |   await expect(page.getByRole("alert")).toContainText("could not load");
  104 |   expect(failedRequests).toBeGreaterThan(0);
  105 |   await expect(page.getByRole("button", { name: "Try again" })).toBeVisible();
  106 |   await page.unroute("**/api/v2/manila.json");
  107 |   await page.getByRole("button", { name: "Try again" }).click();
  108 |   await expect(
  109 |     page.getByRole("heading", { name: "Kulang ang kasalukuyang datos" }),
  110 |   ).toBeVisible();
  111 | });
  112 | 
```