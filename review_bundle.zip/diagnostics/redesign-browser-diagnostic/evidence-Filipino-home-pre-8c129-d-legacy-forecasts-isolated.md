# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: evidence.spec.ts >> Filipino home/prevention, missing API retry, and legacy forecasts isolated
- Location: tests\ui\evidence.spec.ts:85:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Kulang ang kasalukuyang datos' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: 'Kulang ang kasalukuyang datos' }) with timeout 5000ms
  - waiting for getByRole('heading', { name: 'Kulang ang kasalukuyang datos' })

```

```yaml
- link "Lumaktaw sa nilalaman":
  - /url: "#main"
- banner:
  - link "DengueWatch home":
    - /url: /
    - text: DENGUE WATCH
  - navigation "Main navigation":
    - link "Dashboard":
      - /url: /
    - link "Mapa ng Pananaw":
      - /url: /risk-map
    - link "Ulat ng Komunidad":
      - /url: /report
  - button "English"
  - button "Filipino" [pressed]
- main:
  - region "DENGUE WATCH MANILA":
    - text: THESIS PROJECT DATOS HANGGANG 2023-12-02
    - paragraph: Unawain ang datos. Alagaan ang isa?t isa.
    - heading "DENGUE WATCH MANILA" [level=1]
    - link "Tingnan ang Mapa":
      - /url: /risk-map
    - link "Mag-ulat ng Kaso":
      - /url: /report
    - paragraph: Makasaysayang ebidensiya. Araw-araw na pag-iingat. Hindi live na pagmamanman ng kaso.
  - complementary: Hanggang 2023-12-02 ang kaso sa Maynila at 2021-01-10 ang lalawigan/lungsod. Hindi ito live.
  - paragraph: ANG TANONG NG PANANALIKSIK
  - heading "Maaari bang magsimula ang pag-iingat sa tapat na datos?" [level=2]
  - paragraph: Ang dengue ay sakit na naihahawa ng lamok. Sinusuri ng tesis kung makatutulong ang kasaysayan ng kaso at konteksto ng kapaligiran sa pag-iingat nang hindi pinalalabis ang kayang hulaan ng datos.
  - paragraph: "Inihahambing ang pagtataya sa halaga noong nakaraang linggo, ipinapakita ang nawawalang tala, at inihihiwalay ang di-beripikadong ulat sa opisyal na datos. Layunin: ilarawan ang mga pattern, subukin ang pagtataya, at magbigay ng maingat na paraan ng pag-uulat."
  - status: Checking reporting status…
  - text: Pagpapalagay sa petsang walang tala
  - combobox "Pagpapalagay sa petsang walang tala":
    - option "M · nananatiling hindi alam ang walang tala" [selected]
    - option "Z · ipinapalagay na sero ang walang tala"
  - paragraph: Linggong may tala sa lahat ng pitong araw lamang ang sinusuri. Ang petsang walang tala ay hindi awtomatikong sero. Hindi kasama ang huling di-buong linggo sa alinmang pagsusuri.
  - paragraph: MANILA / MAKASAYSAYANG PAGTATAYA
  - heading "Hindi alam ang panganib ngayon" [level=2]
  - paragraph: Luma ang tala para masabi ang panganib ngayon. Para lamang sa Maynila ang pagtatayang ito; relatibong pananaw ang pambansang mapa.
  - paragraph:
    - text: Datos hanggang
    - time: 2023-12-02
    - text: "? Simula ng pagtataya 2023-11-26 ? Senaryo M"
  - article:
    - heading "1 linggo sa hinaharap" [level=3]
    - paragraph: 62 tinatayang kaso
    - paragraph: "Makasaysayang target: 2023-12-03"
    - paragraph: "80% saklaw: 40?84"
  - article:
    - heading "2 linggo sa hinaharap" [level=3]
    - paragraph: 62 tinatayang kaso
    - paragraph: "Makasaysayang target: 2023-12-10"
    - paragraph: "80% saklaw: 31?93"
  - paragraph: Ang isang linggong persistence ay halaga noong nakaraang linggo. Muling pagsusuri ito, hindi babala para sa mga susunod na araw.
  - paragraph: Alisin ang naiipong tubig, protektahan ang sarili sa kagat at magpakonsulta nang maaga kung may sintomas.
  - 'heading "Bantay-panahon: konteksto lamang" [level=2]'
  - paragraph: Hunyo hanggang Nobyembre ang tag-ulan ayon sa PAGASA. Alisin ang mga lalagyang may naiipong tubig. Konteksto lamang ito ng panahon; hindi pagtataya o babala ng dengue.
  - paragraph: Makasaysayang datos ang mga bilang ng dengue; hindi nito masasabi ang panganib ngayon.
  - paragraph: Sa kumpletong tala noong 2016-2023 (Scenario M), ang karaniwang bilang bawat linggo ay 22.8 sa Mayo at 122.1 sa Setyembre. Hindi nito sinusukat ang pagitan mula sa simula ng ulan hanggang sa pagdami ng kaso.
  - status: Konteksto lamang ang datos ng panahon hanggang 2026-10-11; batayang pagtataya ang ipinapakita.
  - link "Kahulugan ng panahon ayon sa PAGASA":
    - /url: https://www.pagasa.dost.gov.ph/information/climate-philippines
  - paragraph: PAGSUSURI / NAITALANG EBIDENSIYA
  - heading "Kasaysayan sa lingguhang tala" [level=2]
  - heading "Lingguhang kaso sa Maynila at mga pinagmulan" [level=3]
  - figure "Scrollable Manila history chart":
    - img "Manila weekly case history 312 observed or scenario-defined weeks. Peak 257 cases. Gaps break the line. Shading marks the COVID period. Exact data appears in the table below.": 0 64 129 193 257 COVID period 2016-01-10 2023-12-03 Weekly cases · gaps remain gaps Source changes
    - text: DOH EPI before 2018; Manila daily-derived weeks from 2018. COVID period shaded (2020–2021). Source dates end 2023-12-02; final partial week excluded. Sunday labels operationally interpreted as week-ending; source semantics unconfirmed.
  - group: Eksaktong lingguhang halaga at kalidad
  - heading "Paghahambing ng mga taon" [level=3]
  - paragraph: Mga linggong may datos lamang; hindi taunang kabuuan ang di-kumpletong taon.
  - region "Year comparison":
    - table:
      - rowgroup:
        - row "Taon Naitalang kaso Mga linggo":
          - columnheader "Taon"
          - columnheader "Naitalang kaso"
          - columnheader "Mga linggo"
      - rowgroup:
        - row "2016 1,990 ? incomplete 45 / 51":
          - rowheader "2016"
          - cell "1,990 ? incomplete"
          - cell "45 / 51"
        - row "2017 2,813 53 / 53":
          - rowheader "2017"
          - cell "2,813"
          - cell "53 / 53"
        - row "2018 3,530 ? incomplete 47 / 52":
          - rowheader "2018"
          - cell "3,530 ? incomplete"
          - cell "47 / 52"
        - row "2019 3,761 ? incomplete 43 / 52":
          - rowheader "2019"
          - cell "3,761 ? incomplete"
          - cell "43 / 52"
        - row "2020 451 ? incomplete 13 / 52":
          - rowheader "2020"
          - cell "451 ? incomplete"
          - cell "13 / 52"
        - row "2021 883 ? incomplete 24 / 52":
          - rowheader "2021"
          - cell "883 ? incomplete"
          - cell "24 / 52"
        - row "2022 2,516 ? incomplete 42 / 52":
          - rowheader "2022"
          - cell "2,516 ? incomplete"
          - cell "42 / 52"
        - row "2023 2,346 ? incomplete 45 / 49":
          - rowheader "2023"
          - cell "2,346 ? incomplete"
          - cell "45 / 49"
  - heading "Pana-panahong pattern" [level=3]
  - paragraph: Karaniwang lingguhang kaso ayon sa buwan ng katapusan ng linggo; hindi buwanang kabuuan.
  - text: Ene
  - 'meter "Month 1: 53.8"'
  - text: 53.8 Peb
  - 'meter "Month 2: 43.7"'
  - text: 43.7 Mar
  - 'meter "Month 3: 29.4"'
  - text: 29.4 Abr
  - 'meter "Month 4: 27.2"'
  - text: 27.2 May
  - 'meter "Month 5: 22.8"'
  - text: 22.8 Hun
  - 'meter "Month 6: 30"'
  - text: 30 Hul
  - 'meter "Month 7: 49.6"'
  - text: 49.6 Ago
  - 'meter "Month 8: 95.3"'
  - text: 95.3 Set
  - 'meter "Month 9: 122.1"'
  - text: 122.1 Okt
  - 'meter "Month 10: 92.8"'
  - text: 92.8 Nob
  - 'meter "Month 11: 72.1"'
  - text: 72.1 Dis
  - 'meter "Month 12: 49.8"'
  - text: "49.8"
  - 'heading "Pagtataya laban sa aktuwal: 2023" [level=3]'
  - img "Saved one-week persistence predictions versus actual held-out cases"
  - paragraph: "Buong linya: aktuwal na tala. Putol-putol: isang linggong persistence. Nauuna ang simula sa target."
  - group: Talahanayan ng backtest
  - paragraph: "Source: data/processed/evaluation.json ? public/api/v2/dashboard.json."
  - heading "Gaano katumpak ito?" [level=2]
  - paragraph: M (kumpletong araw lamang) ang simula ng tsart. Ipinapalagay ng Z na sero ang nawawalang araw sa saklaw ng datos. Sinusuri ang pareho. Halaga noong nakaraang linggo ang isang linggong pagtataya. Hindi napabuti ng weather ang paunang itinakdang paghahambing. Pananaliksik lamang ang dalawa hanggang apat na linggong ridge at malawak ang kawalan ng katiyakan; hindi babala ng outbreak.
  - paragraph: Mean absolute error (MAE) is the average error in weekly case counts, from the saved 2018–2023 held-out evaluation. It does not establish accuracy for current conditions.
  - region "Forecast accuracy from saved evaluation":
    - table:
      - rowgroup:
        - row "Modelo Linggo sa hinaharap MAE (kaso) Sinuring target":
          - columnheader "Modelo"
          - columnheader "Linggo sa hinaharap"
          - columnheader "MAE (kaso)"
          - columnheader "Sinuring target"
      - rowgroup:
        - row "naive 1 15.47 116":
          - rowheader "naive"
          - cell "1"
          - cell "15.47"
          - cell "116"
        - row "ridge-cases 1 16.36 116":
          - rowheader "ridge-cases"
          - cell "1"
          - cell "16.36"
          - cell "116"
        - row "ridge-weather 1 18.39 116":
          - rowheader "ridge-weather"
          - cell "1"
          - cell "18.39"
          - cell "116"
        - row "naive 2 22.90 117":
          - rowheader "naive"
          - cell "2"
          - cell "22.90"
          - cell "117"
        - row "ridge-cases 2 22.17 117":
          - rowheader "ridge-cases"
          - cell "2"
          - cell "22.17"
          - cell "117"
        - row "ridge-weather 2 23.17 117":
          - rowheader "ridge-weather"
          - cell "2"
          - cell "23.17"
          - cell "117"
        - row "naive 4 31.63 112":
          - rowheader "naive"
          - cell "4"
          - cell "31.63"
          - cell "112"
        - row "ridge-cases 4 27.43 112":
          - rowheader "ridge-cases"
          - cell "4"
          - cell "27.43"
          - cell "112"
        - row "ridge-weather 4 28.42 112":
          - rowheader "ridge-weather"
          - cell "4"
          - cell "28.42"
          - cell "112"
  - region "Alamin kung kailan magpatingin":
    - paragraph: MAG-INGAT / KUMILOS NANG MAAGA
    - heading "Alamin kung kailan magpatingin" [level=2]
    - paragraph: Magpatingin agad kung may matinding sakit ng tiyan, tuloy-tuloy na pagsusuka, pagdurugo, hirap huminga, labis na antok o panghihina. Huwag hintayin ang pagsusuri ng ulat.
    - 'link "Sanggunian: CDC, mga babala ng dengue"':
      - /url: https://www.cdc.gov/dengue/hcp/clinical-care/
    - heading "Gawing ugali ang DOH 4S" [level=3]
    - list:
      - listitem: "Hanapin at alisin ang pamugaran ng lamok: itapon ang naiipong tubig at linisin ang lalagyan."
      - listitem: "Protektahan ang sarili: gamitin ang panlaban sa lamok ayon sa tagubilin at magsuot ng pantakip na damit."
      - listitem: Magpakonsulta nang maaga kung may lagnat o sintomas ng dengue.
      - listitem: Suportahan ang pag-spray ng awtoridad sa mga natukoy na hotspot o lugar ng outbreak.
    - 'link "Sanggunian: Ministry of Health, 4S"':
      - /url: https://bangsamoro.gov.ph/news/latest-news/moh-urges-public-to-observe-4s-strategy-against-dengue/
    - paragraph:
      - strong: Impormasyon lamang, hindi pagsusuri ng sakit. Hindi opisyal na produkto ng DOH.
- contentinfo:
  - link "Tungkol at mga Pagkilala":
    - /url: /about
  - button "Tungkol sa datos at pamamaraan"
  - paragraph:
    - text: Saklaw ng nakapaketeng datos.
    - time: Dec 2, 2023
    - text: "?"
    - time: Jan 10, 2021
    - text: . Makasaysayan, hindi live.
  - paragraph: Background photograph by Sumarie Slabber
  - paragraph: Pananaliksik sa tesis ? Hindi opisyal na produkto ng DOH ? Lumang tala, hindi live na babala.
- status
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | import AxeBuilder from "@axe-core/playwright";
  3   | import { mkdir } from "node:fs/promises";
  4   | test("research pages: mobile/desktop, no overflow, no critical or serious axe issues", async ({
  5   |   page,
  6   | }) => {
  7   |   test.setTimeout(180000);
  8   |   const errors: string[] = [];
  9   |   page.on("pageerror", (e) => errors.push(e.message));
  10  |   for (const width of [360, 768, 1280])
  11  |     for (const route of [
  12  |       "/",
  13  |       "/trends",
  14  |       "/metro-manila",
  15  |       "/methodology",
  16  |       "/prevention",
  17  |     ]) {
  18  |       await page.setViewportSize({ width, height: 900 });
  19  |       await page.goto(route);
  20  |       await expect(page.locator("h1")).toBeVisible();
  21  |       if (route === "/")
  22  |         await expect(
  23  |           page.getByRole("heading", { name: "Current risk unavailable" }),
  24  |         ).toBeVisible();
  25  |       if (route === "/metro-manila")
  26  |         await expect(page.locator(".ncr-city-map path")).toHaveCount(17);
  27  |       if (route === "/methodology")
  28  |         await expect(
  29  |           page.getByRole("heading", { name: "Forecast comparison" }),
  30  |         ).toBeVisible();
  31  |       expect(
  32  |         await page.evaluate(
  33  |           () => document.documentElement.scrollWidth <= window.innerWidth,
  34  |         ),
  35  |       ).toBe(true);
  36  |       const a = await new AxeBuilder({ page }).analyze();
  37  |       expect(
  38  |         a.violations.filter((v) =>
  39  |           ["critical", "serious"].includes(v.impact ?? ""),
  40  |         ),
  41  |         JSON.stringify(a.violations),
  42  |       ).toEqual([]);
  43  |     }
  44  |   expect(errors).toEqual([]);
  45  |   await mkdir(".artifacts/evidence-ui", { recursive: true });
  46  |   await page.goto("/");
  47  |   await expect(
  48  |     page.getByRole("heading", { name: "Current risk unavailable" }),
  49  |   ).toBeVisible();
  50  |   await page.evaluate(() => document.fonts.ready);
  51  |   await page.screenshot({
  52  |     path: ".artifacts/evidence-ui/home-1280.png",
  53  |     fullPage: true,
  54  |   });
  55  |   await page.setViewportSize({ width: 360, height: 900 });
  56  |   await page.screenshot({
  57  |     path: ".artifacts/evidence-ui/home-360.png",
  58  |     fullPage: true,
  59  |   });
  60  | });
  61  | test("scenario and year changes keep absence explicit; NCR remains historical", async ({
  62  |   page,
  63  | }) => {
  64  |   await page.goto("/trends");
  65  |   await expect(
  66  |     page.getByRole("heading", { name: "Weekly recorded cases" }),
  67  |   ).toBeVisible();
  68  |   await page.getByLabel("Absent-day scenario").selectOption("Z");
  69  |   await expect(
  70  |     page.getByText("Zero is assumed only", { exact: false }),
  71  |   ).toBeVisible();
  72  |   await page.getByLabel("History year").selectOption("2020");
  73  |   await page.getByText("Exact weekly values and quality flags").click();
  74  |   await expect(
  75  |     page.getByRole("region", { name: "Weekly history data table" }),
  76  |   ).toBeVisible();
  77  |   await page.goto("/metro-manila");
  78  |   await expect(
  79  |     page.getByText("Data ends January 2021.", { exact: true }),
  80  |   ).toBeVisible();
  81  |   await page.getByLabel("Comparison period").selectOption("week");
  82  |   await page.getByLabel("Week label").selectOption("2016-11-06");
  83  |   await expect(page.locator(".ncr-city-map path")).toHaveCount(17);
  84  | });
  85  | test("Filipino home/prevention, missing API retry, and legacy forecasts isolated", async ({
  86  |   page,
  87  | }) => {
  88  |   await page.goto("/");
  89  |   await page.getByRole("button", { name: "Filipino", exact: true }).click();
  90  |   await expect(
  91  |     page.getByRole("heading", { name: "Kulang ang kasalukuyang datos" }),
> 92  |   ).toBeVisible();
      |     ^ Error: expect(locator).toBeVisible() failed
  93  |   await page.goto("/prevention");
  94  |   await expect(page.getByRole("heading", { name: "4S ng DOH" })).toBeVisible();
  95  |   await page.goto("/city/old-id");
  96  |   await expect(page).toHaveURL(/\/trends$/);
  97  |   let failedRequests = 0;
  98  |   await page.route("**/api/v2/manila.json", (route) => {
  99  |     failedRequests++;
  100 |     return route.fulfill({ status: 503, body: "Unavailable" });
  101 |   });
  102 |   await page.goto("/");
  103 |   await expect(page.getByRole("alert")).toContainText("could not load");
  104 |   expect(failedRequests).toBeGreaterThan(0);
  105 |   await expect(page.getByRole("button", { name: "Try again" })).toBeVisible();
  106 |   await page.unroute("**/api/v2/manila.json");
  107 |   await page.getByRole("button", { name: "Try again" }).click();
  108 |   await expect(
  109 |     page.getByRole("heading", { name: "Kulang ang kasalukuyang datos" }),
  110 |   ).toBeVisible();
  111 | });
  112 | 
```