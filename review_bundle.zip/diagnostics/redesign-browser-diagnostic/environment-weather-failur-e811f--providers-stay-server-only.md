# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: environment.spec.ts >> weather failure leaves historical persistence usable and providers stay server-only
- Location: tests\ui\environment.spec.ts:3:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Historical Manila forecast' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: 'Historical Manila forecast' }) with timeout 5000ms
  - waiting for getByRole('heading', { name: 'Historical Manila forecast' })

```

```yaml
- link "Skip to content":
  - /url: "#main"
- banner:
  - link "DengueWatch home":
    - /url: /
    - text: DENGUE WATCH
  - navigation "Main navigation":
    - link "Dashboard":
      - /url: /
    - link "Risk Map":
      - /url: /risk-map
    - link "Community Report":
      - /url: /report
  - button "English" [pressed]
  - button "Filipino"
- main:
  - region "DENGUE WATCH MANILA":
    - text: THESIS PROJECT DATA AS OF 2023-12-02
    - paragraph: Understand the patterns. Take care of each other.
    - heading "DENGUE WATCH MANILA" [level=1]
    - link "View Risk Map":
      - /url: /risk-map
    - link "Report a Case":
      - /url: /report
    - paragraph: Historical evidence. Everyday awareness. No live case surveillance.
  - complementary: Manila case data ends 2023-12-02. Province/city case data ends 2021-01-10. Neither is live.
  - paragraph: THE QUESTION BEHIND THE THESIS
  - heading "Can better awareness begin with honest data?" [level=2]
  - paragraph: Dengue is a mosquito-borne illness. This thesis asks whether historical cases and environmental context can support earlier awareness without overstating what the data can predict.
  - paragraph: "We compare forecasts with a simple last-week baseline, make missing observations visible, and keep unverified community reports separate from official records. Objectives: describe patterns, test predictive skill, and provide a privacy-conscious awareness channel."
  - status: Checking reporting status…
  - text: Absent-day scenario
  - combobox "Absent-day scenario":
    - option "M · absent dates remain missing" [selected]
    - option "Z · absent dates assumed zero"
  - paragraph: Only weeks with seven daily rows are scored. An absent date is not a recorded zero. The final partial week is excluded in both scenarios.
  - paragraph: MANILA / HISTORICAL CASE FORECAST
  - heading "Current risk unavailable" [level=2]
  - paragraph: The case record is too old to establish current risk. This is the only case-forecast panel; the national map is a relative outlook.
  - paragraph:
    - text: Data as of
    - time: 2023-12-02
    - text: "? Forecast origin 2023-11-26 ? Scenario M"
  - article:
    - heading "1 week(s) ahead" [level=3]
    - paragraph: 62 estimated cases
    - paragraph: "Historical target: 2023-12-03"
    - paragraph: "80% interval: 40?84"
  - article:
    - heading "2 week(s) ahead" [level=3]
    - paragraph: 62 estimated cases
    - paragraph: "Historical target: 2023-12-10"
    - paragraph: "80% interval: 31?93"
  - paragraph: One-week persistence means last week's value. These are retrospective estimates, not a warning for the coming days.
  - paragraph: Remove standing water, protect against bites and seek early consultation for symptoms.
  - 'heading "Seasonal watch: context only" [level=2]'
  - paragraph: PAGASA defines June to November as the rainy season. Clear containers of standing water and keep up bite prevention. This is seasonal context, not a dengue prediction or alert.
  - paragraph: Dengue observations remain historical; current weather cannot establish today's dengue risk.
  - paragraph: In complete-row history for 2016-2023 (Scenario M), mean weekly cases ranged from 22.8 in May to 122.1 in September. This does not measure a delay from rainfall onset to rising cases.
  - status: Weather data unavailable; showing baseline forecast.
  - link "PAGASA season definition":
    - /url: https://www.pagasa.dost.gov.ph/information/climate-philippines
  - paragraph: ANALYTICS / RECORDED EVIDENCE
  - heading "The story in the weekly record" [level=2]
  - heading "Manila weekly cases, with source boundaries" [level=3]
  - figure "Scrollable Manila history chart":
    - img "Manila weekly case history 312 observed or scenario-defined weeks. Peak 257 cases. Gaps break the line. Shading marks the COVID period. Exact data appears in the table below.": 0 64 129 193 257 COVID period 2016-01-10 2023-12-03 Weekly cases · gaps remain gaps Source changes
    - text: DOH EPI before 2018; Manila daily-derived weeks from 2018. COVID period shaded (2020–2021). Source dates end 2023-12-02; final partial week excluded. Sunday labels operationally interpreted as week-ending; source semantics unconfirmed.
  - group: Exact weekly values and quality flags
  - heading "Year comparison" [level=3]
  - paragraph: Available weeks only; incomplete years are not annual totals.
  - region "Year comparison":
    - table:
      - rowgroup:
        - row "Year Recorded cases Weeks":
          - columnheader "Year"
          - columnheader "Recorded cases"
          - columnheader "Weeks"
      - rowgroup:
        - row "2016 1,990 ? incomplete 45 / 51":
          - rowheader "2016"
          - cell "1,990 ? incomplete"
          - cell "45 / 51"
        - row "2017 2,813 53 / 53":
          - rowheader "2017"
          - cell "2,813"
          - cell "53 / 53"
        - row "2018 3,530 ? incomplete 47 / 52":
          - rowheader "2018"
          - cell "3,530 ? incomplete"
          - cell "47 / 52"
        - row "2019 3,761 ? incomplete 43 / 52":
          - rowheader "2019"
          - cell "3,761 ? incomplete"
          - cell "43 / 52"
        - row "2020 451 ? incomplete 13 / 52":
          - rowheader "2020"
          - cell "451 ? incomplete"
          - cell "13 / 52"
        - row "2021 883 ? incomplete 24 / 52":
          - rowheader "2021"
          - cell "883 ? incomplete"
          - cell "24 / 52"
        - row "2022 2,516 ? incomplete 42 / 52":
          - rowheader "2022"
          - cell "2,516 ? incomplete"
          - cell "42 / 52"
        - row "2023 2,346 ? incomplete 45 / 49":
          - rowheader "2023"
          - cell "2,346 ? incomplete"
          - cell "45 / 49"
  - heading "Seasonal profile" [level=3]
  - paragraph: Mean weekly cases by month of week ending; observed/scenario-defined weeks only, not monthly totals.
  - text: Jan
  - 'meter "Month 1: 53.8"'
  - text: 53.8 Feb
  - 'meter "Month 2: 43.7"'
  - text: 43.7 Mar
  - 'meter "Month 3: 29.4"'
  - text: 29.4 Apr
  - 'meter "Month 4: 27.2"'
  - text: 27.2 May
  - 'meter "Month 5: 22.8"'
  - text: 22.8 Jun
  - 'meter "Month 6: 30"'
  - text: 30 Jul
  - 'meter "Month 7: 49.6"'
  - text: 49.6 Aug
  - 'meter "Month 8: 95.3"'
  - text: 95.3 Sep
  - 'meter "Month 9: 122.1"'
  - text: 122.1 Oct
  - 'meter "Month 10: 92.8"'
  - text: 92.8 Nov
  - 'meter "Month 11: 72.1"'
  - text: 72.1 Dec
  - 'meter "Month 12: 49.8"'
  - text: "49.8"
  - 'heading "Forecast versus actual: held-out 2023" [level=3]'
  - img "Saved one-week persistence predictions versus actual held-out cases"
  - paragraph: "Solid: recorded values. Dashed: one-week persistence. Each origin precedes its target."
  - group: Backtest data table
  - paragraph: "Source: data/processed/evaluation.json ? public/api/v2/dashboard.json."
  - heading "How accurate is this?" [level=2]
  - paragraph: The public chart starts with Scenario M (only complete daily-row weeks). Scenario Z assumes absent dates are zero within coverage. Both are evaluated. The one-week public forecast is last week's value. Weather did not improve the predeclared one/two-week comparison. Two- to four-week ridge improvements are exploratory with wide uncertainty, not a validated operational warning.
  - paragraph: Mean absolute error (MAE) is the average error in weekly case counts, from the saved 2018–2023 held-out evaluation. It does not establish accuracy for current conditions.
  - region "Forecast accuracy from saved evaluation":
    - table:
      - rowgroup:
        - row "Model Weeks ahead MAE (cases) Evaluated targets":
          - columnheader "Model"
          - columnheader "Weeks ahead"
          - columnheader "MAE (cases)"
          - columnheader "Evaluated targets"
      - rowgroup:
        - row "naive 1 15.47 116":
          - rowheader "naive"
          - cell "1"
          - cell "15.47"
          - cell "116"
        - row "ridge-cases 1 16.36 116":
          - rowheader "ridge-cases"
          - cell "1"
          - cell "16.36"
          - cell "116"
        - row "ridge-weather 1 18.39 116":
          - rowheader "ridge-weather"
          - cell "1"
          - cell "18.39"
          - cell "116"
        - row "naive 2 22.90 117":
          - rowheader "naive"
          - cell "2"
          - cell "22.90"
          - cell "117"
        - row "ridge-cases 2 22.17 117":
          - rowheader "ridge-cases"
          - cell "2"
          - cell "22.17"
          - cell "117"
        - row "ridge-weather 2 23.17 117":
          - rowheader "ridge-weather"
          - cell "2"
          - cell "23.17"
          - cell "117"
        - row "naive 4 31.63 112":
          - rowheader "naive"
          - cell "4"
          - cell "31.63"
          - cell "112"
        - row "ridge-cases 4 27.43 112":
          - rowheader "ridge-cases"
          - cell "4"
          - cell "27.43"
          - cell "112"
        - row "ridge-weather 4 28.42 112":
          - rowheader "ridge-weather"
          - cell "4"
          - cell "28.42"
          - cell "112"
  - region "Know when to seek care":
    - paragraph: TAKE CARE / ACT EARLY
    - heading "Know when to seek care" [level=2]
    - paragraph: Seek urgent medical care for severe abdominal pain, persistent vomiting, bleeding, difficulty breathing, unusual drowsiness or extreme weakness. Do not wait for a report review.
    - 'link "Source: CDC dengue warning signs"':
      - /url: https://www.cdc.gov/dengue/hcp/clinical-care/
    - heading "Make the DOH 4S a habit" [level=3]
    - list:
      - listitem: "Search and destroy mosquito breeding places: empty and clean standing-water containers."
      - listitem: "Self-protection: use repellent as directed and wear protective clothing."
      - listitem: Seek early consultation for fever or dengue-like symptoms.
      - listitem: Support health-authority fogging or spraying in identified hotspot/outbreak areas.
    - 'link "Source: Ministry of Health 4S guidance"':
      - /url: https://bangsamoro.gov.ph/news/latest-news/moh-urges-public-to-observe-4s-strategy-against-dengue/
    - paragraph:
      - strong: Informational, not a diagnosis. Not an official DOH product.
- contentinfo:
  - link "About & Credits":
    - /url: /about
  - button "About the data & methods"
  - paragraph:
    - text: Bundled source periods.
    - time: Dec 2, 2023
    - text: "?"
    - time: Jan 10, 2021
    - text: . Historical, not live.
  - paragraph: Background photograph by Sumarie Slabber
  - paragraph: Thesis research ? Not an official DOH product ? Historical records, not a live warning.
- status
```

# Test source

```ts
  1   | ﻿import { test, expect } from "@playwright/test";
  2   | import AxeBuilder from "@axe-core/playwright";
  3   | test("weather failure leaves historical persistence usable and providers stay server-only", async ({
  4   |   page,
  5   | }) => {
  6   |   const providerCalls: string[] = [];
  7   |   page.on("request", (r) => {
  8   |     if (
  9   |       /archive-api\.open-meteo|power\.larc|overpass|opentopodata/.test(r.url())
  10  |     )
  11  |       providerCalls.push(r.url());
  12  |   });
  13  |   await page.route("**/api/v2/weather.json", (route) =>
  14  |     route.fulfill({ status: 503, body: "unavailable" }),
  15  |   );
  16  |   await page.goto("/");
  17  |   await expect(
  18  |     page.getByRole("heading", { name: "Current risk unavailable" }),
  19  |   ).toBeVisible();
  20  |   await expect(
  21  |     page.getByText("Weather data unavailable; showing baseline forecast.", {
  22  |       exact: true,
  23  |     }),
  24  |   ).toBeVisible();
  25  |   await expect(page.getByText(/In complete-row history/)).toContainText(
  26  |     "122.1",
  27  |   );
  28  |   await expect(
  29  |     page.getByRole("heading", { name: "Historical Manila forecast" }),
> 30  |   ).toBeVisible();
      |     ^ Error: expect(locator).toBeVisible() failed
  31  |   const data = await (await page.request.get("/api/v2/manila.json")).json();
  32  |   expect(data.snapshots.every((s: any) => s.model === "naive")).toBe(true);
  33  |   await page.getByRole("button", { name: "Filipino", exact: true }).click();
  34  |   await expect(
  35  |     page.getByRole("heading", { name: "Bantay-panahon: konteksto lamang" }),
  36  |   ).toBeVisible();
  37  |   await expect(
  38  |     page.getByText(
  39  |       "Hindi makuha ang datos ng panahon; batayang pagtataya ang ipinapakita.",
  40  |       { exact: true },
  41  |     ),
  42  |   ).toBeVisible();
  43  |   expect(providerCalls).toEqual([]);
  44  | });
  45  | test("environment ablation and exploratory city context remain accessible at 360px", async ({
  46  |   page,
  47  | }) => {
  48  |   test.setTimeout(120000);
  49  |   await page.setViewportSize({ width: 360, height: 900 });
  50  |   await page.goto("/methodology");
  51  |   const table = page.getByRole("region", {
  52  |     name: "Season and weather ablation metrics",
  53  |   });
  54  |   await expect(table).toBeVisible();
  55  |   await expect(table.getByRole("row")).toHaveCount(7);
  56  |   await page
  57  |     .getByLabel("Environmental scenario", { exact: true })
  58  |     .selectOption("Z");
  59  |   await page
  60  |     .getByLabel("Environmental fold", { exact: true })
  61  |     .selectOption("2023");
  62  |   await page
  63  |     .getByLabel("Environmental horizon", { exact: true })
  64  |     .selectOption("2");
  65  |   await expect(
  66  |     table.getByRole("rowheader", { name: "env-season", exact: true }),
  67  |   ).toBeVisible();
  68  |   await expect(page.getByText(/469 paired weeks/)).toBeVisible();
  69  |   await page.goto("/metro-manila");
  70  |   await page
  71  |     .getByRole("button", { name: "Show exploratory city context" })
  72  |     .click();
  73  |   const values = page.getByRole("region", {
  74  |     name: "City geographic context values",
  75  |   });
  76  |   await expect(values.getByRole("row")).toHaveCount(18);
  77  |   await expect(
  78  |     page
  79  |       .getByRole("region", { name: "Exploratory geographic effect sizes" })
  80  |       .getByRole("row"),
  81  |   ).toHaveCount(7);
  82  |   const axe = await new AxeBuilder({ page })
  83  |     .withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"])
  84  |     .analyze();
  85  |   expect(
  86  |     axe.violations.filter((v) =>
  87  |       ["critical", "serious"].includes(v.impact ?? ""),
  88  |     ),
  89  |   ).toEqual([]);
  90  |   expect(
  91  |     await page.evaluate(
  92  |       () => document.documentElement.scrollWidth <= innerWidth + 1,
  93  |     ),
  94  |   ).toBe(true);
  95  |   await page.goto("/data-sources");
  96  |   await expect(
  97  |     page.getByRole("heading", {
  98  |       name: "Environmental and geographic providers",
  99  |     }),
  100 |   ).toBeVisible();
  101 |   await expect(
  102 |     page.getByText(/This data was obtained from the NASA Langley/),
  103 |   ).toBeVisible();
  104 | });
  105 | 
```