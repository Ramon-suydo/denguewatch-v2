# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: public-app.spec.ts >> loading resolves to an explicit empty snapshot without fabricated values
- Location: tests\ui\public-app.spec.ts:196:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'No historical research snapshot available' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: 'No historical research snapshot available' }) with timeout 5000ms
  - waiting for getByRole('heading', { name: 'No historical research snapshot available' })

```

```yaml
- link "Skip to content":
  - /url: "#main"
- banner:
  - link "DengueWatch home":
    - /url: /
    - text: DENGUE WATCH
  - navigation "Main navigation":
    - link "Dashboard":
      - /url: /
    - link "Risk Map":
      - /url: /risk-map
    - link "Community Report":
      - /url: /report
  - button "English" [pressed]
  - button "Filipino"
- main:
  - region "DENGUE WATCH MANILA":
    - text: THESIS PROJECT DATA AS OF 2023-12-02
    - paragraph: Understand the patterns. Take care of each other.
    - heading "DENGUE WATCH MANILA" [level=1]
    - link "View Risk Map":
      - /url: /risk-map
    - link "Report a Case":
      - /url: /report
    - paragraph: Historical evidence. Everyday awareness. No live case surveillance.
  - complementary: Manila case data ends 2023-12-02. Province/city case data ends 2021-01-10. Neither is live.
  - paragraph: THE QUESTION BEHIND THE THESIS
  - heading "Can better awareness begin with honest data?" [level=2]
  - paragraph: Dengue is a mosquito-borne illness. This thesis asks whether historical cases and environmental context can support earlier awareness without overstating what the data can predict.
  - paragraph: "We compare forecasts with a simple last-week baseline, make missing observations visible, and keep unverified community reports separate from official records. Objectives: describe patterns, test predictive skill, and provide a privacy-conscious awareness channel."
  - status: Checking reporting status…
  - text: Absent-day scenario
  - combobox "Absent-day scenario":
    - option "M · absent dates remain missing" [selected]
    - option "Z · absent dates assumed zero"
  - paragraph: Only weeks with seven daily rows are scored. An absent date is not a recorded zero. The final partial week is excluded in both scenarios.
  - heading "Manila forecast unavailable" [level=2]
  - 'heading "Seasonal watch: context only" [level=2]'
  - paragraph: PAGASA defines June to November as the rainy season. Clear containers of standing water and keep up bite prevention. This is seasonal context, not a dengue prediction or alert.
  - paragraph: Dengue observations remain historical; current weather cannot establish today's dengue risk.
  - paragraph: In complete-row history for 2016-2023 (Scenario M), mean weekly cases ranged from 22.8 in May to 122.1 in September. This does not measure a delay from rainfall onset to rising cases.
  - status: "Weather is seasonal context only; showing baseline forecast. Dengue observations remain historical. Weather as of: 2026-10-11."
  - link "PAGASA season definition":
    - /url: https://www.pagasa.dost.gov.ph/information/climate-philippines
  - paragraph: ANALYTICS / RECORDED EVIDENCE
  - heading "The story in the weekly record" [level=2]
  - heading "Manila weekly cases, with source boundaries" [level=3]
  - paragraph: No reliable weeks in this selection.
  - group: Exact weekly values and quality flags
  - heading "Year comparison" [level=3]
  - paragraph: Available weeks only; incomplete years are not annual totals.
  - region "Year comparison":
    - table:
      - rowgroup:
        - row "Year Recorded cases Weeks":
          - columnheader "Year"
          - columnheader "Recorded cases"
          - columnheader "Weeks"
      - rowgroup
  - heading "Seasonal profile" [level=3]
  - paragraph: Mean weekly cases by month of week ending; observed/scenario-defined weeks only, not monthly totals.
  - text: Jan
  - 'meter "Month 1: Unavailable"'
  - text: Unavailable Feb
  - 'meter "Month 2: Unavailable"'
  - text: Unavailable Mar
  - 'meter "Month 3: Unavailable"'
  - text: Unavailable Apr
  - 'meter "Month 4: Unavailable"'
  - text: Unavailable May
  - 'meter "Month 5: Unavailable"'
  - text: Unavailable Jun
  - 'meter "Month 6: Unavailable"'
  - text: Unavailable Jul
  - 'meter "Month 7: Unavailable"'
  - text: Unavailable Aug
  - 'meter "Month 8: Unavailable"'
  - text: Unavailable Sep
  - 'meter "Month 9: Unavailable"'
  - text: Unavailable Oct
  - 'meter "Month 10: Unavailable"'
  - text: Unavailable Nov
  - 'meter "Month 11: Unavailable"'
  - text: Unavailable Dec
  - 'meter "Month 12: Unavailable"'
  - text: Unavailable
  - 'heading "Forecast versus actual: held-out 2023" [level=3]'
  - img "Saved one-week persistence predictions versus actual held-out cases"
  - paragraph: "Solid: recorded values. Dashed: one-week persistence. Each origin precedes its target."
  - group: Backtest data table
  - paragraph: "Source: data/processed/evaluation.json ? public/api/v2/dashboard.json."
  - heading "How accurate is this?" [level=2]
  - paragraph: The public chart starts with Scenario M (only complete daily-row weeks). Scenario Z assumes absent dates are zero within coverage. Both are evaluated. The one-week public forecast is last week's value. Weather did not improve the predeclared one/two-week comparison. Two- to four-week ridge improvements are exploratory with wide uncertainty, not a validated operational warning.
  - paragraph: Mean absolute error (MAE) is the average error in weekly case counts, from the saved 2018–2023 held-out evaluation. It does not establish accuracy for current conditions.
  - region "Forecast accuracy from saved evaluation":
    - table:
      - rowgroup:
        - row "Model Weeks ahead MAE (cases) Evaluated targets":
          - columnheader "Model"
          - columnheader "Weeks ahead"
          - columnheader "MAE (cases)"
          - columnheader "Evaluated targets"
      - rowgroup:
        - row "naive 1 15.47 116":
          - rowheader "naive"
          - cell "1"
          - cell "15.47"
          - cell "116"
        - row "ridge-cases 1 16.36 116":
          - rowheader "ridge-cases"
          - cell "1"
          - cell "16.36"
          - cell "116"
        - row "ridge-weather 1 18.39 116":
          - rowheader "ridge-weather"
          - cell "1"
          - cell "18.39"
          - cell "116"
        - row "naive 2 22.90 117":
          - rowheader "naive"
          - cell "2"
          - cell "22.90"
          - cell "117"
        - row "ridge-cases 2 22.17 117":
          - rowheader "ridge-cases"
          - cell "2"
          - cell "22.17"
          - cell "117"
        - row "ridge-weather 2 23.17 117":
          - rowheader "ridge-weather"
          - cell "2"
          - cell "23.17"
          - cell "117"
        - row "naive 4 31.63 112":
          - rowheader "naive"
          - cell "4"
          - cell "31.63"
          - cell "112"
        - row "ridge-cases 4 27.43 112":
          - rowheader "ridge-cases"
          - cell "4"
          - cell "27.43"
          - cell "112"
        - row "ridge-weather 4 28.42 112":
          - rowheader "ridge-weather"
          - cell "4"
          - cell "28.42"
          - cell "112"
  - region "Know when to seek care":
    - paragraph: TAKE CARE / ACT EARLY
    - heading "Know when to seek care" [level=2]
    - paragraph: Seek urgent medical care for severe abdominal pain, persistent vomiting, bleeding, difficulty breathing, unusual drowsiness or extreme weakness. Do not wait for a report review.
    - 'link "Source: CDC dengue warning signs"':
      - /url: https://www.cdc.gov/dengue/hcp/clinical-care/
    - heading "Make the DOH 4S a habit" [level=3]
    - list:
      - listitem: "Search and destroy mosquito breeding places: empty and clean standing-water containers."
      - listitem: "Self-protection: use repellent as directed and wear protective clothing."
      - listitem: Seek early consultation for fever or dengue-like symptoms.
      - listitem: Support health-authority fogging or spraying in identified hotspot/outbreak areas.
    - 'link "Source: Ministry of Health 4S guidance"':
      - /url: https://bangsamoro.gov.ph/news/latest-news/moh-urges-public-to-observe-4s-strategy-against-dengue/
    - paragraph:
      - strong: Informational, not a diagnosis. Not an official DOH product.
- contentinfo:
  - link "About & Credits":
    - /url: /about
  - button "About the data & methods"
  - paragraph:
    - text: Bundled source periods.
    - time: Dec 2, 2023
    - text: "?"
    - time: Jan 10, 2021
    - text: . Historical, not live.
  - paragraph: Background photograph by Sumarie Slabber
  - paragraph: Thesis research ? Not an official DOH product ? Historical records, not a live warning.
- status
```

# Test source

```ts
  120 |   await page.getByLabel("Comparison period").selectOption("week");
  121 |   await page.getByLabel("Week label").selectOption("2016-11-13");
  122 |   await expect(page.locator(".ncr-city-map path")).toHaveCount(17);
  123 |   await expect(
  124 |     page.getByRole("region", { name: "Historical NCR city ranking" }),
  125 |   ).toContainText("Unavailable");
  126 |   await expect(
  127 |     page.getByText("Data ends January 2021.", { exact: true }),
  128 |   ).toBeVisible();
  129 |   await expect(
  130 |     page.getByText("No district or barangay case counts are inferred.", {
  131 |       exact: false,
  132 |     }),
  133 |   ).toBeVisible();
  134 |   expect(await page.locator(".barangay-svg").count()).toBe(0);
  135 | });
  136 | test("public routes retain disclaimers and legal access on phones", async ({
  137 |   page,
  138 | }) => {
  139 |   test.setTimeout(120000);
  140 |   await mockPublicApi(page, { open: false });
  141 |   for (const width of [320, 390, 768])
  142 |     for (const route of [
  143 |       "/",
  144 |       "/trends",
  145 |       "/map",
  146 |       "/report",
  147 |       "/privacy",
  148 |       "/terms",
  149 |       "/data-sources",
  150 |       "/dev",
  151 |       "/not-found",
  152 |     ]) {
  153 |       await page.setViewportSize({ width, height: 844 });
  154 |       await page.goto(route);
  155 |       await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
  156 |       await expect(
  157 |         page.getByRole("complementary", { name: "Estimates, not alerts" }),
  158 |       ).toHaveCount(1);
  159 |       await expect(page.getByRole("contentinfo")).toContainText("Dec 2, 2023");
  160 |       expect(
  161 |         await page.evaluate(
  162 |           () => document.documentElement.scrollWidth <= innerWidth,
  163 |         ),
  164 |       ).toBe(true);
  165 |     }
  166 | });
  167 | test("publishable community aggregates remain delayed, unverified and separate", async ({
  168 |   page,
  169 | }) => {
  170 |   await mockPublicApi(page, { open: false });
  171 |   await page.route("**/rest/v1/rpc/community_signal_aggregates**", (r) =>
  172 |     r.fulfill({
  173 |       status: 200,
  174 |       contentType: "application/json",
  175 |       body: JSON.stringify([
  176 |         {
  177 |           area_label: "Manila city (area not specified)",
  178 |           week_start: "2026-09-21",
  179 |           report_count: 7,
  180 |         },
  181 |       ]),
  182 |     }),
  183 |   );
  184 |   await page.goto("/community");
  185 |   const section = page.getByRole("region", {
  186 |     name: "Unverified community aggregates",
  187 |   });
  188 |   await expect(section).toContainText("7");
  189 |   await expect(
  190 |     page.getByText("minimum 72-hour delay", { exact: false }),
  191 |   ).toBeVisible();
  192 |   await expect(
  193 |     page.locator('[aria-label="Historical forecast table"]'),
  194 |   ).toHaveCount(0);
  195 | });
  196 | test("loading resolves to an explicit empty snapshot without fabricated values", async ({
  197 |   page,
  198 | }) => {
  199 |   let release!: () => void;
  200 |   const gate = new Promise<void>((r) => (release = r));
  201 |   await page.route("**/api/v2/manila.json", async (r) => {
  202 |     await gate;
  203 |     await r.fulfill({
  204 |       status: 200,
  205 |       contentType: "application/json",
  206 |       body: JSON.stringify({
  207 |         ...evidence,
  208 |         series: { M: [], Z: [] },
  209 |         snapshots: [],
  210 |       }),
  211 |     });
  212 |   });
  213 |   await page.goto("/");
  214 |   await expect(page.getByText("Loading data…", { exact: true })).toBeVisible();
  215 |   release();
  216 |   await expect(
  217 |     page.getByRole("heading", {
  218 |       name: "No historical research snapshot available",
  219 |     }),
> 220 |   ).toBeVisible();
      |     ^ Error: expect(locator).toBeVisible() failed
  221 | });
  222 | test("historical forecast exposes all horizons and explicit interval uncertainty", async ({
  223 |   page,
  224 | }) => {
  225 |   await page.goto("/trends");
  226 |   await expect(
  227 |     page.getByRole("heading", { name: "Historical forecast and interval" }),
  228 |   ).toBeVisible();
  229 |   const table = page.getByRole("region", { name: "Forecast intervals" });
  230 |   await expect(table.locator("tbody tr")).toHaveCount(3);
  231 |   await expect(table).toContainText("exploratory");
  232 |   await page.goto("/methodology");
  233 |   await page.getByLabel("Forecast horizon").selectOption("4");
  234 |   await page.getByLabel("Evaluation fold").selectOption("covid-2020-2021");
  235 |   await expect(
  236 |     page
  237 |       .getByRole("region", { name: "Model evaluation metrics" })
  238 |       .locator("tbody tr"),
  239 |   ).toHaveCount(11);
  240 |   await expect(
  241 |     page.getByText("Intervals can under-cover", { exact: false }),
  242 |   ).toBeVisible();
  243 | });
  244 | test("model numbers exactly match saved evidence across scenarios and horizons", async ({
  245 |   page,
  246 | }) => {
  247 |   await page.goto("/methodology");
  248 |   for (const scenario of ["M", "Z"])
  249 |     for (const horizon of [1, 2, 4]) {
  250 |       await page.getByLabel("Absent-day scenario").selectOption(scenario);
  251 |       await page.getByLabel("Forecast horizon").selectOption(String(horizon));
  252 |       const row = evidence.summaries.find(
  253 |         (r: any) =>
  254 |           r.scenario === scenario &&
  255 |           r.horizon === horizon &&
  256 |           r.fold === "test-2018-2023" &&
  257 |           r.model === "naive",
  258 |       );
  259 |       const visible = page
  260 |         .getByRole("region", { name: "Model evaluation metrics" })
  261 |         .locator("tbody tr")
  262 |         .filter({
  263 |           has: page.getByRole("rowheader", { name: "naive", exact: true }),
  264 |         });
  265 |       await expect(visible).toContainText(
  266 |         row.mae.toLocaleString("en-PH", { maximumFractionDigits: 3 }),
  267 |       );
  268 |       await expect(visible).toContainText(String(row.n));
  269 |     }
  270 | });
  271 | test("bundled footer dates never become a false live DB coverage claim", async ({
  272 |   page,
  273 | }) => {
  274 |   await mockPublicApi(page);
  275 |   await page.route("**/rest/v1/historical_surveillance**", (r) =>
  276 |     r.fulfill({
  277 |       status: 200,
  278 |       contentType: "application/json",
  279 |       body: JSON.stringify([{ period_start: "2031-01-01" }]),
  280 |     }),
  281 |   );
  282 |   await page.goto("/");
  283 |   const footer = page.getByRole("contentinfo");
  284 |   await expect(footer).toContainText("Dec 2, 2023");
  285 |   await expect(footer).toContainText("Jan 10, 2021");
  286 |   await expect(footer).not.toContainText("2031");
  287 |   await expect(
  288 |     page.getByText("Bundled source periods.", { exact: false }),
  289 |   ).toBeVisible();
  290 | });
  291 | 
```