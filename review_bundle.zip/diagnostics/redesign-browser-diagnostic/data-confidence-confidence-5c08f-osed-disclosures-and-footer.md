# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: data-confidence.spec.ts >> confidence leads with checked Manila work and retains closed disclosures and footer
- Location: tests\ui\data-confidence.spec.ts:5:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('contentinfo')
Expected substring: "Community reports are unverified"
Received string:    "About & CreditsAbout the data & methodsBundled source periods. Dec 2, 2023 ? Jan 10, 2021. Historical, not live.Background photograph by Sumarie SlabberThesis research ? Not an official DOH product ? Historical records, not a live warning."
Timeout: 5000ms

Call log:
  - Expect "toContainText" getByRole('contentinfo') with timeout 5000ms
  - waiting for getByRole('contentinfo')
    14 × locator resolved to <footer class="photo-footer">…</footer>
       - unexpected value "About & CreditsAbout the data & methodsBundled source periods. Dec 2, 2023 ? Jan 10, 2021. Historical, not live.Background photograph by Sumarie SlabberThesis research ? Not an official DOH product ? Historical records, not a live warning."

```

```yaml
- contentinfo:
  - link "About & Credits":
    - /url: /about
  - button "About the data & methods"
  - paragraph:
    - text: Bundled source periods.
    - time: Dec 2, 2023
    - text: "?"
    - time: Jan 10, 2021
    - text: . Historical, not live.
  - paragraph: Background photograph by Sumarie Slabber
  - paragraph: Thesis research ? Not an official DOH product ? Historical records, not a live warning.
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | import AxeBuilder from "@axe-core/playwright";
  3  | import {readFile} from "node:fs/promises";
  4  | const snapshot=JSON.parse(await readFile("public/demo-snapshot.json","utf8"));
  5  | test("confidence leads with checked Manila work and retains closed disclosures and footer",async({page})=>{
  6  |  await page.addInitScript(()=>Object.defineProperty(navigator,"onLine",{get:()=>false}));
  7  |  await page.goto("/data-sources");await expect(page.getByRole("heading",{name:"Data confidence",exact:true})).toBeVisible();
  8  |  const id=snapshot.cities.find((c:{name:string})=>c.name==="MANILA CITY").id;
  9  |  await expect(page.locator(".stat-value").first()).toHaveText(snapshot.history.filter((r:{lgu_id:string})=>r.lgu_id===id).length.toLocaleString("en-PH"));
  10 |  await expect(page.locator(".coverage-present").first()).not.toHaveCSS("background-color","rgba(0, 0, 0, 0)");
  11 |  const notes=page.locator("details.data-notes");await expect(notes).not.toHaveAttribute("open");
  12 |  await notes.locator("summary").click();for(const text of ["Historical, not live.","Missing is not zero.","Deaths excluded from forecasts.","Community reports are unverified.","Jan 10, 2021","Dec 2, 2023"])await expect(notes).toContainText(text);
  13 |  await expect(page.locator("main")).not.toContainText("QUEZON CITY");await expect(page.locator("main")).not.toContainText("Pateros");
> 14 |  await expect(page.getByRole("contentinfo")).toContainText("Community reports are unverified");await expect(page.getByRole("contentinfo")).toContainText("not medical advice");
     |                                              ^ Error: expect(locator).toContainText(expected) failed
  15 |  for(const width of [320,390,768,1280]){await page.setViewportSize({width,height:900});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);expect((await new AxeBuilder({page}).withTags(["wcag2a","wcag2aa","wcag21aa"]).analyze()).violations).toEqual([]);}
  16 | });
  17 | 
```