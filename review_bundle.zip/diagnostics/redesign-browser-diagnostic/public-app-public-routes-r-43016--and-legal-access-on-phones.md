# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: public-app.spec.ts >> public routes retain disclaimers and legal access on phones
- Location: tests\ui\public-app.spec.ts:136:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('complementary', { name: 'Estimates, not alerts' })
Expected: 1
Received: 0
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" getByRole('complementary', { name: 'Estimates, not alerts' }) with timeout 5000ms
  - waiting for getByRole('complementary', { name: 'Estimates, not alerts' })
    13 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - link "Skip to content" [ref=e5] [cursor=pointer]:
      - /url: "#main"
    - banner [ref=e6]:
      - link "DengueWatch home" [ref=e7] [cursor=pointer]:
        - /url: /
        - text: DENGUE
        - generic [ref=e8]: WATCH
      - button "Menu" [ref=e9] [cursor=pointer]
      - generic "Page language" [ref=e10]:
        - button "English" [pressed] [ref=e11] [cursor=pointer]
        - button "Filipino" [ref=e12] [cursor=pointer]
    - main [ref=e13]:
      - region [ref=e14]:
        - generic [ref=e17]:
          - generic [ref=e18]: THESIS PROJECT
          - generic [ref=e19]: DATA AS OF 2023-12-02
        - generic [ref=e20]:
          - paragraph [ref=e21]: Understand the patterns. Take care of each other.
          - heading "DENGUE WATCH MANILA" [level=1] [ref=e22]: DENGUE WATCHMANILA
          - generic [ref=e23]:
            - link "View Risk Map" [ref=e24] [cursor=pointer]:
              - /url: /risk-map
            - link "Report a Case" [ref=e25] [cursor=pointer]:
              - /url: /report
          - paragraph [ref=e26]: Historical evidence. Everyday awareness. No live case surveillance.
      - generic [ref=e27]:
        - complementary [ref=e28]: Manila case data ends 2023-12-02. Province/city case data ends 2021-01-10. Neither is live.
        - generic [ref=e29]:
          - generic [ref=e30]:
            - paragraph [ref=e31]: THE QUESTION BEHIND THE THESIS
            - heading "Can better awareness begin with honest data?" [level=2] [ref=e32]
          - generic [ref=e33]:
            - paragraph [ref=e34]: Dengue is a mosquito-borne illness. This thesis asks whether historical cases and environmental context can support earlier awareness without overstating what the data can predict.
            - paragraph [ref=e35]: "We compare forecasts with a simple last-week baseline, make missing observations visible, and keep unverified community reports separate from official records. Objectives: describe patterns, test predictive skill, and provide a privacy-conscious awareness channel."
            - status [ref=e36]: Community reporting is closed.
        - generic [ref=e37]:
          - generic [ref=e38]: Absent-day scenario
          - combobox "Absent-day scenario" [ref=e39] [cursor=pointer]:
            - option "M · absent dates remain missing" [selected]
            - option "Z · absent dates assumed zero"
        - paragraph [ref=e40]: Only weeks with seven daily rows are scored. An absent date is not a recorded zero. The final partial week is excluded in both scenarios.
        - generic [ref=e41]:
          - paragraph [ref=e42]: MANILA / HISTORICAL CASE FORECAST
          - heading "Current risk unavailable" [level=2] [ref=e43]
          - paragraph [ref=e44]: The case record is too old to establish current risk. This is the only case-forecast panel; the national map is a relative outlook.
          - paragraph [ref=e45]:
            - text: Data as of
            - time [ref=e46]: 2023-12-02
            - text: "? Forecast origin 2023-11-26 ? Scenario M"
          - generic [ref=e47]:
            - article [ref=e48]:
              - heading "1 week(s) ahead" [level=3] [ref=e49]
              - paragraph [ref=e50]: 62 estimated cases
              - paragraph [ref=e51]: "Historical target: 2023-12-03"
              - paragraph [ref=e52]: "80% interval: 40?84"
            - article [ref=e53]:
              - heading "2 week(s) ahead" [level=3] [ref=e54]
              - paragraph [ref=e55]: 62 estimated cases
              - paragraph [ref=e56]: "Historical target: 2023-12-10"
              - paragraph [ref=e57]: "80% interval: 31?93"
          - paragraph [ref=e58]: One-week persistence means last week's value. These are retrospective estimates, not a warning for the coming days.
          - paragraph [ref=e59]: Remove standing water, protect against bites and seek early consultation for symptoms.
        - generic [ref=e60]:
          - 'heading "Seasonal watch: context only" [level=2] [ref=e61]'
          - paragraph [ref=e62]: PAGASA defines June to November as the rainy season. Clear containers of standing water and keep up bite prevention. This is seasonal context, not a dengue prediction or alert.
          - paragraph [ref=e63]: Dengue observations remain historical; current weather cannot establish today's dengue risk.
          - paragraph [ref=e64]: In complete-row history for 2016-2023 (Scenario M), mean weekly cases ranged from 22.8 in May to 122.1 in September. This does not measure a delay from rainfall onset to rising cases.
          - status [ref=e65]: "Weather is seasonal context only; showing baseline forecast. Dengue observations remain historical. Weather as of: 2026-10-11."
          - link "PAGASA season definition" [ref=e66] [cursor=pointer]:
            - /url: https://www.pagasa.dost.gov.ph/information/climate-philippines
        - generic [ref=e67]:
          - paragraph [ref=e68]: ANALYTICS / RECORDED EVIDENCE
          - heading "The story in the weekly record" [level=2] [ref=e69]
          - generic [ref=e70]:
            - heading "Manila weekly cases, with source boundaries" [level=3] [ref=e71]
            - figure "Scrollable Manila history chart" [ref=e72]:
              - img "Manila weekly case history 312 observed or scenario-defined weeks. Peak 257 cases. Gaps break the line. Shading marks the COVID period. Exact data appears in the table below." [ref=e73]:
                - generic [ref=e75]: "0"
                - generic [ref=e77]: "64"
                - generic [ref=e79]: "129"
                - generic [ref=e81]: "193"
                - generic [ref=e83]: "257"
                - generic [ref=e85]: COVID period
                - generic [ref=e107]: 2016-01-10
                - generic [ref=e108]: 2023-12-03
                - generic [ref=e109]: Weekly cases · gaps remain gaps
                - generic [ref=e110]: Source changes
              - generic [ref=e111]: DOH EPI before 2018; Manila daily-derived weeks from 2018. COVID period shaded (2020–2021). Source dates end 2023-12-02; final partial week excluded. Sunday labels operationally interpreted as week-ending; source semantics unconfirmed.
            - group [ref=e112]:
              - generic "Exact weekly values and quality flags" [ref=e113] [cursor=pointer]
          - generic [ref=e114]:
            - generic [ref=e115]:
              - heading "Year comparison" [level=3] [ref=e116]
              - paragraph [ref=e117]: Available weeks only; incomplete years are not annual totals.
              - region "Year comparison" [ref=e118]:
                - table [ref=e119]:
                  - rowgroup [ref=e120]:
                    - row [ref=e121]:
                      - columnheader "Year" [ref=e122]
                      - columnheader "Recorded cases" [ref=e123]
                      - columnheader "Weeks" [ref=e124]
                  - rowgroup [ref=e125]:
                    - row [ref=e126]:
                      - rowheader "2016" [ref=e127]
                      - cell "1,990 ? incomplete" [ref=e128]
                      - cell "45 / 51" [ref=e129]
                    - row [ref=e130]:
                      - rowheader "2017" [ref=e131]
                      - cell "2,813" [ref=e132]
                      - cell "53 / 53" [ref=e133]
                    - row [ref=e134]:
                      - rowheader "2018" [ref=e135]
                      - cell "3,530 ? incomplete" [ref=e136]
                      - cell "47 / 52" [ref=e137]
                    - row [ref=e138]:
                      - rowheader "2019" [ref=e139]
                      - cell "3,761 ? incomplete" [ref=e140]
                      - cell "43 / 52" [ref=e141]
                    - row [ref=e142]:
                      - rowheader "2020" [ref=e143]
                      - cell "451 ? incomplete" [ref=e144]
                      - cell "13 / 52" [ref=e145]
                    - row [ref=e146]:
                      - rowheader "2021" [ref=e147]
                      - cell "883 ? incomplete" [ref=e148]
                      - cell "24 / 52" [ref=e149]
                    - row [ref=e150]:
                      - rowheader "2022" [ref=e151]
                      - cell "2,516 ? incomplete" [ref=e152]
                      - cell "42 / 52" [ref=e153]
                    - row [ref=e154]:
                      - rowheader "2023" [ref=e155]
                      - cell "2,346 ? incomplete" [ref=e156]
                      - cell "45 / 49" [ref=e157]
            - generic [ref=e158]:
              - heading "Seasonal profile" [level=3] [ref=e159]
              - paragraph [ref=e160]: Mean weekly cases by month of week ending; observed/scenario-defined weeks only, not monthly totals.
              - generic [ref=e161]:
                - generic [ref=e162]:
                  - generic [ref=e163]: Jan
                  - 'meter "Month 1: 53.8" [ref=e164]'
                  - generic [ref=e165]: "53.8"
                - generic [ref=e166]:
                  - generic [ref=e167]: Feb
                  - 'meter "Month 2: 43.7" [ref=e168]'
                  - generic [ref=e169]: "43.7"
                - generic [ref=e170]:
                  - generic [ref=e171]: Mar
                  - 'meter "Month 3: 29.4" [ref=e172]'
                  - generic [ref=e173]: "29.4"
                - generic [ref=e174]:
                  - generic [ref=e175]: Apr
                  - 'meter "Month 4: 27.2" [ref=e176]'
                  - generic [ref=e177]: "27.2"
                - generic [ref=e178]:
                  - generic [ref=e179]: May
                  - 'meter "Month 5: 22.8" [ref=e180]'
                  - generic [ref=e181]: "22.8"
                - generic [ref=e182]:
                  - generic [ref=e183]: Jun
                  - 'meter "Month 6: 30" [ref=e184]'
                  - generic [ref=e185]: "30"
                - generic [ref=e186]:
                  - generic [ref=e187]: Jul
                  - 'meter "Month 7: 49.6" [ref=e188]'
                  - generic [ref=e189]: "49.6"
                - generic [ref=e190]:
                  - generic [ref=e191]: Aug
                  - 'meter "Month 8: 95.3" [ref=e192]'
                  - generic [ref=e193]: "95.3"
                - generic [ref=e194]:
                  - generic [ref=e195]: Sep
                  - 'meter "Month 9: 122.1" [ref=e196]'
                  - generic [ref=e197]: "122.1"
                - generic [ref=e198]:
                  - generic [ref=e199]: Oct
                  - 'meter "Month 10: 92.8" [ref=e200]'
                  - generic [ref=e201]: "92.8"
                - generic [ref=e202]:
                  - generic [ref=e203]: Nov
                  - 'meter "Month 11: 72.1" [ref=e204]'
                  - generic [ref=e205]: "72.1"
                - generic [ref=e206]:
                  - generic [ref=e207]: Dec
                  - 'meter "Month 12: 49.8" [ref=e208]'
                  - generic [ref=e209]: "49.8"
          - generic [ref=e210]:
            - 'heading "Forecast versus actual: held-out 2023" [level=3] [ref=e211]'
            - img "Saved one-week persistence predictions versus actual held-out cases" [ref=e212]
            - paragraph [ref=e215]: "Solid: recorded values. Dashed: one-week persistence. Each origin precedes its target."
            - group [ref=e216]:
              - generic "Backtest data table" [ref=e217] [cursor=pointer]
            - paragraph [ref=e218]: "Source: data/processed/evaluation.json ? public/api/v2/dashboard.json."
          - generic [ref=e219]:
            - heading "How accurate is this?" [level=2] [ref=e220]
            - paragraph [ref=e221]: The public chart starts with Scenario M (only complete daily-row weeks). Scenario Z assumes absent dates are zero within coverage. Both are evaluated. The one-week public forecast is last week's value. Weather did not improve the predeclared one/two-week comparison. Two- to four-week ridge improvements are exploratory with wide uncertainty, not a validated operational warning.
            - paragraph [ref=e222]: Mean absolute error (MAE) is the average error in weekly case counts, from the saved 2018–2023 held-out evaluation. It does not establish accuracy for current conditions.
            - region "Forecast accuracy from saved evaluation" [ref=e223]:
              - table [ref=e224]:
                - rowgroup [ref=e225]:
                  - row [ref=e226]:
                    - columnheader "Model" [ref=e227]
                    - columnheader "Weeks ahead" [ref=e228]
                    - columnheader "MAE (cases)" [ref=e229]
                    - columnheader "Evaluated targets" [ref=e230]
                - rowgroup [ref=e231]:
                  - row [ref=e232]:
                    - rowheader "naive" [ref=e233]
                    - cell "1" [ref=e234]
                    - cell "15.47" [ref=e235]
                    - cell "116" [ref=e236]
                  - row [ref=e237]:
                    - rowheader "ridge-cases" [ref=e238]
                    - cell "1" [ref=e239]
                    - cell "16.36" [ref=e240]
                    - cell "116" [ref=e241]
                  - row [ref=e242]:
                    - rowheader "ridge-weather" [ref=e243]
                    - cell "1" [ref=e244]
                    - cell "18.39" [ref=e245]
                    - cell "116" [ref=e246]
                  - row [ref=e247]:
                    - rowheader "naive" [ref=e248]
                    - cell "2" [ref=e249]
                    - cell "22.90" [ref=e250]
                    - cell "117" [ref=e251]
                  - row [ref=e252]:
                    - rowheader "ridge-cases" [ref=e253]
                    - cell "2" [ref=e254]
                    - cell "22.17" [ref=e255]
                    - cell "117" [ref=e256]
                  - row [ref=e257]:
                    - rowheader "ridge-weather" [ref=e258]
                    - cell "2" [ref=e259]
                    - cell "23.17" [ref=e260]
                    - cell "117" [ref=e261]
                  - row [ref=e262]:
                    - rowheader "naive" [ref=e263]
                    - cell "4" [ref=e264]
                    - cell "31.63" [ref=e265]
                    - cell "112" [ref=e266]
                  - row [ref=e267]:
                    - rowheader "ridge-cases" [ref=e268]
                    - cell "4" [ref=e269]
                    - cell "27.43" [ref=e270]
                    - cell "112" [ref=e271]
                  - row [ref=e272]:
                    - rowheader "ridge-weather" [ref=e273]
                    - cell "4" [ref=e274]
                    - cell "28.42" [ref=e275]
                    - cell "112" [ref=e276]
        - region [ref=e278]:
          - paragraph [ref=e279]: TAKE CARE / ACT EARLY
          - heading "Know when to seek care" [level=2] [ref=e280]
          - paragraph [ref=e281]: Seek urgent medical care for severe abdominal pain, persistent vomiting, bleeding, difficulty breathing, unusual drowsiness or extreme weakness. Do not wait for a report review.
          - 'link "Source: CDC dengue warning signs" [ref=e282] [cursor=pointer]':
            - /url: https://www.cdc.gov/dengue/hcp/clinical-care/
          - heading "Make the DOH 4S a habit" [level=3] [ref=e283]
          - list [ref=e284]:
            - listitem [ref=e285]: "Search and destroy mosquito breeding places: empty and clean standing-water containers."
            - listitem [ref=e286]: "Self-protection: use repellent as directed and wear protective clothing."
            - listitem [ref=e287]: Seek early consultation for fever or dengue-like symptoms.
            - listitem [ref=e288]: Support health-authority fogging or spraying in identified hotspot/outbreak areas.
          - 'link "Source: Ministry of Health 4S guidance" [ref=e289] [cursor=pointer]':
            - /url: https://bangsamoro.gov.ph/news/latest-news/moh-urges-public-to-observe-4s-strategy-against-dengue/
          - paragraph [ref=e290]:
            - strong [ref=e291]: Informational, not a diagnosis. Not an official DOH product.
    - contentinfo [ref=e292]:
      - generic [ref=e293]:
        - link "About & Credits" [ref=e294] [cursor=pointer]:
          - /url: /about
        - button "About the data & methods" [ref=e295] [cursor=pointer]
      - paragraph [ref=e296]:
        - text: Bundled source periods.
        - time [ref=e297]: Dec 2, 2023
        - text: "?"
        - time [ref=e298]: Jan 10, 2021
        - text: . Historical, not live.
      - paragraph [ref=e299]: Background photograph by Sumarie Slabber
      - paragraph [ref=e300]: Thesis research ? Not an official DOH product ? Historical records, not a live warning.
  - status
```

# Test source

```ts
  58  |         .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
  59  |         .analyze()
  60  |     ).violations,
  61  |   ).toEqual([]);
  62  |   await page.getByRole("button", { name: "Submit community report" }).click();
  63  |   await expect(
  64  |     page.getByRole("heading", { name: "Report received" }),
  65  |   ).toBeVisible();
  66  |   expect(data.submissions).toHaveLength(1);
  67  |   expect(data.submissions[0]).toMatchObject({
  68  |     p_consent_given: true,
  69  |     p_consent_version: "community-v1",
  70  |     p_contact_opt_in: false,
  71  |     p_contact_value: null,
  72  |   });
  73  |   expect(await page.evaluate(() => JSON.stringify(localStorage))).not.toContain(
  74  |     "DW-",
  75  |   );
  76  |   expect(page.url()).not.toContain("DW-");
  77  |   await page.getByRole("link", { name: "Privacy → Withdraw a report" }).click();
  78  |   await page
  79  |     .getByLabel("Reference code", { exact: true })
  80  |     .fill("DW-AAAAAAAAAAAAAAAAAAAAAAAA");
  81  |   await page.getByRole("button", { name: "Request withdrawal" }).click();
  82  |   await expect(
  83  |     page.getByText("Request processed.", { exact: false }),
  84  |   ).toBeVisible();
  85  |   expect(data.deletions).toHaveLength(1);
  86  |   await expect(page.getByLabel("Reference code", { exact: true })).toHaveValue(
  87  |     "",
  88  |   );
  89  | });
  90  | 
  91  | test("closed collection, legacy redirect, service errors and retry have usable states", async ({
  92  |   page,
  93  | }) => {
  94  |   await mockPublicApi(page, { open: false });
  95  |   await page.goto("/report");
  96  |   await expect(
  97  |     page.getByText("New submissions are not open yet.", { exact: false }),
  98  |   ).toBeVisible();
  99  |   await page.getByRole("checkbox").check();
  100 |   await expect(
  101 |     page.getByRole("button", { name: "Continue to report" }),
  102 |   ).toBeDisabled();
  103 |   await page.goto("/city/not-a-city");
  104 |   await expect(page).toHaveURL(/\/trends$/);
  105 |   await page.route("**/api/v2/manila.json", (r) =>
  106 |     r.fulfill({ status: 503, body: "Unavailable" }),
  107 |   );
  108 |   await page.reload();
  109 |   await expect(page.getByRole("alert")).toBeVisible();
  110 |   await page.unroute("**/api/v2/manila.json");
  111 |   await page.getByRole("button", { name: "Try again" }).click();
  112 |   await expect(
  113 |     page.getByRole("heading", { name: "Weekly recorded cases" }),
  114 |   ).toBeVisible();
  115 | });
  116 | test("historical NCR map distinguishes missing source weeks from zero", async ({
  117 |   page,
  118 | }) => {
  119 |   await page.goto("/map");
  120 |   await page.getByLabel("Comparison period").selectOption("week");
  121 |   await page.getByLabel("Week label").selectOption("2016-11-13");
  122 |   await expect(page.locator(".ncr-city-map path")).toHaveCount(17);
  123 |   await expect(
  124 |     page.getByRole("region", { name: "Historical NCR city ranking" }),
  125 |   ).toContainText("Unavailable");
  126 |   await expect(
  127 |     page.getByText("Data ends January 2021.", { exact: true }),
  128 |   ).toBeVisible();
  129 |   await expect(
  130 |     page.getByText("No district or barangay case counts are inferred.", {
  131 |       exact: false,
  132 |     }),
  133 |   ).toBeVisible();
  134 |   expect(await page.locator(".barangay-svg").count()).toBe(0);
  135 | });
  136 | test("public routes retain disclaimers and legal access on phones", async ({
  137 |   page,
  138 | }) => {
  139 |   test.setTimeout(120000);
  140 |   await mockPublicApi(page, { open: false });
  141 |   for (const width of [320, 390, 768])
  142 |     for (const route of [
  143 |       "/",
  144 |       "/trends",
  145 |       "/map",
  146 |       "/report",
  147 |       "/privacy",
  148 |       "/terms",
  149 |       "/data-sources",
  150 |       "/dev",
  151 |       "/not-found",
  152 |     ]) {
  153 |       await page.setViewportSize({ width, height: 844 });
  154 |       await page.goto(route);
  155 |       await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
  156 |       await expect(
  157 |         page.getByRole("complementary", { name: "Estimates, not alerts" }),
> 158 |       ).toHaveCount(1);
      |         ^ Error: expect(locator).toHaveCount(expected) failed
  159 |       await expect(page.getByRole("contentinfo")).toContainText("Dec 2, 2023");
  160 |       expect(
  161 |         await page.evaluate(
  162 |           () => document.documentElement.scrollWidth <= innerWidth,
  163 |         ),
  164 |       ).toBe(true);
  165 |     }
  166 | });
  167 | test("publishable community aggregates remain delayed, unverified and separate", async ({
  168 |   page,
  169 | }) => {
  170 |   await mockPublicApi(page, { open: false });
  171 |   await page.route("**/rest/v1/rpc/community_signal_aggregates**", (r) =>
  172 |     r.fulfill({
  173 |       status: 200,
  174 |       contentType: "application/json",
  175 |       body: JSON.stringify([
  176 |         {
  177 |           area_label: "Manila city (area not specified)",
  178 |           week_start: "2026-09-21",
  179 |           report_count: 7,
  180 |         },
  181 |       ]),
  182 |     }),
  183 |   );
  184 |   await page.goto("/community");
  185 |   const section = page.getByRole("region", {
  186 |     name: "Unverified community aggregates",
  187 |   });
  188 |   await expect(section).toContainText("7");
  189 |   await expect(
  190 |     page.getByText("minimum 72-hour delay", { exact: false }),
  191 |   ).toBeVisible();
  192 |   await expect(
  193 |     page.locator('[aria-label="Historical forecast table"]'),
  194 |   ).toHaveCount(0);
  195 | });
  196 | test("loading resolves to an explicit empty snapshot without fabricated values", async ({
  197 |   page,
  198 | }) => {
  199 |   let release!: () => void;
  200 |   const gate = new Promise<void>((r) => (release = r));
  201 |   await page.route("**/api/v2/manila.json", async (r) => {
  202 |     await gate;
  203 |     await r.fulfill({
  204 |       status: 200,
  205 |       contentType: "application/json",
  206 |       body: JSON.stringify({
  207 |         ...evidence,
  208 |         series: { M: [], Z: [] },
  209 |         snapshots: [],
  210 |       }),
  211 |     });
  212 |   });
  213 |   await page.goto("/");
  214 |   await expect(page.getByText("Loading data…", { exact: true })).toBeVisible();
  215 |   release();
  216 |   await expect(
  217 |     page.getByRole("heading", {
  218 |       name: "No historical research snapshot available",
  219 |     }),
  220 |   ).toBeVisible();
  221 | });
  222 | test("historical forecast exposes all horizons and explicit interval uncertainty", async ({
  223 |   page,
  224 | }) => {
  225 |   await page.goto("/trends");
  226 |   await expect(
  227 |     page.getByRole("heading", { name: "Historical forecast and interval" }),
  228 |   ).toBeVisible();
  229 |   const table = page.getByRole("region", { name: "Forecast intervals" });
  230 |   await expect(table.locator("tbody tr")).toHaveCount(3);
  231 |   await expect(table).toContainText("exploratory");
  232 |   await page.goto("/methodology");
  233 |   await page.getByLabel("Forecast horizon").selectOption("4");
  234 |   await page.getByLabel("Evaluation fold").selectOption("covid-2020-2021");
  235 |   await expect(
  236 |     page
  237 |       .getByRole("region", { name: "Model evaluation metrics" })
  238 |       .locator("tbody tr"),
  239 |   ).toHaveCount(11);
  240 |   await expect(
  241 |     page.getByText("Intervals can under-cover", { exact: false }),
  242 |   ).toBeVisible();
  243 | });
  244 | test("model numbers exactly match saved evidence across scenarios and horizons", async ({
  245 |   page,
  246 | }) => {
  247 |   await page.goto("/methodology");
  248 |   for (const scenario of ["M", "Z"])
  249 |     for (const horizon of [1, 2, 4]) {
  250 |       await page.getByLabel("Absent-day scenario").selectOption(scenario);
  251 |       await page.getByLabel("Forecast horizon").selectOption(String(horizon));
  252 |       const row = evidence.summaries.find(
  253 |         (r: any) =>
  254 |           r.scenario === scenario &&
  255 |           r.horizon === horizon &&
  256 |           r.fold === "test-2018-2023" &&
  257 |           r.model === "naive",
  258 |       );
```