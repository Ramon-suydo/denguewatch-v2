# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: staff-reporting.spec.ts >> v2 reporting is closed by default, opt-in and bilingual without storing health fields
- Location: tests\ui\staff-reporting.spec.ts:32:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('New submissions are not open yet.')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('New submissions are not open yet.') with timeout 5000ms
  - waiting for getByText('New submissions are not open yet.')

```

```yaml
- link "Skip to content":
  - /url: "#main"
- banner:
  - link "DengueWatch home":
    - /url: /
    - text: DENGUE WATCH
  - navigation "Main navigation":
    - link "Dashboard":
      - /url: /
    - link "Risk Map":
      - /url: /risk-map
    - link "Community Report":
      - /url: /report
  - button "English" [pressed]
  - button "Filipino"
- main:
  - paragraph: COMMUNITY / UNVERIFIED
  - heading "Share an awareness signal." [level=1]
  - paragraph: Report a suspected case in your household or an unusual cluster you noticed. Choose only a coarse area; no GPS or free-text address is collected. Barangay selection is available only for the verified Manila catalogue; other units stay at province/city level. The onset day may be approximate.
  - paragraph: We do not ask for your name or contact details, do not store your IP address or precise location, and use no trackers. No system can promise perfect anonymity, so do not include details that identify you or others. Reports never enter official counts, forecasts or the Outlook Index.
  - paragraph: An IP address, when provided by the trusted hosting proxy, is used transiently to derive a rotating salted rate-limit hash. Raw IPs are never stored. Hashes expire after a 15-minute window and are physically removed on a successful request or the hourly retention job (up to 75 minutes). Automated note filters cannot detect every identifying detail. Retention and consent require DPO review before collection opens.
  - status: New submissions are closed.
  - heading "Understand and consent" [level=2]
  - paragraph: Your optional health report is sensitive personal information. It supports research and coarse community awareness, not diagnosis, emergency response or validated prediction.
  - paragraph: Only staff can review individual reports. Public counts require staff approval, a 72-hour delay and at least three reports per area/week. Reports are removed after 90 days; withdraw sooner with your private code.
  - paragraph:
    - text: Please report only your own household experience or a coarse, non-identifying cluster observation. Do not include anyone’s identity or address.
    - link "Privacy and withdrawal":
      - /url: /report?drawer=privacy
    - text: .
  - checkbox "I voluntarily consent to this research use of my report under community-v2."
  - text: I voluntarily consent to this research use of my report under community-v2.
  - button "Continue to report" [disabled]
  - paragraph: "Controller: DengueWatch student research team. Contact: [REDACTED]. Notice requires DPO review before collection opens."
  - paragraph:
    - link "View community aggregates":
      - /url: /community
    - text: ·
    - link "Prevention and urgent warning signs":
      - /url: /prevention
- contentinfo:
  - link "About & Credits":
    - /url: /about
  - button "About the data & methods"
  - button "Privacy notice"
  - paragraph:
    - text: Bundled source periods.
    - time: Dec 2, 2023
    - text: "?"
    - time: Jan 10, 2021
    - text: . Historical, not live.
  - paragraph: Background photograph by Sumarie Slabber
  - paragraph: Thesis research ? Not an official DOH product ? Historical records, not a live warning.
- status
```

# Test source

```ts
  1  | ﻿import { test, expect } from "@playwright/test";
  2  | import AxeBuilder from "@axe-core/playwright";
  3  | test("unauthenticated staff paths expose only sign-in and no public navigation or queue", async ({
  4  |   page,
  5  | }) => {
  6  |   let queueReads = 0;
  7  |   await page.route("**/rest/v1/rpc/staff_signal_queue**", (r) => {
  8  |     queueReads++;
  9  |     return r.fulfill({ status: 403, body: "denied" });
  10 |   });
  11 |   for (const path of ["/admin", "/admin/moderation", "/admin/uploads"]) {
  12 |     await page.goto(path);
  13 |     await expect(
  14 |       page.getByRole("heading", { name: "Staff sign in" }),
  15 |     ).toBeVisible();
  16 |     await expect(page.getByLabel("Staff email")).toBeVisible();
  17 |     await expect(
  18 |       page.getByRole("heading", { name: "Moderation queue" }),
  19 |     ).toHaveCount(0);
  20 |     await expect(
  21 |       page.getByRole("navigation", { name: "Main navigation" }),
  22 |     ).toHaveCount(0);
  23 |   }
  24 |   expect(queueReads).toBe(0);
  25 |   await page.setViewportSize({ width: 360, height: 900 });
  26 |   expect(
  27 |     (await new AxeBuilder({ page }).analyze()).violations.filter((v) =>
  28 |       ["critical", "serious"].includes(v.impact ?? ""),
  29 |     ),
  30 |   ).toEqual([]);
  31 | });
  32 | test("v2 reporting is closed by default, opt-in and bilingual without storing health fields", async ({
  33 |   page,
  34 | }) => {
  35 |   await page.route("**/rest/v1/reporting_v2_policy**", (r) =>
  36 |     r.fulfill({
  37 |       status: 200,
  38 |       contentType: "application/json",
  39 |       body: JSON.stringify({ enabled: false, consent_version: "community-v2" }),
  40 |     }),
  41 |   );
  42 |   await page.goto("/report");
  43 |   await expect(
  44 |     page.getByText("New submissions are not open yet.", { exact: false }),
> 45 |   ).toBeVisible();
     |     ^ Error: expect(locator).toBeVisible() failed
  46 |   await expect(page.getByRole("checkbox")).not.toBeChecked();
  47 |   await page.getByRole("checkbox").check();
  48 |   await expect(
  49 |     page.getByRole("button", { name: "Continue to report" }),
  50 |   ).toBeDisabled();
  51 |   await page.getByRole("button", { name: "Filipino", exact: true }).click();
  52 |   await expect(
  53 |     page.getByRole("heading", { name: "Unawain at pumayag" }),
  54 |   ).toBeVisible();
  55 |   await expect(page.locator("html")).toHaveAttribute("lang", "fil");
  56 |   expect(await page.evaluate(() => JSON.stringify(localStorage))).not.toContain(
  57 |     "DW2-",
  58 |   );
  59 | });
  60 | test("v2 open-policy preview collects coarse fields only and strips identifying note patterns", async ({
  61 |   page,
  62 | }) => {
  63 |   await page.route("**/rest/v1/reporting_v2_policy**", (r) =>
  64 |     r.fulfill({
  65 |       status: 200,
  66 |       contentType: "application/json",
  67 |       body: JSON.stringify({ enabled: true, consent_version: "community-v2" }),
  68 |     }),
  69 |   );
  70 |   await page.goto("/report");
  71 |   await page.getByRole("checkbox").check();
  72 |   await page.getByRole("button", { name: "Continue to report" }).click();
  73 |   await expect(page.getByLabel("Barangay (coarse area only)")).toBeVisible();
  74 |   await expect(page.getByLabel("Symptom-onset date (required)")).toBeVisible();
  75 |   await page
  76 |     .getByLabel("Short note (optional, 250 characters)")
  77 |     .fill("Reach [REDACTED] or [REDACTED]");
  78 |   await expect(
  79 |     page.getByText("Sanitized note:", { exact: false }),
  80 |   ).not.toContainText("[REDACTED]");
  81 |   await expect(
  82 |     page.getByText("Sanitized note:", { exact: false }),
  83 |   ).toContainText("[email removed]");
  84 |   await expect(page.getByLabel("Email address or phone number")).toHaveCount(0);
  85 |   await expect(page.getByLabel("Full name")).toHaveCount(0);
  86 |   await page.setViewportSize({ width: 360, height: 900 });
  87 |   expect(
  88 |     (await new AxeBuilder({ page }).analyze()).violations.filter((v) =>
  89 |       ["critical", "serious"].includes(v.impact ?? ""),
  90 |     ),
  91 |   ).toEqual([]);
  92 | });
  93 | 
```