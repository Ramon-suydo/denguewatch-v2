# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: redesign.spec.ts >> national map uses every explicit match, no guessed areas, exact saved metrics and real calendar windows
- Location: tests\ui\redesign.spec.ts:35:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.national-map [data-boundary-id]')
Expected: 104
Received: 0
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('.national-map [data-boundary-id]') with timeout 5000ms
  - waiting for locator('.national-map [data-boundary-id]')
    10 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - link "Skip to content" [ref=e5] [cursor=pointer]:
      - /url: "#main"
    - banner [ref=e6]:
      - link "DengueWatch home" [ref=e7] [cursor=pointer]:
        - /url: /
        - text: DENGUE
        - generic [ref=e8]: WATCH
      - navigation "Main navigation" [ref=e9]:
        - link "Dashboard" [ref=e10] [cursor=pointer]:
          - /url: /
        - link "Risk Map" [ref=e11] [cursor=pointer]:
          - /url: /risk-map
        - link "Community Report" [ref=e12] [cursor=pointer]:
          - /url: /report
      - generic "Page language" [ref=e13]:
        - button "English" [pressed] [ref=e14] [cursor=pointer]
        - button "Filipino" [ref=e15] [cursor=pointer]
    - main [ref=e16]:
      - generic [ref=e17]:
        - paragraph [ref=e18]: PHILIPPINES / RELATIVE OUTLOOK
        - heading "PATTERNS, NOT PREDICTIONS." [level=1] [ref=e19]
        - paragraph [ref=e20]: Explore historical burden and the season ahead. An outlook is not a forecast of case counts.
        - complementary [ref=e21]: Outlook = relative seasonal patterns and historical burden, not predicted case counts. Weather is not used without validation. Only Manila has a historical calibrated case-forecast panel; current risk is unavailable.
        - generic [ref=e22]:
          - generic [ref=e23]:
            - generic [ref=e24]: Search province / city
            - searchbox "Search province / city" [ref=e25]
          - generic [ref=e26]:
            - generic [ref=e27]:
              - generic [ref=e28]: Map layer
              - combobox "Map layer" [ref=e29] [cursor=pointer]:
                - option "Outlook Index" [selected]
                - option "Historical recorded burden (2016–2020)"
                - option "Community-reported signals (unverified)"
            - group "Outlook day window" [ref=e30]:
              - button "Today" [pressed] [ref=e31] [cursor=pointer]
              - button "+3 days" [ref=e32] [cursor=pointer]
              - button "+7 days" [ref=e33] [cursor=pointer]
          - paragraph [ref=e34]: "Selected window: 2026-10-20. Case data as of 2021-01-10."
          - paragraph [ref=e35]: Large provinces can rank higher simply because more people live there. Population-adjusted risk is not verified.
        - generic [ref=e36]:
          - generic [ref=e37]:
            - group "Map pan and zoom" [ref=e38]:
              - button "Zoom in" [ref=e39] [cursor=pointer]: +
              - button "Zoom out" [ref=e40] [cursor=pointer]: −
              - button "Reset" [ref=e41] [cursor=pointer]
              - button "Pan ←" [ref=e42] [cursor=pointer]: ←
              - button "Pan →" [ref=e43] [cursor=pointer]: →
              - button "Pan ↑" [ref=e44] [cursor=pointer]: ↑
              - button "Pan ↓" [ref=e45] [cursor=pointer]: ↓
            - group "Philippines province and city map" [ref=e46]:
              - generic [ref=e47]:
                - 'button "Abra: Outlook Index 24, relative seasonal conditions" [ref=e49] [cursor=pointer]'
                - 'button "Agusan del Norte: Outlook Index 12, relative seasonal conditions" [ref=e51] [cursor=pointer]'
                - 'button "Agusan del Sur: Outlook Index 53.6, relative seasonal conditions" [ref=e53] [cursor=pointer]'
                - 'button "Aklan: Outlook Index 62.4, relative seasonal conditions" [ref=e55] [cursor=pointer]'
                - 'button "Albay: Outlook Index 21.6, relative seasonal conditions" [ref=e57] [cursor=pointer]'
                - 'button "Antique: Outlook Index 54.4, relative seasonal conditions" [ref=e59] [cursor=pointer]'
                - 'button "Apayao: Outlook Index 52.8, relative seasonal conditions" [ref=e61] [cursor=pointer]'
                - 'button "Aurora: Outlook Index 20.8, relative seasonal conditions" [ref=e63] [cursor=pointer]'
                - 'button "Basilan: Outlook Index 8, relative seasonal conditions" [ref=e65] [cursor=pointer]'
                - 'button "Bataan: Outlook Index 84.8, relative seasonal conditions" [ref=e67] [cursor=pointer]'
                - 'button "Batanes: Outlook Index 0.8, relative seasonal conditions" [ref=e69] [cursor=pointer]'
                - 'button "Batangas: Outlook Index 94.4, relative seasonal conditions" [ref=e71] [cursor=pointer]'
                - 'button "Benguet: Outlook Index 41.6, relative seasonal conditions" [ref=e73] [cursor=pointer]'
                - 'button "Biliran: Outlook Index 19.2, relative seasonal conditions" [ref=e75] [cursor=pointer]'
                - 'button "Bohol: Outlook Index 92, relative seasonal conditions" [ref=e77] [cursor=pointer]'
                - 'button "Bukidnon: Outlook Index 85.6, relative seasonal conditions" [ref=e79] [cursor=pointer]'
                - 'button "Bulacan: Outlook Index 96, relative seasonal conditions" [ref=e81] [cursor=pointer]'
                - 'button "Cagayan: Outlook Index 76.8, relative seasonal conditions" [ref=e83] [cursor=pointer]'
                - 'button "Camarines Norte: Outlook Index 31.2, relative seasonal conditions" [ref=e85] [cursor=pointer]'
                - 'button "Camarines Sur: Outlook Index 65.6, relative seasonal conditions" [ref=e87] [cursor=pointer]'
                - 'button "Camiguin: Outlook Index 38.4, relative seasonal conditions" [ref=e89] [cursor=pointer]'
                - 'button "Capiz: Outlook Index 56, relative seasonal conditions" [ref=e91] [cursor=pointer]'
                - 'button "Catanduanes: Outlook Index 5.6, relative seasonal conditions" [ref=e93] [cursor=pointer]'
                - 'button "Cavite: Outlook Index 100, relative seasonal conditions" [ref=e95] [cursor=pointer]'
                - 'button "Cebu: Outlook Index 98.4, relative seasonal conditions" [ref=e97] [cursor=pointer]'
                - 'button "City of Isabela: Outlook Index 25.6, relative seasonal conditions" [ref=e99] [cursor=pointer]'
                - 'button "Compostela Valley: No data" [ref=e101] [cursor=pointer]'
                - 'button "Cotabato: No data" [ref=e103] [cursor=pointer]'
                - 'button "Cotabato City: Outlook Index 16, relative seasonal conditions" [ref=e105] [cursor=pointer]'
                - 'button "Davao del Norte: Outlook Index 36.8, relative seasonal conditions" [ref=e107] [cursor=pointer]'
                - 'button "Davao del Sur: Outlook Index 7.2, relative seasonal conditions" [ref=e109] [cursor=pointer]'
                - 'button "Davao Occidental: Outlook Index 0, relative seasonal conditions" [ref=e111] [cursor=pointer]'
                - 'button "Davao Oriental: Outlook Index 32.8, relative seasonal conditions" [ref=e113] [cursor=pointer]'
                - 'button "Dinagat Islands: Outlook Index 10.8, relative seasonal conditions" [ref=e115] [cursor=pointer]'
                - 'button "Eastern Samar: Outlook Index 58.4, relative seasonal conditions" [ref=e117] [cursor=pointer]'
                - 'button "Guimaras: Outlook Index 12.8, relative seasonal conditions" [ref=e119] [cursor=pointer]'
                - 'button "Ifugao: Outlook Index 40, relative seasonal conditions" [ref=e121] [cursor=pointer]'
                - 'button "Ilocos Norte: Outlook Index 76, relative seasonal conditions" [ref=e123] [cursor=pointer]'
                - 'button "Ilocos Sur: Outlook Index 69.6, relative seasonal conditions" [ref=e125] [cursor=pointer]'
                - 'button "Iloilo: Outlook Index 84, relative seasonal conditions" [ref=e127] [cursor=pointer]'
                - 'button "Isabela: Outlook Index 88, relative seasonal conditions" [ref=e129] [cursor=pointer]'
                - 'button "Kalinga: Outlook Index 51.2, relative seasonal conditions" [ref=e131] [cursor=pointer]'
                - 'button "La Union: Outlook Index 60.8, relative seasonal conditions" [ref=e133] [cursor=pointer]'
                - 'button "Laguna: Outlook Index 99.2, relative seasonal conditions" [ref=e135] [cursor=pointer]'
                - 'button "Lanao del Norte: Outlook Index 79.2, relative seasonal conditions" [ref=e137] [cursor=pointer]'
                - 'button "Lanao del Sur: Outlook Index 49.6, relative seasonal conditions" [ref=e139] [cursor=pointer]'
                - 'button "Leyte: Outlook Index 73.6, relative seasonal conditions" [ref=e141] [cursor=pointer]'
                - 'button "Maguindanao: Outlook Index 20, relative seasonal conditions" [ref=e143] [cursor=pointer]'
                - 'button "Marinduque: Outlook Index 6.4, relative seasonal conditions" [ref=e145] [cursor=pointer]'
                - 'button "Masbate: Outlook Index 24.8, relative seasonal conditions" [ref=e147] [cursor=pointer]'
                - 'button "Misamis Occidental: Outlook Index 63.2, relative seasonal conditions" [ref=e149] [cursor=pointer]'
                - 'button "Misamis Oriental: Outlook Index 80.8, relative seasonal conditions" [ref=e151] [cursor=pointer]'
                - 'button "Mountain Province: Outlook Index 15.2, relative seasonal conditions" [ref=e153] [cursor=pointer]'
                - 'button "NCR, City of Manila, First District: No data" [ref=e155] [cursor=pointer]'
                - 'button "NCR, Fourth District: No data" [ref=e157] [cursor=pointer]'
                - 'button "NCR, Second District: No data" [ref=e159] [cursor=pointer]'
                - 'button "NCR, Third District: No data" [ref=e161] [cursor=pointer]'
                - 'button "Negros Occidental: Outlook Index 91.2, relative seasonal conditions" [ref=e163] [cursor=pointer]'
                - 'button "Negros Oriental: Outlook Index 89.6, relative seasonal conditions" [ref=e165] [cursor=pointer]'
                - 'button "Northern Samar: Outlook Index 68, relative seasonal conditions" [ref=e167] [cursor=pointer]'
                - 'button "Nueva Ecija: Outlook Index 92.8, relative seasonal conditions" [ref=e169] [cursor=pointer]'
                - 'button "Nueva Vizcaya: No data" [ref=e171] [cursor=pointer]'
                - 'button "Occidental Mindoro: Outlook Index 34.4, relative seasonal conditions" [ref=e173] [cursor=pointer]'
                - 'button "Oriental Mindoro: Outlook Index 48.8, relative seasonal conditions" [ref=e175] [cursor=pointer]'
                - 'button "Palawan: Outlook Index 64, relative seasonal conditions" [ref=e177] [cursor=pointer]'
                - 'button "Pampanga: Outlook Index 95.2, relative seasonal conditions" [ref=e179] [cursor=pointer]'
                - 'button "Pangasinan: Outlook Index 96.8, relative seasonal conditions" [ref=e181] [cursor=pointer]'
                - 'button "Quezon: Outlook Index 90.4, relative seasonal conditions" [ref=e183] [cursor=pointer]'
                - 'button "Quirino: Outlook Index 64.8, relative seasonal conditions" [ref=e185] [cursor=pointer]'
                - 'button "Rizal: Outlook Index 93.6, relative seasonal conditions" [ref=e187] [cursor=pointer]'
                - 'button "Romblon: Outlook Index 8.8, relative seasonal conditions" [ref=e189] [cursor=pointer]'
                - 'button "Samar: Outlook Index 77.6, relative seasonal conditions" [ref=e191] [cursor=pointer]'
                - 'button "Sarangani: Outlook Index 44, relative seasonal conditions" [ref=e193] [cursor=pointer]'
                - 'button "Siquijor: No data" [ref=e195] [cursor=pointer]'
                - 'button "Sorsogon: Outlook Index 36, relative seasonal conditions" [ref=e197] [cursor=pointer]'
                - 'button "South Cotabato: Outlook Index 71.2, relative seasonal conditions" [ref=e199] [cursor=pointer]'
                - 'button "Southern Leyte: Outlook Index 27.2, relative seasonal conditions" [ref=e201] [cursor=pointer]'
                - 'button "Sultan Kudarat: Outlook Index 23.2, relative seasonal conditions" [ref=e203] [cursor=pointer]'
                - 'button "Sulu: Outlook Index 3.2, relative seasonal conditions" [ref=e205] [cursor=pointer]'
                - 'button "Surigao del Norte: Outlook Index 39.2, relative seasonal conditions" [ref=e207] [cursor=pointer]'
                - 'button "Surigao del Sur: Outlook Index 57.6, relative seasonal conditions" [ref=e209] [cursor=pointer]'
                - 'button "Tarlac: Outlook Index 88.8, relative seasonal conditions" [ref=e211] [cursor=pointer]'
                - 'button "Tawi-Tawi: Outlook Index 1.6, relative seasonal conditions" [ref=e213] [cursor=pointer]'
                - 'button "Zambales: Outlook Index 56.8, relative seasonal conditions" [ref=e215] [cursor=pointer]'
                - 'button "Zamboanga del Norte: Outlook Index 75.2, relative seasonal conditions" [ref=e217] [cursor=pointer]'
                - 'button "Zamboanga del Sur: Outlook Index 37.6, relative seasonal conditions" [ref=e219] [cursor=pointer]'
                - 'button "Zamboanga Sibugay: Outlook Index 59.2, relative seasonal conditions" [ref=e221] [cursor=pointer]'
                - 'button "City of Manila: Outlook Index 87.2, relative seasonal conditions" [pressed] [ref=e223] [cursor=pointer]'
                - 'button "City of Mandaluyong: Outlook Index 32, relative seasonal conditions" [ref=e225] [cursor=pointer]'
                - 'button "City of Marikina: Outlook Index 44.8, relative seasonal conditions" [ref=e227] [cursor=pointer]'
                - 'button "City of Pasig: Outlook Index 80, relative seasonal conditions" [ref=e229] [cursor=pointer]'
                - 'button "Quezon City: Outlook Index 97.6, relative seasonal conditions" [ref=e231] [cursor=pointer]'
                - 'button "City of San Juan: Outlook Index 22.4, relative seasonal conditions" [ref=e233] [cursor=pointer]'
                - 'button "Caloocan City: Outlook Index 78.4, relative seasonal conditions" [ref=e235] [cursor=pointer]'
                - 'button "City of Malabon: Outlook Index 74.4, relative seasonal conditions" [ref=e237] [cursor=pointer]'
                - 'button "City of Navotas: Outlook Index 28, relative seasonal conditions" [ref=e239] [cursor=pointer]'
                - 'button "City of Valenzuela: Outlook Index 52, relative seasonal conditions" [ref=e241] [cursor=pointer]'
                - 'button "City of Las Piñas: Outlook Index 55.2, relative seasonal conditions" [ref=e243] [cursor=pointer]'
                - 'button "City of Makati: Outlook Index 48, relative seasonal conditions" [ref=e245] [cursor=pointer]'
                - 'button "City of Muntinlupa: Outlook Index 45.6, relative seasonal conditions" [ref=e247] [cursor=pointer]'
                - 'button "City of Parañaque: Outlook Index 81.6, relative seasonal conditions" [ref=e249] [cursor=pointer]'
                - 'button "Pasay City: Outlook Index 47.2, relative seasonal conditions" [ref=e251] [cursor=pointer]'
                - 'button "Pateros: Outlook Index 10.8, relative seasonal conditions" [ref=e253] [cursor=pointer]'
                - 'button "Taguig City: Outlook Index 70.4, relative seasonal conditions" [ref=e255] [cursor=pointer]'
            - generic [ref=e256]:
              - generic [ref=e257]: Lower relative index
              - generic [ref=e259]: Upper relative index (hatched)
            - paragraph [ref=e260]: "Gray diagonal pattern: no matched data. Labels and table duplicate every value; colour does not indicate confirmed risk."
          - generic [ref=e261]:
            - paragraph [ref=e262]: SELECTED REPORTING UNIT
            - heading "MANILA CITY" [level=2] [ref=e263]
            - paragraph [ref=e264]: "87.2"
            - paragraph [ref=e265]: Outlook Index / 100 · relative rank 17 among reporting units
            - paragraph [ref=e266]: "Seasonal expectation vs its own historical weekly mean: 167%"
            - paragraph [ref=e267]: "Last available case record: 2021-01-10"
            - paragraph [ref=e268]: Weather forecast unavailable. Seasonal outlook retained.
            - paragraph [ref=e269]: Centroid weather represents coarse grid cells of about 9–50 km, not neighbourhood or household conditions.
            - link "About the data & methods" [ref=e270] [cursor=pointer]:
              - /url: "?drawer=methods"
        - group [ref=e272]:
          - 'generic "Data table: all reporting units and unmatched areas" [ref=e273] [cursor=pointer]'
        - generic [ref=e274]:
          - heading "How reliable is this map?" [level=2] [ref=e275]
          - paragraph [ref=e276]: These are retrospective rankings of recorded case counts, not population-adjusted risk. Results vary by year, missing coverage and the COVID period. Seasonal history did not improve every year.
          - paragraph [ref=e277]: Lagged weather did not consistently beat both seasonal-only baselines across held-out years and all three metrics.
          - region "National map validation metrics" [ref=e278]:
            - table [ref=e279]:
              - rowgroup [ref=e280]:
                - row [ref=e281]:
                  - columnheader "Test year" [ref=e282]
                  - columnheader "Model" [ref=e283]
                  - columnheader "Weeks" [ref=e284]
                  - columnheader "Min units" [ref=e285]
                  - columnheader "Spearman ↑" [ref=e286]
                  - columnheader "Top-10 hit rate ↑" [ref=e287]
                  - columnheader "Normalized rank error ↓" [ref=e288]
              - rowgroup [ref=e289]:
                - row [ref=e290]:
                  - rowheader "2018" [ref=e291]
                  - cell "burden-only" [ref=e292]
                  - cell "52" [ref=e293]
                  - cell "126" [ref=e294]
                  - cell "0.748" [ref=e295]
                  - cell "0.529" [ref=e296]
                  - cell "0.156" [ref=e297]
                - row [ref=e298]:
                  - rowheader "2018" [ref=e299]
                  - cell "lagged-weather-weather-cohort" [ref=e300]
                  - cell "52" [ref=e301]
                  - cell "96" [ref=e302]
                  - cell "0.751" [ref=e303]
                  - cell "0.575" [ref=e304]
                  - cell "0.152" [ref=e305]
                - row [ref=e306]:
                  - rowheader "2018" [ref=e307]
                  - cell "season-burden" [ref=e308]
                  - cell "52" [ref=e309]
                  - cell "126" [ref=e310]
                  - cell "0.741" [ref=e311]
                  - cell "0.492" [ref=e312]
                  - cell "0.158" [ref=e313]
                - row [ref=e314]:
                  - rowheader "2018" [ref=e315]
                  - cell "season-burden-weather-cohort" [ref=e316]
                  - cell "52" [ref=e317]
                  - cell "96" [ref=e318]
                  - cell "0.759" [ref=e319]
                  - cell "0.542" [ref=e320]
                  - cell "0.152" [ref=e321]
                - row [ref=e322]:
                  - rowheader "2018" [ref=e323]
                  - cell "season-ridge-weather-cohort" [ref=e324]
                  - cell "52" [ref=e325]
                  - cell "96" [ref=e326]
                  - cell "0.777" [ref=e327]
                  - cell "0.56" [ref=e328]
                  - cell "0.146" [ref=e329]
                - row [ref=e330]:
                  - rowheader "2019" [ref=e331]
                  - cell "burden-only" [ref=e332]
                  - cell "51" [ref=e333]
                  - cell "126" [ref=e334]
                  - cell "0.738" [ref=e335]
                  - cell "0.516" [ref=e336]
                  - cell "0.16" [ref=e337]
                - row [ref=e338]:
                  - rowheader "2019" [ref=e339]
                  - cell "lagged-weather-weather-cohort" [ref=e340]
                  - cell "51" [ref=e341]
                  - cell "96" [ref=e342]
                  - cell "0.769" [ref=e343]
                  - cell "0.588" [ref=e344]
                  - cell "0.15" [ref=e345]
                - row [ref=e346]:
                  - rowheader "2019" [ref=e347]
                  - cell "season-burden" [ref=e348]
                  - cell "51" [ref=e349]
                  - cell "126" [ref=e350]
                  - cell "0.767" [ref=e351]
                  - cell "0.569" [ref=e352]
                  - cell "0.149" [ref=e353]
                - row [ref=e354]:
                  - rowheader "2019" [ref=e355]
                  - cell "season-burden-weather-cohort" [ref=e356]
                  - cell "51" [ref=e357]
                  - cell "96" [ref=e358]
                  - cell "0.772" [ref=e359]
                  - cell "0.563" [ref=e360]
                  - cell "0.147" [ref=e361]
                - row [ref=e362]:
                  - rowheader "2019" [ref=e363]
                  - cell "season-ridge-weather-cohort" [ref=e364]
                  - cell "51" [ref=e365]
                  - cell "96" [ref=e366]
                  - cell "0.775" [ref=e367]
                  - cell "0.584" [ref=e368]
                  - cell "0.146" [ref=e369]
                - row [ref=e370]:
                  - rowheader "2020" [ref=e371]
                  - cell "burden-only" [ref=e372]
                  - cell "52" [ref=e373]
                  - cell "80" [ref=e374]
                  - cell "0.622" [ref=e375]
                  - cell "0.321" [ref=e376]
                  - cell "0.194" [ref=e377]
                - row [ref=e378]:
                  - rowheader "2020" [ref=e379]
                  - cell "lagged-weather-weather-cohort" [ref=e380]
                  - cell "52" [ref=e381]
                  - cell "59" [ref=e382]
                  - cell "0.67" [ref=e383]
                  - cell "0.423" [ref=e384]
                  - cell "0.181" [ref=e385]
                - row [ref=e386]:
                  - rowheader "2020" [ref=e387]
                  - cell "season-burden" [ref=e388]
                  - cell "52" [ref=e389]
                  - cell "80" [ref=e390]
                  - cell "0.65" [ref=e391]
                  - cell "0.412" [ref=e392]
                  - cell "0.185" [ref=e393]
                - row [ref=e394]:
                  - rowheader "2020" [ref=e395]
                  - cell "season-burden-weather-cohort" [ref=e396]
                  - cell "52" [ref=e397]
                  - cell "59" [ref=e398]
                  - cell "0.675" [ref=e399]
                  - cell "0.431" [ref=e400]
                  - cell "0.179" [ref=e401]
                - row [ref=e402]:
                  - rowheader "2020" [ref=e403]
                  - cell "season-ridge-weather-cohort" [ref=e404]
                  - cell "52" [ref=e405]
                  - cell "59" [ref=e406]
                  - cell "0.678" [ref=e407]
                  - cell "0.421" [ref=e408]
                  - cell "0.179" [ref=e409]
          - paragraph [ref=e410]: "Each test year uses strictly earlier years. Spearman compares within-week ranks; top-10 hit rate is overlap / 10; normalized error is mean absolute rank difference / (unit count − 1). Missing observations are excluded, never zero-filled. Regenerate: npm run evaluate:map."
        - generic [ref=e411]:
          - paragraph [ref=e412]: MANILA / HISTORICAL CASE FORECAST
          - heading "Current risk unavailable" [level=2] [ref=e413]
          - paragraph [ref=e414]: The case record is too old to establish current risk. This is the only case-forecast panel; the national map is a relative outlook.
          - paragraph [ref=e415]:
            - text: Data as of
            - time [ref=e416]: 2023-12-02
            - text: · Forecast origin 2023-11-26 · Scenario M
          - heading "Historical Manila forecast" [level=3] [ref=e417]
          - generic [ref=e418]:
            - article [ref=e419]:
              - heading "1 week(s) ahead" [level=3] [ref=e420]
              - paragraph [ref=e421]: 62 estimated cases
              - paragraph [ref=e422]: "Historical target: 2023-12-03"
              - paragraph [ref=e423]: "80% interval: 40–84"
            - article [ref=e424]:
              - heading "2 week(s) ahead" [level=3] [ref=e425]
              - paragraph [ref=e426]: 62 estimated cases
              - paragraph [ref=e427]: "Historical target: 2023-12-10"
              - paragraph [ref=e428]: "80% interval: 31–93"
          - paragraph [ref=e429]:
            - text: "Measured historical error (MAE, cases):"
            - generic [ref=e430]: "1 week(s): 15.47."
            - generic [ref=e431]: "2 week(s): 22.90."
          - paragraph [ref=e432]: One-week persistence means last week's value. These are retrospective estimates, not a warning for the coming days.
          - paragraph [ref=e433]: Remove standing water, protect against bites and seek early consultation for symptoms.
      - complementary [ref=e434]:
        - heading "Estimates, not alerts" [level=2] [ref=e435]
        - paragraph [ref=e436]: Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.
    - contentinfo [ref=e437]:
      - generic [ref=e438]:
        - link "About & Credits" [ref=e439] [cursor=pointer]:
          - /url: /about
        - button "About the data & methods" [ref=e440] [cursor=pointer]
      - paragraph [ref=e441]:
        - text: Bundled source periods.
        - time [ref=e442]: Dec 2, 2023
        - text: ·
        - time [ref=e443]: Jan 10, 2021
        - text: . Historical, not live.
      - paragraph [ref=e444]: Community reports are unverified; not medical advice.
      - paragraph [ref=e445]: Background photograph by Sumarie Slabber
      - paragraph [ref=e446]: Thesis research · Not an official DOH product · Historical records, not a live warning.
  - status
```

# Test source

```ts
  1   | import {test,expect} from '@playwright/test';
  2   | import {readFile} from 'node:fs/promises';
  3   | import AxeBuilder from '@axe-core/playwright';
  4   | import {goto,activeView} from '../support/active-view';
  5   | import {outlookRows,type Outlook} from '../../src/redesign/outlook';
  6   | const read=async(path:string)=>JSON.parse(await readFile(path,'utf8'));
  7   | 
  8   | test('three navigation destinations, footer attribution, empty owner fields and old-route drawers',async({page})=>{
  9   |  test.setTimeout(120000);
  10  |  for(const width of [360,1280])for(const path of ['/','/risk-map','/report','/about']){
  11  |   await page.setViewportSize({width,height:1000});await goto(page,path);
  12  |   if(width===360)await page.getByRole('button',{name:'Menu',exact:true}).click();
  13  |   const nav=page.getByRole('navigation',{name:'Main navigation'});
  14  |   await expect(nav.getByRole('link')).toHaveText(['Dashboard','Risk Map','Community Report']);
  15  |   await expect(nav.getByRole('link',{name:'About & Credits'})).toHaveCount(0);
  16  |   await expect(page.getByRole('contentinfo').getByRole('link',{name:'About & Credits'})).toHaveAttribute('href','/about');
  17  |   await expect(page.getByRole('contentinfo')).toContainText('Background photograph by Sumarie Slabber');
  18  |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  19  |   expect((await new AxeBuilder({page}).analyze()).violations.filter(v=>['critical','serious'].includes(v.impact??''))).toEqual([]);
  20  |  }
  21  |  await goto(page,'/about');await expect(page.locator('#team')).toHaveCount(0);
  22  |  await expect(page.locator('#image-credit')).toContainText('Background photograph by Sumarie Slabber');
  23  |  await expect(page.locator('#image-credit a')).toHaveCount(0);
  24  |  const software=await read('src/content/software-credits.json');
  25  |  await page.locator('#software summary').click();await expect(page.locator('#software tbody tr')).toHaveCount(software.length);
  26  |  await goto(page,'/');await page.getByRole('contentinfo').getByRole('button',{name:'About the data & methods',exact:true}).click();await activeView(page).getByRole('link',{name:'About & Credits',exact:true}).click();await expect(page).toHaveURL(/\/about$/);await expect(page.locator('dialog[open]')).toHaveCount(0);
  27  |  for(const old of ['/trends','/methodology','/data-sources','/prevention','/map','/privacy']){
  28  |   await goto(page,old);await expect(page).not.toHaveURL(new RegExp(old+'$'));
  29  |   await expect(page.locator('dialog[open]')).toBeVisible();
  30  |   await activeView(page).getByRole('button',{name:'Close dialog'}).click();
  31  |   await expect(page.locator('dialog[open]')).toHaveCount(0);
  32  |  }
  33  | });
  34  | 
  35  | test('national map uses every explicit match, no guessed areas, exact saved metrics and real calendar windows',async({page})=>{
  36  |  await page.clock.setFixedTime(new Date('2026-10-20T04:00:00Z'));
  37  |  await page.route('**/api/v2/outlook-weather.json',route=>route.fulfill({status:503,body:'Unavailable'}));
  38  |  const external:string[]=[];page.on('request',r=>{if(/open-meteo|power\.larc|tile\./.test(r.url()))external.push(r.url());});
  39  |  await goto(page,'/risk-map');const geo=await read('public/geo/philippines.geojson'),data=await read('public/api/v2/outlook.json') as Outlook;
> 40  |  const polygons=page.locator('.national-map [data-boundary-id]');await expect(polygons).toHaveCount(geo.features.length);
      |                                                                                         ^ Error: expect(locator).toHaveCount(expected) failed
  41  |  await expect(page.locator('.national-map [data-no-data="true"]')).toHaveCount(8);
  42  |  expect(geo.features.filter((f:any)=>f.properties.case_name)).toHaveLength(96);
  43  |  await expect(page.locator('.province-detail')).toContainText('Weather forecast unavailable. Seasonal outlook retained.');
  44  |  const detail=page.locator('.province-detail');await expect(detail).not.toContainText('estimated cases');
  45  |  await expect(page.locator('.national-map [data-case-unit]:not([data-case-unit=""])')).toHaveCount(96);
  46  |  const manila=page.locator('.national-map [data-case-unit="MANILA CITY"]');await manila.focus();await page.keyboard.press('Enter');await expect(manila).toHaveAttribute('aria-pressed','true');
  47  |  const expected=(date:string)=>outlookRows(data,date).find(r=>r.name==='MANILA CITY')!.index!.toLocaleString('en-US',{maximumFractionDigits:1});
  48  |  for(const [label,date] of [['Today','2026-10-20'],['+3 days','2026-10-23'],['+7 days','2026-10-27']]){
  49  |   await page.getByRole('button',{name:label,exact:true}).click();await expect(detail.locator('[data-outlook-index]')).toHaveText(expected(date));
  50  |  }
  51  |  const transform=await page.locator('.national-map>g').getAttribute('transform');await page.getByRole('button',{name:'Zoom in',exact:true}).click();expect(await page.locator('.national-map>g').getAttribute('transform')).not.toBe(transform);
  52  |  await page.getByRole('button',{name:'Reset',exact:true}).click();
  53  |  const table=page.getByRole('region',{name:'Outlook Index data table'});await page.getByText('Data table: all reporting units and unmatched areas',{exact:true}).click();
  54  |  await expect(table.locator('tbody tr')).toHaveCount(134);
  55  |  for(const row of outlookRows(data,'2026-10-27')){
  56  |   const tr=table.locator('tbody tr').filter({has:page.getByRole('button',{name:row.name,exact:true})});
  57  |   const matched=geo.features.some((f:any)=>f.properties.case_name===row.name);
  58  |   await expect(tr.locator('td').first()).toHaveText(matched?row.index!.toLocaleString('en-US',{maximumFractionDigits:1}):'No data');
  59  |  }
  60  |  const metricRows=page.getByRole('region',{name:'National map validation metrics'}).locator('tbody tr');await expect(metricRows).toHaveCount(data.models.length);
  61  |  for(let i=0;i<data.models.length;i++){const r=data.models[i];await expect(metricRows.nth(i).locator('td')).toHaveText([r.model,String(r.weeks),String(r.min_units),...[r.spearman!,r.top10_hit_rate,r.normalized_rank_error].map(v=>v.toLocaleString('en-PH',{maximumFractionDigits:3}))]);}
  62  |  await page.getByLabel('Search province / city').fill('DAVAO DE ORO');await expect(table.locator('tbody tr')).toHaveCount(1);await expect(table).toContainText('Unmatched: no data');
  63  |  await table.getByRole('button',{name:'DAVAO DE ORO',exact:true}).click();await expect(detail).toContainText('No data: no explicit polygon/reporting-unit match.');
  64  |  await page.getByLabel('Map layer',{exact:true}).selectOption('history');await expect(page.getByLabel('Historical year')).toHaveValue('2020');
  65  |  await page.getByLabel('Historical source week').selectOption('2020-01-05');expect(external).toEqual([]);
  66  | });
  67  | 
  68  | test('Dashboard and Manila map panel expose saved MAEs and backtest values, with bilingual core pages and privacy',async({page})=>{
  69  |  const data=await read('public/api/v2/manila.json');
  70  |  for(const path of ['/','/risk-map']){
  71  |   await goto(page,path);await expect(page.getByRole('heading',{name:'Current risk unavailable'})).toBeVisible();
  72  |   for(const h of [1,2]){const expected=data.summaries.find((r:any)=>r.scenario==='M'&&r.fold==='test-2018-2023'&&r.model==='naive'&&r.horizon===h).mae;await expect(page.locator(`[data-panel-horizon="${h}"]`)).toHaveAttribute('data-panel-mae',String(expected));}
  73  |  }
  74  |  for(const [path,heading] of [['/','Hindi alam ang panganib ngayon'],['/risk-map','MGA PATTERN, HINDI HULA.'],['/report','Unawain at pumayag']]){
  75  |   await goto(page,path);await page.getByRole('button',{name:'Filipino',exact:true}).click();await expect(page.getByRole('heading',{name:heading,exact:true})).toBeVisible();await expect(page.locator('html')).toHaveAttribute('lang','fil');
  76  |   await page.getByRole('button',{name:'English',exact:true}).click();
  77  |  }
  78  |  await page.getByRole('contentinfo').getByRole('button',{name:'Privacy notice',exact:true}).click();await expect(activeView(page)).toContainText('RA 10173');
  79  |  await expect(activeView(page)).toContainText('No system can promise perfect anonymity');
  80  | });
  81  | 
  82  | 
  83  | test('Dashboard numeric analytics reproduce published series, exact backtest rows and forecast values',async({page})=>{
  84  |  await goto(page,'/');const data=await read('public/api/v2/manila.json'),backtest=await read('public/api/v2/dashboard.json');
  85  |  const format=(v:number,digits=1)=>v.toLocaleString('en-PH',{maximumFractionDigits:digits});
  86  |  for(const scenario of ['M','Z']){
  87  |   await page.getByLabel('Absent-day scenario',{exact:true}).selectOption(scenario);
  88  |   const snapshot=data.snapshots.find((r:any)=>r.scenario===scenario);
  89  |   const forecasts=page.locator('.forecast-pair article');await expect(forecasts).toHaveCount(2);
  90  |   for(let i=0;i<2;i++){const f=snapshot.forecasts[i];await expect(forecasts.nth(i)).toContainText(format(f.predicted));await expect(forecasts.nth(i)).toContainText(f.target);if(f.low80!==null)await expect(forecasts.nth(i)).toContainText(format(f.low80)+'–'+format(f.high80));}
  91  |   const years=page.getByRole('region',{name:'Year comparison'}).locator('tbody tr');await expect(years).toHaveCount(snapshot.year_comparison.length);
  92  |   for(let i=0;i<snapshot.year_comparison.length;i++){const r=snapshot.year_comparison[i];await expect(years.nth(i)).toContainText(format(r.scorable_cases,0));await expect(years.nth(i)).toContainText(r.observed_week_count+' / '+r.calendar_week_count);}
  93  |   for(let m=1;m<=12;m++){const observed=data.series[scenario].filter((r:any)=>r.cases!==null&&Number(r.week_ending.slice(5,7))===m),mean=observed.reduce((s:number,r:any)=>s+r.cases,0)/observed.length;await expect(page.locator('.season-bars>div').nth(m-1).locator('span').last()).toHaveText(format(mean));}
  94  |   const detail=page.locator('details').filter({has:page.getByText('Backtest data table',{exact:true})});if((await detail.getAttribute('open'))===null)await detail.locator('summary').click();
  95  |   await expect(detail.locator('table')).toBeVisible();
  96  |   const expected=backtest.rows.filter((r:any)=>r.scenario===scenario);await expect(detail.locator('tbody tr')).toHaveCount(expected.length);
  97  |   for(let i=0;i<expected.length;i++){const r=expected[i];await expect(detail.locator('tbody tr').nth(i).locator('th,td')).toHaveText([r.origin,r.target,String(r.actual),String(r.predicted)]);}
  98  |  }
  99  | });
  100 | 
  101 | 
  102 | test('historical map layer and accessible table expose the same saved year/week counts',async({page})=>{
  103 |  // Synthetic local aggregate fixtures test filtering only; these never enter shipped data or a model.
  104 |  await page.route('**/rest/v1/rpc/community_signal_aggregates**',r=>r.fulfill({status:200,contentType:'application/json',body:JSON.stringify([{area_label:'ABRA',week_start:'2020-01-05',report_count:3},{area_label:'CEBU',week_start:'2020-01-05',report_count:5}])}));
  105 |  await goto(page,'/risk-map');const data=await read('public/api/v2/outlook.json'),geo=await read('public/geo/philippines.geojson');
  106 |  await page.getByLabel('Map layer',{exact:true}).selectOption('history');await page.getByLabel('Historical year').selectOption('2019');
  107 |  const table=page.locator('details').filter({has:page.getByText('Data table: all reporting units and unmatched areas',{exact:true})});await table.locator('summary').click();
  108 |  for(const week of ['', '2019-09-08']){
  109 |   await page.getByLabel('Historical source week').selectOption(week);
  110 |   for(const name of Object.keys(data.profiles)){
  111 |    const tr=table.locator('tbody tr').filter({has:page.getByRole('button',{name,exact:true})}),records=data.history[name].filter((r:any)=>r.date.startsWith('2019')&&(!week||r.date===week));
  112 |    const matched=geo.features.some((f:any)=>f.properties.case_name===name),expected=matched&&records.length?records.reduce((total:number,r:any)=>total+r.cases,0).toLocaleString('en-PH'):'No data';
  113 |    await expect(tr.locator('td').first()).toHaveText(expected);
  114 |   }
  115 |  }
  116 |  await expect(page.locator('.map-legend')).toContainText('Lower recorded count');
  117 |  await expect(page.locator('.province-detail')).not.toContainText('Weather forecast');
  118 |  await expect(page.locator('.map-page')).toContainText('Historical period: 2019');
  119 |  await page.getByLabel('Map layer',{exact:true}).selectOption('community');await expect(table).toHaveCount(0);await page.getByLabel('Search province / city').fill('CEBU');const groups=page.getByRole('region',{name:'Unverified community aggregates'});await expect(groups.locator('tbody tr')).toHaveCount(1);await expect(groups).toContainText('CEBU');await expect(groups).not.toContainText('ABRA');
  120 | });
  121 | 
```