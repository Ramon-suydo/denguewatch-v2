# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: demo-keyboard.spec.ts >> keyboard skip link, visible focus and reduced motion
- Location: tests\ui\demo-keyboard.spec.ts:3:1

# Error details

```
Error: Actual keyboard indicator on a light map card

expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 3
Received:    1.662872072525193
```

# Page snapshot

```yaml
- generic [ref=f1e2]:
  - generic [ref=f1e3]:
    - link "Skip to content" [ref=f1e5] [cursor=pointer]:
      - /url: "#main"
    - banner [ref=f1e6]:
      - link "DengueWatch home" [ref=f1e7] [cursor=pointer]:
        - /url: /
        - text: DENGUE
        - generic [ref=f1e8]: WATCH
      - navigation "Main navigation" [ref=f1e9]:
        - link "Dashboard" [ref=f1e10] [cursor=pointer]:
          - /url: /
        - link "Risk Map" [ref=f1e11] [cursor=pointer]:
          - /url: /risk-map
        - link "Community Report" [ref=f1e12] [cursor=pointer]:
          - /url: /report
      - generic "Page language" [ref=f1e13]:
        - button "English" [pressed] [ref=f1e14] [cursor=pointer]
        - button "Filipino" [ref=f1e15] [cursor=pointer]
    - main [ref=f1e16]:
      - generic [ref=f1e17]:
        - paragraph [ref=f1e18]: PHILIPPINES / RELATIVE OUTLOOK
        - heading "PATTERNS, NOT PREDICTIONS." [level=1] [ref=f1e19]
        - paragraph [ref=f1e20]: Explore historical burden and the season ahead. An outlook is not a forecast of case counts.
        - complementary [ref=f1e21]: Outlook = relative seasonal patterns and historical burden, not predicted case counts. Weather is not used without validation. Only Manila has a historical calibrated case-forecast panel; current risk is unavailable.
        - generic [ref=f1e22]:
          - generic [ref=f1e23]:
            - generic [ref=f1e24]: Search province / city
            - searchbox "Search province / city" [ref=f1e25]
          - generic [ref=f1e26]:
            - generic [ref=f1e27]:
              - generic [ref=f1e28]: Map layer
              - combobox "Map layer" [ref=f1e29] [cursor=pointer]:
                - option "Outlook Index" [selected]
                - option "Historical recorded burden (2016–2020)"
                - option "Community-reported signals (unverified)"
            - group "Outlook day window" [ref=f1e30]:
              - button "Today" [pressed] [ref=f1e31] [cursor=pointer]
              - button "+3 days" [ref=f1e32] [cursor=pointer]
              - button "+7 days" [ref=f1e33] [cursor=pointer]
          - paragraph [ref=f1e34]: "Selected window: 2026-10-25. Case data as of 2021-01-10."
          - paragraph [ref=f1e35]: Large provinces can rank higher simply because more people live there. Population-adjusted risk is not verified.
        - generic [ref=f1e36]:
          - generic [ref=f1e37]:
            - group "Map pan and zoom" [ref=f1e38]:
              - button "Zoom in" [active] [ref=f1e39] [cursor=pointer]: +
              - button "Zoom out" [ref=f1e40] [cursor=pointer]: −
              - button "Reset" [ref=f1e41] [cursor=pointer]
              - button "Pan ←" [ref=f1e42] [cursor=pointer]: ←
              - button "Pan →" [ref=f1e43] [cursor=pointer]: →
              - button "Pan ↑" [ref=f1e44] [cursor=pointer]: ↑
              - button "Pan ↓" [ref=f1e45] [cursor=pointer]: ↓
            - group "Philippines province and city map" [ref=f1e46]:
              - generic [ref=f1e47]:
                - 'button "Abra: Outlook Index 24, relative seasonal conditions" [ref=f1e49] [cursor=pointer]'
                - 'button "Agusan del Norte: Outlook Index 12, relative seasonal conditions" [ref=f1e51] [cursor=pointer]'
                - 'button "Agusan del Sur: Outlook Index 53.6, relative seasonal conditions" [ref=f1e53] [cursor=pointer]'
                - 'button "Aklan: Outlook Index 62.4, relative seasonal conditions" [ref=f1e55] [cursor=pointer]'
                - 'button "Albay: Outlook Index 21.6, relative seasonal conditions" [ref=f1e57] [cursor=pointer]'
                - 'button "Antique: Outlook Index 54.4, relative seasonal conditions" [ref=f1e59] [cursor=pointer]'
                - 'button "Apayao: Outlook Index 52.8, relative seasonal conditions" [ref=f1e61] [cursor=pointer]'
                - 'button "Aurora: Outlook Index 20.8, relative seasonal conditions" [ref=f1e63] [cursor=pointer]'
                - 'button "Basilan: Outlook Index 8, relative seasonal conditions" [ref=f1e65] [cursor=pointer]'
                - 'button "Bataan: Outlook Index 84.8, relative seasonal conditions" [ref=f1e67] [cursor=pointer]'
                - 'button "Batanes: Outlook Index 0.8, relative seasonal conditions" [ref=f1e69] [cursor=pointer]'
                - 'button "Batangas: Outlook Index 94.4, relative seasonal conditions" [ref=f1e71] [cursor=pointer]'
                - 'button "Benguet: Outlook Index 41.6, relative seasonal conditions" [ref=f1e73] [cursor=pointer]'
                - 'button "Biliran: Outlook Index 19.2, relative seasonal conditions" [ref=f1e75] [cursor=pointer]'
                - 'button "Bohol: Outlook Index 92, relative seasonal conditions" [ref=f1e77] [cursor=pointer]'
                - 'button "Bukidnon: Outlook Index 85.6, relative seasonal conditions" [ref=f1e79] [cursor=pointer]'
                - 'button "Bulacan: Outlook Index 96, relative seasonal conditions" [ref=f1e81] [cursor=pointer]'
                - 'button "Cagayan: Outlook Index 76.8, relative seasonal conditions" [ref=f1e83] [cursor=pointer]'
                - 'button "Camarines Norte: Outlook Index 31.2, relative seasonal conditions" [ref=f1e85] [cursor=pointer]'
                - 'button "Camarines Sur: Outlook Index 65.6, relative seasonal conditions" [ref=f1e87] [cursor=pointer]'
                - 'button "Camiguin: Outlook Index 38.4, relative seasonal conditions" [ref=f1e89] [cursor=pointer]'
                - 'button "Capiz: Outlook Index 56, relative seasonal conditions" [ref=f1e91] [cursor=pointer]'
                - 'button "Catanduanes: Outlook Index 5.6, relative seasonal conditions" [ref=f1e93] [cursor=pointer]'
                - 'button "Cavite: Outlook Index 100, relative seasonal conditions" [ref=f1e95] [cursor=pointer]'
                - 'button "Cebu: Outlook Index 98.4, relative seasonal conditions" [ref=f1e97] [cursor=pointer]'
                - 'button "City of Isabela: Outlook Index 25.6, relative seasonal conditions" [ref=f1e99] [cursor=pointer]'
                - 'button "Compostela Valley: No data" [ref=f1e101] [cursor=pointer]'
                - 'button "Cotabato: No data" [ref=f1e103] [cursor=pointer]'
                - 'button "Cotabato City: Outlook Index 16, relative seasonal conditions" [ref=f1e105] [cursor=pointer]'
                - 'button "Davao del Norte: Outlook Index 36.8, relative seasonal conditions" [ref=f1e107] [cursor=pointer]'
                - 'button "Davao del Sur: Outlook Index 7.2, relative seasonal conditions" [ref=f1e109] [cursor=pointer]'
                - 'button "Davao Occidental: Outlook Index 0, relative seasonal conditions" [ref=f1e111] [cursor=pointer]'
                - 'button "Davao Oriental: Outlook Index 32.8, relative seasonal conditions" [ref=f1e113] [cursor=pointer]'
                - 'button "Dinagat Islands: Outlook Index 10.8, relative seasonal conditions" [ref=f1e115] [cursor=pointer]'
                - 'button "Eastern Samar: Outlook Index 58.4, relative seasonal conditions" [ref=f1e117] [cursor=pointer]'
                - 'button "Guimaras: Outlook Index 12.8, relative seasonal conditions" [ref=f1e119] [cursor=pointer]'
                - 'button "Ifugao: Outlook Index 40, relative seasonal conditions" [ref=f1e121] [cursor=pointer]'
                - 'button "Ilocos Norte: Outlook Index 76, relative seasonal conditions" [ref=f1e123] [cursor=pointer]'
                - 'button "Ilocos Sur: Outlook Index 69.6, relative seasonal conditions" [ref=f1e125] [cursor=pointer]'
                - 'button "Iloilo: Outlook Index 84, relative seasonal conditions" [ref=f1e127] [cursor=pointer]'
                - 'button "Isabela: Outlook Index 88, relative seasonal conditions" [ref=f1e129] [cursor=pointer]'
                - 'button "Kalinga: Outlook Index 51.2, relative seasonal conditions" [ref=f1e131] [cursor=pointer]'
                - 'button "La Union: Outlook Index 60.8, relative seasonal conditions" [ref=f1e133] [cursor=pointer]'
                - 'button "Laguna: Outlook Index 99.2, relative seasonal conditions" [ref=f1e135] [cursor=pointer]'
                - 'button "Lanao del Norte: Outlook Index 79.2, relative seasonal conditions" [ref=f1e137] [cursor=pointer]'
                - 'button "Lanao del Sur: Outlook Index 49.6, relative seasonal conditions" [ref=f1e139] [cursor=pointer]'
                - 'button "Leyte: Outlook Index 73.6, relative seasonal conditions" [ref=f1e141] [cursor=pointer]'
                - 'button "Maguindanao: Outlook Index 20, relative seasonal conditions" [ref=f1e143] [cursor=pointer]'
                - 'button "Marinduque: Outlook Index 6.4, relative seasonal conditions" [ref=f1e145] [cursor=pointer]'
                - 'button "Masbate: Outlook Index 24.8, relative seasonal conditions" [ref=f1e147] [cursor=pointer]'
                - 'button "Misamis Occidental: Outlook Index 63.2, relative seasonal conditions" [ref=f1e149] [cursor=pointer]'
                - 'button "Misamis Oriental: Outlook Index 80.8, relative seasonal conditions" [ref=f1e151] [cursor=pointer]'
                - 'button "Mountain Province: Outlook Index 15.2, relative seasonal conditions" [ref=f1e153] [cursor=pointer]'
                - 'button "NCR, City of Manila, First District: No data" [ref=f1e155] [cursor=pointer]'
                - 'button "NCR, Fourth District: No data" [ref=f1e157] [cursor=pointer]'
                - 'button "NCR, Second District: No data" [ref=f1e159] [cursor=pointer]'
                - 'button "NCR, Third District: No data" [ref=f1e161] [cursor=pointer]'
                - 'button "Negros Occidental: Outlook Index 91.2, relative seasonal conditions" [ref=f1e163] [cursor=pointer]'
                - 'button "Negros Oriental: Outlook Index 89.6, relative seasonal conditions" [ref=f1e165] [cursor=pointer]'
                - 'button "Northern Samar: Outlook Index 68, relative seasonal conditions" [ref=f1e167] [cursor=pointer]'
                - 'button "Nueva Ecija: Outlook Index 92.8, relative seasonal conditions" [ref=f1e169] [cursor=pointer]'
                - 'button "Nueva Vizcaya: No data" [ref=f1e171] [cursor=pointer]'
                - 'button "Occidental Mindoro: Outlook Index 34.4, relative seasonal conditions" [ref=f1e173] [cursor=pointer]'
                - 'button "Oriental Mindoro: Outlook Index 48.8, relative seasonal conditions" [ref=f1e175] [cursor=pointer]'
                - 'button "Palawan: Outlook Index 64, relative seasonal conditions" [ref=f1e177] [cursor=pointer]'
                - 'button "Pampanga: Outlook Index 95.2, relative seasonal conditions" [ref=f1e179] [cursor=pointer]'
                - 'button "Pangasinan: Outlook Index 96.8, relative seasonal conditions" [ref=f1e181] [cursor=pointer]'
                - 'button "Quezon: Outlook Index 90.4, relative seasonal conditions" [ref=f1e183] [cursor=pointer]'
                - 'button "Quirino: Outlook Index 64.8, relative seasonal conditions" [ref=f1e185] [cursor=pointer]'
                - 'button "Rizal: Outlook Index 93.6, relative seasonal conditions" [ref=f1e187] [cursor=pointer]'
                - 'button "Romblon: Outlook Index 8.8, relative seasonal conditions" [ref=f1e189] [cursor=pointer]'
                - 'button "Samar: Outlook Index 77.6, relative seasonal conditions" [ref=f1e191] [cursor=pointer]'
                - 'button "Sarangani: Outlook Index 44, relative seasonal conditions" [ref=f1e193] [cursor=pointer]'
                - 'button "Siquijor: No data" [ref=f1e195] [cursor=pointer]'
                - 'button "Sorsogon: Outlook Index 36, relative seasonal conditions" [ref=f1e197] [cursor=pointer]'
                - 'button "South Cotabato: Outlook Index 71.2, relative seasonal conditions" [ref=f1e199] [cursor=pointer]'
                - 'button "Southern Leyte: Outlook Index 27.2, relative seasonal conditions" [ref=f1e201] [cursor=pointer]'
                - 'button "Sultan Kudarat: Outlook Index 23.2, relative seasonal conditions" [ref=f1e203] [cursor=pointer]'
                - 'button "Sulu: Outlook Index 3.2, relative seasonal conditions" [ref=f1e205] [cursor=pointer]'
                - 'button "Surigao del Norte: Outlook Index 39.2, relative seasonal conditions" [ref=f1e207] [cursor=pointer]'
                - 'button "Surigao del Sur: Outlook Index 57.6, relative seasonal conditions" [ref=f1e209] [cursor=pointer]'
                - 'button "Tarlac: Outlook Index 88.8, relative seasonal conditions" [ref=f1e211] [cursor=pointer]'
                - 'button "Tawi-Tawi: Outlook Index 1.6, relative seasonal conditions" [ref=f1e213] [cursor=pointer]'
                - 'button "Zambales: Outlook Index 56.8, relative seasonal conditions" [ref=f1e215] [cursor=pointer]'
                - 'button "Zamboanga del Norte: Outlook Index 75.2, relative seasonal conditions" [ref=f1e217] [cursor=pointer]'
                - 'button "Zamboanga del Sur: Outlook Index 37.6, relative seasonal conditions" [ref=f1e219] [cursor=pointer]'
                - 'button "Zamboanga Sibugay: Outlook Index 59.2, relative seasonal conditions" [ref=f1e221] [cursor=pointer]'
                - 'button "City of Manila: Outlook Index 87.2, relative seasonal conditions" [pressed] [ref=f1e223] [cursor=pointer]'
                - 'button "City of Mandaluyong: Outlook Index 32, relative seasonal conditions" [ref=f1e225] [cursor=pointer]'
                - 'button "City of Marikina: Outlook Index 44.8, relative seasonal conditions" [ref=f1e227] [cursor=pointer]'
                - 'button "City of Pasig: Outlook Index 80, relative seasonal conditions" [ref=f1e229] [cursor=pointer]'
                - 'button "Quezon City: Outlook Index 97.6, relative seasonal conditions" [ref=f1e231] [cursor=pointer]'
                - 'button "City of San Juan: Outlook Index 22.4, relative seasonal conditions" [ref=f1e233] [cursor=pointer]'
                - 'button "Caloocan City: Outlook Index 78.4, relative seasonal conditions" [ref=f1e235] [cursor=pointer]'
                - 'button "City of Malabon: Outlook Index 74.4, relative seasonal conditions" [ref=f1e237] [cursor=pointer]'
                - 'button "City of Navotas: Outlook Index 28, relative seasonal conditions" [ref=f1e239] [cursor=pointer]'
                - 'button "City of Valenzuela: Outlook Index 52, relative seasonal conditions" [ref=f1e241] [cursor=pointer]'
                - 'button "City of Las Piñas: Outlook Index 55.2, relative seasonal conditions" [ref=f1e243] [cursor=pointer]'
                - 'button "City of Makati: Outlook Index 48, relative seasonal conditions" [ref=f1e245] [cursor=pointer]'
                - 'button "City of Muntinlupa: Outlook Index 45.6, relative seasonal conditions" [ref=f1e247] [cursor=pointer]'
                - 'button "City of Parañaque: Outlook Index 81.6, relative seasonal conditions" [ref=f1e249] [cursor=pointer]'
                - 'button "Pasay City: Outlook Index 47.2, relative seasonal conditions" [ref=f1e251] [cursor=pointer]'
                - 'button "Pateros: Outlook Index 10.8, relative seasonal conditions" [ref=f1e253] [cursor=pointer]'
                - 'button "Taguig City: Outlook Index 70.4, relative seasonal conditions" [ref=f1e255] [cursor=pointer]'
            - generic [ref=f1e256]:
              - generic [ref=f1e257]: Lower relative index
              - generic [ref=f1e259]: Upper relative index (hatched)
            - paragraph [ref=f1e260]: "Gray diagonal pattern: no matched data. Labels and table duplicate every value; colour does not indicate confirmed risk."
          - generic [ref=f1e261]:
            - paragraph [ref=f1e262]: SELECTED REPORTING UNIT
            - heading "MANILA CITY" [level=2] [ref=f1e263]
            - paragraph [ref=f1e264]: "87.2"
            - paragraph [ref=f1e265]: Outlook Index / 100 · relative rank 17 among reporting units
            - paragraph [ref=f1e266]: "Seasonal expectation vs its own historical weekly mean: 167%"
            - paragraph [ref=f1e267]: "Last available case record: 2021-01-10"
            - paragraph [ref=f1e268]: "Weather forecast context only, not used in this index: 29.8 °C · 0.1 mm rain. Open-Meteo."
            - paragraph [ref=f1e269]: Centroid weather represents coarse grid cells of about 9–50 km, not neighbourhood or household conditions.
            - link "About the data & methods" [ref=f1e270] [cursor=pointer]:
              - /url: "?drawer=methods"
        - group [ref=f1e272]:
          - 'generic "Data table: all reporting units and unmatched areas" [ref=f1e273] [cursor=pointer]'
        - generic [ref=f1e274]:
          - heading "How reliable is this map?" [level=2] [ref=f1e275]
          - paragraph [ref=f1e276]: These are retrospective rankings of recorded case counts, not population-adjusted risk. Results vary by year, missing coverage and the COVID period. Seasonal history did not improve every year.
          - paragraph [ref=f1e277]: Lagged weather did not consistently beat both seasonal-only baselines across held-out years and all three metrics.
          - region "National map validation metrics" [ref=f1e278]:
            - table [ref=f1e279]:
              - rowgroup [ref=f1e280]:
                - row [ref=f1e281]:
                  - columnheader "Test year" [ref=f1e282]
                  - columnheader "Model" [ref=f1e283]
                  - columnheader "Weeks" [ref=f1e284]
                  - columnheader "Min units" [ref=f1e285]
                  - columnheader "Spearman ↑" [ref=f1e286]
                  - columnheader "Top-10 hit rate ↑" [ref=f1e287]
                  - columnheader "Normalized rank error ↓" [ref=f1e288]
              - rowgroup [ref=f1e289]:
                - row [ref=f1e290]:
                  - rowheader "2018" [ref=f1e291]
                  - cell "burden-only" [ref=f1e292]
                  - cell "52" [ref=f1e293]
                  - cell "126" [ref=f1e294]
                  - cell "0.748" [ref=f1e295]
                  - cell "0.529" [ref=f1e296]
                  - cell "0.156" [ref=f1e297]
                - row [ref=f1e298]:
                  - rowheader "2018" [ref=f1e299]
                  - cell "lagged-weather-weather-cohort" [ref=f1e300]
                  - cell "52" [ref=f1e301]
                  - cell "96" [ref=f1e302]
                  - cell "0.751" [ref=f1e303]
                  - cell "0.575" [ref=f1e304]
                  - cell "0.152" [ref=f1e305]
                - row [ref=f1e306]:
                  - rowheader "2018" [ref=f1e307]
                  - cell "season-burden" [ref=f1e308]
                  - cell "52" [ref=f1e309]
                  - cell "126" [ref=f1e310]
                  - cell "0.741" [ref=f1e311]
                  - cell "0.492" [ref=f1e312]
                  - cell "0.158" [ref=f1e313]
                - row [ref=f1e314]:
                  - rowheader "2018" [ref=f1e315]
                  - cell "season-burden-weather-cohort" [ref=f1e316]
                  - cell "52" [ref=f1e317]
                  - cell "96" [ref=f1e318]
                  - cell "0.759" [ref=f1e319]
                  - cell "0.542" [ref=f1e320]
                  - cell "0.152" [ref=f1e321]
                - row [ref=f1e322]:
                  - rowheader "2018" [ref=f1e323]
                  - cell "season-ridge-weather-cohort" [ref=f1e324]
                  - cell "52" [ref=f1e325]
                  - cell "96" [ref=f1e326]
                  - cell "0.777" [ref=f1e327]
                  - cell "0.56" [ref=f1e328]
                  - cell "0.146" [ref=f1e329]
                - row [ref=f1e330]:
                  - rowheader "2019" [ref=f1e331]
                  - cell "burden-only" [ref=f1e332]
                  - cell "51" [ref=f1e333]
                  - cell "126" [ref=f1e334]
                  - cell "0.738" [ref=f1e335]
                  - cell "0.516" [ref=f1e336]
                  - cell "0.16" [ref=f1e337]
                - row [ref=f1e338]:
                  - rowheader "2019" [ref=f1e339]
                  - cell "lagged-weather-weather-cohort" [ref=f1e340]
                  - cell "51" [ref=f1e341]
                  - cell "96" [ref=f1e342]
                  - cell "0.769" [ref=f1e343]
                  - cell "0.588" [ref=f1e344]
                  - cell "0.15" [ref=f1e345]
                - row [ref=f1e346]:
                  - rowheader "2019" [ref=f1e347]
                  - cell "season-burden" [ref=f1e348]
                  - cell "51" [ref=f1e349]
                  - cell "126" [ref=f1e350]
                  - cell "0.767" [ref=f1e351]
                  - cell "0.569" [ref=f1e352]
                  - cell "0.149" [ref=f1e353]
                - row [ref=f1e354]:
                  - rowheader "2019" [ref=f1e355]
                  - cell "season-burden-weather-cohort" [ref=f1e356]
                  - cell "51" [ref=f1e357]
                  - cell "96" [ref=f1e358]
                  - cell "0.772" [ref=f1e359]
                  - cell "0.563" [ref=f1e360]
                  - cell "0.147" [ref=f1e361]
                - row [ref=f1e362]:
                  - rowheader "2019" [ref=f1e363]
                  - cell "season-ridge-weather-cohort" [ref=f1e364]
                  - cell "51" [ref=f1e365]
                  - cell "96" [ref=f1e366]
                  - cell "0.775" [ref=f1e367]
                  - cell "0.584" [ref=f1e368]
                  - cell "0.146" [ref=f1e369]
                - row [ref=f1e370]:
                  - rowheader "2020" [ref=f1e371]
                  - cell "burden-only" [ref=f1e372]
                  - cell "52" [ref=f1e373]
                  - cell "80" [ref=f1e374]
                  - cell "0.622" [ref=f1e375]
                  - cell "0.321" [ref=f1e376]
                  - cell "0.194" [ref=f1e377]
                - row [ref=f1e378]:
                  - rowheader "2020" [ref=f1e379]
                  - cell "lagged-weather-weather-cohort" [ref=f1e380]
                  - cell "52" [ref=f1e381]
                  - cell "59" [ref=f1e382]
                  - cell "0.67" [ref=f1e383]
                  - cell "0.423" [ref=f1e384]
                  - cell "0.181" [ref=f1e385]
                - row [ref=f1e386]:
                  - rowheader "2020" [ref=f1e387]
                  - cell "season-burden" [ref=f1e388]
                  - cell "52" [ref=f1e389]
                  - cell "80" [ref=f1e390]
                  - cell "0.65" [ref=f1e391]
                  - cell "0.412" [ref=f1e392]
                  - cell "0.185" [ref=f1e393]
                - row [ref=f1e394]:
                  - rowheader "2020" [ref=f1e395]
                  - cell "season-burden-weather-cohort" [ref=f1e396]
                  - cell "52" [ref=f1e397]
                  - cell "59" [ref=f1e398]
                  - cell "0.675" [ref=f1e399]
                  - cell "0.431" [ref=f1e400]
                  - cell "0.179" [ref=f1e401]
                - row [ref=f1e402]:
                  - rowheader "2020" [ref=f1e403]
                  - cell "season-ridge-weather-cohort" [ref=f1e404]
                  - cell "52" [ref=f1e405]
                  - cell "59" [ref=f1e406]
                  - cell "0.678" [ref=f1e407]
                  - cell "0.421" [ref=f1e408]
                  - cell "0.179" [ref=f1e409]
          - paragraph [ref=f1e410]: "Each test year uses strictly earlier years. Spearman compares within-week ranks; top-10 hit rate is overlap / 10; normalized error is mean absolute rank difference / (unit count − 1). Missing observations are excluded, never zero-filled. Regenerate: npm run evaluate:map."
        - generic [ref=f1e411]:
          - paragraph [ref=f1e412]: MANILA / HISTORICAL CASE FORECAST
          - heading "Current risk unavailable" [level=2] [ref=f1e413]
          - paragraph [ref=f1e414]: The case record is too old to establish current risk. This is the only case-forecast panel; the national map is a relative outlook.
          - paragraph [ref=f1e415]:
            - text: Data as of
            - time [ref=f1e416]: 2023-12-02
            - text: · Forecast origin 2023-11-26 · Scenario M
          - heading "Historical Manila forecast" [level=3] [ref=f1e417]
          - generic [ref=f1e418]:
            - article [ref=f1e419]:
              - heading "1 week(s) ahead" [level=3] [ref=f1e420]
              - paragraph [ref=f1e421]: 62 estimated cases
              - paragraph [ref=f1e422]: "Historical target: 2023-12-03"
              - paragraph [ref=f1e423]: "80% interval: 40–84"
            - article [ref=f1e424]:
              - heading "2 week(s) ahead" [level=3] [ref=f1e425]
              - paragraph [ref=f1e426]: 62 estimated cases
              - paragraph [ref=f1e427]: "Historical target: 2023-12-10"
              - paragraph [ref=f1e428]: "80% interval: 31–93"
          - paragraph [ref=f1e429]:
            - text: "Measured historical error (MAE, cases):"
            - generic [ref=f1e430]: "1 week(s): 15.47."
            - generic [ref=f1e431]: "2 week(s): 22.90."
          - paragraph [ref=f1e432]: One-week persistence means last week's value. These are retrospective estimates, not a warning for the coming days.
          - paragraph [ref=f1e433]: Remove standing water, protect against bites and seek early consultation for symptoms.
      - complementary [ref=f1e434]:
        - heading "Estimates, not alerts" [level=2] [ref=f1e435]
        - paragraph [ref=f1e436]: Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.
    - contentinfo [ref=f1e437]:
      - generic [ref=f1e438]:
        - link "About & Credits" [ref=f1e439] [cursor=pointer]:
          - /url: /about
        - button "About the data & methods" [ref=f1e440] [cursor=pointer]
      - paragraph [ref=f1e441]:
        - text: Bundled source periods.
        - time [ref=f1e442]: Dec 2, 2023
        - text: ·
        - time [ref=f1e443]: Jan 10, 2021
        - text: . Historical, not live.
      - paragraph [ref=f1e444]: Community reports are unverified; not medical advice.
      - paragraph [ref=f1e445]: Background photograph by Sumarie Slabber
      - paragraph [ref=f1e446]: Thesis research · Not an official DOH product · Historical records, not a live warning.
  - status
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { mockPublicApi } from "../fixtures/public-fixtures";
  3  | test("keyboard skip link, visible focus and reduced motion", async ({ page }) => {
  4  |   await mockPublicApi(page, { open: false });
  5  |   await page.emulateMedia({ reducedMotion: "reduce" });
  6  |   await page.goto("/");
  7  |   await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
  8  |   await page.evaluate(() => { document.body.tabIndex = -1; document.body.focus(); });
  9  |   await page.keyboard.press("Tab");
  10 |   const skip = page.getByRole("link", { name: "Skip to content" });
  11 |   await expect(skip).toBeFocused();
  12 |   expect(await skip.evaluate(e => e.getBoundingClientRect().top)).toBeGreaterThanOrEqual(0);
  13 |   expect(await skip.evaluate(e => getComputedStyle(e).outlineStyle)).not.toBe("none");
  14 |   await page.keyboard.press("Enter");
  15 |   await expect(page.locator("#main")).toBeFocused();
  16 |   expect(await page.evaluate(() => [...document.querySelectorAll("*")].every(e => {
  17 |     const style = getComputedStyle(e);
  18 |     return style.animationName === "none" && style.transitionDuration === "0s";
  19 |   }))).toBeTruthy();
  20 |   await page.goto('/risk-map');
  21 |   const zoom=page.getByRole('button',{name:'Zoom in',exact:true});await expect(zoom).toBeVisible();await page.keyboard.press('Tab');await zoom.focus();
  22 |   function contrast(a:string,b:string){const luminance=(color:string)=>{const rgb=color.match(/[0-9.]+/g)!.slice(0,3).map(Number).map(v=>v/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4);return .2126*rgb[0]+.7152*rgb[1]+.0722*rgb[2];};const x=luminance(a),y=luminance(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);}
  23 |   const ring=await zoom.evaluate(element=>{const s=getComputedStyle(element),background=getComputedStyle(element.closest('.ui-card')!).backgroundColor;return {outline:s.outlineStyle==='none'?null:s.outlineColor,shadow:s.boxShadow.match(/rgba?\([^)]+\)/)?.[0]??null,background};});
> 24 |   expect(Math.max(...[ring.outline,ring.shadow].filter((c):c is string=>c!==null).map(c=>contrast(c,ring.background))),'Actual keyboard indicator on a light map card').toBeGreaterThanOrEqual(3);
     |                                                                                                                                                                         ^ Error: Actual keyboard indicator on a light map card
  25 |   const province=page.locator('.national-map [data-case-unit="MANILA CITY"]');await expect(province).toBeVisible();await province.focus();await expect(province).toBeFocused();
  26 |   const path=await province.evaluate(element=>{const s=getComputedStyle(element);return {fill:s.fill,stroke:s.stroke,outline:s.outlineStyle==='none'?null:s.outlineColor};});
  27 |   expect(Math.max(...[path.stroke,path.outline].filter((c):c is string=>c!==null).map(c=>contrast(c,path.fill))),'Actual province focus on a dark choropleth class').toBeGreaterThanOrEqual(3);
  28 | 
  29 | });
  30 | 
```