# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: evidence.spec.ts >> research pages: mobile/desktop, no overflow, no critical or serious axe issues
- Location: tests\ui\evidence.spec.ts:5:1

# Error details

```
Error: [{"id":"color-contrast","impact":"serious","tags":["cat.color","wcag2aa","wcag143","TTv5","TT13.c","EN-301-549","EN-9.1.4.3","ACT","RGAAv4","RGAA-3.2.1"],"description":"Ensure the contrast between foreground and background colors meets WCAG 2 AA minimum contrast ratio thresholds","help":"Elements must meet minimum color contrast ratio thresholds","helpUrl":"https://dequeuniversity.com/rules/axe/4.13/color-contrast?application=playwright","nodes":[{"any":[{"id":"color-contrast","data":{"fgColor":"#102a43","bgColor":"#0f1a3d","contrastRatio":1.16,"fontSize":"13.5pt (18px)","fontWeight":"normal","messageKey":null,"expectedContrastRatio":"4.5:1"},"relatedNodes":[{"html":"<button type=\"button\" class=\"ui-button ui-button-ghost\" aria-pressed=\"true\">English</button>","target":[".ui-container > .language-control[aria-label=\"Page language\"] > .ui-button-ghost.ui-button[type=\"button\"]:nth-child(1)"]}],"impact":"serious","message":"Element has insufficient color contrast of 1.16 (foreground color: #102a43, background color: #0f1a3d, font size: 13.5pt (18px), font weight: normal). Expected contrast ratio of 4.5:1"}],"all":[],"none":[],"impact":"serious","html":"<button type=\"button\" class=\"ui-button ui-button-ghost\" aria-pressed=\"true\">English</button>","target":[".ui-container > .language-control[aria-label=\"Page language\"] > .ui-button-ghost.ui-button[type=\"button\"]:nth-child(1)"],"failureSummary":"Fix any of the following:\n  Element has insufficient color contrast of 1.16 (foreground color: #102a43, background color: #0f1a3d, font size: 13.5pt (18px), font weight: normal). Expected contrast ratio of 4.5:1"}]}]

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 58

- Array []
+ Array [
+   Object {
+     "description": "Ensure the contrast between foreground and background colors meets WCAG 2 AA minimum contrast ratio thresholds",
+     "help": "Elements must meet minimum color contrast ratio thresholds",
+     "helpUrl": "https://dequeuniversity.com/rules/axe/4.13/color-contrast?application=playwright",
+     "id": "color-contrast",
+     "impact": "serious",
+     "nodes": Array [
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "bgColor": "#0f1a3d",
+               "contrastRatio": 1.16,
+               "expectedContrastRatio": "4.5:1",
+               "fgColor": "#102a43",
+               "fontSize": "13.5pt (18px)",
+               "fontWeight": "normal",
+               "messageKey": null,
+             },
+             "id": "color-contrast",
+             "impact": "serious",
+             "message": "Element has insufficient color contrast of 1.16 (foreground color: #102a43, background color: #0f1a3d, font size: 13.5pt (18px), font weight: normal). Expected contrast ratio of 4.5:1",
+             "relatedNodes": Array [
+               Object {
+                 "html": "<button type=\"button\" class=\"ui-button ui-button-ghost\" aria-pressed=\"true\">English</button>",
+                 "target": Array [
+                   ".ui-container > .language-control[aria-label=\"Page language\"] > .ui-button-ghost.ui-button[type=\"button\"]:nth-child(1)",
+                 ],
+               },
+             ],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Element has insufficient color contrast of 1.16 (foreground color: #102a43, background color: #0f1a3d, font size: 13.5pt (18px), font weight: normal). Expected contrast ratio of 4.5:1",
+         "html": "<button type=\"button\" class=\"ui-button ui-button-ghost\" aria-pressed=\"true\">English</button>",
+         "impact": "serious",
+         "none": Array [],
+         "target": Array [
+           ".ui-container > .language-control[aria-label=\"Page language\"] > .ui-button-ghost.ui-button[type=\"button\"]:nth-child(1)",
+         ],
+       },
+     ],
+     "tags": Array [
+       "cat.color",
+       "wcag2aa",
+       "wcag143",
+       "TTv5",
+       "TT13.c",
+       "EN-301-549",
+       "EN-9.1.4.3",
+       "ACT",
+       "RGAAv4",
+       "RGAA-3.2.1",
+     ],
+   },
+ ]
```

# Page snapshot

```yaml
- generic [ref=f4e2]:
  - generic [ref=f4e3]:
    - link "Skip to content" [ref=f4e5] [cursor=pointer]:
      - /url: "#main"
    - banner [ref=f4e6]:
      - link "DengueWatch home" [ref=f4e7] [cursor=pointer]:
        - /url: /
        - text: DENGUE
        - generic [ref=f4e8]: WATCH
      - button "Menu" [ref=f4e9] [cursor=pointer]
      - generic "Page language" [ref=f4e10]:
        - button "English" [pressed] [ref=f4e11] [cursor=pointer]
        - button "Filipino" [ref=f4e12] [cursor=pointer]
    - main [ref=f4e13]:
      - generic [ref=f4e14]:
        - region [ref=f4e15]:
          - generic [ref=f4e18]:
            - generic [ref=f4e19]: THESIS PROJECT
            - generic [ref=f4e20]: CITY DATA THROUGH 2020-12-27
          - generic [ref=f4e21]:
            - generic [ref=f4e22]: Replay · historical example
            - heading "DENGUE WATCH MANILA" [level=1] [ref=f4e23]: DENGUE WATCHMANILA
            - paragraph [ref=f4e24]: Explore next-week city estimates through historical examples.
            - generic [ref=f4e25]:
              - link "Explore map" [ref=f4e26] [cursor=pointer]:
                - /url: /risk-map
              - link "Report a case" [ref=f4e27] [cursor=pointer]:
                - /url: /report
        - generic [ref=f4e28]:
          - region "Forecast mode" [ref=f4e29]:
            - generic [ref=f4e30]:
              - text: Replay · historical example
              - paragraph [ref=f4e31]: Example week from our test data.
              - paragraph [ref=f4e32]:
                - text: Showing week of
                - time [ref=f4e33]: 2019-09-01
            - generic [ref=f4e34]:
              - generic [ref=f4e35]:
                - button "Replay" [pressed] [ref=f4e36] [cursor=pointer]
                - button "Live" [disabled] [ref=f4e37]
              - paragraph [ref=f4e38]: Live needs recent weekly counts for all 17 cities.
              - paragraph [ref=f4e39]: Ask the project admin to upload reviewed counts.
          - region [ref=f4e40]:
            - generic [ref=f4e41]:
              - paragraph [ref=f4e42]: YOUR QUICK VIEW
              - heading "Cities to watch" [level=2] [ref=f4e43]
              - paragraph [ref=f4e44]: 14 city areas have higher estimates.
              - paragraph [ref=f4e45]:
                - generic [ref=f4e46]:
                  - text: "17"
                  - generic [ref=f4e47]: "17"
                - text: city areas in view.
              - list [ref=f4e48]:
                - listitem [ref=f4e49]:
                  - link "Muntinlupa High more than 9 in 10" [ref=f4e50] [cursor=pointer]:
                    - /url: /risk-map
                    - strong [ref=f4e51]: Muntinlupa
                    - generic [ref=f4e52]:
                      - generic [aria-hidden] [ref=f4e53]: "!"
                      - text: High
                    - generic [ref=f4e54]: more than 9 in 10
                - listitem [ref=f4e55]:
                  - link "Paranaque High more than 9 in 10" [ref=f4e56] [cursor=pointer]:
                    - /url: /risk-map
                    - strong [ref=f4e57]: Paranaque
                    - generic [ref=f4e58]:
                      - generic [aria-hidden] [ref=f4e59]: "!"
                      - text: High
                    - generic [ref=f4e60]: more than 9 in 10
                - listitem [ref=f4e61]:
                  - link "Taguig High more than 9 in 10" [ref=f4e62] [cursor=pointer]:
                    - /url: /risk-map
                    - strong [ref=f4e63]: Taguig
                    - generic [ref=f4e64]:
                      - generic [aria-hidden] [ref=f4e65]: "!"
                      - text: High
                    - generic [ref=f4e66]: more than 9 in 10
              - paragraph [ref=f4e67]: These are research estimates, not official outbreak declarations.
          - generic [ref=f4e68]:
            - paragraph [ref=f4e69]: SMALL STEPS MATTER
            - heading "What should I do?" [level=2] [ref=f4e70]
            - generic [ref=f4e71]:
              - article [ref=f4e72]:
                - generic [aria-hidden] [ref=f4e73]: ◉
                - heading "Clear standing water" [level=3] [ref=f4e74]
                - paragraph [ref=f4e75]: Empty containers. Cover stored water. Clean places where mosquitoes breed.
              - article [ref=f4e76]:
                - generic [aria-hidden] [ref=f4e77]: ◇
                - heading "Protect against bites" [level=3] [ref=f4e78]
                - paragraph [ref=f4e79]: Use repellent as directed. Wear protective clothing. Use screens or nets.
              - article [ref=f4e80]:
                - generic [aria-hidden] [ref=f4e81]: ＋
                - heading "Seek care early" [level=3] [ref=f4e82]
                - paragraph [ref=f4e83]: Seek medical care for fever or worsening symptoms.
            - group [ref=f4e84]:
              - generic "Know the urgent warning signs" [ref=f4e85] [cursor=pointer]
            - paragraph [ref=f4e86]:
              - text: "Prevention guidance: DOH 4S. Warning signs: CDC."
              - link "DOH / MOH" [ref=f4e87] [cursor=pointer]:
                - /url: https://bangsamoro.gov.ph/news/latest-news/moh-urges-public-to-observe-4s-strategy-against-dengue/
          - generic [ref=f4e88]:
            - paragraph [ref=f4e89]: THREE SIMPLE STEPS
            - heading "How it works" [level=2] [ref=f4e90]
            - list [ref=f4e91]:
              - listitem [ref=f4e92]:
                - generic [ref=f4e93]: "01"
                - heading "Data" [level=3] [ref=f4e94]
                - paragraph [ref=f4e95]: We collect recorded weekly city counts.
              - listitem [ref=f4e96]:
                - generic [ref=f4e97]: "02"
                - heading "Model" [level=3] [ref=f4e98]
                - paragraph [ref=f4e99]: We compare computer estimates with a simple rule.
              - listitem [ref=f4e100]:
                - generic [ref=f4e101]: "03"
                - heading "Map" [level=3] [ref=f4e102]
                - paragraph [ref=f4e103]: We show city-level estimates with clear dates.
            - paragraph [ref=f4e104]: "Our question: can past counts flag next-week dengue increases?"
          - group [ref=f4e105]:
            - 'generic "Evidence: see how the models performed" [ref=f4e106] [cursor=pointer]'
      - complementary [ref=f4e107]:
        - heading "Estimates, not alerts" [level=2] [ref=f4e108]
        - paragraph [ref=f4e109]: Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.
    - contentinfo [ref=f4e110]:
      - generic [ref=f4e111]:
        - link "About & Credits" [ref=f4e112] [cursor=pointer]:
          - /url: /about
        - button "About the data & methods" [ref=f4e113] [cursor=pointer]
      - paragraph [ref=f4e114]:
        - text: Bundled source periods.
        - time [ref=f4e115]: Dec 2, 2023
        - text: ·
        - time [ref=f4e116]: Dec 27, 2020
        - text: . Replay uses historical records. Live needs reviewed recent counts.
      - paragraph [ref=f4e117]: Community reports are unverified; not medical advice.
      - paragraph [ref=f4e118]: Background photograph by Sumarie Slabber
      - paragraph [ref=f4e119]: Thesis research · Not an official DOH product · Historical records, not a live warning.
    - dialog [ref=f4e120]:
      - generic [ref=f4e121]:
        - heading "About the data & methods" [level=2] [ref=f4e122]
        - button "Close dialog" [active] [ref=f4e123] [cursor=pointer]: ✕
      - generic [ref=f4e124]:
        - paragraph [ref=f4e125]: Current city models use historical NCR data through 2020-12-27. Replay is the default. Older Manila research remains below as an archive.
        - link "About & Credits" [ref=f4e126] [cursor=pointer]:
          - /url: /about
        - generic [ref=f4e127]:
          - generic [ref=f4e128]: Research detail
          - combobox "Research detail" [ref=f4e129] [cursor=pointer]:
            - 'option "City classification: methods and evidence"'
            - option "Archived Manila analytics"
            - option "Separate community aggregates"
            - option "Evaluation and limitations"
            - option "Source coverage and integrity"
            - option "Complete historical tables"
            - option "NCR historical city archive"
            - option "Full prevention and warning signs" [selected]
            - option "Terms of Use"
            - option "Legal and privacy notices"
            - option "Prior research summary"
        - generic [ref=f4e130]:
          - generic "Page language" [ref=f4e131]:
            - button "English" [pressed] [ref=f4e132] [cursor=pointer]
            - button "Filipino" [ref=f4e133] [cursor=pointer]
          - paragraph [ref=f4e134]: PREVENTION / EVERYDAY CARE
          - heading "Small actions. Everyday protection." [level=1] [ref=f4e135]
          - paragraph [ref=f4e136]: Informational, not a diagnosis.
          - generic [ref=f4e137]:
            - heading "The DOH 4S strategy" [level=2] [ref=f4e138]
            - list [ref=f4e139]:
              - listitem [ref=f4e140]: Find and remove mosquito breeding places, including water-holding containers.
              - listitem [ref=f4e141]: Use protective clothing and mosquito repellent.
              - listitem [ref=f4e142]: Seek early consultation when symptoms appear.
              - listitem [ref=f4e143]: Support fogging or spraying in identified hotspots under health-office guidance.
            - paragraph [ref=f4e144]:
              - link "DOH Central Visayas · 4S guidance" [ref=f4e145] [cursor=pointer]:
                - /url: https://ro7.doh.gov.ph/news-and-advisories/98-press-releases/2514-doh-central-visayas-chd-underscores-the-significance-of-4s-in-dengue-mitigation
              - text: · Checked 2026-10-25.
          - generic [ref=f4e146]:
            - heading "Warning signs need urgent care" [level=2] [ref=f4e147]
            - paragraph [ref=f4e148]: Go to a clinic or emergency room immediately for abdominal pain or tenderness, repeated vomiting, nose or gum bleeding, blood in vomit or stool, or extreme tiredness or restlessness. Warning signs can begin after fever subsides.
            - paragraph [ref=f4e149]: Do not wait for an app risk level or report confirmation before seeking care.
            - paragraph [ref=f4e150]:
              - link "CDC · dengue symptoms and warning signs" [ref=f4e151] [cursor=pointer]:
                - /url: https://www.cdc.gov/dengue/signs-symptoms/
              - text: · Checked 2026-10-25.
  - status
```

# Test source

```ts
  1   | import {goto,activeView} from '../support/active-view';
  2   | import { test, expect } from "@playwright/test";
  3   | import AxeBuilder from "@axe-core/playwright";
  4   | import { mkdir } from "node:fs/promises";
  5   | test("research pages: mobile/desktop, no overflow, no critical or serious axe issues", async ({
  6   |   page,
  7   | }) => {
  8   |   test.setTimeout(180000);
  9   |   const errors: string[] = [];
  10  |   page.on("pageerror", (e) => errors.push(e.message));
  11  |   for (const width of [360, 768, 1280])
  12  |     for (const route of [
  13  |       "/",
  14  |       "/trends",
  15  |       "/metro-manila",
  16  |       "/methodology",
  17  |       "/prevention",
  18  |     ]) {
  19  |       await page.setViewportSize({ width, height: 900 });
  20  |       await goto(page, route);
  21  |       await expect(activeView(page).locator("h1")).toBeVisible();
  22  |       if (route === "/")
  23  |         await expect(
  24  |           activeView(page).getByRole("heading", { name: "Cities to watch" }),
  25  |         ).toBeVisible();
  26  |       if (route === "/metro-manila")
  27  |         await expect(page.locator(".ncr-city-map path")).toHaveCount(17);
  28  |       if (route === "/methodology")
  29  |         await expect(
  30  |           activeView(page).getByRole("heading", { name: "Forecast comparison" }),
  31  |         ).toBeVisible();
  32  |       expect(
  33  |         await page.evaluate(
  34  |           () => document.documentElement.scrollWidth <= window.innerWidth,
  35  |         ),
  36  |       ).toBe(true);
  37  |       const a = await new AxeBuilder({ page }).analyze();
  38  |       expect(
  39  |         a.violations.filter((v) =>
  40  |           ["critical", "serious"].includes(v.impact ?? ""),
  41  |         ),
  42  |         JSON.stringify(a.violations),
> 43  |       ).toEqual([]);
      |         ^ Error: [{"id":"color-contrast","impact":"serious","tags":["cat.color","wcag2aa","wcag143","TTv5","TT13.c","EN-301-549","EN-9.1.4.3","ACT","RGAAv4","RGAA-3.2.1"],"description":"Ensure the contrast between foreground and background colors meets WCAG 2 AA minimum contrast ratio thresholds","help":"Elements must meet minimum color contrast ratio thresholds","helpUrl":"https://dequeuniversity.com/rules/axe/4.13/color-contrast?application=playwright","nodes":[{"any":[{"id":"color-contrast","data":{"fgColor":"#102a43","bgColor":"#0f1a3d","contrastRatio":1.16,"fontSize":"13.5pt (18px)","fontWeight":"normal","messageKey":null,"expectedContrastRatio":"4.5:1"},"relatedNodes":[{"html":"<button type=\"button\" class=\"ui-button ui-button-ghost\" aria-pressed=\"true\">English</button>","target":[".ui-container > .language-control[aria-label=\"Page language\"] > .ui-button-ghost.ui-button[type=\"button\"]:nth-child(1)"]}],"impact":"serious","message":"Element has insufficient color contrast of 1.16 (foreground color: #102a43, background color: #0f1a3d, font size: 13.5pt (18px), font weight: normal). Expected contrast ratio of 4.5:1"}],"all":[],"none":[],"impact":"serious","html":"<button type=\"button\" class=\"ui-button ui-button-ghost\" aria-pressed=\"true\">English</button>","target":[".ui-container > .language-control[aria-label=\"Page language\"] > .ui-button-ghost.ui-button[type=\"button\"]:nth-child(1)"],"failureSummary":"Fix any of the following:\n  Element has insufficient color contrast of 1.16 (foreground color: #102a43, background color: #0f1a3d, font size: 13.5pt (18px), font weight: normal). Expected contrast ratio of 4.5:1"}]}]
  44  |     }
  45  |   expect(errors).toEqual([]);
  46  |   await mkdir(".artifacts/evidence-ui", { recursive: true });
  47  |   await goto(page, "/");
  48  |   await expect(
  49  |     activeView(page).getByRole("heading", { name: "Cities to watch" }),
  50  |   ).toBeVisible();
  51  |   await page.evaluate(() => document.fonts.ready);
  52  |   await page.screenshot({
  53  |     path: ".artifacts/evidence-ui/home-1280.png",
  54  |     fullPage: true,
  55  |   });
  56  |   await page.setViewportSize({ width: 360, height: 900 });
  57  |   await page.screenshot({
  58  |     path: ".artifacts/evidence-ui/home-360.png",
  59  |     fullPage: true,
  60  |   });
  61  | });
  62  | test("scenario and year changes keep absence explicit; NCR remains historical", async ({
  63  |   page,
  64  | }) => {
  65  |   await goto(page, "/trends");
  66  |   await expect(
  67  |     activeView(page).getByRole("heading", { name: "Weekly recorded cases" }),
  68  |   ).toBeVisible();
  69  |   await activeView(page).getByLabel("Absent-day scenario").selectOption("Z");
  70  |   await expect(
  71  |     activeView(page).getByText("Zero is assumed only", { exact: false }),
  72  |   ).toBeVisible();
  73  |   await activeView(page).getByLabel("History year").selectOption("2020");
  74  |   await activeView(page).getByText("Exact weekly values and quality flags").click();
  75  |   await expect(
  76  |     activeView(page).getByRole("region", { name: "Weekly history data table" }),
  77  |   ).toBeVisible();
  78  |   await goto(page, "/metro-manila");
  79  |   await expect(
  80  |     activeView(page).getByText("Data ends January 2021.", { exact: true }),
  81  |   ).toBeVisible();
  82  |   await activeView(page).getByLabel("Comparison period").selectOption("week");
  83  |   await activeView(page).getByLabel("Week label").selectOption("2016-11-06");
  84  |   await expect(page.locator(".ncr-city-map path")).toHaveCount(17);
  85  | });
  86  | test("Filipino home/prevention, missing API retry, and legacy forecasts isolated", async ({
  87  |   page,
  88  | }) => {
  89  |   await goto(page, "/");
  90  |   await activeView(page).getByRole("button", { name: "Filipino", exact: true }).click();
  91  |   await expect(
  92  |     activeView(page).getByRole("heading", { name: "Mga dapat bantayan" }),
  93  |   ).toBeVisible();
  94  |   await goto(page, "/prevention");
  95  |   await expect(activeView(page).getByRole("heading", { name: "4S ng DOH" })).toBeVisible();
  96  |   await goto(page, "/city/old-id");
  97  |   await expect(page).toHaveURL(/\/\?drawer=methods&section=trends$/);
  98  |   let failedRequests = 0;
  99  |   await page.route("**/ml/summary.json", (route) => {
  100 |     failedRequests++;
  101 |     return route.fulfill({ status: 503, body: "Unavailable" });
  102 |   });
  103 |   await goto(page, "/");
  104 |   await expect(activeView(page).getByRole("alert")).toContainText("Hindi ma-load");
  105 |   expect(failedRequests).toBeGreaterThan(0);
  106 |   await expect(activeView(page).getByRole("button", { name: "Subukan muli" })).toBeVisible();
  107 |   await page.unroute("**/ml/summary.json");
  108 |   await activeView(page).getByRole("button", { name: "Subukan muli" }).click();
  109 |   await expect(
  110 |     activeView(page).getByRole("heading", { name: "Mga dapat bantayan" }),
  111 |   ).toBeVisible();
  112 | });
  113 | 
```