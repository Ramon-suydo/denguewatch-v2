# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: redesign.spec.ts >> three navigation destinations, footer attribution, empty owner fields and old-route drawers
- Location: tests\ui\redesign.spec.ts:8:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 64

- Array []
+ Array [
+   Object {
+     "description": "Ensure the contrast between foreground and background colors meets WCAG 2 AA minimum contrast ratio thresholds",
+     "help": "Elements must meet minimum color contrast ratio thresholds",
+     "helpUrl": "https://dequeuniversity.com/rules/axe/4.13/color-contrast?application=playwright",
+     "id": "color-contrast",
+     "impact": "serious",
+     "nodes": Array [
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "bgColor": "#f4f7f8",
+               "contrastRatio": 1.03,
+               "expectedContrastRatio": "4.5:1",
+               "fgColor": "#f8fbfc",
+               "fontSize": "7.5pt (10px)",
+               "fontWeight": "normal",
+               "messageKey": null,
+             },
+             "id": "color-contrast",
+             "impact": "serious",
+             "message": "Element has insufficient color contrast of 1.03 (foreground color: #f8fbfc, background color: #f4f7f8, font size: 7.5pt (10px), font weight: normal). Expected contrast ratio of 4.5:1",
+             "relatedNodes": Array [
+               Object {
+                 "html": "<details class=\"maplibregl-ctrl maplibregl-ctrl-attrib\" open=\"\">",
+                 "target": Array [
+                   "details",
+                 ],
+               },
+               Object {
+                 "html": "<div class=\"map-drawing\" role=\"status\">Drawing city areas…</div>",
+                 "target": Array [
+                   ".map-drawing",
+                 ],
+               },
+             ],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Element has insufficient color contrast of 1.03 (foreground color: #f8fbfc, background color: #f4f7f8, font size: 7.5pt (10px), font weight: normal). Expected contrast ratio of 4.5:1",
+         "html": "<div class=\"maplibregl-ctrl-attrib-inner\"><a href=\"https://openfreemap.org\" target=\"_blank\">OpenFreeMap</a> <a href=\"https://www.openmaptiles.org/\" target=\"_blank\">© OpenMapTiles</a> Data from <a href=\"https://www.openstreetmap.org/copyright\" target=\"_blank\">OpenStreetMap</a></div>",
+         "impact": "serious",
+         "none": Array [],
+         "target": Array [
+           ".maplibregl-ctrl-attrib-inner",
+         ],
+       },
+     ],
+     "tags": Array [
+       "cat.color",
+       "wcag2aa",
+       "wcag143",
+       "TTv5",
+       "TT13.c",
+       "EN-301-549",
+       "EN-9.1.4.3",
+       "ACT",
+       "RGAAv4",
+       "RGAA-3.2.1",
+     ],
+   },
+ ]
```

# Page snapshot

```yaml
- generic [ref=f5e2]:
  - generic [ref=f5e3]:
    - link "Skip to content" [ref=f5e5] [cursor=pointer]:
      - /url: "#main"
    - banner [ref=f5e6]:
      - link "DengueWatch home" [ref=f5e7] [cursor=pointer]:
        - /url: /
        - text: DENGUE
        - generic [ref=f5e8]: WATCH
      - navigation "Main navigation" [ref=f5e9]:
        - link "Dashboard" [ref=f5e10] [cursor=pointer]:
          - /url: /
        - link "Risk Map" [ref=f5e11] [cursor=pointer]:
          - /url: /risk-map
        - link "Community Report" [ref=f5e12] [cursor=pointer]:
          - /url: /report
      - generic "Page language" [ref=f5e13]:
        - button "English" [pressed] [ref=f5e14] [cursor=pointer]
        - button "Filipino" [ref=f5e15] [cursor=pointer]
    - main [ref=f5e16]:
      - generic [ref=f5e17]:
        - generic [ref=f5e18]:
          - generic [ref=f5e19]:
            - paragraph [ref=f5e20]: METRO MANILA · 17 AREAS
            - heading "Risk Map" [level=1] [ref=f5e21]
          - link "What should I do?" [ref=f5e22] [cursor=pointer]:
            - /url: /#actions
        - region "Forecast mode" [ref=f5e23]:
          - generic [ref=f5e24]:
            - text: Replay · historical example
            - paragraph [ref=f5e25]: Example week from our test data.
            - paragraph [ref=f5e26]:
              - text: Showing week of
              - time [ref=f5e27]: 2019-09-01
          - generic [ref=f5e28]:
            - generic [ref=f5e29]:
              - button "Replay" [pressed] [ref=f5e30] [cursor=pointer]
              - button "Live" [disabled] [ref=f5e31]
            - paragraph [ref=f5e32]: Live needs recent weekly counts for all 17 cities.
            - paragraph [ref=f5e33]: Ask the project admin to upload reviewed counts.
        - paragraph [ref=f5e34]: An outbreak here means unusually high recorded cases. It is not an official declaration.
        - generic [ref=f5e35]:
          - generic [ref=f5e36]:
            - text: Find a city
            - searchbox "Find a city" [ref=f5e37]
          - button "Show data table" [ref=f5e38] [cursor=pointer]
          - generic [ref=f5e39]:
            - checkbox "High contrast" [ref=f5e40]
            - text: High contrast
          - generic [ref=f5e41]:
            - checkbox "Tilt map" [disabled] [ref=f5e42]
            - text: Tilt map
        - group "Choose a city" [ref=f5e43]:
          - button "Caloocan. more than 9 in 10" [ref=f5e44] [cursor=pointer]: Caloocan
          - button "Las Pinas. more than 9 in 10" [ref=f5e45] [cursor=pointer]: Las Pinas
          - button "Makati. more than 9 in 10" [ref=f5e46] [cursor=pointer]: Makati
          - button "Malabon. more than 9 in 10" [ref=f5e47] [cursor=pointer]: Malabon
          - button "Mandaluyong. about 8 in 10" [ref=f5e48] [cursor=pointer]: Mandaluyong
          - button "Manila. more than 9 in 10" [pressed] [ref=f5e49] [cursor=pointer]: Manila
          - button "Marikina. more than 9 in 10" [ref=f5e50] [cursor=pointer]: Marikina
          - button "Muntinlupa. more than 9 in 10" [ref=f5e51] [cursor=pointer]: Muntinlupa
          - button "Navotas. about 6 in 10" [ref=f5e52] [cursor=pointer]: Navotas
          - button "Paranaque. more than 9 in 10" [ref=f5e53] [cursor=pointer]: Paranaque
          - button "Pasay. more than 9 in 10" [ref=f5e54] [cursor=pointer]: Pasay
          - button "Pasig. more than 9 in 10" [ref=f5e55] [cursor=pointer]: Pasig
          - button "Pateros. less than 1 in 10" [ref=f5e56] [cursor=pointer]: Pateros
          - button "Quezon. more than 9 in 10" [ref=f5e57] [cursor=pointer]: Quezon
          - button "San Juan. about 9 in 10" [ref=f5e58] [cursor=pointer]: San Juan
          - button "Taguig. more than 9 in 10" [ref=f5e59] [cursor=pointer]: Taguig
          - button "Valenzuela. more than 9 in 10" [ref=f5e60] [cursor=pointer]: Valenzuela
        - generic [ref=f5e61]:
          - generic [ref=f5e62]:
            - generic "Interactive city map" [ref=f5e64]:
              - region "Metro Manila city risk map. Arrow keys cycle cities. Enter selects." [ref=f5e65]
              - generic:
                - generic [ref=f5e66]:
                  - button "Zoom in" [ref=f5e67] [cursor=pointer]
                  - button "Zoom out" [ref=f5e69] [cursor=pointer]
                - group [ref=f5e71]:
                  - generic [ref=f5e72]:
                    - link "OpenFreeMap" [ref=f5e73] [cursor=pointer]:
                      - /url: https://openfreemap.org
                    - link "© OpenMapTiles" [ref=f5e74] [cursor=pointer]:
                      - /url: https://www.openmaptiles.org/
                    - text: Data from
                    - link "OpenStreetMap" [ref=f5e75] [cursor=pointer]:
                      - /url: https://www.openstreetmap.org/copyright
            - status: "Map: online"
            - paragraph [ref=f5e76]: OpenFreeMap, OpenMapTiles, data from OpenStreetMap contributors
          - complementary "Selected city" [ref=f5e77]:
            - paragraph [ref=f5e78]: CITY DETAIL
            - heading "Manila" [level=2] [ref=f5e79]
            - generic [ref=f5e80]:
              - generic [aria-hidden] [ref=f5e81]: "!"
              - text: High
            - paragraph [ref=f5e82]: "Chance of an outbreak next week:"
            - paragraph [ref=f5e83]: more than 9 in 10
            - paragraph [ref=f5e84]: Recent counts were already high for this city.
            - paragraph [ref=f5e85]: ↑ Last recorded count rose.
            - img "Eight-week recorded cases. Missing weeks leave gaps." [ref=f5e86]
            - paragraph [ref=f5e88]: Recorded cases over eight weeks.
            - paragraph [ref=f5e89]: "Latest recorded count: 144"
            - generic [ref=f5e90]:
              - heading "What actually happened" [level=3] [ref=f5e91]
              - paragraph [ref=f5e92]: "Yes: cases were unusually high."
              - paragraph [ref=f5e93]: 179 recorded cases
            - paragraph [ref=f5e94]: In past test weeks at this level, 186 / 199 crossed the threshold.
            - link "What to do now" [ref=f5e95] [cursor=pointer]:
              - /url: /#actions
        - generic "Risk legend" [ref=f5e96]:
          - generic [ref=f5e97]: ○ Low
          - generic [ref=f5e98]: ◔ Watch
          - generic [ref=f5e99]: ▲ Raised
          - generic [ref=f5e100]: "! High"
          - generic [ref=f5e101]: "Resolution: city."
        - generic [ref=f5e102]:
          - button "Play weeks" [disabled] [ref=f5e103]
          - generic [ref=f5e104]:
            - text: Choose an example week
            - slider "Choose an example week" [ref=f5e105]: "0"
          - status [ref=f5e106]: 2019-09-01
          - paragraph [ref=f5e107]: Motion is off. Change weeks with the slider.
        - paragraph [ref=f5e108]:
          - text: The online map contacts OpenFreeMap. Its server receives your IP address.
          - link "Read the methods and privacy limits." [ref=f5e109] [cursor=pointer]:
            - /url: /about#methods
      - complementary [ref=f5e110]:
        - heading "Estimates, not alerts" [level=2] [ref=f5e111]
        - paragraph [ref=f5e112]: Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.
    - contentinfo [ref=f5e113]:
      - generic [ref=f5e114]:
        - link "About & Credits" [ref=f5e115] [cursor=pointer]:
          - /url: /about
        - button "About the data & methods" [ref=f5e116] [cursor=pointer]
      - paragraph [ref=f5e117]:
        - text: Bundled source periods.
        - time [ref=f5e118]: Dec 2, 2023
        - text: ·
        - time [ref=f5e119]: Dec 27, 2020
        - text: . Replay uses historical records. Live needs reviewed recent counts.
      - paragraph [ref=f5e120]: Community reports are unverified; not medical advice.
      - paragraph [ref=f5e121]: Background photograph by Sumarie Slabber
      - paragraph [ref=f5e122]: Thesis research · Not an official DOH product · Historical records, not a live warning.
  - status
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import {readFile} from 'node:fs/promises';
  3  | import AxeBuilder from '@axe-core/playwright';
  4  | import {goto,activeView} from '../support/active-view';
  5  | import {mockPublicApi} from '../fixtures/public-fixtures';
  6  | const read=async(path:string)=>JSON.parse(await readFile(path,'utf8'));
  7  | 
  8  | test('three navigation destinations, footer attribution, empty owner fields and old-route drawers',async({page})=>{
  9  |  test.setTimeout(120000);
  10 |  for(const width of [360,1280])for(const path of ['/','/risk-map','/report','/about']){
  11 |   await page.setViewportSize({width,height:1000});await goto(page,path);
  12 |   if(width===360)await page.getByRole('button',{name:'Menu',exact:true}).click();
  13 |   const nav=page.getByRole('navigation',{name:'Main navigation'});
  14 |   await expect(nav.getByRole('link')).toHaveText(['Dashboard','Risk Map','Community Report']);
  15 |   await expect(nav.getByRole('link',{name:'About & Credits'})).toHaveCount(0);
  16 |   await expect(page.getByRole('contentinfo').getByRole('link',{name:'About & Credits'})).toHaveAttribute('href','/about');
  17 |   await expect(page.getByRole('contentinfo')).toContainText('Background photograph by Sumarie Slabber');
  18 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
> 19 |   expect((await new AxeBuilder({page}).analyze()).violations.filter(v=>['critical','serious'].includes(v.impact??''))).toEqual([]);
     |                                                                                                                        ^ Error: expect(received).toEqual(expected) // deep equality
  20 |  }
  21 |  await goto(page,'/about');await expect(page.locator('#team')).toHaveCount(0);
  22 |  await expect(page.locator('#image-credit')).toContainText('Background photograph by Sumarie Slabber');
  23 |  await expect(page.locator('#image-credit a')).toHaveCount(0);
  24 |  const software=await read('src/content/software-credits.json');
  25 |  await page.locator('#software summary').click();await expect(page.locator('#software tbody tr')).toHaveCount(software.length);
  26 |  await goto(page,'/');await page.getByRole('contentinfo').getByRole('button',{name:'About the data & methods',exact:true}).click();await activeView(page).getByRole('link',{name:'About & Credits',exact:true}).click();await expect(page).toHaveURL(/\/about$/);await expect(page.locator('dialog[open]')).toHaveCount(0);
  27 |  for(const old of ['/trends','/methodology','/data-sources','/prevention','/map','/privacy']){
  28 |   await goto(page,old);await expect(page).not.toHaveURL(new RegExp(old+'$'));
  29 |   await expect(page.locator('dialog[open]')).toBeVisible();
  30 |   await activeView(page).getByRole('button',{name:'Close dialog'}).click();
  31 |   await expect(page.locator('dialog[open]')).toHaveCount(0);
  32 |  }
  33 | });
  34 | 
  35 | test('city map uses all 17 explicit matches and exact saved probabilities, without national or weather data',async({page})=>{
  36 |  await mockPublicApi(page,{open:false});await page.route('https://tiles.openfreemap.org/**',r=>r.abort());
  37 |  const forbidden:string[]=[];page.on('request',r=>{if(/open-meteo|power\.larc|philippines\.geojson|outlook\.json/.test(r.url()))forbidden.push(r.url());});
  38 |  await goto(page,'/risk-map');const geo=await read('public/geo/ncr-cities.geojson'),crosswalk=await read('data/geo/ncr-ml-crosswalk.json'),saved=await read('public/ml/replay.json');
  39 |  expect(geo.features).toHaveLength(17);expect(crosswalk.rows).toHaveLength(17);expect(crosswalk.unmatched).toEqual([]);expect(new Set(crosswalk.rows.map((r:any)=>r.doh_name)).size).toBe(17);
  40 |  await expect(page.locator('.city-picker button')).toHaveCount(17);await expect(page.locator('.forecast-mode')).toContainText('Replay');await expect(page.getByRole('button',{name:'Live',exact:true})).toBeDisabled();
  41 |  await page.waitForFunction(()=>{const host=document.querySelector('.city-map-canvas') as HTMLElement&{cityMap?:{getSource:(id:string)=>{serialize:()=>{data:{features:unknown[]}}}|undefined;getLayer:(id:string)=>unknown;queryRenderedFeatures:(query:unknown)=>unknown[]}}|null;const map=host?.cityMap;return map?.getSource('ncr-risk')?.serialize().data.features.length===17&&map.getLayer('ncr-fill')&&map.queryRenderedFeatures({layers:['ncr-fill']}).length>0;});
  42 |  await page.getByRole('button',{name:'Show data table',exact:true}).click();const table=page.getByRole('region',{name:'City prediction data'});await expect(table.locator('tbody tr')).toHaveCount(17);
  43 |  const expected=saved.rows.filter((r:any)=>r.target===saved.weeks[0]);for(const r of expected)await expect(table.locator(`tr[data-city-row="${r.city}"]`)).toHaveAttribute('data-probability',String(r.probability));
  44 |  await page.getByLabel('Find a city',{exact:true}).fill('Manila');await expect(table.locator('tbody tr')).toHaveCount(1);await expect(table).toContainText('Manila');await expect(page.locator('.traffic-legend')).toContainText('Resolution: city.');expect(forbidden).toEqual([]);
  45 | });
  46 | 
  47 | test('Dashboard and Manila map panel expose saved MAEs and backtest values, with bilingual core pages and privacy',async({page})=>{
  48 |  const data=await read('public/api/v2/manila.json');
  49 |  for(const path of ['/about?drawer=methods&section=dashboard']){
  50 |   await goto(page,path);await expect(activeView(page).getByRole('heading',{name:'Current risk unavailable'})).toBeVisible();
  51 |   for(const h of [1,2]){const expected=data.summaries.find((r:any)=>r.scenario==='M'&&r.fold==='test-2018-2023'&&r.model==='naive'&&r.horizon===h).mae;await expect(page.locator(`[data-panel-horizon="${h}"]`)).toHaveAttribute('data-panel-mae',String(expected));}
  52 |  }
  53 |  for(const [path,heading] of [['/','Mga dapat bantayan'],['/risk-map','Mapa ng Panganib'],['/report','Unawain at pumayag']]){
  54 |   await goto(page,path);await page.getByRole('button',{name:'Filipino',exact:true}).click();await expect(page.getByRole('heading',{name:heading,exact:true})).toBeVisible();await expect(page.locator('html')).toHaveAttribute('lang','fil');
  55 |   await page.getByRole('button',{name:'English',exact:true}).click();
  56 |  }
  57 |  await page.getByRole('contentinfo').getByRole('button',{name:'Privacy notice',exact:true}).click();await expect(activeView(page)).toContainText('RA 10173');
  58 |  await expect(activeView(page)).toContainText('No system can promise perfect anonymity');
  59 | });
  60 | 
  61 | 
  62 | test('Dashboard numeric analytics reproduce published series, exact backtest rows and forecast values',async({page})=>{
  63 |  await goto(page,'/about?drawer=methods&section=dashboard');const data=await read('public/api/v2/manila.json'),backtest=await read('public/api/v2/dashboard.json');
  64 |  const format=(v:number,digits=1)=>v.toLocaleString('en-PH',{maximumFractionDigits:digits});
  65 |  for(const scenario of ['M','Z']){
  66 |   await page.getByLabel('Absent-day scenario',{exact:true}).selectOption(scenario);
  67 |   const snapshot=data.snapshots.find((r:any)=>r.scenario===scenario);
  68 |   const forecasts=page.locator('.forecast-pair article');await expect(forecasts).toHaveCount(2);
  69 |   for(let i=0;i<2;i++){const f=snapshot.forecasts[i];await expect(forecasts.nth(i)).toContainText(format(f.predicted));await expect(forecasts.nth(i)).toContainText(f.target);if(f.low80!==null)await expect(forecasts.nth(i)).toContainText(format(f.low80)+'–'+format(f.high80));}
  70 |   const years=page.getByRole('region',{name:'Year comparison'}).locator('tbody tr');await expect(years).toHaveCount(snapshot.year_comparison.length);
  71 |   for(let i=0;i<snapshot.year_comparison.length;i++){const r=snapshot.year_comparison[i];await expect(years.nth(i)).toContainText(format(r.scorable_cases,0));await expect(years.nth(i)).toContainText(r.observed_week_count+' / '+r.calendar_week_count);}
  72 |   for(let m=1;m<=12;m++){const observed=data.series[scenario].filter((r:any)=>r.cases!==null&&Number(r.week_ending.slice(5,7))===m),mean=observed.reduce((s:number,r:any)=>s+r.cases,0)/observed.length;await expect(page.locator('.season-bars>div').nth(m-1).locator('span').last()).toHaveText(format(mean));}
  73 |   const detail=page.locator('details').filter({has:page.getByText('Backtest data table',{exact:true})});if((await detail.getAttribute('open'))===null)await detail.locator('summary').click();
  74 |   await expect(detail.locator('table')).toBeVisible();
  75 |   const expected=backtest.rows.filter((r:any)=>r.scenario===scenario);await expect(detail.locator('tbody tr')).toHaveCount(expected.length);
  76 |   for(let i=0;i<expected.length;i++){const r=expected[i];await expect(detail.locator('tbody tr').nth(i).locator('th,td')).toHaveText([r.origin,r.target,String(r.actual),String(r.predicted)]);}
  77 |  }
  78 | });
  79 | 
  80 | 
  81 | test('every Replay calendar week and all 17 table rows match saved predictions and missing-data flags',async({page})=>{
  82 |  test.setTimeout(120000);await mockPublicApi(page,{open:false});await page.route('https://tiles.openfreemap.org/**',r=>r.abort());await goto(page,'/risk-map');const data=await read('public/ml/replay.json');await page.getByRole('button',{name:'Show data table',exact:true}).click();const slider=page.getByLabel('Choose an example week',{exact:true});await slider.focus();const table=page.getByRole('region',{name:'City prediction data'});let unavailable=0;
  83 |  for(let i=0;i<data.weeks.length;i++){
  84 |   if(i)await slider.press('ArrowRight');await expect(page.locator('.replay-controls output')).toHaveText(data.weeks[i]);
  85 |   const expected=data.rows.filter((r:any)=>r.target===data.weeks[i]);expect(expected).toHaveLength(17);
  86 |   const actual=await table.locator('tbody tr').evaluateAll(rows=>rows.map(row=>({city:row.getAttribute('data-city-row'),probability:row.getAttribute('data-probability'),level:row.querySelector('[data-risk-level]')?.getAttribute('data-risk-level')})));
  87 |   expect(actual).toEqual(expected.map((r:any)=>({city:r.city,probability:r.probability===null?'missing':String(r.probability),level:r.probability===null?'no-data':String(data.bands.filter((cut:number)=>r.probability>=cut).length)})));unavailable+=expected.filter((r:any)=>r.probability===null).length;
  88 |  }
  89 |  expect(unavailable).toBe(119);await expect(table).toContainText('No estimate');await expect(page.locator('.city-detail')).toContainText('Some source weeks are missing');
  90 | });
  91 | 
```