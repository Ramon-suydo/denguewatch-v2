# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: redesign.spec.ts >> national map uses every explicit match, no guessed areas, exact saved metrics and real calendar windows
- Location: tests\ui\redesign.spec.ts:34:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  getByRole('region', { name: 'Outlook Index data table' }).locator('tbody tr').filter({ has: getByRole('button', { name: 'AGUSAN DEL NORTE', exact: true }) }).locator('td').first()
Expected: "12.0"
Received: "12"
Timeout:  5000ms

Call log:
  - Expect "toHaveText" getByRole('region', { name: 'Outlook Index data table' }).locator('tbody tr').filter({ has: getByRole('button', { name: 'AGUSAN DEL NORTE', exact: true }) }).locator('td').first() with timeout 5000ms
  - waiting for getByRole('region', { name: 'Outlook Index data table' }).locator('tbody tr').filter({ has: getByRole('button', { name: 'AGUSAN DEL NORTE', exact: true }) }).locator('td').first()
    13 × locator resolved to <td data-source="outlook.json.profiles; tied percentile">12</td>
       - unexpected value "12"

```

```yaml
- cell "12"
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import {readFile} from 'node:fs/promises';
  3  | import AxeBuilder from '@axe-core/playwright';
  4  | import {goto,activeView} from '../support/active-view';
  5  | import {outlookRows,type Outlook} from '../../src/redesign/outlook';
  6  | const read=async(path:string)=>JSON.parse(await readFile(path,'utf8'));
  7  | 
  8  | test('three navigation destinations, footer attribution, empty owner fields and old-route drawers',async({page})=>{
  9  |  test.setTimeout(120000);
  10 |  for(const width of [360,1280])for(const path of ['/','/risk-map','/report','/about']){
  11 |   await page.setViewportSize({width,height:1000});await goto(page,path);
  12 |   if(width===360)await page.getByRole('button',{name:'Menu',exact:true}).click();
  13 |   const nav=page.getByRole('navigation',{name:'Main navigation'});
  14 |   await expect(nav.getByRole('link')).toHaveText(['Dashboard','Risk Map','Community Report']);
  15 |   await expect(nav.getByRole('link',{name:'About & Credits'})).toHaveCount(0);
  16 |   await expect(page.getByRole('contentinfo').getByRole('link',{name:'About & Credits'})).toHaveAttribute('href','/about');
  17 |   await expect(page.getByRole('contentinfo')).toContainText('Background photograph by Sumarie Slabber');
  18 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  19 |   expect((await new AxeBuilder({page}).analyze()).violations.filter(v=>['critical','serious'].includes(v.impact??''))).toEqual([]);
  20 |  }
  21 |  await goto(page,'/about');await expect(page.locator('#team')).toHaveCount(0);
  22 |  await expect(page.locator('#image-credit')).toContainText('Background photograph by Sumarie Slabber');
  23 |  await expect(page.locator('#image-credit a')).toHaveCount(0);
  24 |  const software=await read('src/content/software-credits.json');
  25 |  await page.locator('#software summary').click();await expect(page.locator('#software tbody tr')).toHaveCount(software.length);
  26 |  for(const old of ['/trends','/methodology','/data-sources','/prevention','/map','/privacy']){
  27 |   await goto(page,old);await expect(page).not.toHaveURL(new RegExp(old+'$'));
  28 |   await expect(page.locator('dialog[open]')).toBeVisible();
  29 |   await activeView(page).getByRole('button',{name:'Close dialog'}).click();
  30 |   await expect(page.locator('dialog[open]')).toHaveCount(0);
  31 |  }
  32 | });
  33 | 
  34 | test('national map uses every explicit match, no guessed areas, exact saved metrics and real calendar windows',async({page})=>{
  35 |  await page.clock.setFixedTime(new Date('2026-10-20T04:00:00Z'));
  36 |  await page.route('**/api/v2/outlook-weather.json',route=>route.fulfill({status:503,body:'Unavailable'}));
  37 |  const external:string[]=[];page.on('request',r=>{if(/open-meteo|power\.larc|tile\./.test(r.url()))external.push(r.url());});
  38 |  await goto(page,'/risk-map');const geo=await read('public/geo/philippines.geojson'),data=await read('public/api/v2/outlook.json') as Outlook;
  39 |  const polygons=page.locator('.national-map [data-boundary-id]');await expect(polygons).toHaveCount(geo.features.length);
  40 |  await expect(page.locator('.national-map [data-no-data="true"]')).toHaveCount(8);
  41 |  expect(geo.features.filter((f:any)=>f.properties.case_name)).toHaveLength(96);
  42 |  await expect(page.locator('.province-detail')).toContainText('Weather forecast unavailable. Seasonal outlook retained.');
  43 |  const detail=page.locator('.province-detail');await expect(detail).not.toContainText('estimated cases');
  44 |  const chosen=polygons.filter({hasNot:page.locator('[data-case-unit=""]')});expect(await chosen.count()).toBeGreaterThan(0);
  45 |  const manila=page.locator('.national-map [data-case-unit="MANILA CITY"]');await manila.focus();await page.keyboard.press('Enter');await expect(manila).toHaveAttribute('aria-pressed','true');
  46 |  const expected=(date:string)=>outlookRows(data,date).find(r=>r.name==='MANILA CITY')!.index!.toLocaleString('en-US',{maximumFractionDigits:1,minimumFractionDigits:1});
  47 |  for(const [label,date] of [['Today','2026-10-20'],['+3 days','2026-10-23'],['+7 days','2026-10-27']]){
  48 |   await page.getByRole('button',{name:label,exact:true}).click();await expect(detail.locator('[data-outlook-index]')).toHaveText(expected(date));
  49 |  }
  50 |  const transform=await page.locator('.national-map>g').getAttribute('transform');await page.getByRole('button',{name:'Zoom in',exact:true}).click();expect(await page.locator('.national-map>g').getAttribute('transform')).not.toBe(transform);
  51 |  await page.getByRole('button',{name:'Reset',exact:true}).click();
  52 |  const table=page.getByRole('region',{name:'Outlook Index data table'});await page.getByText('Data table: all reporting units and unmatched areas',{exact:true}).click();
  53 |  await expect(table.locator('tbody tr')).toHaveCount(134);
  54 |  for(const row of outlookRows(data,'2026-10-27')){
  55 |   const tr=table.locator('tbody tr').filter({has:page.getByRole('button',{name:row.name,exact:true})});
  56 |   const matched=geo.features.some((f:any)=>f.properties.case_name===row.name);
> 57 |   await expect(tr.locator('td').first()).toHaveText(matched?row.index!.toLocaleString('en-US',{maximumFractionDigits:1,minimumFractionDigits:1}):'No data');
     |                                          ^ Error: expect(locator).toHaveText(expected) failed
  58 |  }
  59 |  const metricRows=page.getByRole('region',{name:'National map validation metrics'}).locator('tbody tr');await expect(metricRows).toHaveCount(data.models.length);
  60 |  for(let i=0;i<data.models.length;i++){const r=data.models[i];await expect(metricRows.nth(i).locator('td')).toHaveText([r.model,String(r.weeks),String(r.min_units),r.spearman!.toFixed(3),r.top10_hit_rate.toFixed(3),r.normalized_rank_error.toFixed(3)]);}
  61 |  await page.getByLabel('Search province / city').fill('DAVAO DE ORO');await expect(table.locator('tbody tr')).toHaveCount(1);await expect(table).toContainText('Unmatched: no data');
  62 |  await table.getByRole('button',{name:'DAVAO DE ORO',exact:true}).click();await expect(detail).toContainText('No data: no explicit polygon/reporting-unit match.');
  63 |  await page.getByLabel('Map layer',{exact:true}).selectOption('history');await expect(page.getByLabel('Historical year')).toHaveValue('2020');
  64 |  await page.getByLabel('Historical source week').selectOption('2020-01-05');expect(external).toEqual([]);
  65 | });
  66 | 
  67 | test('Dashboard and Manila map panel expose saved MAEs and backtest values, with bilingual core pages and privacy',async({page})=>{
  68 |  const data=await read('public/api/v2/manila.json');
  69 |  for(const path of ['/','/risk-map']){
  70 |   await goto(page,path);await expect(page.getByRole('heading',{name:'Current risk unavailable'})).toBeVisible();
  71 |   for(const h of [1,2]){const expected=data.summaries.find((r:any)=>r.scenario==='M'&&r.fold==='test-2018-2023'&&r.model==='naive'&&r.horizon===h).mae;await expect(page.locator(`[data-panel-horizon="${h}"]`)).toHaveAttribute('data-panel-mae',String(expected));}
  72 |  }
  73 |  for(const [path,heading] of [['/','Hindi alam ang panganib ngayon'],['/risk-map','MGA PATTERN, HINDI HULA.'],['/report','Unawain at pumayag']]){
  74 |   await goto(page,path);await page.getByRole('button',{name:'Filipino',exact:true}).click();await expect(page.getByRole('heading',{name:heading,exact:true})).toBeVisible();await expect(page.locator('html')).toHaveAttribute('lang','fil');
  75 |   await page.getByRole('button',{name:'English',exact:true}).click();
  76 |  }
  77 |  await page.getByRole('contentinfo').getByRole('button',{name:'Privacy notice',exact:true}).click();await expect(activeView(page)).toContainText('RA 10173');
  78 |  await expect(activeView(page)).toContainText('No system can promise perfect anonymity');
  79 | });
  80 | 
```