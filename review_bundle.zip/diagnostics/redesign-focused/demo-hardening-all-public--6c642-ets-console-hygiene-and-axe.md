# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: demo-hardening.spec.ts >> all public routes retain mobile targets, console hygiene and axe
- Location: tests\ui\demo-hardening.spec.ts:26:1

# Error details

```
Error: /terms 768

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 58

- Array []
+ Array [
+   Object {
+     "description": "Ensure the contrast between foreground and background colors meets WCAG 2 AA minimum contrast ratio thresholds",
+     "help": "Elements must meet minimum color contrast ratio thresholds",
+     "helpUrl": "https://dequeuniversity.com/rules/axe/4.13/color-contrast?application=playwright",
+     "id": "color-contrast",
+     "impact": "serious",
+     "nodes": Array [
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "bgColor": "#0f1a3d",
+               "contrastRatio": 1.16,
+               "expectedContrastRatio": "3:1",
+               "fgColor": "#102a43",
+               "fontSize": "24.0pt (32px)",
+               "fontWeight": "bold",
+               "messageKey": null,
+             },
+             "id": "color-contrast",
+             "impact": "serious",
+             "message": "Element has insufficient color contrast of 1.16 (foreground color: #102a43, background color: #0f1a3d, font size: 24.0pt (32px), font weight: bold). Expected contrast ratio of 3:1",
+             "relatedNodes": Array [
+               Object {
+                 "html": "<section class=\"page-header\">",
+                 "target": Array [
+                   ".page-header",
+                 ],
+               },
+             ],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Element has insufficient color contrast of 1.16 (foreground color: #102a43, background color: #0f1a3d, font size: 24.0pt (32px), font weight: bold). Expected contrast ratio of 3:1",
+         "html": "<h1>Terms with a clear purpose.</h1>",
+         "impact": "serious",
+         "none": Array [],
+         "target": Array [
+           ".ui-container > div > h1",
+         ],
+       },
+     ],
+     "tags": Array [
+       "cat.color",
+       "wcag2aa",
+       "wcag143",
+       "TTv5",
+       "TT13.c",
+       "EN-301-549",
+       "EN-9.1.4.3",
+       "ACT",
+       "RGAAv4",
+       "RGAA-3.2.1",
+     ],
+   },
+ ]
```

# Page snapshot

```yaml
- generic [ref=f32e2]:
  - generic [ref=f32e3]:
    - link "Skip to content" [ref=f32e5] [cursor=pointer]:
      - /url: "#main"
    - banner [ref=f32e6]:
      - link "DengueWatch home" [ref=f32e7] [cursor=pointer]:
        - /url: /
        - text: DENGUE
        - generic [ref=f32e8]: WATCH
      - navigation "Main navigation" [ref=f32e9]:
        - link "Dashboard" [ref=f32e10] [cursor=pointer]:
          - /url: /
        - link "Risk Map" [ref=f32e11] [cursor=pointer]:
          - /url: /risk-map
        - link "Community Report" [ref=f32e12] [cursor=pointer]:
          - /url: /report
      - generic "Page language" [ref=f32e13]:
        - button "English" [pressed] [ref=f32e14] [cursor=pointer]
        - button "Filipino" [ref=f32e15] [cursor=pointer]
    - main [ref=f32e16]:
      - generic [ref=f32e17]:
        - paragraph [ref=f32e18]: THESIS PROJECT / ATTRIBUTION
        - heading "ABOUT & CREDITS" [level=1] [ref=f32e19]
        - paragraph [ref=f32e20]: The people, records and tools behind this research.
        - navigation "About sections" [ref=f32e21]:
          - link "Project" [ref=f32e22] [cursor=pointer]:
            - /url: "#project"
          - link "Data" [ref=f32e23] [cursor=pointer]:
            - /url: "#data-credits"
          - link "Software" [ref=f32e24] [cursor=pointer]:
            - /url: "#software"
          - link "Photograph" [ref=f32e25] [cursor=pointer]:
            - /url: "#image-credit"
        - generic [ref=f32e27]:
          - heading "About the project" [level=2] [ref=f32e28]
          - paragraph [ref=f32e29]: DengueWatch asks whether historical dengue patterns can support earlier awareness while making uncertainty visible. It combines a retrospective Manila case-forecast evaluation, a national seasonal outlook and a separate, privacy-conscious community reporting channel.
          - paragraph [ref=f32e30]: This is not medical advice, a diagnosis, an official DOH product or evidence of institutional affiliation. Old case records cannot establish current risk.
        - generic [ref=f32e32]:
          - heading "Data credits" [level=2] [ref=f32e33]
          - article [ref=f32e34]:
            - heading "DOH Epidemiology Bureau weekly surveillance (EPI)" [level=3] [ref=f32e35]
            - paragraph [ref=f32e36]: Historical province/city counts and seasonal ranking validation
            - generic [ref=f32e37]:
              - term [ref=f32e38]: Coverage
              - definition [ref=f32e39]: 2016-01-10 to 2021-01-10
              - term [ref=f32e40]: Licence / terms
              - definition [ref=f32e41]: unknown; data-owner confirmation required
              - term [ref=f32e42]: Retrieval
              - definition [ref=f32e43]: unknown
            - paragraph [ref=f32e44]: doh-epi-dengue-data-2016-2021.csv
          - article [ref=f32e45]:
            - heading "City of Manila health department" [level=3] [ref=f32e46]
            - paragraph [ref=f32e47]: Daily case data provided to the project team; formal citation pending data owner
            - generic [ref=f32e48]:
              - term [ref=f32e49]: Coverage
              - definition [ref=f32e50]: 2018-01-01 to 2023-12-02
              - term [ref=f32e51]: Licence / terms
              - definition [ref=f32e52]: unknown; attribution and permission required
              - term [ref=f32e53]: Retrieval
              - definition [ref=f32e54]: unknown
            - paragraph [ref=f32e55]: Daily_Reported_Cases_of_Dengue_in_the_City_of_Manila_from_2018_to_2023.xlsx
          - article [ref=f32e56]:
            - heading "Philippine Statistics Authority (PSA)" [level=3] [ref=f32e57]
            - paragraph [ref=f32e58]: Existing NCR 2020 denominators; national unit-aligned denominators unverified, so outlook uses count ranks and discloses population confounding
            - generic [ref=f32e59]:
              - term [ref=f32e60]: Coverage
              - definition [ref=f32e61]: 2020 census
              - term [ref=f32e62]: Licence / terms
              - definition [ref=f32e63]: source-specific terms; no blanket government-data licence assumed
              - term [ref=f32e64]: Retrieval
              - definition [ref=f32e65]: 2026-10-25 (reference checked); original supplied denominators unknown
            - link "Source and attribution" [ref=f32e66] [cursor=pointer]:
              - /url: https://psa.gov.ph/content/highlights-philippine-population-2020-census-population-and-housing-2020-cph
          - article [ref=f32e67]:
            - heading "geoBoundaries / NAMRIA / PSA / OCHA Philippines" [level=3] [ref=f32e68]
            - paragraph [ref=f32e69]: Local Philippines province display geometry; simplified from geoBoundaries ADM2, plus existing NCR city shapes
            - generic [ref=f32e70]:
              - term [ref=f32e71]: Coverage
              - definition [ref=f32e72]: ADM2 represents 2020; existing NCR ADM3 valid 2025-02-13, not historical boundary proof
              - term [ref=f32e73]: Licence / terms
              - definition [ref=f32e74]: CC BY 3.0 IGO; retain NAMRIA/PSA/OCHA attribution; simplification changes geometry
              - term [ref=f32e75]: Retrieval
              - definition [ref=f32e76]: 2026-10-25
            - link "Source and attribution" [ref=f32e77] [cursor=pointer]:
              - /url: https://www.geoboundaries.org/api/current/gbOpen/PHL/ADM2/
          - article [ref=f32e78]:
            - heading "Open-Meteo / Copernicus C3S / ECMWF ERA5" [level=3] [ref=f32e79]
            - paragraph [ref=f32e80]: Historical centroid weather validation and separately labeled forecast context; weather excluded from outlook unless validated
            - generic [ref=f32e81]:
              - term [ref=f32e82]: Coverage
              - definition [ref=f32e83]: History 2016-2020; dated cached forecast context
              - term [ref=f32e84]: Licence / terms
              - definition [ref=f32e85]: CC BY 4.0 data; free hosted API is for non-commercial use within fair-use limits
              - term [ref=f32e86]: Retrieval
              - definition [ref=f32e87]: See cache receipts; documentation verified 2026-10-25
            - link "Source and attribution" [ref=f32e88] [cursor=pointer]:
              - /url: https://open-meteo.com/
          - article [ref=f32e89]:
            - heading "NASA POWER / NASA Langley Research Center" [level=3] [ref=f32e90]
            - paragraph [ref=f32e91]: Historical weather cross-check for four polygon centroids, 2018–2020. NASA POWER is funded by the NASA Applied Sciences Program within the Earth Science Division of the Science Mission Directorate; web services collaborate with the NASA Langley Research Center Atmospheric Science Data Center (ASDC).
            - generic [ref=f32e92]:
              - term [ref=f32e93]: Coverage
              - definition [ref=f32e94]: See cached provenance; existing Manila historical cross-check
              - term [ref=f32e95]: Licence / terms
              - definition [ref=f32e96]: NASA POWER data access/acknowledgement terms; see original receipts
              - term [ref=f32e97]: Retrieval
              - definition [ref=f32e98]: 2026-10-25
            - link "Source and attribution" [ref=f32e99] [cursor=pointer]:
              - /url: https://power.larc.nasa.gov/docs/
          - article [ref=f32e100]:
            - heading "OpenStreetMap contributors" [level=3] [ref=f32e101]
            - paragraph [ref=f32e102]: Existing exploratory water/geography context; community data never enters official forecasts
            - generic [ref=f32e103]:
              - term [ref=f32e104]: Coverage
              - definition [ref=f32e105]: Provider snapshot dates in cache receipts
              - term [ref=f32e106]: Licence / terms
              - definition [ref=f32e107]: ODbL; OpenStreetMap contributors
              - term [ref=f32e108]: Retrieval
              - definition [ref=f32e109]: See cache receipts
            - link "Source and attribution" [ref=f32e110] [cursor=pointer]:
              - /url: https://www.openstreetmap.org/copyright
          - article [ref=f32e111]:
            - heading "NASA SRTM / Open-Meteo elevation service" [level=3] [ref=f32e112]
            - paragraph [ref=f32e113]: Existing exploratory terrain context; not household risk
            - generic [ref=f32e114]:
              - term [ref=f32e115]: Coverage
              - definition [ref=f32e116]: SRTM mission elevation / provider cache dates
              - term [ref=f32e117]: Licence / terms
              - definition [ref=f32e118]: Provider-specific attribution recorded in receipts
              - term [ref=f32e119]: Retrieval
              - definition [ref=f32e120]: See cache receipts
            - link "Source and attribution" [ref=f32e121] [cursor=pointer]:
              - /url: https://open-meteo.com/en/docs/elevation-api
          - article [ref=f32e122]:
            - heading "DOH CAR; National Privacy Commission; CDC" [level=3] [ref=f32e123]
            - paragraph [ref=f32e124]: 4S prevention, urgent warning signs and RA 10173 notice drafting; DPO/clinical review still required
            - generic [ref=f32e125]:
              - term [ref=f32e126]: Coverage
              - definition [ref=f32e127]: Guidance references checked 2026-10-25
              - term [ref=f32e128]: Licence / terms
              - definition [ref=f32e129]: Links and paraphrased guidance; no agency affiliation
              - term [ref=f32e130]: Retrieval
              - definition [ref=f32e131]: 2026-10-25
            - link "Source and attribution" [ref=f32e132] [cursor=pointer]:
              - /url: https://caro.doh.gov.ph/
          - article [ref=f32e133]:
            - heading "PAGASA" [level=3] [ref=f32e134]
            - paragraph [ref=f32e135]: Existing rainy-season contextual guidance; not an outbreak prediction
            - generic [ref=f32e136]:
              - term [ref=f32e137]: Coverage
              - definition [ref=f32e138]: Guidance reference in source manifest
              - term [ref=f32e139]: Licence / terms
              - definition [ref=f32e140]: Source-specific government guidance; attribution retained
              - term [ref=f32e141]: Retrieval
              - definition [ref=f32e142]: See original source manifest
            - link "Source and attribution" [ref=f32e143] [cursor=pointer]:
              - /url: https://www.pagasa.dost.gov.ph/
          - article [ref=f32e144]:
            - heading "OpenTopoData / NASA SRTM" [level=3] [ref=f32e145]
            - paragraph [ref=f32e146]: Elevation service considered by the existing terrain pipeline; original cache provenance identifies actual provider
            - generic [ref=f32e147]:
              - term [ref=f32e148]: Coverage
              - definition [ref=f32e149]: SRTM mission / cached provider date
              - term [ref=f32e150]: Licence / terms
              - definition [ref=f32e151]: Underlying dataset and service-specific terms; see provenance
              - term [ref=f32e152]: Retrieval
              - definition [ref=f32e153]: See original receipts
            - link "Source and attribution" [ref=f32e154] [cursor=pointer]:
              - /url: https://www.opentopodata.org/
          - article [ref=f32e155]:
            - heading "UP NOAH, UP DREAM/LiPAD and MGB" [level=3] [ref=f32e156]
            - paragraph [ref=f32e157]: Portals checked in the prior research; no licensed national analytical flood extract used
            - generic [ref=f32e158]:
              - term [ref=f32e159]: Coverage
              - definition [ref=f32e160]: Reference checks only; no derived flood layer
              - term [ref=f32e161]: Licence / terms
              - definition [ref=f32e162]: No flood dataset redistributed or represented as validated
              - term [ref=f32e163]: Retrieval
              - definition [ref=f32e164]: See source manifest
            - link "Source and attribution" [ref=f32e165] [cursor=pointer]:
              - /url: https://noah.up.edu.ph/noah-studio
        - generic [ref=f32e167]:
          - heading "Software, fonts & icons" [level=2] [ref=f32e168]
          - paragraph [ref=f32e169]: Generated from the committed lockfile and installed package licence metadata. Both runtime and build tools are included.
          - paragraph [ref=f32e170]:
            - text: Montserrat · OFL-1.1 ·
            - link "Font source" [ref=f32e171] [cursor=pointer]:
              - /url: https://fonts.google.com/specimen/Montserrat
          - paragraph [ref=f32e172]:
            - text: Roboto · OFL-1.1 ·
            - link "Font source" [ref=f32e173] [cursor=pointer]:
              - /url: https://fonts.google.com/specimen/Roboto
          - paragraph [ref=f32e174]:
            - text: Fraunces · OFL-1.1 ·
            - link "Font source" [ref=f32e175] [cursor=pointer]:
              - /url: https://fonts.google.com/specimen/Fraunces
          - paragraph [ref=f32e176]: Project SVG line symbols and text glyphs · MIT project code; no third-party icon library
          - paragraph [ref=f32e177]:
            - link "THIRD_PARTY_LICENSES.md" [ref=f32e178] [cursor=pointer]:
              - /url: /THIRD_PARTY_LICENSES.md
          - group [ref=f32e179]:
            - generic "Open dependency licence inventory" [ref=f32e180] [cursor=pointer]
        - generic [ref=f32e181]:
          - generic [ref=f32e182]:
            - heading "The photograph" [level=2] [ref=f32e183]
            - paragraph [ref=f32e184]: Background photograph by Sumarie Slabber
          - generic [ref=f32e185]:
            - heading "Responsible use & privacy" [level=2] [ref=f32e186]
            - paragraph [ref=f32e187]: Community signals are unverified and never enter official counts, forecasts or the Outlook Index. A tracking code supports withdrawal. No system can promise perfect anonymity.
            - link "Read the privacy notice" [ref=f32e188] [cursor=pointer]:
              - /url: /report?drawer=privacy
            - text: ·
            - link "About the data & methods" [ref=f32e189] [cursor=pointer]:
              - /url: /about?drawer=methods
          - generic [ref=f32e190]:
            - heading "Feedback & security" [level=2] [ref=f32e191]
            - paragraph [ref=f32e192]:
              - link "SECURITY.md" [ref=f32e193] [cursor=pointer]:
                - /url: /SECURITY.md
          - generic [ref=f32e194]:
            - heading "Version & evidence" [level=2] [ref=f32e195]
            - generic [ref=f32e196]:
              - term [ref=f32e197]: Version
              - definition [ref=f32e198]: 0.1.0
              - term [ref=f32e199]: Commit
              - definition [ref=f32e200]: e9a3047
              - term [ref=f32e201]: Map evaluation date
              - definition [ref=f32e202]: 2026-10-25
              - term [ref=f32e203]: Manila data as of
              - definition [ref=f32e204]: 2023-12-02
      - complementary [ref=f32e205]:
        - heading "Estimates, not alerts" [level=2] [ref=f32e206]
        - paragraph [ref=f32e207]: Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.
    - contentinfo [ref=f32e208]:
      - generic [ref=f32e209]:
        - link "About & Credits" [ref=f32e210] [cursor=pointer]:
          - /url: /about
        - button "About the data & methods" [ref=f32e211] [cursor=pointer]
      - paragraph [ref=f32e212]:
        - text: Bundled source periods.
        - time [ref=f32e213]: Dec 2, 2023
        - text: ·
        - time [ref=f32e214]: Jan 10, 2021
        - text: . Historical, not live.
      - paragraph [ref=f32e215]: Community reports are unverified; not medical advice.
      - paragraph [ref=f32e216]: Background photograph by Sumarie Slabber
      - paragraph [ref=f32e217]: Thesis research · Not an official DOH product · Historical records, not a live warning.
    - dialog [ref=f32e218]:
      - generic [ref=f32e219]:
        - heading "About the data & methods" [level=2] [ref=f32e220]
        - button "Close dialog" [active] [ref=f32e221] [cursor=pointer]: ✕
      - generic [ref=f32e222]:
        - paragraph [ref=f32e223]: Manila cases end 2023-12-02; national cases end 2021-01-10. M keeps absent dates missing; Z assumes zero only inside source coverage. Neither assumption is confirmed by the data owner. The public chart defaults to M.
        - paragraph [ref=f32e224]: The national outlook is relative season + historical burden, not predicted case counts or current disease risk. Population-adjusted rates and reporting/boundary equivalence are not verified. Community signals never enter either model.
        - link "About & Credits" [ref=f32e225] [cursor=pointer]:
          - /url: /about
        - generic [ref=f32e226]:
          - generic [ref=f32e227]: Research detail
          - combobox "Research detail" [ref=f32e228] [cursor=pointer]:
            - option "Evaluation and limitations"
            - option "Source coverage and integrity"
            - option "Complete historical tables"
            - option "NCR historical city archive"
            - option "Full prevention and warning signs"
            - option "Terms of Use" [selected]
            - option "Legal and privacy notices"
            - option "Prior research summary"
        - generic [ref=f32e231]:
          - paragraph [ref=f32e232]: USING DENGUEWATCH
          - heading "Terms with a clear purpose." [level=1] [ref=f32e233]
          - paragraph [ref=f32e234]: Educational/research prototype; draft for review.
        - generic [ref=f32e241]:
          - paragraph [ref=f32e242]: Draft for review. Not legal advice. Version legal-v2 · 2026-10-25
          - heading "Terms of Use" [level=2] [ref=f32e243]
          - paragraph [ref=f32e244]: DengueWatch is an educational/research prototype, not an official DOH service. Published histories, forecasts and legacy risk labels may be incomplete, delayed or unavailable. Estimates describe historical source labels; they do not establish current conditions.
          - paragraph [ref=f32e245]: Do not rely on the app for diagnosis, treatment, emergency decisions or outbreak declarations. Follow DOH/local health-office guidance and qualified clinical advice. Community reports, when server policy permits submission, remain unverified and separate from official records.
          - heading "Acceptable use" [level=3] [ref=f32e246]
          - paragraph [ref=f32e247]: Do not submit fabricated or repeated reports, other people's personal information, attempt to identify people from aggregates, probe private records, bypass access controls or disrupt the service. Reporting requires voluntary consent and truthful self-reporting. No medical monitoring or personal reply is promised.
          - heading "Availability and liability — lawyer review required" [level=3] [ref=f32e248]
          - paragraph [ref=f32e249]: "The prototype is provided without a promise of uninterrupted availability, completeness or fitness for a particular purpose. Proposed limitation of liability: to the extent permitted by applicable law, the research operators would limit responsibility for losses arising from reliance on the prototype. This proposed clause requires lawyer review; it does not waive statutory rights or establish an enforceable liability limit."
          - paragraph [ref=f32e250]:
            - text: Respect source usage terms and attribution; permission to redistribute or reuse supplied files has not been established by a descriptive attribution.
            - link "Data Sources & Attribution" [ref=f32e251] [cursor=pointer]:
              - /url: /legal#sources
            - text: ·
            - link "Privacy Notice" [ref=f32e252] [cursor=pointer]:
              - /url: /legal#privacy
            - text: .
  - status
```

# Test source

```ts
  1   | import {goto,ready,activeView} from '../support/active-view';
  2   | import { test, expect } from "@playwright/test";
  3   | import AxeBuilder from "@axe-core/playwright";
  4   | import { mockPublicApi } from "../fixtures/public-fixtures";
  5   | const routes = [
  6   |   "/",
  7   |   "/trends",
  8   |   "/metro-manila",
  9   |   "/methodology",
  10  |   "/prevention",
  11  |   "/community",
  12  |   "/report",
  13  |   "/privacy",
  14  |   "/terms",
  15  |   "/legal",
  16  |   "/data-sources",
  17  |   "/not-found",
  18  | ];
  19  | async function navigate(page: import("@playwright/test").Page, path: string) {
  20  |   await page.evaluate((p) => {
  21  |     history.pushState({}, "", p);
  22  |     dispatchEvent(new PopStateEvent("popstate"));
  23  |   }, path);
  24  |   await ready(page,path);
  25  | }
  26  | test("all public routes retain mobile targets, console hygiene and axe", async ({
  27  |   page,
  28  | }) => {
  29  |   test.setTimeout(240000);
  30  |   const errors: string[] = [];
  31  |   page.on("pageerror", (e) => errors.push(e.message));
  32  |   page.on("console", (message) => {
  33  |     if (["warning", "error"].includes(message.type()))
  34  |       errors.push(message.text());
  35  |   });
  36  |   await mockPublicApi(page, { open: false });
  37  |   for (const width of [320, 390, 768, 1280])
  38  |     for (const route of routes) {
  39  |       await page.setViewportSize({ width, height: 900 });
  40  |       await goto(page, route);
  41  |       await expect(activeView(page).getByRole("heading", { level: 1 })).toBeVisible();
  42  |       expect(
  43  |         await page.evaluate(
  44  |           () => document.documentElement.scrollWidth <= innerWidth,
  45  |         ),
  46  |       ).toBe(true);
  47  |       const violations = (
  48  |         await new AxeBuilder({ page }).analyze()
  49  |       ).violations.filter((v) =>
  50  |         ["serious", "critical"].includes(v.impact ?? ""),
  51  |       );
> 52  |       expect(violations, route + " " + width).toEqual([]);
      |                                               ^ Error: /terms 768
  53  |       const small = await page
  54  |         .locator(
  55  |           "button:visible:not([disabled]),select:visible,summary:visible,a:visible:not(.skip-link)",
  56  |         )
  57  |         .evaluateAll((elements) =>
  58  |           elements
  59  |             .filter((e) => e.getBoundingClientRect().height < 43.5)
  60  |             .map((e) => e.textContent?.trim().slice(0, 45)),
  61  |         );
  62  |       expect(small, route + " " + width).toEqual([]);
  63  |     }
  64  |   expect(errors).toEqual([]);
  65  | });
  66  | test("blocked external services leave static historical pages and closed reporting usable", async ({
  67  |   page,
  68  |   context,
  69  | }) => {
  70  |   const external: string[] = [];
  71  |   await page.addInitScript(() =>
  72  |     Object.defineProperty(navigator, "onLine", { get: () => false }),
  73  |   );
  74  |   await context.route("**/*", (r) => {
  75  |     if (
  76  |       ["localhost", "127.0.0.1"].includes(new URL(r.request().url()).hostname)
  77  |     )
  78  |       return r.continue();
  79  |     external.push(r.request().url());
  80  |     return r.abort();
  81  |   });
  82  |   for (const route of [
  83  |     "/",
  84  |     "/trends",
  85  |     "/metro-manila",
  86  |     "/methodology",
  87  |     "/prevention",
  88  |     "/report",
  89  |   ]) {
  90  |     await goto(page, route);
  91  |     await expect(activeView(page).getByRole("heading", { level: 1 })).toBeVisible();
  92  |     await expect(
  93  |       page.locator("main>.evidence-banner"),
  94  |     ).toBeVisible();
  95  |   }
  96  |   await expect(
  97  |     activeView(page).getByText("New submissions are closed.", { exact: false }),
  98  |   ).toBeVisible();
  99  |   expect(external).toEqual([]);
  100 | });
  101 | test("warmed routes and validated datasets remain available with the browser fully offline", async ({
  102 |   page,
  103 |   context,
  104 | }) => {
  105 |   const errors: string[] = [];
  106 |   page.on("pageerror", (e) => errors.push(e.message));
  107 |   await goto(page, "/");
  108 |   await expect(
  109 |     activeView(page).getByRole("heading", { name: "Current risk unavailable" }),
  110 |   ).toBeVisible();
  111 |   for (const route of [
  112 |     "/trends",
  113 |     "/metro-manila",
  114 |     "/methodology",
  115 |     "/prevention",
  116 |     "/",
  117 |   ])
  118 |     await navigate(page, route);
  119 |   await context.setOffline(true);
  120 |   for (const route of [
  121 |     "/trends",
  122 |     "/metro-manila",
  123 |     "/methodology",
  124 |     "/prevention",
  125 |     "/",
  126 |   ]) {
  127 |     await navigate(page, route);
  128 |     await expect(
  129 |       page.locator("main>.evidence-banner"),
  130 |     ).toBeVisible();
  131 |   }
  132 |   expect(errors).toEqual([]);
  133 | });
  134 | test("slow research reads show loading without inventing a current risk, then resolve", async ({
  135 |   page,
  136 | }) => {
  137 |   let release!: () => void;
  138 |   const gate = new Promise<void>((r) => (release = r));
  139 |   await page.route("**/api/v2/manila.json", async (r) => {
  140 |     await gate;
  141 |     await r.continue();
  142 |   });
  143 |   await goto(page, "/");
  144 |   await expect(activeView(page).getByText("Loading data…", { exact: true })).toBeVisible();
  145 |   await expect(
  146 |     activeView(page).getByRole("heading", { name: "Current risk unavailable" }),
  147 |   ).toHaveCount(0);
  148 |   release();
  149 |   await expect(
  150 |     activeView(page).getByRole("heading", { name: "Current risk unavailable" }),
  151 |   ).toBeVisible();
  152 | });
```