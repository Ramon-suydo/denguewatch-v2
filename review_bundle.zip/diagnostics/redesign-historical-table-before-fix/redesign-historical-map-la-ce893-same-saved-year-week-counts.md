# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: redesign.spec.ts >> historical map layer and accessible table expose the same saved year/week counts
- Location: tests\ui\redesign.spec.ts:102:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  locator('details').filter({ has: getByText('Data table: all reporting units and unmatched areas', { exact: true }) }).locator('tbody tr').filter({ has: getByRole('button', { name: 'ABRA', exact: true }) }).locator('td').first()
Expected: "1,315"
Received: "24"
Timeout:  5000ms

Call log:
  - Expect "toHaveText" locator('details').filter({ has: getByText('Data table: all reporting units and unmatched areas', { exact: true }) }).locator('tbody tr').filter({ has: getByRole('button', { name: 'ABRA', exact: true }) }).locator('td').first() with timeout 5000ms
  - waiting for locator('details').filter({ has: getByText('Data table: all reporting units and unmatched areas', { exact: true }) }).locator('tbody tr').filter({ has: getByRole('button', { name: 'ABRA', exact: true }) }).locator('td').first()
    13 × locator resolved to <td data-source="outlook.json.profiles; tied percentile">24</td>
       - unexpected value "24"

```

```yaml
- cell "24"
```

# Test source

```ts
  11  |   await page.setViewportSize({width,height:1000});await goto(page,path);
  12  |   if(width===360)await page.getByRole('button',{name:'Menu',exact:true}).click();
  13  |   const nav=page.getByRole('navigation',{name:'Main navigation'});
  14  |   await expect(nav.getByRole('link')).toHaveText(['Dashboard','Risk Map','Community Report']);
  15  |   await expect(nav.getByRole('link',{name:'About & Credits'})).toHaveCount(0);
  16  |   await expect(page.getByRole('contentinfo').getByRole('link',{name:'About & Credits'})).toHaveAttribute('href','/about');
  17  |   await expect(page.getByRole('contentinfo')).toContainText('Background photograph by Sumarie Slabber');
  18  |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  19  |   expect((await new AxeBuilder({page}).analyze()).violations.filter(v=>['critical','serious'].includes(v.impact??''))).toEqual([]);
  20  |  }
  21  |  await goto(page,'/about');await expect(page.locator('#team')).toHaveCount(0);
  22  |  await expect(page.locator('#image-credit')).toContainText('Background photograph by Sumarie Slabber');
  23  |  await expect(page.locator('#image-credit a')).toHaveCount(0);
  24  |  const software=await read('src/content/software-credits.json');
  25  |  await page.locator('#software summary').click();await expect(page.locator('#software tbody tr')).toHaveCount(software.length);
  26  |  await goto(page,'/');await page.getByRole('contentinfo').getByRole('button',{name:'About the data & methods',exact:true}).click();await activeView(page).getByRole('link',{name:'About & Credits',exact:true}).click();await expect(page).toHaveURL(/\/about$/);await expect(page.locator('dialog[open]')).toHaveCount(0);
  27  |  for(const old of ['/trends','/methodology','/data-sources','/prevention','/map','/privacy']){
  28  |   await goto(page,old);await expect(page).not.toHaveURL(new RegExp(old+'$'));
  29  |   await expect(page.locator('dialog[open]')).toBeVisible();
  30  |   await activeView(page).getByRole('button',{name:'Close dialog'}).click();
  31  |   await expect(page.locator('dialog[open]')).toHaveCount(0);
  32  |  }
  33  | });
  34  | 
  35  | test('national map uses every explicit match, no guessed areas, exact saved metrics and real calendar windows',async({page})=>{
  36  |  await page.clock.setFixedTime(new Date('2026-10-20T04:00:00Z'));
  37  |  await page.route('**/api/v2/outlook-weather.json',route=>route.fulfill({status:503,body:'Unavailable'}));
  38  |  const external:string[]=[];page.on('request',r=>{if(/open-meteo|power\.larc|tile\./.test(r.url()))external.push(r.url());});
  39  |  await goto(page,'/risk-map');const geo=await read('public/geo/philippines.geojson'),data=await read('public/api/v2/outlook.json') as Outlook;
  40  |  const polygons=page.locator('.national-map [data-boundary-id]');await expect(polygons).toHaveCount(geo.features.length);
  41  |  await expect(page.locator('.national-map [data-no-data="true"]')).toHaveCount(8);
  42  |  expect(geo.features.filter((f:any)=>f.properties.case_name)).toHaveLength(96);
  43  |  await expect(page.locator('.province-detail')).toContainText('Weather forecast unavailable. Seasonal outlook retained.');
  44  |  const detail=page.locator('.province-detail');await expect(detail).not.toContainText('estimated cases');
  45  |  await expect(page.locator('.national-map [data-case-unit]:not([data-case-unit=""])')).toHaveCount(96);
  46  |  const manila=page.locator('.national-map [data-case-unit="MANILA CITY"]');await manila.focus();await page.keyboard.press('Enter');await expect(manila).toHaveAttribute('aria-pressed','true');
  47  |  const expected=(date:string)=>outlookRows(data,date).find(r=>r.name==='MANILA CITY')!.index!.toLocaleString('en-US',{maximumFractionDigits:1});
  48  |  for(const [label,date] of [['Today','2026-10-20'],['+3 days','2026-10-23'],['+7 days','2026-10-27']]){
  49  |   await page.getByRole('button',{name:label,exact:true}).click();await expect(detail.locator('[data-outlook-index]')).toHaveText(expected(date));
  50  |  }
  51  |  const transform=await page.locator('.national-map>g').getAttribute('transform');await page.getByRole('button',{name:'Zoom in',exact:true}).click();expect(await page.locator('.national-map>g').getAttribute('transform')).not.toBe(transform);
  52  |  await page.getByRole('button',{name:'Reset',exact:true}).click();
  53  |  const table=page.getByRole('region',{name:'Outlook Index data table'});await page.getByText('Data table: all reporting units and unmatched areas',{exact:true}).click();
  54  |  await expect(table.locator('tbody tr')).toHaveCount(134);
  55  |  for(const row of outlookRows(data,'2026-10-27')){
  56  |   const tr=table.locator('tbody tr').filter({has:page.getByRole('button',{name:row.name,exact:true})});
  57  |   const matched=geo.features.some((f:any)=>f.properties.case_name===row.name);
  58  |   await expect(tr.locator('td').first()).toHaveText(matched?row.index!.toLocaleString('en-US',{maximumFractionDigits:1}):'No data');
  59  |  }
  60  |  const metricRows=page.getByRole('region',{name:'National map validation metrics'}).locator('tbody tr');await expect(metricRows).toHaveCount(data.models.length);
  61  |  for(let i=0;i<data.models.length;i++){const r=data.models[i];await expect(metricRows.nth(i).locator('td')).toHaveText([r.model,String(r.weeks),String(r.min_units),...[r.spearman!,r.top10_hit_rate,r.normalized_rank_error].map(v=>v.toLocaleString('en-PH',{maximumFractionDigits:3}))]);}
  62  |  await page.getByLabel('Search province / city').fill('DAVAO DE ORO');await expect(table.locator('tbody tr')).toHaveCount(1);await expect(table).toContainText('Unmatched: no data');
  63  |  await table.getByRole('button',{name:'DAVAO DE ORO',exact:true}).click();await expect(detail).toContainText('No data: no explicit polygon/reporting-unit match.');
  64  |  await page.getByLabel('Map layer',{exact:true}).selectOption('history');await expect(page.getByLabel('Historical year')).toHaveValue('2020');
  65  |  await page.getByLabel('Historical source week').selectOption('2020-01-05');expect(external).toEqual([]);
  66  | });
  67  | 
  68  | test('Dashboard and Manila map panel expose saved MAEs and backtest values, with bilingual core pages and privacy',async({page})=>{
  69  |  const data=await read('public/api/v2/manila.json');
  70  |  for(const path of ['/','/risk-map']){
  71  |   await goto(page,path);await expect(page.getByRole('heading',{name:'Current risk unavailable'})).toBeVisible();
  72  |   for(const h of [1,2]){const expected=data.summaries.find((r:any)=>r.scenario==='M'&&r.fold==='test-2018-2023'&&r.model==='naive'&&r.horizon===h).mae;await expect(page.locator(`[data-panel-horizon="${h}"]`)).toHaveAttribute('data-panel-mae',String(expected));}
  73  |  }
  74  |  for(const [path,heading] of [['/','Hindi alam ang panganib ngayon'],['/risk-map','MGA PATTERN, HINDI HULA.'],['/report','Unawain at pumayag']]){
  75  |   await goto(page,path);await page.getByRole('button',{name:'Filipino',exact:true}).click();await expect(page.getByRole('heading',{name:heading,exact:true})).toBeVisible();await expect(page.locator('html')).toHaveAttribute('lang','fil');
  76  |   await page.getByRole('button',{name:'English',exact:true}).click();
  77  |  }
  78  |  await page.getByRole('contentinfo').getByRole('button',{name:'Privacy notice',exact:true}).click();await expect(activeView(page)).toContainText('RA 10173');
  79  |  await expect(activeView(page)).toContainText('No system can promise perfect anonymity');
  80  | });
  81  | 
  82  | 
  83  | test('Dashboard numeric analytics reproduce published series, exact backtest rows and forecast values',async({page})=>{
  84  |  await goto(page,'/');const data=await read('public/api/v2/manila.json'),backtest=await read('public/api/v2/dashboard.json');
  85  |  const format=(v:number,digits=1)=>v.toLocaleString('en-PH',{maximumFractionDigits:digits});
  86  |  for(const scenario of ['M','Z']){
  87  |   await page.getByLabel('Absent-day scenario',{exact:true}).selectOption(scenario);
  88  |   const snapshot=data.snapshots.find((r:any)=>r.scenario===scenario);
  89  |   const forecasts=page.locator('.forecast-pair article');await expect(forecasts).toHaveCount(2);
  90  |   for(let i=0;i<2;i++){const f=snapshot.forecasts[i];await expect(forecasts.nth(i)).toContainText(format(f.predicted));await expect(forecasts.nth(i)).toContainText(f.target);if(f.low80!==null)await expect(forecasts.nth(i)).toContainText(format(f.low80)+'–'+format(f.high80));}
  91  |   const years=page.getByRole('region',{name:'Year comparison'}).locator('tbody tr');await expect(years).toHaveCount(snapshot.year_comparison.length);
  92  |   for(let i=0;i<snapshot.year_comparison.length;i++){const r=snapshot.year_comparison[i];await expect(years.nth(i)).toContainText(format(r.scorable_cases,0));await expect(years.nth(i)).toContainText(r.observed_week_count+' / '+r.calendar_week_count);}
  93  |   for(let m=1;m<=12;m++){const observed=data.series[scenario].filter((r:any)=>r.cases!==null&&Number(r.week_ending.slice(5,7))===m),mean=observed.reduce((s:number,r:any)=>s+r.cases,0)/observed.length;await expect(page.locator('.season-bars>div').nth(m-1).locator('span').last()).toHaveText(format(mean));}
  94  |   const detail=page.locator('details').filter({has:page.getByText('Backtest data table',{exact:true})});if((await detail.getAttribute('open'))===null)await detail.locator('summary').click();
  95  |   await expect(detail.locator('table')).toBeVisible();
  96  |   const expected=backtest.rows.filter((r:any)=>r.scenario===scenario);await expect(detail.locator('tbody tr')).toHaveCount(expected.length);
  97  |   for(let i=0;i<expected.length;i++){const r=expected[i];await expect(detail.locator('tbody tr').nth(i).locator('th,td')).toHaveText([r.origin,r.target,String(r.actual),String(r.predicted)]);}
  98  |  }
  99  | });
  100 | 
  101 | 
  102 | test('historical map layer and accessible table expose the same saved year/week counts',async({page})=>{
  103 |  await goto(page,'/risk-map');const data=await read('public/api/v2/outlook.json'),geo=await read('public/geo/philippines.geojson');
  104 |  await page.getByLabel('Map layer',{exact:true}).selectOption('history');await page.getByLabel('Historical year').selectOption('2019');
  105 |  const table=page.locator('details').filter({has:page.getByText('Data table: all reporting units and unmatched areas',{exact:true})});await table.locator('summary').click();
  106 |  for(const week of ['', '2019-09-08']){
  107 |   await page.getByLabel('Historical source week').selectOption(week);
  108 |   for(const name of Object.keys(data.profiles)){
  109 |    const tr=table.locator('tbody tr').filter({has:page.getByRole('button',{name,exact:true})}),records=data.history[name].filter((r:any)=>r.date.startsWith('2019')&&(!week||r.date===week));
  110 |    const matched=geo.features.some((f:any)=>f.properties.case_name===name),expected=matched&&records.length?records.reduce((total:number,r:any)=>total+r.cases,0).toLocaleString('en-PH'):'No data';
> 111 |    await expect(tr.locator('td').first()).toHaveText(expected);
      |                                           ^ Error: expect(locator).toHaveText(expected) failed
  112 |   }
  113 |  }
  114 |  await expect(page.locator('.map-legend')).toContainText('Lower recorded count');
  115 |  await expect(page.locator('.province-detail')).not.toContainText('Weather forecast');
  116 |  await expect(page.locator('.map-page')).toContainText('Historical period: 2019');
  117 |  await page.getByLabel('Map layer',{exact:true}).selectOption('community');await expect(table).toHaveCount(0);
  118 | });
  119 | 
```