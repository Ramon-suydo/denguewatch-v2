# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: redesign.spec.ts >> Dashboard and Manila map panel expose saved MAEs and backtest values, with bilingual core pages and privacy
- Location: tests\ui\redesign.spec.ts:47:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('body:has(dialog[open]) dialog[open], body:not(:has(dialog[open]))').getByRole('heading', { name: 'Current risk unavailable' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('body:has(dialog[open]) dialog[open], body:not(:has(dialog[open]))').getByRole('heading', { name: 'Current risk unavailable' }) with timeout 5000ms
  - waiting for locator('body:has(dialog[open]) dialog[open], body:not(:has(dialog[open]))').getByRole('heading', { name: 'Current risk unavailable' })

```

```yaml
- link "Skip to content":
  - /url: "#main"
- banner:
  - link "DengueWatch home":
    - /url: /
    - text: DENGUE WATCH
  - navigation "Main navigation":
    - link "Dashboard":
      - /url: /
    - link "Risk Map":
      - /url: /risk-map
    - link "Community Report":
      - /url: /report
  - button "English" [pressed]
  - button "Filipino"
- main:
  - paragraph: THESIS PROJECT / ATTRIBUTION
  - heading "ABOUT & CREDITS" [level=1]
  - paragraph: The people, records and tools behind this research.
  - navigation "About sections":
    - link "Project":
      - /url: "#project"
    - link "Data":
      - /url: "#data-credits"
    - link "Software":
      - /url: "#software"
    - link "Photograph":
      - /url: "#image-credit"
  - heading "About the project" [level=2]
  - paragraph: DengueWatch asks whether historical dengue patterns can support earlier awareness while making uncertainty visible. It combines a retrospective Manila case-forecast evaluation, a national seasonal outlook and a separate, privacy-conscious community reporting channel.
  - paragraph: This is not medical advice, a diagnosis, an official DOH product or evidence of institutional affiliation. Old case records cannot establish current risk.
  - heading "Data credits" [level=2]
  - article:
    - heading "DOH Epidemiology Bureau weekly surveillance (EPI)" [level=3]
    - paragraph: NCR city-week classification, plus archived historical analyses; raw input remains unchanged.
    - term: Coverage
    - definition: 2016-01-10 to 2021-01-10
    - term: Licence / terms
    - definition: unknown; data-owner confirmation required
    - term: Retrieval
    - definition: unknown
    - paragraph: doh-epi-dengue-data-2016-2021.csv
  - article:
    - heading "City of Manila health department" [level=3]
    - paragraph: Daily case data provided to the project team; formal citation pending data owner
    - term: Coverage
    - definition: 2018-01-01 to 2023-12-02
    - term: Licence / terms
    - definition: unknown; attribution and permission required
    - term: Retrieval
    - definition: unknown
    - paragraph: Daily_Reported_Cases_of_Dengue_in_the_City_of_Manila_from_2018_to_2023.xlsx
  - article:
    - heading "Philippine Statistics Authority (PSA)" [level=3]
    - paragraph: Existing NCR 2020 denominators; national unit-aligned denominators unverified, so outlook uses count ranks and discloses population confounding
    - term: Coverage
    - definition: 2020 census
    - term: Licence / terms
    - definition: source-specific terms; no blanket government-data licence assumed
    - term: Retrieval
    - definition: 2026-10-25 (reference checked); original supplied denominators unknown
    - link "Source and attribution":
      - /url: https://psa.gov.ph/content/highlights-philippine-population-2020-census-population-and-housing-2020-cph
  - article:
    - heading "geoBoundaries / NAMRIA / PSA / OCHA Philippines" [level=3]
    - paragraph: Local Philippines province display geometry; simplified from geoBoundaries ADM2, plus existing NCR city shapes
    - term: Coverage
    - definition: ADM2 represents 2020; existing NCR ADM3 valid 2025-02-13, not historical boundary proof
    - term: Licence / terms
    - definition: CC BY 3.0 IGO; retain NAMRIA/PSA/OCHA attribution; simplification changes geometry
    - term: Retrieval
    - definition: 2026-10-25
    - link "Source and attribution":
      - /url: https://www.geoboundaries.org/api/current/gbOpen/PHL/ADM2/
  - article:
    - heading "Open-Meteo / Copernicus C3S / ECMWF ERA5" [level=3]
    - paragraph: Historical centroid weather validation and separately labeled forecast context; weather excluded from outlook unless validated
    - term: Coverage
    - definition: History 2016-2020; dated cached forecast context
    - term: Licence / terms
    - definition: CC BY 4.0 data; free hosted API is for non-commercial use within fair-use limits
    - term: Retrieval
    - definition: See cache receipts; documentation verified 2026-10-25
    - link "Source and attribution":
      - /url: https://open-meteo.com/
  - article:
    - heading "NASA POWER / NASA Langley Research Center" [level=3]
    - paragraph: Historical weather cross-check for four polygon centroids, 2018–2020. NASA POWER is funded by the NASA Applied Sciences Program within the Earth Science Division of the Science Mission Directorate; web services collaborate with the NASA Langley Research Center Atmospheric Science Data Center (ASDC).
    - term: Coverage
    - definition: See cached provenance; existing Manila historical cross-check
    - term: Licence / terms
    - definition: NASA POWER data access/acknowledgement terms; see original receipts
    - term: Retrieval
    - definition: 2026-10-25
    - link "Source and attribution":
      - /url: https://power.larc.nasa.gov/docs/
  - article:
    - heading "OpenStreetMap contributors" [level=3]
    - paragraph: Existing exploratory water/geography context; community data never enters official forecasts
    - term: Coverage
    - definition: Provider snapshot dates in cache receipts
    - term: Licence / terms
    - definition: ODbL; OpenStreetMap contributors
    - term: Retrieval
    - definition: See cache receipts
    - link "Source and attribution":
      - /url: https://www.openstreetmap.org/copyright
  - article:
    - heading "NASA SRTM / Open-Meteo elevation service" [level=3]
    - paragraph: Existing exploratory terrain context; not household risk
    - term: Coverage
    - definition: SRTM mission elevation / provider cache dates
    - term: Licence / terms
    - definition: Provider-specific attribution recorded in receipts
    - term: Retrieval
    - definition: See cache receipts
    - link "Source and attribution":
      - /url: https://open-meteo.com/en/docs/elevation-api
  - article:
    - heading "DOH regional offices / MOH BARMM; National Privacy Commission; CDC; WHO" [level=3]
    - paragraph: 4S prevention, urgent warning signs and RA 10173 notice drafting; DPO/clinical review still required
    - term: Coverage
    - definition: Guidance references checked 2026-10-25
    - term: Licence / terms
    - definition: Links and paraphrased guidance; no agency affiliation
    - term: Retrieval
    - definition: 2026-10-25
    - link "Source and attribution":
      - /url: https://bangsamoro.gov.ph/news/latest-news/moh-urges-public-to-observe-4s-strategy-against-dengue/
  - article:
    - heading "PAGASA" [level=3]
    - paragraph: Existing rainy-season contextual guidance; not an outbreak prediction
    - term: Coverage
    - definition: Guidance reference in source manifest
    - term: Licence / terms
    - definition: Source-specific government guidance; attribution retained
    - term: Retrieval
    - definition: See original source manifest
    - link "Source and attribution":
      - /url: https://www.pagasa.dost.gov.ph/
  - article:
    - heading "OpenTopoData / NASA SRTM" [level=3]
    - paragraph: Elevation service considered by the existing terrain pipeline; original cache provenance identifies actual provider
    - term: Coverage
    - definition: SRTM mission / cached provider date
    - term: Licence / terms
    - definition: Underlying dataset and service-specific terms; see provenance
    - term: Retrieval
    - definition: See original receipts
    - link "Source and attribution":
      - /url: https://www.opentopodata.org/
  - article:
    - heading "UP NOAH, UP DREAM/LiPAD and MGB" [level=3]
    - paragraph: Portals checked in the prior research; no licensed national analytical flood extract used
    - term: Coverage
    - definition: Reference checks only; no derived flood layer
    - term: Licence / terms
    - definition: No flood dataset redistributed or represented as validated
    - term: Retrieval
    - definition: See source manifest
    - link "Source and attribution":
      - /url: https://noah.up.edu.ph/noah-studio
  - article:
    - heading "OpenFreeMap / OpenMapTiles / OpenStreetMap contributors" [level=3]
    - paragraph: Online Risk Map basemap only; no API key; third-party server sees IP and viewed map area
    - term: Coverage
    - definition: Current basemap service; model case data are separate
    - term: Licence / terms
    - definition: OpenFreeMap service as-is; map data OpenStreetMap contributors, ODbL; preserve provider attribution
    - term: Retrieval
    - definition: 2026-10-26
    - link "Source and attribution":
      - /url: https://openfreemap.org/quick_start/
  - article:
    - heading "Protomaps / OpenStreetMap contributors" [level=3]
    - paragraph: Self-hosted Metro Manila PMTiles and styles; local glyphs/sprites
    - term: Coverage
    - definition: 2026-10-25 planet extract; max zoom 13
    - term: Licence / terms
    - definition: OSM ODbL produced work; styles BSD-3-Clause; Noto glyphs OFL-1.1; tangrams/icons sprites MIT
    - term: Retrieval
    - definition: 2026-10-26
    - link "Source and attribution":
      - /url: https://docs.protomaps.com/basemaps/downloads
  - article:
    - heading "Sarma et al. (2020), Dengue Prediction using Machine Learning Algorithms" [level=3]
    - paragraph: Owner-requested protocol context only; patient-level study accuracy does not transfer to city-week labels
    - term: Coverage
    - definition: IEEE R10-HTC 2020; document 9357035
    - term: Licence / terms
    - definition: Bibliographic citation only; publisher full text access-blocked; metadata verified with Crossref
    - term: Retrieval
    - definition: 2026-10-26
    - link "Source and attribution":
      - /url: https://ieeexplore.ieee.org/document/9357035
  - article:
    - heading "W3C SVG / XML namespace specification" [level=3]
    - paragraph: Inline city-thumbnail SVG syntax; namespace identifiers cause no network requests
    - term: Coverage
    - definition: SVG namespace
    - term: Licence / terms
    - definition: Specification reference only; no copied specification text
    - term: Retrieval
    - definition: 2026-10-26
    - link "Source and attribution":
      - /url: https://www.w3.org/TR/SVG2/
  - heading "Methods and evidence" [level=2]
  - paragraph: We classify next-week research threshold events for 17 Metro Manila areas.
  - paragraph: The areas are 16 cities and Pateros municipality. No barangay estimates are produced.
  - paragraph: An event means next week exceeds the city’s past mean plus one standard deviation. The minimum cutoff is 10 cases. These are research labels, not official outbreak declarations.
  - paragraph: All thresholds and features use only information available by the forecast origin. Missing weeks stay missing. Live requires reviewed counts for all cities within 21 days.
  - group: Definitions and limitations
  - heading "Study that informed the protocol" [level=3]
  - paragraph:
    - text: Dhiman Sarma, Sohrab Hossain, Tanni Mittra, Md. Abdul Motaleb Bhuiya, Ishita Saha, Ravina Chakma. Dengue Prediction using Machine Learning Algorithms. 2020 IEEE 8th R10 Humanitarian Technology Conference (R10-HTC), 2020.
    - link "IEEE document 9357035":
      - /url: https://ieeexplore.ieee.org/document/9357035
    - text: ". DOI:"
    - link "10.1109/r10-htc49770.2020.9357035":
      - /url: https://doi.org/10.1109/r10-htc49770.2020.9357035
    - text: .
  - paragraph: That study classifies patients. Its reported accuracy is not our city-week accuracy. The owner supplied its protocol; citation metadata was verified with Crossref. Full text remains access-blocked.
  - heading "Chronological 70:30 results" [level=3]
  - paragraph: 2016-07-17–2019-08-25 / 2019-09-01–2020-11-08
  - paragraph: Confidence limits below are 95% block-bootstrap intervals.
  - region "Chronological headline results":
    - table "Chronological headline results":
      - caption: Chronological headline results
      - rowgroup:
        - row "Model N / positive accuracy balanced accuracy precision recall f1 roc auc pr auc brier":
          - columnheader "Model"
          - columnheader "N / positive"
          - columnheader "accuracy"
          - columnheader "balanced accuracy"
          - columnheader "precision"
          - columnheader "recall"
          - columnheader "f1"
          - columnheader "roc auc"
          - columnheader "pr auc"
          - columnheader "brier"
      - rowgroup:
        - row "majority 1071 / 225 0.7899 [0.6050, 0.9300] 0.5000 [0.5000, 0.5000] 0.0000 [0.0000, 0.0000] 0.0000 [0.0000, 0.0000] 0.0000 [0.0000, 0.0000] 0.5000 [0.5000, 0.5000] 0.2101 [0.0700, 0.3950] 0.1711 [0.1098, 0.2518]":
          - rowheader "majority"
          - cell "1071 / 225"
          - cell "0.7899 [0.6050, 0.9300]"
          - cell "0.5000 [0.5000, 0.5000]"
          - cell "0.0000 [0.0000, 0.0000]"
          - cell "0.0000 [0.0000, 0.0000]"
          - cell "0.0000 [0.0000, 0.0000]"
          - cell "0.5000 [0.5000, 0.5000]"
          - cell "0.2101 [0.0700, 0.3950]"
          - cell "0.1711 [0.1098, 0.2518]"
        - row "persistence 1071 / 225 0.9505 [0.9047, 0.9841] 0.9361 [0.8513, 0.9799] 0.8613 [0.6309, 0.9608] 0.9111 [0.7374, 0.9730] 0.8855 [0.7049, 0.9630] 0.9865 [0.9540, 0.9984] 0.9593 [0.7999, 0.9944] 0.0388 [0.0131, 0.0699]":
          - rowheader "persistence"
          - cell "1071 / 225"
          - cell "0.9505 [0.9047, 0.9841]"
          - cell "0.9361 [0.8513, 0.9799]"
          - cell "0.8613 [0.6309, 0.9608]"
          - cell "0.9111 [0.7374, 0.9730]"
          - cell "0.8855 [0.7049, 0.9630]"
          - cell "0.9865 [0.9540, 0.9984]"
          - cell "0.9593 [0.7999, 0.9944]"
          - cell "0.0388 [0.0131, 0.0699]"
        - row "seasonal 1071 / 225 0.6937 [0.5349, 0.8229] 0.4636 [0.3927, 0.5376] 0.1128 [0.0000, 0.4724] 0.0667 [0.0000, 0.1621] 0.0838 [0.0000, 0.1936] 0.6986 [0.5339, 0.8631] 0.2808 [0.0891, 0.5941] 0.2063 [0.1131, 0.2924]":
          - rowheader "seasonal"
          - cell "1071 / 225"
          - cell "0.6937 [0.5349, 0.8229]"
          - cell "0.4636 [0.3927, 0.5376]"
          - cell "0.1128 [0.0000, 0.4724]"
          - cell "0.0667 [0.0000, 0.1621]"
          - cell "0.0838 [0.0000, 0.1936]"
          - cell "0.6986 [0.5339, 0.8631]"
          - cell "0.2808 [0.0891, 0.5941]"
          - cell "0.2063 [0.1131, 0.2924]"
        - row "DT 1071 / 225 0.6144 [0.4669, 0.7443] 0.7282 [0.6233, 0.8136] 0.3444 [0.1290, 0.5809] 0.9244 [0.7650, 0.9906] 0.5018 [0.2258, 0.7225] 0.9334 [0.8270, 0.9826] 0.8366 [0.5427, 0.9479] 0.1449 [0.1186, 0.1711]":
          - rowheader "DT"
          - cell "1071 / 225"
          - cell "0.6144 [0.4669, 0.7443]"
          - cell "0.7282 [0.6233, 0.8136]"
          - cell "0.3444 [0.1290, 0.5809]"
          - cell "0.9244 [0.7650, 0.9906]"
          - cell "0.5018 [0.2258, 0.7225]"
          - cell "0.9334 [0.8270, 0.9826]"
          - cell "0.8366 [0.5427, 0.9479]"
          - cell "0.1449 [0.1186, 0.1711]"
        - row "RF 1071 / 225 0.9094 [0.8243, 0.9720] 0.9247 [0.8334, 0.9791] 0.7133 [0.4161, 0.8984] 0.9511 [0.7924, 1.0000] 0.8152 [0.5307, 0.9401] 0.9803 [0.9292, 0.9984] 0.9523 [0.7024, 0.9937] 0.0445 [0.0133, 0.0856]":
          - rowheader "RF"
          - cell "1071 / 225"
          - cell "0.9094 [0.8243, 0.9720]"
          - cell "0.9247 [0.8334, 0.9791]"
          - cell "0.7133 [0.4161, 0.8984]"
          - cell "0.9511 [0.7924, 1.0000]"
          - cell "0.8152 [0.5307, 0.9401]"
          - cell "0.9803 [0.9292, 0.9984]"
          - cell "0.9523 [0.7024, 0.9937]"
          - cell "0.0445 [0.0133, 0.0856]"
  - paragraph: Persistence clearly improves F1 over RF in this comparison.
  - paragraph: "RF minus rule F1, 95% CI: -0.1538 to -0.0157."
  - group: "Onset: early-warning subset"
  - group: Random stratified 70:30 comparison
  - group: Per-city results, including Manila
  - group: Yearly robustness and label sensitivity
  - group: Confusion matrices and feature importance
  - paragraph: "Missing calendar weeks: 2016-11-13, 2019-01-06, 2020-11-15."
  - paragraph:
    - text: "Data SHA-256:"
    - code: 4e993553f10081b4e6b35a0d4b3c9bd0cc271765645a123fcb2e0c5d7084633c
  - link "Download the complete evaluation":
    - /url: /ml/evaluation.json
  - heading "Software, fonts & icons" [level=2]
  - paragraph: Generated from the committed lockfile and installed package licence metadata. Both runtime and build tools are included.
  - paragraph:
    - text: Montserrat · OFL-1.1 ·
    - link "Font source":
      - /url: https://fonts.google.com/specimen/Montserrat
  - paragraph:
    - text: Roboto · OFL-1.1 ·
    - link "Font source":
      - /url: https://fonts.google.com/specimen/Roboto
  - paragraph:
    - text: Fraunces · OFL-1.1 ·
    - link "Font source":
      - /url: https://fonts.google.com/specimen/Fraunces
  - paragraph:
    - text: DejaVu Sans (evaluation figures) · Bitstream Vera / DejaVu font licence ·
    - link "Font source":
      - /url: /THIRD_PARTY_LICENSES.md
  - paragraph:
    - text: Noto Sans Regular (local map glyphs) · OFL-1.1 ·
    - link "Font source":
      - /url: https://github.com/protomaps/basemaps-assets/tree/main/fonts
  - paragraph: Project SVG line symbols and text glyphs · MIT project code; no third-party icon library
  - paragraph: Protomaps sprites derived from tangrams/icons · MIT
  - paragraph:
    - link "THIRD_PARTY_LICENSES.md":
      - /url: /THIRD_PARTY_LICENSES.md
  - group: Open dependency licence inventory
  - heading "The photograph" [level=2]
  - paragraph: Background photograph by Sumarie Slabber
  - heading "Responsible use & privacy" [level=2]
  - paragraph: Community signals are unverified and never enter official counts, forecasts or city model estimates. A tracking code supports withdrawal. No system can promise perfect anonymity.
  - link "Read the privacy notice":
    - /url: /report?drawer=privacy
  - text: ·
  - link "About the data & methods":
    - /url: /about?drawer=methods
  - heading "Feedback & security" [level=2]
  - paragraph:
    - link "SECURITY.md":
      - /url: /SECURITY.md
  - heading "Version & evidence" [level=2]
  - term: Version
  - definition: 0.1.0
  - term: Commit
  - definition: bbc3e63
  - term: Map evaluation date
  - definition: 2026-10-26
  - term: Manila data as of
  - definition: 2023-12-02
  - complementary "Estimates, not alerts":
    - heading "Estimates, not alerts" [level=2]
    - paragraph: Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.
- contentinfo:
  - link "About & Credits":
    - /url: /about
  - button "About the data & methods"
  - paragraph:
    - text: Bundled source periods.
    - time: Dec 2, 2023
    - text: ·
    - time: Dec 27, 2020
    - text: . Replay uses historical records. Live needs reviewed recent counts.
  - paragraph: Community reports are unverified; not medical advice.
  - paragraph: Background photograph by Sumarie Slabber
  - paragraph: Thesis research · Not an official DOH product · Historical records, not a live warning.
- dialog "About the data & methods":
  - heading "About the data & methods" [level=2]
  - button "Close dialog": ✕
  - paragraph: Current city models use historical NCR data through 2020-12-27. Replay is the default. Older Manila research remains below as an archive.
  - link "About & Credits":
    - /url: /about
  - text: Research detail
  - combobox "Research detail":
    - 'option "City classification: methods and evidence"'
    - option "Archived Manila analytics" [selected]
    - option "Separate community aggregates"
    - option "Evaluation and limitations"
    - option "Source coverage and integrity"
    - option "Complete historical tables"
    - option "NCR historical city archive"
    - option "Full prevention and warning signs"
    - option "Terms of Use"
    - option "Legal and privacy notices"
    - option "Prior research summary"
  - button "English" [pressed]
  - button "Filipino"
  - heading "Archived Manila research" [level=1]
  - paragraph: This earlier case-forecast research does not drive the current city classification map.
  - complementary: Manila case data ends 2023-12-02. Province/city case data ends 2021-01-10. Neither is live.
  - paragraph: THE QUESTION BEHIND THE THESIS
  - heading "Can better awareness begin with honest data?" [level=2]
  - paragraph: Dengue is a mosquito-borne illness. This thesis asks whether historical cases and environmental context can support earlier awareness without overstating what the data can predict.
  - paragraph: "We compare forecasts with a simple last-week baseline, make missing observations visible, and keep unverified community reports separate from official records. Objectives: describe patterns, test predictive skill, and provide a privacy-conscious awareness channel."
  - status: Checking reporting status…
  - status: Loading data…
  - region "Know when to seek care":
    - paragraph: TAKE CARE / ACT EARLY
    - heading "Know when to seek care" [level=2]
    - paragraph: Seek urgent medical care for severe abdominal pain, persistent vomiting, bleeding, difficulty breathing, unusual drowsiness or extreme weakness. Do not wait for a report review.
    - 'link "Source: CDC dengue warning signs"':
      - /url: https://www.cdc.gov/dengue/hcp/clinical-care/
    - heading "Make the DOH 4S a habit" [level=3]
    - list:
      - listitem: "Search and destroy mosquito breeding places: empty and clean standing-water containers."
      - listitem: "Self-protection: use repellent as directed and wear protective clothing."
      - listitem: Seek early consultation for fever or dengue-like symptoms.
      - listitem: Support health-authority fogging or spraying in identified hotspot/outbreak areas.
    - 'link "Source: Ministry of Health 4S guidance"':
      - /url: https://bangsamoro.gov.ph/news/latest-news/moh-urges-public-to-observe-4s-strategy-against-dengue/
    - paragraph:
      - strong: Informational, not a diagnosis. Not an official DOH product.
- status
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import {readFile} from 'node:fs/promises';
  3  | import AxeBuilder from '@axe-core/playwright';
  4  | import {goto,activeView} from '../support/active-view';
  5  | import {mockPublicApi} from '../fixtures/public-fixtures';
  6  | const read=async(path:string)=>JSON.parse(await readFile(path,'utf8'));
  7  | 
  8  | test('three navigation destinations, footer attribution, empty owner fields and old-route drawers',async({page})=>{
  9  |  test.setTimeout(120000);
  10 |  for(const width of [360,1280])for(const path of ['/','/risk-map','/report','/about']){
  11 |   await page.setViewportSize({width,height:1000});await goto(page,path);
  12 |   if(width===360)await page.getByRole('button',{name:'Menu',exact:true}).click();
  13 |   const nav=page.getByRole('navigation',{name:'Main navigation'});
  14 |   await expect(nav.getByRole('link')).toHaveText(['Dashboard','Risk Map','Community Report']);
  15 |   await expect(nav.getByRole('link',{name:'About & Credits'})).toHaveCount(0);
  16 |   await expect(page.getByRole('contentinfo').getByRole('link',{name:'About & Credits'})).toHaveAttribute('href','/about');
  17 |   await expect(page.getByRole('contentinfo')).toContainText('Background photograph by Sumarie Slabber');
  18 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  19 |   expect((await new AxeBuilder({page}).analyze()).violations.filter(v=>['critical','serious'].includes(v.impact??''))).toEqual([]);
  20 |  }
  21 |  await goto(page,'/about');await expect(page.locator('#team')).toHaveCount(0);
  22 |  await expect(page.locator('#image-credit')).toContainText('Background photograph by Sumarie Slabber');
  23 |  await expect(page.locator('#image-credit a')).toHaveCount(0);
  24 |  const software=await read('src/content/software-credits.json');
  25 |  await page.locator('#software summary').click();await expect(page.locator('#software tbody tr')).toHaveCount(software.length);
  26 |  await goto(page,'/');await page.getByRole('contentinfo').getByRole('button',{name:'About the data & methods',exact:true}).click();await activeView(page).getByRole('link',{name:'About & Credits',exact:true}).click();await expect(page).toHaveURL(/\/about$/);await expect(page.locator('dialog[open]')).toHaveCount(0);
  27 |  for(const old of ['/trends','/methodology','/data-sources','/prevention','/map','/privacy']){
  28 |   await goto(page,old);await expect(page).not.toHaveURL(new RegExp(old+'$'));
  29 |   await expect(page.locator('dialog[open]')).toBeVisible();
  30 |   await activeView(page).getByRole('button',{name:'Close dialog'}).click();
  31 |   await expect(page.locator('dialog[open]')).toHaveCount(0);
  32 |  }
  33 | });
  34 | 
  35 | test('city map uses all 17 explicit matches and exact saved probabilities, without national or weather data',async({page})=>{
  36 |  await mockPublicApi(page,{open:false});await page.route('https://tiles.openfreemap.org/**',r=>r.abort());
  37 |  const forbidden:string[]=[];page.on('request',r=>{if(/open-meteo|power\.larc|philippines\.geojson|outlook\.json/.test(r.url()))forbidden.push(r.url());});
  38 |  await goto(page,'/risk-map');const geo=await read('public/geo/ncr-cities.geojson'),crosswalk=await read('data/geo/ncr-ml-crosswalk.json'),saved=await read('public/ml/replay.json');
  39 |  expect(geo.features).toHaveLength(17);expect(crosswalk.rows).toHaveLength(17);expect(crosswalk.unmatched).toEqual([]);expect(new Set(crosswalk.rows.map((r:any)=>r.doh_name)).size).toBe(17);
  40 |  await expect(page.locator('.city-picker button')).toHaveCount(17);await expect(page.locator('.forecast-mode')).toContainText('Replay');await expect(page.getByRole('button',{name:'Live',exact:true})).toBeDisabled();
  41 |  await page.waitForFunction(()=>{const host=document.querySelector('.city-map-canvas') as HTMLElement&{cityMap?:{getSource:(id:string)=>{serialize:()=>{data:{features:unknown[]}}}|undefined;getLayer:(id:string)=>unknown;queryRenderedFeatures:(query:unknown)=>unknown[]}}|null;const map=host?.cityMap;return map?.getSource('ncr-risk')?.serialize().data.features.length===17&&map.getLayer('ncr-fill')&&map.queryRenderedFeatures({layers:['ncr-fill']}).length>0;});
  42 |  await page.getByRole('button',{name:'Show data table',exact:true}).click();const table=page.getByRole('region',{name:'City prediction data'});await expect(table.locator('tbody tr')).toHaveCount(17);
  43 |  const expected=saved.rows.filter((r:any)=>r.target===saved.weeks[0]);for(const r of expected)await expect(table.locator(`tr[data-city-row="${r.city}"]`)).toHaveAttribute('data-probability',String(r.probability));
  44 |  await page.getByLabel('Find a city',{exact:true}).fill('Manila');await expect(table.locator('tbody tr')).toHaveCount(1);await expect(table).toContainText('Manila');await expect(page.locator('.traffic-legend')).toContainText('Resolution: city.');expect(forbidden).toEqual([]);
  45 | });
  46 | 
  47 | test('Dashboard and Manila map panel expose saved MAEs and backtest values, with bilingual core pages and privacy',async({page})=>{
  48 |  const data=await read('public/api/v2/manila.json');
  49 |  for(const path of ['/about?drawer=methods&section=dashboard']){
> 50 |   await goto(page,path);await expect(activeView(page).getByRole('heading',{name:'Current risk unavailable'})).toBeVisible();
     |                                                                                                               ^ Error: expect(locator).toBeVisible() failed
  51 |   for(const h of [1,2]){const expected=data.summaries.find((r:any)=>r.scenario==='M'&&r.fold==='test-2018-2023'&&r.model==='naive'&&r.horizon===h).mae;await expect(page.locator(`[data-panel-horizon="${h}"]`)).toHaveAttribute('data-panel-mae',String(expected));}
  52 |  }
  53 |  for(const [path,heading] of [['/','Mga dapat bantayan'],['/risk-map','Mapa ng Panganib'],['/report','Unawain at pumayag']]){
  54 |   await goto(page,path);await page.getByRole('button',{name:'Filipino',exact:true}).click();await expect(page.getByRole('heading',{name:heading,exact:true})).toBeVisible();await expect(page.locator('html')).toHaveAttribute('lang','fil');
  55 |   await page.getByRole('button',{name:'English',exact:true}).click();
  56 |  }
  57 |  await page.getByRole('contentinfo').getByRole('button',{name:'Privacy notice',exact:true}).click();await expect(activeView(page)).toContainText('RA 10173');
  58 |  await expect(activeView(page)).toContainText('No system can promise perfect anonymity');
  59 | });
  60 | 
  61 | 
  62 | test('Dashboard numeric analytics reproduce published series, exact backtest rows and forecast values',async({page})=>{
  63 |  await goto(page,'/about?drawer=methods&section=dashboard');const data=await read('public/api/v2/manila.json'),backtest=await read('public/api/v2/dashboard.json');
  64 |  const format=(v:number,digits=1)=>v.toLocaleString('en-PH',{maximumFractionDigits:digits});
  65 |  for(const scenario of ['M','Z']){
  66 |   await page.getByLabel('Absent-day scenario',{exact:true}).selectOption(scenario);
  67 |   const snapshot=data.snapshots.find((r:any)=>r.scenario===scenario);
  68 |   const forecasts=page.locator('.forecast-pair article');await expect(forecasts).toHaveCount(2);
  69 |   for(let i=0;i<2;i++){const f=snapshot.forecasts[i];await expect(forecasts.nth(i)).toContainText(format(f.predicted));await expect(forecasts.nth(i)).toContainText(f.target);if(f.low80!==null)await expect(forecasts.nth(i)).toContainText(format(f.low80)+'–'+format(f.high80));}
  70 |   const years=page.getByRole('region',{name:'Year comparison'}).locator('tbody tr');await expect(years).toHaveCount(snapshot.year_comparison.length);
  71 |   for(let i=0;i<snapshot.year_comparison.length;i++){const r=snapshot.year_comparison[i];await expect(years.nth(i)).toContainText(format(r.scorable_cases,0));await expect(years.nth(i)).toContainText(r.observed_week_count+' / '+r.calendar_week_count);}
  72 |   for(let m=1;m<=12;m++){const observed=data.series[scenario].filter((r:any)=>r.cases!==null&&Number(r.week_ending.slice(5,7))===m),mean=observed.reduce((s:number,r:any)=>s+r.cases,0)/observed.length;await expect(page.locator('.season-bars>div').nth(m-1).locator('span').last()).toHaveText(format(mean));}
  73 |   const detail=page.locator('details').filter({has:page.getByText('Backtest data table',{exact:true})});if((await detail.getAttribute('open'))===null)await detail.locator('summary').click();
  74 |   await expect(detail.locator('table')).toBeVisible();
  75 |   const expected=backtest.rows.filter((r:any)=>r.scenario===scenario);await expect(detail.locator('tbody tr')).toHaveCount(expected.length);
  76 |   for(let i=0;i<expected.length;i++){const r=expected[i];await expect(detail.locator('tbody tr').nth(i).locator('th,td')).toHaveText([r.origin,r.target,String(r.actual),String(r.predicted)]);}
  77 |  }
  78 | });
  79 | 
  80 | 
  81 | test('every Replay calendar week and all 17 table rows match saved predictions and missing-data flags',async({page})=>{
  82 |  test.setTimeout(120000);await mockPublicApi(page,{open:false});await page.route('https://tiles.openfreemap.org/**',r=>r.abort());await goto(page,'/risk-map');const data=await read('public/ml/replay.json');await page.getByRole('button',{name:'Show data table',exact:true}).click();const slider=page.getByLabel('Choose an example week',{exact:true});await slider.focus();const table=page.getByRole('region',{name:'City prediction data'});let unavailable=0;
  83 |  for(let i=0;i<data.weeks.length;i++){
  84 |   if(i)await slider.press('ArrowRight');await expect(page.locator('.replay-controls output')).toHaveText(data.weeks[i]);
  85 |   const expected=data.rows.filter((r:any)=>r.target===data.weeks[i]);expect(expected).toHaveLength(17);
  86 |   const actual=await table.locator('tbody tr').evaluateAll(rows=>rows.map(row=>({city:row.getAttribute('data-city-row'),probability:row.getAttribute('data-probability'),level:row.querySelector('[data-risk-level]')?.getAttribute('data-risk-level')})));
  87 |   expect(actual).toEqual(expected.map((r:any)=>({city:r.city,probability:r.probability===null?'missing':String(r.probability),level:r.probability===null?'no-data':String(data.bands.filter((cut:number)=>r.probability>=cut).length)})));unavailable+=expected.filter((r:any)=>r.probability===null).length;
  88 |  }
  89 |  expect(unavailable).toBe(119);await expect(table).toContainText('No estimate');await expect(page.locator('.city-detail')).toContainText('Some source weeks are missing');
  90 | });
  91 | 
```