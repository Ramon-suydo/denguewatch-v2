# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: demo-hardening.spec.ts >> all public routes retain mobile targets, console hygiene and axe
- Location: tests\ui\demo-hardening.spec.ts:26:1

# Error details

```
Error: /community 320

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 58

- Array []
+ Array [
+   Object {
+     "description": "Ensure the contrast between foreground and background colors meets WCAG 2 AA minimum contrast ratio thresholds",
+     "help": "Elements must meet minimum color contrast ratio thresholds",
+     "helpUrl": "https://dequeuniversity.com/rules/axe/4.13/color-contrast?application=playwright",
+     "id": "color-contrast",
+     "impact": "serious",
+     "nodes": Array [
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "bgColor": "#071b2b",
+               "contrastRatio": 1.02,
+               "expectedContrastRatio": "3:1",
+               "fgColor": "#0f1a3d",
+               "fontSize": "20.4pt (27.2px)",
+               "fontWeight": "bold",
+               "messageKey": null,
+             },
+             "id": "color-contrast",
+             "impact": "serious",
+             "message": "Element has insufficient color contrast of 1.02 (foreground color: #0f1a3d, background color: #071b2b, font size: 20.4pt (27.2px), font weight: bold). Expected contrast ratio of 3:1",
+             "relatedNodes": Array [
+               Object {
+                 "html": "<div class=\"photo-app inner-page\">",
+                 "target": Array [
+                   ".photo-app",
+                 ],
+               },
+             ],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Element has insufficient color contrast of 1.02 (foreground color: #0f1a3d, background color: #071b2b, font size: 20.4pt (27.2px), font weight: bold). Expected contrast ratio of 3:1",
+         "html": "<h2>Community reports, kept separate.</h2>",
+         "impact": "serious",
+         "none": Array [],
+         "target": Array [
+           ".ui-container > h2",
+         ],
+       },
+     ],
+     "tags": Array [
+       "cat.color",
+       "wcag2aa",
+       "wcag143",
+       "TTv5",
+       "TT13.c",
+       "EN-301-549",
+       "EN-9.1.4.3",
+       "ACT",
+       "RGAAv4",
+       "RGAA-3.2.1",
+     ],
+   },
+ ]
```

# Page snapshot

```yaml
- generic [ref=f5e2]:
  - generic [ref=f5e3]:
    - link "Skip to content" [ref=f5e5] [cursor=pointer]:
      - /url: "#main"
    - banner [ref=f5e6]:
      - link "DengueWatch home" [ref=f5e7] [cursor=pointer]:
        - /url: /
        - text: DENGUE
        - generic [ref=f5e8]: WATCH
      - button "Menu" [ref=f5e9] [cursor=pointer]
      - generic "Page language" [ref=f5e10]:
        - button "English" [pressed] [ref=f5e11] [cursor=pointer]
        - button "Filipino" [ref=f5e12] [cursor=pointer]
    - main [ref=f5e13]:
      - generic [ref=f5e14]:
        - paragraph [ref=f5e15]: PHILIPPINES / RELATIVE OUTLOOK
        - heading "PATTERNS, NOT PREDICTIONS." [level=1] [ref=f5e16]
        - paragraph [ref=f5e17]: Explore historical burden and the season ahead. An outlook is not a forecast of case counts.
        - complementary [ref=f5e18]: Outlook = relative seasonal patterns and historical burden, not predicted case counts. Weather is not used without validation. Only Manila has a historical calibrated case-forecast panel; current risk is unavailable.
        - generic [ref=f5e19]:
          - generic [ref=f5e20]:
            - generic [ref=f5e21]: Search province / city
            - searchbox "Search province / city" [ref=f5e22]
          - generic [ref=f5e24]:
            - generic [ref=f5e25]: Map layer
            - combobox "Map layer" [ref=f5e26] [cursor=pointer]:
              - option "Outlook Index"
              - option "Historical recorded burden (2016–2020)"
              - option "Community-reported signals (unverified)" [selected]
          - paragraph [ref=f5e27]: "Selected window: 2026-10-25. Case data as of 2021-01-10."
          - paragraph [ref=f5e28]: Large provinces can rank higher simply because more people live there. Population-adjusted risk is not verified.
        - generic [ref=f5e29]:
          - paragraph [ref=f5e30]: COMMUNITY / UNVERIFIED
          - heading "Community reports, kept separate." [level=2] [ref=f5e31]
          - generic [ref=f5e32]:
            - paragraph [ref=f5e33]:
              - status [ref=f5e34]: Community reporting is closed.
              - text: These are community-reported, unverified awareness signals, never official dengue counts or forecast inputs. Staff approval is a content review, not medical verification.
            - paragraph [ref=f5e35]: Publication requires at least three approved reports per area/week and a minimum 72-hour delay. Missing or suppressed groups do not mean zero cases. There is no validation history establishing predictive value.
          - generic [ref=f5e36]:
            - heading "Published community aggregates" [level=2] [ref=f5e37]
            - paragraph [ref=f5e38]: No publishable groups. Reports may be absent, awaiting review, delayed or suppressed; no count is inferred.
            - paragraph [ref=f5e39]: "Source: voluntary community reports, delayed and moderated; displayed onset weeks are historical, not official diagnoses."
        - group [ref=f5e41]:
          - 'generic "Data table: all reporting units and unmatched areas" [ref=f5e42] [cursor=pointer]'
        - generic [ref=f5e43]:
          - heading "How reliable is this map?" [level=2] [ref=f5e44]
          - paragraph [ref=f5e45]: These are retrospective rankings of recorded case counts, not population-adjusted risk. Results vary by year, missing coverage and the COVID period. Seasonal history did not improve every year.
          - paragraph [ref=f5e46]: Lagged weather did not consistently beat both seasonal-only baselines across held-out years and all three metrics.
          - region "National map validation metrics" [ref=f5e47]:
            - table [ref=f5e48]:
              - rowgroup [ref=f5e49]:
                - row [ref=f5e50]:
                  - columnheader "Test year" [ref=f5e51]
                  - columnheader "Model" [ref=f5e52]
                  - columnheader "Weeks" [ref=f5e53]
                  - columnheader "Min units" [ref=f5e54]
                  - columnheader "Spearman ?" [ref=f5e55]
                  - columnheader "Top-10 hit rate ?" [ref=f5e56]
                  - columnheader "Normalized rank error ?" [ref=f5e57]
              - rowgroup [ref=f5e58]:
                - row [ref=f5e59]:
                  - rowheader "2018" [ref=f5e60]
                  - cell "burden-only" [ref=f5e61]
                  - cell "52" [ref=f5e62]
                  - cell "126" [ref=f5e63]
                  - cell "0.748" [ref=f5e64]
                  - cell "0.529" [ref=f5e65]
                  - cell "0.156" [ref=f5e66]
                - row [ref=f5e67]:
                  - rowheader "2018" [ref=f5e68]
                  - cell "lagged-weather-weather-cohort" [ref=f5e69]
                  - cell "52" [ref=f5e70]
                  - cell "96" [ref=f5e71]
                  - cell "0.752" [ref=f5e72]
                  - cell "0.577" [ref=f5e73]
                  - cell "0.152" [ref=f5e74]
                - row [ref=f5e75]:
                  - rowheader "2018" [ref=f5e76]
                  - cell "season-burden" [ref=f5e77]
                  - cell "52" [ref=f5e78]
                  - cell "126" [ref=f5e79]
                  - cell "0.743" [ref=f5e80]
                  - cell "0.49" [ref=f5e81]
                  - cell "0.157" [ref=f5e82]
                - row [ref=f5e83]:
                  - rowheader "2018" [ref=f5e84]
                  - cell "season-burden-weather-cohort" [ref=f5e85]
                  - cell "52" [ref=f5e86]
                  - cell "96" [ref=f5e87]
                  - cell "0.761" [ref=f5e88]
                  - cell "0.542" [ref=f5e89]
                  - cell "0.151" [ref=f5e90]
                - row [ref=f5e91]:
                  - rowheader "2018" [ref=f5e92]
                  - cell "season-ridge-weather-cohort" [ref=f5e93]
                  - cell "52" [ref=f5e94]
                  - cell "96" [ref=f5e95]
                  - cell "0.777" [ref=f5e96]
                  - cell "0.562" [ref=f5e97]
                  - cell "0.146" [ref=f5e98]
                - row [ref=f5e99]:
                  - rowheader "2019" [ref=f5e100]
                  - cell "burden-only" [ref=f5e101]
                  - cell "51" [ref=f5e102]
                  - cell "126" [ref=f5e103]
                  - cell "0.738" [ref=f5e104]
                  - cell "0.516" [ref=f5e105]
                  - cell "0.16" [ref=f5e106]
                - row [ref=f5e107]:
                  - rowheader "2019" [ref=f5e108]
                  - cell "lagged-weather-weather-cohort" [ref=f5e109]
                  - cell "51" [ref=f5e110]
                  - cell "96" [ref=f5e111]
                  - cell "0.769" [ref=f5e112]
                  - cell "0.588" [ref=f5e113]
                  - cell "0.15" [ref=f5e114]
                - row [ref=f5e115]:
                  - rowheader "2019" [ref=f5e116]
                  - cell "season-burden" [ref=f5e117]
                  - cell "51" [ref=f5e118]
                  - cell "126" [ref=f5e119]
                  - cell "0.767" [ref=f5e120]
                  - cell "0.573" [ref=f5e121]
                  - cell "0.149" [ref=f5e122]
                - row [ref=f5e123]:
                  - rowheader "2019" [ref=f5e124]
                  - cell "season-burden-weather-cohort" [ref=f5e125]
                  - cell "51" [ref=f5e126]
                  - cell "96" [ref=f5e127]
                  - cell "0.772" [ref=f5e128]
                  - cell "0.567" [ref=f5e129]
                  - cell "0.147" [ref=f5e130]
                - row [ref=f5e131]:
                  - rowheader "2019" [ref=f5e132]
                  - cell "season-ridge-weather-cohort" [ref=f5e133]
                  - cell "51" [ref=f5e134]
                  - cell "96" [ref=f5e135]
                  - cell "0.775" [ref=f5e136]
                  - cell "0.582" [ref=f5e137]
                  - cell "0.146" [ref=f5e138]
                - row [ref=f5e139]:
                  - rowheader "2020" [ref=f5e140]
                  - cell "burden-only" [ref=f5e141]
                  - cell "52" [ref=f5e142]
                  - cell "80" [ref=f5e143]
                  - cell "0.622" [ref=f5e144]
                  - cell "0.321" [ref=f5e145]
                  - cell "0.194" [ref=f5e146]
                - row [ref=f5e147]:
                  - rowheader "2020" [ref=f5e148]
                  - cell "lagged-weather-weather-cohort" [ref=f5e149]
                  - cell "52" [ref=f5e150]
                  - cell "59" [ref=f5e151]
                  - cell "0.671" [ref=f5e152]
                  - cell "0.425" [ref=f5e153]
                  - cell "0.18" [ref=f5e154]
                - row [ref=f5e155]:
                  - rowheader "2020" [ref=f5e156]
                  - cell "season-burden" [ref=f5e157]
                  - cell "52" [ref=f5e158]
                  - cell "80" [ref=f5e159]
                  - cell "0.651" [ref=f5e160]
                  - cell "0.413" [ref=f5e161]
                  - cell "0.185" [ref=f5e162]
                - row [ref=f5e163]:
                  - rowheader "2020" [ref=f5e164]
                  - cell "season-burden-weather-cohort" [ref=f5e165]
                  - cell "52" [ref=f5e166]
                  - cell "59" [ref=f5e167]
                  - cell "0.676" [ref=f5e168]
                  - cell "0.433" [ref=f5e169]
                  - cell "0.179" [ref=f5e170]
                - row [ref=f5e171]:
                  - rowheader "2020" [ref=f5e172]
                  - cell "season-ridge-weather-cohort" [ref=f5e173]
                  - cell "52" [ref=f5e174]
                  - cell "59" [ref=f5e175]
                  - cell "0.678" [ref=f5e176]
                  - cell "0.421" [ref=f5e177]
                  - cell "0.179" [ref=f5e178]
          - paragraph [ref=f5e179]: "Each test year uses strictly earlier years. Spearman compares within-week ranks; top-10 hit rate is overlap / 10; normalized error is mean absolute rank difference / (unit count · 1). Missing observations are excluded, never zero-filled. Regenerate: npm run evaluate:map."
        - generic [ref=f5e180]:
          - paragraph [ref=f5e181]: MANILA / HISTORICAL CASE FORECAST
          - heading "Current risk unavailable" [level=2] [ref=f5e182]
          - paragraph [ref=f5e183]: The case record is too old to establish current risk. This is the only case-forecast panel; the national map is a relative outlook.
          - paragraph [ref=f5e184]:
            - text: Data as of
            - time [ref=f5e185]: 2023-12-02
            - text: · Forecast origin 2023-11-26 · Scenario M
          - heading "Historical Manila forecast" [level=3] [ref=f5e186]
          - generic [ref=f5e187]:
            - article [ref=f5e188]:
              - heading "1 week(s) ahead" [level=3] [ref=f5e189]
              - paragraph [ref=f5e190]: 62 estimated cases
              - paragraph [ref=f5e191]: "Historical target: 2023-12-03"
              - paragraph [ref=f5e192]: "80% interval: 40–84"
            - article [ref=f5e193]:
              - heading "2 week(s) ahead" [level=3] [ref=f5e194]
              - paragraph [ref=f5e195]: 62 estimated cases
              - paragraph [ref=f5e196]: "Historical target: 2023-12-10"
              - paragraph [ref=f5e197]: "80% interval: 31–93"
          - paragraph [ref=f5e198]: One-week persistence means last week's value. These are retrospective estimates, not a warning for the coming days.
          - paragraph [ref=f5e199]: Remove standing water, protect against bites and seek early consultation for symptoms.
      - complementary [ref=f5e200]:
        - heading "Estimates, not alerts" [level=2] [ref=f5e201]
        - paragraph [ref=f5e202]: Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.
    - contentinfo [ref=f5e203]:
      - generic [ref=f5e204]:
        - link "About & Credits" [ref=f5e205] [cursor=pointer]:
          - /url: /about
        - button "About the data & methods" [ref=f5e206] [cursor=pointer]
      - paragraph [ref=f5e207]:
        - text: Bundled source periods.
        - time [ref=f5e208]: Dec 2, 2023
        - text: ·
        - time [ref=f5e209]: Jan 10, 2021
        - text: . Historical, not live.
      - paragraph [ref=f5e210]: Community reports are unverified; not medical advice.
      - paragraph [ref=f5e211]: Background photograph by Sumarie Slabber
      - paragraph [ref=f5e212]: Thesis research · Not an official DOH product · Historical records, not a live warning.
  - status
```

# Test source

```ts
  1   | import {goto,ready,activeView} from '../support/active-view';
  2   | import { test, expect } from "@playwright/test";
  3   | import AxeBuilder from "@axe-core/playwright";
  4   | import { mockPublicApi } from "../fixtures/public-fixtures";
  5   | const routes = [
  6   |   "/",
  7   |   "/trends",
  8   |   "/metro-manila",
  9   |   "/methodology",
  10  |   "/prevention",
  11  |   "/community",
  12  |   "/report",
  13  |   "/privacy",
  14  |   "/terms",
  15  |   "/legal",
  16  |   "/data-sources",
  17  |   "/not-found",
  18  | ];
  19  | async function navigate(page: import("@playwright/test").Page, path: string) {
  20  |   await page.evaluate((p) => {
  21  |     history.pushState({}, "", p);
  22  |     dispatchEvent(new PopStateEvent("popstate"));
  23  |   }, path);
  24  |   await ready(page,path);
  25  | }
  26  | test("all public routes retain mobile targets, console hygiene and axe", async ({
  27  |   page,
  28  | }) => {
  29  |   test.setTimeout(240000);
  30  |   const errors: string[] = [];
  31  |   page.on("pageerror", (e) => errors.push(e.message));
  32  |   page.on("console", (message) => {
  33  |     if (["warning", "error"].includes(message.type()))
  34  |       errors.push(message.text());
  35  |   });
  36  |   await mockPublicApi(page, { open: false });
  37  |   for (const width of [320, 390, 768, 1280])
  38  |     for (const route of routes) {
  39  |       await page.setViewportSize({ width, height: 900 });
  40  |       await goto(page, route);
  41  |       await expect(activeView(page).getByRole("heading", { level: 1 })).toBeVisible();
  42  |       expect(
  43  |         await page.evaluate(
  44  |           () => document.documentElement.scrollWidth <= innerWidth,
  45  |         ),
  46  |       ).toBe(true);
  47  |       const violations = (
  48  |         await new AxeBuilder({ page }).analyze()
  49  |       ).violations.filter((v) =>
  50  |         ["serious", "critical"].includes(v.impact ?? ""),
  51  |       );
> 52  |       expect(violations, route + " " + width).toEqual([]);
      |                                               ^ Error: /community 320
  53  |       const small = await page
  54  |         .locator(
  55  |           "button:visible:not([disabled]),select:visible,summary:visible,a:visible:not(.skip-link)",
  56  |         )
  57  |         .evaluateAll((elements) =>
  58  |           elements
  59  |             .filter((e) => e.getBoundingClientRect().height < 43.5)
  60  |             .map((e) => e.textContent?.trim().slice(0, 45)),
  61  |         );
  62  |       expect(small, route + " " + width).toEqual([]);
  63  |     }
  64  |   expect(errors).toEqual([]);
  65  | });
  66  | test("blocked external services leave static historical pages and closed reporting usable", async ({
  67  |   page,
  68  |   context,
  69  | }) => {
  70  |   const external: string[] = [];
  71  |   await page.addInitScript(() =>
  72  |     Object.defineProperty(navigator, "onLine", { get: () => false }),
  73  |   );
  74  |   await context.route("**/*", (r) => {
  75  |     if (
  76  |       ["localhost", "127.0.0.1"].includes(new URL(r.request().url()).hostname)
  77  |     )
  78  |       return r.continue();
  79  |     external.push(r.request().url());
  80  |     return r.abort();
  81  |   });
  82  |   for (const route of [
  83  |     "/",
  84  |     "/trends",
  85  |     "/metro-manila",
  86  |     "/methodology",
  87  |     "/prevention",
  88  |     "/report",
  89  |   ]) {
  90  |     await goto(page, route);
  91  |     await expect(activeView(page).getByRole("heading", { level: 1 })).toBeVisible();
  92  |     await expect(
  93  |       page.locator("main>.evidence-banner"),
  94  |     ).toBeVisible();
  95  |   }
  96  |   await expect(
  97  |     activeView(page).getByText("New submissions are closed.", { exact: false }),
  98  |   ).toBeVisible();
  99  |   expect(external).toEqual([]);
  100 | });
  101 | test("warmed routes and validated datasets remain available with the browser fully offline", async ({
  102 |   page,
  103 |   context,
  104 | }) => {
  105 |   const errors: string[] = [];
  106 |   page.on("pageerror", (e) => errors.push(e.message));
  107 |   await goto(page, "/");
  108 |   await expect(
  109 |     activeView(page).getByRole("heading", { name: "Current risk unavailable" }),
  110 |   ).toBeVisible();
  111 |   for (const route of [
  112 |     "/trends",
  113 |     "/metro-manila",
  114 |     "/methodology",
  115 |     "/prevention",
  116 |     "/",
  117 |   ])
  118 |     await navigate(page, route);
  119 |   await context.setOffline(true);
  120 |   for (const route of [
  121 |     "/trends",
  122 |     "/metro-manila",
  123 |     "/methodology",
  124 |     "/prevention",
  125 |     "/",
  126 |   ]) {
  127 |     await navigate(page, route);
  128 |     await expect(
  129 |       page.locator("main>.evidence-banner"),
  130 |     ).toBeVisible();
  131 |   }
  132 |   expect(errors).toEqual([]);
  133 | });
  134 | test("slow research reads show loading without inventing a current risk, then resolve", async ({
  135 |   page,
  136 | }) => {
  137 |   let release!: () => void;
  138 |   const gate = new Promise<void>((r) => (release = r));
  139 |   await page.route("**/api/v2/manila.json", async (r) => {
  140 |     await gate;
  141 |     await r.continue();
  142 |   });
  143 |   await goto(page, "/");
  144 |   await expect(activeView(page).getByText("Loading data…", { exact: true })).toBeVisible();
  145 |   await expect(
  146 |     activeView(page).getByRole("heading", { name: "Current risk unavailable" }),
  147 |   ).toHaveCount(0);
  148 |   release();
  149 |   await expect(
  150 |     activeView(page).getByRole("heading", { name: "Current risk unavailable" }),
  151 |   ).toBeVisible();
  152 | });
```