# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: pwa.spec.ts >> production PWA isolates map caching, serves offline PMTiles ranges, and keeps reports map-free
- Location: tests\production\pwa.spec.ts:4:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=f2e2]:
  - generic [ref=f2e3]:
    - link "Skip to content" [ref=f2e5] [cursor=pointer]:
      - /url: "#main"
    - banner [ref=f2e6]:
      - link "DengueWatch home" [ref=f2e7] [cursor=pointer]:
        - /url: /
        - text: DENGUE
        - generic [ref=f2e8]: WATCH
      - navigation "Main navigation" [ref=f2e9]:
        - link "Dashboard" [ref=f2e10] [cursor=pointer]:
          - /url: /
        - link "Risk Map" [ref=f2e11] [cursor=pointer]:
          - /url: /risk-map
        - link "Community Report" [ref=f2e12] [cursor=pointer]:
          - /url: /report
      - generic "Page language" [ref=f2e13]:
        - button "English" [pressed] [ref=f2e14] [cursor=pointer]
        - button "Filipino" [ref=f2e15] [cursor=pointer]
    - main [ref=f2e16]:
      - generic [ref=f2e17]:
        - generic [ref=f2e18]:
          - generic [ref=f2e19]:
            - paragraph [ref=f2e20]: METRO MANILA · 17 AREAS
            - heading "Risk Map" [level=1] [ref=f2e21]
          - link "What should I do?" [ref=f2e22] [cursor=pointer]:
            - /url: /#actions
        - region "Forecast mode" [ref=f2e23]:
          - generic [ref=f2e24]:
            - text: Replay · historical example
            - paragraph [ref=f2e25]: Example week from our test data.
            - paragraph [ref=f2e26]:
              - text: Showing week of
              - time [ref=f2e27]: 2019-09-01
          - generic [ref=f2e28]:
            - generic [ref=f2e29]:
              - button "Replay" [pressed] [ref=f2e30] [cursor=pointer]
              - button "Live" [disabled] [ref=f2e31]
            - paragraph [ref=f2e32]: Live needs recent weekly counts for all 17 cities.
            - paragraph [ref=f2e33]: Ask the project admin to upload reviewed counts.
        - paragraph [ref=f2e34]: An outbreak here means unusually high recorded cases. It is not an official declaration.
        - generic [ref=f2e35]:
          - generic [ref=f2e36]:
            - text: Find a city
            - searchbox "Find a city" [ref=f2e37]
          - button "Show data table" [ref=f2e38] [cursor=pointer]
          - generic [ref=f2e39]:
            - checkbox "High contrast" [ref=f2e40]
            - text: High contrast
          - generic [ref=f2e41]:
            - checkbox "Tilt map" [ref=f2e42]
            - text: Tilt map
        - group "Choose a city" [ref=f2e43]:
          - button "Caloocan. more than 9 in 10" [ref=f2e44] [cursor=pointer]: Caloocan
          - button "Las Pinas. more than 9 in 10" [ref=f2e45] [cursor=pointer]: Las Pinas
          - button "Makati. more than 9 in 10" [ref=f2e46] [cursor=pointer]: Makati
          - button "Malabon. more than 9 in 10" [ref=f2e47] [cursor=pointer]: Malabon
          - button "Mandaluyong. about 8 in 10" [ref=f2e48] [cursor=pointer]: Mandaluyong
          - button "Manila. more than 9 in 10" [pressed] [ref=f2e49] [cursor=pointer]: Manila
          - button "Marikina. more than 9 in 10" [ref=f2e50] [cursor=pointer]: Marikina
          - button "Muntinlupa. more than 9 in 10" [ref=f2e51] [cursor=pointer]: Muntinlupa
          - button "Navotas. about 6 in 10" [ref=f2e52] [cursor=pointer]: Navotas
          - button "Paranaque. more than 9 in 10" [ref=f2e53] [cursor=pointer]: Paranaque
          - button "Pasay. more than 9 in 10" [ref=f2e54] [cursor=pointer]: Pasay
          - button "Pasig. more than 9 in 10" [ref=f2e55] [cursor=pointer]: Pasig
          - button "Pateros. less than 1 in 10" [ref=f2e56] [cursor=pointer]: Pateros
          - button "Quezon. more than 9 in 10" [ref=f2e57] [cursor=pointer]: Quezon
          - button "San Juan. about 9 in 10" [ref=f2e58] [cursor=pointer]: San Juan
          - button "Taguig. more than 9 in 10" [ref=f2e59] [cursor=pointer]: Taguig
          - button "Valenzuela. more than 9 in 10" [ref=f2e60] [cursor=pointer]: Valenzuela
        - generic [ref=f2e61]:
          - generic [ref=f2e62]:
            - generic "Interactive city map" [ref=f2e64]:
              - region "Metro Manila city risk map. Arrow keys cycle cities. Enter selects." [ref=f2e65]
              - generic [ref=f2e66]:
                - button "Zoom in" [ref=f2e67] [cursor=pointer]
                - button "Zoom out" [ref=f2e69] [cursor=pointer]
            - status: Base map unavailable. City areas remain available.
            - paragraph [ref=f2e71]: "City boundaries: NAMRIA / PSA / OCHA"
          - complementary "Selected city" [ref=f2e72]:
            - paragraph [ref=f2e73]: CITY DETAIL
            - heading "Manila" [level=2] [ref=f2e74]
            - generic [ref=f2e75]:
              - generic [aria-hidden] [ref=f2e76]: "!"
              - text: High
            - paragraph [ref=f2e77]: "Chance of an outbreak next week:"
            - paragraph [ref=f2e78]: more than 9 in 10
            - paragraph [ref=f2e79]: Recent counts were already high for this city.
            - paragraph [ref=f2e80]: ↑ Last recorded count rose.
            - img "Eight-week recorded cases. Missing weeks leave gaps." [ref=f2e81]
            - paragraph [ref=f2e83]: Recorded cases over eight weeks.
            - paragraph [ref=f2e84]: "Latest recorded count: 144"
            - generic [ref=f2e85]:
              - heading "What actually happened" [level=3] [ref=f2e86]
              - paragraph [ref=f2e87]: "Yes: cases were unusually high."
              - paragraph [ref=f2e88]: 179 recorded cases
            - paragraph [ref=f2e89]: Across all 17 areas, in past examples with this level, 186 / 199 were followed by unusually high counts.
            - link "What to do now" [ref=f2e90] [cursor=pointer]:
              - /url: /#actions
        - generic "Risk legend" [ref=f2e91]:
          - generic [ref=f2e92]: ○ Low
          - generic [ref=f2e93]: ◔ Watch
          - generic [ref=f2e94]: ▲ Raised
          - generic [ref=f2e95]: "! High"
          - generic [ref=f2e96]: "Resolution: city."
        - generic [ref=f2e97]:
          - button "Play weeks" [ref=f2e98] [cursor=pointer]
          - generic [ref=f2e99]:
            - text: Choose an example week
            - slider "Choose an example week" [ref=f2e100]: "0"
          - status [ref=f2e101]: 2019-09-01
        - paragraph [ref=f2e102]:
          - text: The online map contacts OpenFreeMap. Its server receives your IP address.
          - link "Read the methods and privacy limits." [ref=f2e103] [cursor=pointer]:
            - /url: /about#methods
      - complementary [ref=f2e104]:
        - heading "Estimates, not alerts" [level=2] [ref=f2e105]
        - paragraph [ref=f2e106]: Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.
    - contentinfo [ref=f2e107]:
      - generic [ref=f2e108]:
        - link "About & Credits" [ref=f2e109] [cursor=pointer]:
          - /url: /about
        - button "About the data & methods" [ref=f2e110] [cursor=pointer]
      - paragraph [ref=f2e111]:
        - text: Bundled source periods.
        - time [ref=f2e112]: Dec 2, 2023
        - text: ·
        - time [ref=f2e113]: Dec 27, 2020
        - text: . Replay uses historical records. Live needs reviewed recent counts.
      - paragraph [ref=f2e114]: Community reports are unverified; not medical advice.
      - paragraph [ref=f2e115]: Background photograph by Sumarie Slabber
      - paragraph [ref=f2e116]: Thesis research · Not an official DOH product · Historical records, not a live warning.
  - status
```

# Test source

```ts
  1  | import {readFile} from 'node:fs/promises';
  2  | import {goto,activeView} from '../support/active-view';
  3  | import { test, expect } from "@playwright/test";
  4  | test("production PWA isolates map caching, serves offline PMTiles ranges, and keeps reports map-free",async({page,context})=>{
  5  |  test.setTimeout(90000);const violations:string[]=[];await page.exposeFunction('recordOfflinePolicy',(directive:string)=>violations.push(directive));await page.addInitScript(()=>document.addEventListener('securitypolicyviolation',e=>{void (window as any).recordOfflinePolicy(e.violatedDirective);}));const mapRequests:string[]=[];page.on('request',r=>{if(/MapProvider|maplibre|\.pmtiles|openfreemap|ncr-cities\.geojson/.test(r.url()))mapRequests.push(r.url());});
  6  |  await page.route('https://tiles.openfreemap.org/**',r=>r.abort());await goto(page,'/');await expect(page.locator('.top-city-list li')).toHaveCount(3);
  7  |  await page.evaluate(async()=>{await navigator.serviceWorker.ready;if(!navigator.serviceWorker.controller)await new Promise<void>(r=>navigator.serviceWorker.addEventListener('controllerchange',()=>r(),{once:true}));});
  8  |  const cachePaths=()=>page.evaluate(async()=>(await Promise.all((await caches.keys()).filter(n=>n.startsWith('dw-research-')).map(async n=>(await(await caches.open(n)).keys()).map(r=>new URL(r.url).pathname)))).flat());
  9  |  let paths=await cachePaths();expect(paths.some(p=>p.includes('MapProvider')||p.endsWith('.pmtiles')||p.includes('ncr-cities'))).toBe(false);expect(mapRequests).toEqual([]);
  10 |  await goto(page,'/report');await expect(page.getByRole('heading',{level:1})).toBeVisible();expect(mapRequests).toEqual([]);
  11 |  await goto(page,'/risk-map');await expect(page.locator('.city-picker button')).toHaveCount(17);await page.waitForFunction(()=>{const m=(document.querySelector('.city-map-canvas') as HTMLElement&{cityMap:any})?.cityMap;return m?.getLayer('ncr-fill')&&m.queryRenderedFeatures({layers:['ncr-fill']}).length>0;});
> 12 |  const mapAssets=JSON.parse(await readFile('docs/evidence/ml-pwa-assets.json','utf8')).map_only_assets as string[];await expect.poll(async()=>{const paths=await cachePaths();return mapAssets.every(asset=>paths.includes(asset));}).toBe(true);
     |                                                                                                                                                                                                                                       ^ Error: expect(received).toBe(expected) // Object.is equality
  13 |  await context.setOffline(true);await page.reload();await expect(page.locator('.city-picker button')).toHaveCount(17);await expect(page.locator('.basemap-indicator')).toContainText('offline');await page.waitForFunction(()=>{const m=(document.querySelector('.city-map-canvas') as HTMLElement&{cityMap:any})?.cityMap;return m?.getLayer('ncr-fill')&&m.queryRenderedFeatures({layers:['ncr-fill']}).length>0;});
  14 |  const range=await page.evaluate(async()=>{const r=await fetch('/basemap/metro-manila.pmtiles',{headers:{Range:'bytes=0-126'}});return {status:r.status,bytes:(await r.arrayBuffer()).byteLength,range:r.headers.get('Content-Range')};});expect(range).toEqual({status:206,bytes:127,range:'bytes 0-126/6712783'});
  15 |  mapRequests.length=0;await goto(page,'/report');await page.getByRole('checkbox').check();await expect(page.getByRole('button',{name:'Continue to report',exact:true})).toBeDisabled();expect(mapRequests).toEqual([]);
  16 |  expect(violations).toEqual([]);paths=await cachePaths();expect(paths.some(p=>p.startsWith('/admin')||p.includes('rest/v1')||p.startsWith('/img/source/'))).toBe(false);
  17 | });
  18 | test("production serves security headers and rejects fixture pages and legacy report preview", async ({
  19 |   page,
  20 |   request,
  21 | }) => {
  22 |   const response = await request.get("/");
  23 |   expect(response.headers()["content-security-policy"]).toContain(
  24 |     "script-src 'self'",
  25 |   );
  26 |   expect(response.headers()["content-security-policy"]).toContain(
  27 |     "frame-ancestors 'none'",
  28 |   );
  29 |   expect(response.headers()["x-content-type-options"]).toBe("nosniff");
  30 |   for (const route of ["/dev", "/design-preview", "/dev/legacy-report"]) {
  31 |     await goto(page, route);
  32 |     await expect(
  33 |       activeView(page).getByRole("heading", { name: "Page not found" }),
  34 |     ).toBeVisible();
  35 |   }
  36 | });
  37 | 
  38 | test("production styles and public research charts comply with the strict CSP",async({page})=>{
  39 |  const violations:string[]=[];
  40 |  await page.exposeFunction('recordPolicyViolation',(directive:string)=>violations.push(directive));
  41 |  await page.addInitScript(()=>document.addEventListener('securitypolicyviolation',event=>{void (window as any).recordPolicyViolation(event.violatedDirective);}));
  42 |  for(const path of ['/','/risk-map','/report','/about','/trends','/methodology','/data-sources']){
  43 |   await goto(page, path);await expect(activeView(page).getByRole('heading',{level:1})).toBeVisible();
  44 |   if(path==='/methodology')await expect(activeView(page).getByRole('heading',{name:'How accurate is this?'})).toBeVisible();
  45 |   if(path==='/data-sources')await expect(page.locator('.coverage-present').first()).not.toHaveCSS('background-color','rgba(0, 0, 0, 0)');
  46 |  }
  47 |  expect(violations).toEqual([]);
  48 | });
  49 | 
```