# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ml-map.spec.ts >> rendered map pixels show the saved green and red probability classes
- Location: tests\ui\ml-map.spec.ts:29:1

# Error details

```
Error: Command failed: python tests/map-pixels.py .artifacts/mlux/pixels/red.png 481.89062500014774 729.8906249999261 3
Traceback (most recent call last):
  File "D:\Project\[REDACTED]\tests\map-pixels.py", line 11, in <module>
    print(json.dumps({'level':level,'sampled':samples,'matching_pixels':matched,'passed':matched>=8}));assert matched>=8,'Expected traffic color was not rendered near the measured city interior'
                                                                                                              ^^^^^^^^^^
AssertionError: Expected traffic color was not rendered near the measured city interior

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - link "Skip to content" [ref=e5] [cursor=pointer]:
      - /url: "#main"
    - banner [ref=e6]:
      - link "DengueWatch home" [ref=e7] [cursor=pointer]:
        - /url: /
        - text: DENGUE
        - generic [ref=e8]: WATCH
      - navigation "Main navigation" [ref=e9]:
        - link "Dashboard" [ref=e10] [cursor=pointer]:
          - /url: /
        - link "Risk Map" [ref=e11] [cursor=pointer]:
          - /url: /risk-map
        - link "Community Report" [ref=e12] [cursor=pointer]:
          - /url: /report
      - generic "Page language" [ref=e13]:
        - button "English" [pressed] [ref=e14] [cursor=pointer]
        - button "Filipino" [ref=e15] [cursor=pointer]
    - main [ref=e16]:
      - generic [ref=e17]:
        - generic [ref=e18]:
          - generic [ref=e19]:
            - paragraph [ref=e20]: METRO MANILA · 17 AREAS
            - heading "Risk Map" [level=1] [ref=e21]
          - link "What should I do?" [ref=e22] [cursor=pointer]:
            - /url: /#actions
        - region "Forecast mode" [ref=e23]:
          - generic [ref=e24]:
            - text: Replay · historical example
            - paragraph [ref=e25]: Example week from our test data.
            - paragraph [ref=e26]:
              - text: Showing week of
              - time [ref=e27]: 2019-09-01
          - generic [ref=e28]:
            - generic [ref=e29]:
              - button "Replay" [pressed] [ref=e30] [cursor=pointer]
              - button "Live" [disabled] [ref=e31]
            - paragraph [ref=e32]: Live needs recent weekly counts for all 17 cities.
            - paragraph [ref=e33]: Ask the project admin to upload reviewed counts.
        - paragraph [ref=e34]: An outbreak here means unusually high recorded cases. It is not an official declaration.
        - generic [ref=e35]:
          - generic [ref=e36]:
            - text: Find a city
            - searchbox "Find a city" [ref=e37]
          - button "Show data table" [ref=e38] [cursor=pointer]
          - generic [ref=e39]:
            - checkbox "High contrast" [ref=e40]
            - text: High contrast
          - generic [ref=e41]:
            - checkbox "Tilt map" [disabled] [ref=e42]
            - text: Tilt map
        - group "Choose a city" [ref=e43]:
          - button "Caloocan. more than 9 in 10" [active] [pressed] [ref=e44] [cursor=pointer]: Caloocan
          - button "Las Pinas. more than 9 in 10" [ref=e45] [cursor=pointer]: Las Pinas
          - button "Makati. more than 9 in 10" [ref=e46] [cursor=pointer]: Makati
          - button "Malabon. more than 9 in 10" [ref=e47] [cursor=pointer]: Malabon
          - button "Mandaluyong. about 8 in 10" [ref=e48] [cursor=pointer]: Mandaluyong
          - button "Manila. more than 9 in 10" [ref=e49] [cursor=pointer]: Manila
          - button "Marikina. more than 9 in 10" [ref=e50] [cursor=pointer]: Marikina
          - button "Muntinlupa. more than 9 in 10" [ref=e51] [cursor=pointer]: Muntinlupa
          - button "Navotas. about 6 in 10" [ref=e52] [cursor=pointer]: Navotas
          - button "Paranaque. more than 9 in 10" [ref=e53] [cursor=pointer]: Paranaque
          - button "Pasay. more than 9 in 10" [ref=e54] [cursor=pointer]: Pasay
          - button "Pasig. more than 9 in 10" [ref=e55] [cursor=pointer]: Pasig
          - button "Pateros. less than 1 in 10" [ref=e56] [cursor=pointer]: Pateros
          - button "Quezon. more than 9 in 10" [ref=e57] [cursor=pointer]: Quezon
          - button "San Juan. about 9 in 10" [ref=e58] [cursor=pointer]: San Juan
          - button "Taguig. more than 9 in 10" [ref=e59] [cursor=pointer]: Taguig
          - button "Valenzuela. more than 9 in 10" [ref=e60] [cursor=pointer]: Valenzuela
        - generic [ref=e61]:
          - generic [ref=e62]:
            - generic "Interactive city map" [ref=e64]:
              - region "Metro Manila city risk map. Arrow keys cycle cities. Enter selects." [ref=e65]
              - generic:
                - generic [ref=e66]:
                  - button "Zoom in" [ref=e67] [cursor=pointer]
                  - button "Zoom out" [ref=e69] [cursor=pointer]
                - group [ref=e71]:
                  - generic [ref=e72]: Protomaps; OpenStreetMap contributors
            - status: "Map: offline · local basemap"
            - paragraph [ref=e73]: Protomaps · OpenStreetMap contributors
          - complementary "Selected city" [ref=e74]:
            - paragraph [ref=e75]: CITY DETAIL
            - heading "Caloocan" [level=2] [ref=e76]
            - generic [ref=e77]:
              - generic [aria-hidden] [ref=e78]: "!"
              - text: High
            - paragraph [ref=e79]: "Chance of an outbreak next week:"
            - paragraph [ref=e80]: more than 9 in 10
            - paragraph [ref=e81]: Recent counts were already high for this city.
            - paragraph [ref=e82]: ↑ Last recorded count rose.
            - img "Eight-week recorded cases. Missing weeks leave gaps." [ref=e83]
            - paragraph [ref=e85]: Recorded cases over eight weeks.
            - paragraph [ref=e86]: "Latest recorded count: 166"
            - generic [ref=e87]:
              - heading "What actually happened" [level=3] [ref=e88]
              - paragraph [ref=e89]: "Yes: cases were unusually high."
              - paragraph [ref=e90]: 198 recorded cases
            - paragraph [ref=e91]: In past test weeks at this level, 186 / 199 crossed the threshold.
            - link "What to do now" [ref=e92] [cursor=pointer]:
              - /url: /#actions
        - generic "Risk legend" [ref=e93]:
          - generic [ref=e94]: ○ Low
          - generic [ref=e95]: ◔ Watch
          - generic [ref=e96]: ▲ Raised
          - generic [ref=e97]: "! High"
          - generic [ref=e98]: "Resolution: city."
        - generic [ref=e99]:
          - button "Play weeks" [disabled] [ref=e100]
          - generic [ref=e101]:
            - text: Choose an example week
            - slider "Choose an example week" [ref=e102]: "0"
          - status [ref=e103]: 2019-09-01
          - paragraph [ref=e104]: Motion is off. Change weeks with the slider.
        - paragraph [ref=e105]:
          - text: The online map contacts OpenFreeMap. Its server receives your IP address.
          - link "Read the methods and privacy limits." [ref=e106] [cursor=pointer]:
            - /url: /about#methods
      - complementary [ref=e107]:
        - heading "Estimates, not alerts" [level=2] [ref=e108]
        - paragraph [ref=e109]: Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.
    - contentinfo [ref=e110]:
      - generic [ref=e111]:
        - link "About & Credits" [ref=e112] [cursor=pointer]:
          - /url: /about
        - button "About the data & methods" [ref=e113] [cursor=pointer]
      - paragraph [ref=e114]:
        - text: Bundled source periods.
        - time [ref=e115]: Dec 2, 2023
        - text: ·
        - time [ref=e116]: Dec 27, 2020
        - text: . Replay uses historical records. Live needs reviewed recent counts.
      - paragraph [ref=e117]: Community reports are unverified; not medical advice.
      - paragraph [ref=e118]: Background photograph by Sumarie Slabber
      - paragraph [ref=e119]: Thesis research · Not an official DOH product · Historical records, not a live warning.
  - status
```

# Test source

```ts
  1  | import {mkdir} from 'node:fs/promises';
  2  | import {execFileSync} from 'node:child_process';
  3  | import {test,expect,type Page} from '@playwright/test';
  4  | import {readFile} from 'node:fs/promises';
  5  | import {parse} from 'csv-parse/sync';
  6  | import {mockPublicApi} from '../fixtures/public-fixtures';
  7  | import {reportingHarness} from '../support/reporting-harness';
  8  | const saved=JSON.parse(await readFile('public/ml/replay.json','utf8'));
  9  | const summary=JSON.parse(await readFile('public/ml/summary.json','utf8'));
  10 | const raw=parse(await readFile('data/raw/doh-epi-dengue-data-2016-2021.csv','utf8'),{columns:true,skip_empty_lines:true}) as Record<string,string>[];
  11 | const batch=raw.filter(r=>r.Region==='NATIONAL CAPITAL REGION').map(r=>({city:r.loc,week_ending:new Date(r.date+' UTC').toISOString().slice(0,10),cases:Number(r.cases)})).filter(r=>r.week_ending>='2019-03-10'&&r.week_ending<='2019-09-01');
  12 | async function mapReady(page:Page){await expect(page.locator('.city-picker button')).toHaveCount(17);await page.waitForFunction(()=>{const m=(document.querySelector('.city-map-canvas') as HTMLElement&{cityMap:any}|null)?.cityMap;return m?.getLayer('ncr-fill')&&m.queryRenderedFeatures({layers:['ncr-fill']}).length>0;});await expect(page.locator('.map-drawing')).toHaveCount(0);}
  13 | async function base(page:Page){await mockPublicApi(page,{open:false});await page.route('https://tiles.openfreemap.org/**',r=>r.abort());}
  14 | 
  15 | test('Dashboard gives the exact top three, dated Replay, actions and closed evidence without primary jargon or map requests',async({page})=>{await base(page);const mapRequests:string[]=[];page.on('request',r=>{if(/MapProvider|maplibre|\.pmtiles|openfreemap|ncr-cities\.geojson/.test(r.url()))mapRequests.push(r.url());});await page.goto('/');await expect(page.locator('.top-city-list li')).toHaveCount(3);const expected=summary.preview.slice().sort((a:any,b:any)=>b.probability-a.probability||a.city.localeCompare(b.city)).slice(0,3);expect(await page.locator('.top-city-list li').evaluateAll(nodes=>nodes.map(n=>({city:n.getAttribute('data-city'),p:Number(n.getAttribute('data-probability'))})))).toEqual(expected.map((r:any)=>({city:r.city,p:r.probability})));await expect(page.locator('.forecast-mode')).toContainText(summary.preview_week);await expect(page.getByRole('button',{name:'Live',exact:true})).toBeDisabled();await expect(page.locator('.action-card-grid article')).toHaveCount(3);await expect(page.locator('.how-it-works li')).toHaveCount(3);await expect(page.locator('.dashboard-evidence')).not.toHaveAttribute('open');const visible=await page.locator('main').innerText();expect(visible).not.toMatch(/MAE|Spearman|Scenario M|persistence|Outlook Index/);await page.locator('.warning-details summary').click();await expect(page.locator('.warning-details')).toContainText('after fever goes away');await page.getByRole('button',{name:'Filipino',exact:true}).click();await expect(page.getByRole('heading',{name:'Mga dapat bantayan',exact:true})).toBeVisible();await expect(page.getByRole('heading',{name:'Ano ang dapat kong gawin?',exact:true})).toBeVisible();expect(mapRequests).toEqual([]);});
  16 | 
  17 | test('OpenFreeMap failure loads the real local PMTiles via HTTP ranges, with visible attribution and no cookies',async({page,context})=>{await base(page);const ranges:number[]=[];page.on('response',r=>{if(r.url().endsWith('.pmtiles'))ranges.push(r.status());});await page.goto('/risk-map');await mapReady(page);await expect(page.locator('.basemap-indicator')).toContainText('offline');expect(ranges).toContain(206);await expect(page.locator('.map-attribution')).toContainText('OpenStreetMap');const shape=await page.evaluate(()=>{const m=(document.querySelector('.city-map-canvas') as HTMLElement&{cityMap:any}).cityMap;return {source:m.getSource('ncr-risk').serialize().data.features.map((f:any)=>f.properties.city),centers:m.getSource('ncr-labels').serialize().data.features.length,visible:[...new Set(m.queryRenderedFeatures({layers:['ncr-fill']}).map((f:any)=>f.properties.city))]};});expect(new Set(shape.source).size).toBe(17);expect(shape.centers).toBe(17);expect(shape.visible.length).toBe(17);expect(await context.cookies()).toEqual([]);});
  18 | 
  19 | test('failure of both basemaps leaves actual city polygons and table on a plain background',async({page})=>{await base(page);await page.route('**/basemap/metro-manila.pmtiles',r=>r.fulfill({status:503,body:'Local file unavailable in this resilience test'}));await page.goto('/risk-map');await mapReady(page);await expect(page.locator('.basemap-indicator')).toContainText('Base map unavailable');await page.getByRole('button',{name:'Show data table',exact:true}).click();await expect(page.locator('.city-table tbody tr')).toHaveCount(17);expect(await page.locator('.city-table tbody tr').evaluateAll(rows=>rows.every(r=>r.getAttribute('data-probability')!=='missing'))).toBe(true);});
  20 | 
  21 | test('WebGL-unavailable fallback exposes 17 labelled keyboard-operable city polygons',async({page})=>{await base(page);await page.addInitScript(()=>{const original=HTMLCanvasElement.prototype.getContext;HTMLCanvasElement.prototype.getContext=function(this:HTMLCanvasElement,type:any,...args:any[]){if(String(type).includes('webgl'))return null;return original.call(this,type,...args as []) as any;} as typeof original;});await page.goto('/risk-map');const paths=page.locator('.city-map-fallback [data-city]');await expect(paths).toHaveCount(17);await paths.first().focus();const visited=new Set<string>();for(let i=0;i<17;i++){visited.add((await page.locator('.city-map-fallback :focus').getAttribute('data-city'))!);await page.keyboard.press('ArrowRight');}expect(visited.size).toBe(17);await expect(page.locator('.city-detail h2')).toBeVisible();});
  22 | 
  23 | test('reduced motion disables playback and tilt, all cities are reachable, high contrast and Filipino controls work',async({page})=>{await base(page);await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/risk-map');await mapReady(page);await expect(page.getByRole('button',{name:'Play weeks',exact:true})).toBeDisabled();await expect(page.getByLabel('Tilt map',{exact:true})).toBeDisabled();const buttons=page.locator('.city-picker button');await buttons.first().focus();const visited=new Set<string>();for(let i=0;i<17;i++){visited.add((await page.locator('.city-picker :focus').textContent())!);await page.keyboard.press('ArrowRight');}expect(visited.size).toBe(17);expect(await page.evaluate(()=>(document.querySelector('.city-map-canvas') as HTMLElement&{cityMap:any}).cityMap.getPaintProperty('ncr-pulse','line-width'))).toBe(3);await page.getByLabel('High contrast',{exact:true}).check();await page.waitForFunction(()=>(document.querySelector('.city-map-canvas') as HTMLElement&{cityMap:any}).cityMap.getLayer('ncr-hatch'));await page.getByRole('button',{name:'Filipino',exact:true}).click();await expect(page.getByRole('heading',{name:'Mapa ng Panganib',exact:true})).toBeVisible();await expect(page.getByRole('button',{name:'Palakihin ang mapa',exact:true})).toBeVisible();await expect(page.getByRole('button',{name:'I-play ang mga linggo',exact:true})).toBeDisabled();});
  24 | 
  25 | test('Live uses actual historical rows under a retrospective clock, matches Python, and disables stale or future inputs',async({page})=>{await base(page);await page.route('**/rest/v1/rpc/published_ncr_model_input',r=>r.fulfill({status:200,json:{id:'LOCAL-ACTUAL-SOURCE-ONLY',rows:batch,citation:'Actual DOH source; retrospective clock test'}}));await page.clock.setFixedTime(new Date('2019-09-02T04:00:00Z'));await page.goto('/risk-map');await expect(page.getByRole('button',{name:'Live',exact:true})).toBeEnabled();await page.getByRole('button',{name:'Live',exact:true}).click();await expect(page.locator('.forecast-mode')).toContainText('2019-09-08');await page.getByRole('button',{name:'Show data table',exact:true}).click();const expected=saved.rows.filter((r:any)=>r.target==='2019-09-08');for(const r of expected){const p=Number(await page.locator(`.city-table tr[data-city-row="${r.city}"]`).getAttribute('data-probability'));expect(Math.abs(p-r.probability)).toBeLessThanOrEqual(1e-9);}await page.clock.setFixedTime(new Date('2019-09-22T04:00:00Z'));await page.reload();await expect(page.getByRole('button',{name:'Live',exact:true})).toBeEnabled();await page.getByRole('button',{name:'Live',exact:true}).click();await expect(page.locator('.forecast-mode')).toContainText('The shown week has passed');await page.clock.setFixedTime(new Date('2019-09-23T04:00:00Z'));await page.reload();await expect(page.getByRole('button',{name:'Live',exact:true})).toBeDisabled();await expect(page.locator('.forecast-mode')).toContainText('Replay');await page.clock.setFixedTime(new Date('2019-08-01T04:00:00Z'));await page.reload();await expect(page.getByRole('button',{name:'Live',exact:true})).toBeDisabled();});
  26 | 
  27 | test('AAL2 admin previews actual 26-week NCR source rows, publishes and rolls back through real SQL',async({page})=>{const local=await reportingHarness('admin');try{await local.attach(page);await page.goto('/admin');await page.getByLabel('Staff email',{exact:true}).fill(local.email);await page.getByLabel('Password',{exact:true}).fill(local.password);await page.getByRole('button',{name:'Sign in',exact:true}).click();await expect(page.getByRole('heading',{name:'Metro Manila model data',exact:true})).toBeVisible();const csv='city,week_ending,cases\n'+batch.map(r=>`${r.city},${r.week_ending},${r.cases}`).join('\n');await page.getByLabel('NCR model CSV',{exact:true}).setInputFiles({name:'actual-doh-ncr.csv',mimeType:'text/csv',buffer:Buffer.from(csv)});await expect(page.getByRole('region',{name:'NCR upload preview'}).locator('tbody tr')).toHaveCount(34);await page.getByLabel('NCR source citation',{exact:true}).fill('LOCAL TEST: actual DOH NCR source');await page.getByRole('button',{name:'Stage NCR batch',exact:true}).click();await expect(page.getByRole('button',{name:'Publish NCR version',exact:true})).toBeVisible();await page.getByRole('button',{name:'Publish NCR version',exact:true}).click();await expect(page.getByRole('button',{name:'Roll back NCR version',exact:true})).toBeVisible();await page.getByRole('button',{name:'Roll back NCR version',exact:true}).click();await expect(page.getByRole('button',{name:'Roll back NCR version',exact:true})).toHaveCount(0);await local.db.exec('reset role');const audit=await local.db.query<{action:string}>("select action from public.staff_audit where action like '%ncr_model%' order by id");expect(audit.rows.map(r=>r.action)).toEqual(['stage_ncr_model_upload','ncr_model_published','ncr_model_rolled_back']);}finally{await local.close();}});
  28 | 
> 29 | test('rendered map pixels show the saved green and red probability classes',async({page})=>{await base(page);await page.goto('/risk-map');await mapReady(page);const week=saved.weeks.find((w:string)=>{const rows=saved.rows.filter((r:any)=>r.target===w);return rows.some((r:any)=>r.probability!==null&&r.probability<saved.bands[0])&&rows.some((r:any)=>r.probability>=saved.bands[2]);});expect(week).toBeTruthy();const slider=page.getByLabel('Choose an example week',{exact:true});await slider.focus();await slider.press('Home');for(let i=0;i<saved.weeks.indexOf(week);i++)await slider.press('ArrowRight');await expect(page.locator('.replay-controls output')).toHaveText(week);await mkdir('.artifacts/mlux/pixels',{recursive:true});for(const [kind,n] of [['green',0],['red',3]] as const){const row=saved.rows.find((r:any)=>r.target===week&&r.probability!==null&&(n===0?r.probability<saved.bands[0]:r.probability>=saved.bands[2]));await page.locator(`.city-picker button[aria-label^="${row.city.replace(' CITY','').toLowerCase().replace(/\b\w/g,(c:string)=>c.toUpperCase())}."]`).click();await page.waitForFunction((city:string)=>{const host=document.querySelector('.city-map-canvas') as HTMLElement&{cityMap:any};const m=host.cityMap;return !m.isMoving()&&m.queryRenderedFeatures({layers:['ncr-fill']}).some((f:any)=>f.properties.city===city);},row.city);const point=await page.evaluate((city:string)=>{const host=document.querySelector('.city-map-canvas') as HTMLElement&{cityMap:any},m=host.cityMap,f=m.getSource('ncr-risk').serialize().data.features.find((r:any)=>r.properties.city===city),p=m.project(f.properties.center),rect=m.getCanvas().getBoundingClientRect();return {x:rect.left+p.x,y:rect.top+p.y};},row.city);const file=`.artifacts/mlux/pixels/${kind}.png`;await page.screenshot({path:file});const output=JSON.parse(execFileSync(process.platform==='win32'?'python':'python3',['tests/map-pixels.py',file,String(point.x),String(point.y),String(n)],{encoding:'utf8'}));expect(output.passed).toBe(true);}});
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ^ Error: Command failed: python tests/map-pixels.py .artifacts/mlux/pixels/red.png 481.89062500014774 729.8906249999261 3
  30 | 
```