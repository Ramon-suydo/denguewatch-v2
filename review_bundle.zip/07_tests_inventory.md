# Test inventory

## tests/composite.test.ts
- real-data paired backtest excludes future targets, rejects candidate and records all factors
- suppressed community weeks never become zeros; only complete weeks compare
## tests/data-and-security.test.ts
- real sources: coverage, gaps, anomalies and all six year-pairs
- normalization and strict number/date validation
- rerun is idempotent; citations and unchanged ingestion timestamps survive
- failed verification rolls back the whole import
- public tables are readable but anonymous and ordinary users cannot write
- admin writes work and backtest absolute error is database-derived
- community insert validates consent, status, dates, LGU, and optional contact
- no public raw reads; groups below five suppressed; code withdrawal removes contact
- constraints also protect privileged direct writes
- real-source forecasts persist for all cities and public users cannot change them or collection policy
- collection gate and global daily ceiling apply to direct anonymous RPC calls
- expired rows are suppressed immediately and the owner cleanup removes them
## tests/data-confidence.test.ts
- confidence totals, overlap differences and gaps come from the verified Manila snapshot
## tests/database-tls.test.ts
- CA configuration accepts PEM files and explains directory/missing/invalid paths
## tests/demo-snapshot.test.ts
- verified DB snapshot preserves counts, every official source value, gaps and artifact checksums without community/contact data
- cancelled published reads do not switch the app to snapshot mode
## tests/environment.test.ts
- civil Manila hours align Monday-Sunday without shifting to UTC day
- frozen lag selection ignores test-year cases and weather
- forecast features and training fits never use origin-week or future weather / cases
- cross-source comparison pairs dates, reports disagreement and never fills absent weeks
- public forecast remains persistence when environmental input is absent or rejected
- daily server refresh caches failures too and only accepts delayed complete weeks
- cache fetches cannot target arbitrary services and offline misses give exact destination
- PAGASA season context is explicitly non-predictive in both languages
- saved environmental evidence is paired, uses training-only lag selection and contains no raw reports
## tests/fixture-build-guard.test.ts
- production rejects the test-only fixture flag
## tests/fixtures/DesignPreview.tsx
helper/fixture or Python unittest; inspect copied source
## tests/fixtures/geometry-invalid.json
helper/fixture or Python unittest; inspect copied source
## tests/fixtures/public-fixtures.ts
helper/fixture or Python unittest; inspect copied source
## tests/forecast.test.ts
- WMA and interpolated thresholds use the city distribution, not fixed thresholds
- partial, suspect, wrong-source, wrong-city and incomplete months cannot enter a forecast
- insufficient sample and degenerate distributions never invent risk tiers
- date controls and recent community window use Asia/Manila calendar dates
## tests/geography-context.test.py
helper/fixture or Python unittest; inspect copied source
## tests/launch-gate.test.ts
- retired activation command fails before any database connection
## tests/local-setup.test.ts
- local setup rejects hosted, credential-confusable, non-HTTP and remote database destinations
- staff development mode refuses fallback to hosted configuration
## tests/manila-data.test.ts
- Sunday weeks, ISO year boundaries and leap days are deterministic in UTC
- Z explicitly imputes absence; M preserves missing; zero rows are observed
- all-absent interior weeks differ from partial coverage; no assumption beyond source end
- real immutable sources: join, gaps, audit reconciliation, reproducible weekly sums
## tests/manila-model.test.ts
- fitters cannot see future targets, scalers, tree splits or weather
- exact calendar lags are required and demographics are not features
- threshold uses previous years and cannot depend on the future target count
- calibration waits for outcomes to mature; undefined classification stays unavailable
- MASE, interval coverage, tied AUC and seeded paired bootstrap are verifiable
- episode lead uses observed consecutive weeks and actual pre-onset calendar origins
## tests/measurements.test.ts
- calendar autocorrelation never compresses missing weeks or invents variance
## tests/ncr-colors.test.ts
- NCR boundary strokes exceed 3:1 against every rate fill across normal and simulated color vision
## tests/production/pwa.spec.ts
- production PWA installs public cache, survives offline reload, and never caches staff/report requests
- production serves security headers and rejects fixture pages and legacy report preview
- production styles and public research charts comply with the strict CSP
## tests/reporting-v2.test.ts
- new reporting is closed by default; legacy path remains closed even if its old policy opens
- consent, future date, schema, honeypot and unknown area are enforced before storage
- proof replay fails, notes are scrubbed, XSS remains text, duplicate/burst signals quarantine
- public and ordinary authenticated callers cannot enumerate reports or use staff RPCs
- moderation is role checked and audited; only delayed groups >=3 publish; withdrawal has no existence oracle
- validated upload preview, publish and rollback are atomic, audited and separate from frozen data
- retention removes sensitive signals; all new tables have RLS; purge is not public
- appointed staff cannot review reports with an AAL1 session
- v2 global submission and challenge issuance limits reject bursts without bypassing proof
- legacy admin RLS requires AAL2 and recognizes current admin appointments
## tests/research-security.test.ts
- client builds reject private environment names and service-role JWTs
- versioned public research endpoints contain no individual reports and cannot claim live risk
- PWA allowlist contains public assets only and security headers prohibit framing and script injection
## tests/retention-launch.test.ts
- fresh migration chain protects retention RPC and provides an hourly schedule definition
- shipped attribution/filler gate rejects unresolved template text without rejecting honest unknowns
## tests/secret-audit.test.mjs
- secret audit detects private patterns in text and compressed archive members without exposing values
## tests/source-metadata.test.ts
- citation metadata reports pending fields without blocking the test or build
## tests/support/reporting-harness.ts
helper/fixture or Python unittest; inspect copied source
## tests/tondo-map.test.ts
- map covers real source shapes and populations with explicit missing records and equal-area units
- map ramp preserves monotonic luminance in three color-vision simulations and absence is distinct from zero
- committed shared topology passes per-polygon validity, winding and five-percent area gates
- invalid or collapsed polygons are rejected rather than drawn
## tests/ui/accuracy.spec.ts
- visible accuracy MAEs match every selected saved evaluation value exactly
## tests/ui/data-confidence.spec.ts
- confidence leads with checked Manila work and retains closed disclosures and footer
## tests/ui/demo-hardening.spec.ts
- all public routes retain mobile targets, console hygiene and axe
- blocked external services leave static historical pages and closed reporting usable
- warmed routes and validated datasets remain available with the browser fully offline
- slow research reads show loading without inventing a current risk, then resolve
## tests/ui/demo-keyboard.spec.ts
- keyboard skip link, visible focus and reduced motion
## tests/ui/design-system.spec.ts
- preview interactions, consent, focus restoration and desktop accessibility
- responsive layout, mobile menu and mobile accessibility
## tests/ui/environment.spec.ts
- weather failure leaves historical persistence usable and providers stay server-only
- environment ablation and exploratory city context remain accessible at 360px
## tests/ui/evidence.spec.ts
- research pages: mobile/desktop, no overflow, no critical or serious axe issues
- scenario and year changes keep absence explicit; NCR remains historical
- Filipino home/prevention, missing API retry, and legacy forecasts isolated
## tests/ui/grid.spec.ts
- historical NCR map is offline, keyboard accessible and never assigns district case counts
- all 17 city shapes and selected-city details clear navigation at four widths
## tests/ui/legal-print.spec.ts
- legal notices, closed consent, no sensitive browser storage and print-friendly public evidence
## tests/ui/public-app.spec.ts
- Manila stitched history preserves exact recorded values and source boundaries
- consent is opt-in, contact is optional, submission uses only RPC, and withdrawal hides code existence
- closed collection, legacy redirect, service errors and retry have usable states
- historical NCR map distinguishes missing source weeks from zero
- public routes retain disclaimers and legal access on phones
- publishable community aggregates remain delayed, unverified and separate
- loading resolves to an explicit empty snapshot without fabricated values
- historical forecast exposes all horizons and explicit interval uncertainty
- model numbers exactly match saved evidence across scenarios and horizons
- bundled footer dates never become a false live DB coverage claim
## tests/ui/reporting-flow.spec.ts
- local seeded MFA staff reviews real SQL reports; threshold, delay, PII, raw denial and withdrawal hold
## tests/ui/staff-reporting.spec.ts
- unauthenticated staff paths expose only sign-in and no public navigation or queue
- v2 reporting is closed by default, opt-in and bilingual without storing health fields
- v2 open-policy preview collects coarse fields only and strips identifying note patterns
## tests/weekly-forecast.test.ts
- weekly forecasts never read future cases, future training labels, or unobserved multi-step residuals
- weekly gaps and suspect observations never become zero, shifted lags or interpolated training examples
- MAE, RMSE, zero-safe sMAPE, skill and empirical interval coverage match tiny hand-calculated examples
- rolling evaluation compares identical targets and reports COVID by target date; model selection ignores test outcomes

## Coverage

- ingestion: TESTS EXIST; see complete source inventory and fresh command logs.
- absent-day scenarios: TESTS EXIST; see complete source inventory and fresh command logs.
- feature leakage: TESTS EXIST; see complete source inventory and fresh command logs.
- risk logic: TESTS EXIST; see complete source inventory and fresh command logs.
- forecast/backtest: TESTS EXIST; see complete source inventory and fresh command logs.
- weather fallback: TESTS EXIST; see complete source inventory and fresh command logs.
- report validation: TESTS EXIST; see complete source inventory and fresh command logs.
- PII stripping: TESTS EXIST; see complete source inventory and fresh command logs.
- k-threshold suppression: TESTS EXIST; see complete source inventory and fresh command logs.
- rate limiting: TESTS EXIST; see complete source inventory and fresh command logs.
- staff role/MFA claims: TESTS EXIST; see complete source inventory and fresh command logs.
- RLS: TESTS EXIST; see complete source inventory and fresh command logs.
- purge/retention: TESTS EXIST; see complete source inventory and fresh command logs.
- accessibility: TESTS EXIST; see complete source inventory and fresh command logs.
- saved-evaluation UI numbers: TESTS EXIST; see complete source inventory and fresh command logs.

Real hosted Supabase Auth/TOTP delivery, actual deployed schedule execution, hosted ZAP and human usability/DPO approval: NO VERIFIED LOCAL SUBSTITUTE / NEEDS OWNER. The signed local Auth/PostgREST adapter verifies ephemeral test JWTs and runs actual SQL roles/RPCs; it is not certification of Supabase Auth cryptography or hosted deployment. Existing legacy v1 regression tests deliberately use the five older migrations; current v2 tests and db:verify apply all eleven.
