# Test inventory and coverage

Static source names follow. Fresh actual registrations: 02_logs/test-list.txt; full output and failures are in 02_logs. Static source presence is not a fresh passing result. Fixtures are synthetic/local; no real reports are included.

|Area|Tests present|Fresh evidence / limit|
|---|---|---|
|Ingestion|data-and-security.test.ts, manila-data.test.ts|Fresh Node/SQL tests passed; scope is isolated fixtures, not hosting.|
|Absent-day Z/M scenarios|manila-data.test.ts, measurements.test.ts|Fresh Node/SQL tests passed; scope is isolated fixtures, not hosting.|
|No-leakage in features|manila-model.test.ts, environment.test.ts|Fresh Node/SQL tests passed; scope is isolated fixtures, not hosting.|
|Risk / endemic threshold logic|manila-model.test.ts, forecast.test.ts, composite.test.ts|Fresh Node/SQL tests passed; scope is isolated fixtures, not hosting.|
|Forecast / backtest|forecast.test.ts, weekly-forecast.test.ts, manila-model.test.ts|Fresh Node/SQL tests passed; scope is isolated fixtures, not hosting.|
|Weather fallback|environment.test.ts, ui/environment.spec.ts|Fresh Node unit suite passed; browser coverage exists but the complete fresh browser suite failed, so do not cite it as a pass.|
|Report validation|reporting-v2.test.ts, ui/staff-reporting.spec.ts|Fresh Node unit suite passed; browser coverage exists but the complete fresh browser suite failed, so do not cite it as a pass.|
|PII stripping|reporting-v2.test.ts, ui/staff-reporting.spec.ts|Fresh Node unit suite passed; browser coverage exists but the complete fresh browser suite failed, so do not cite it as a pass.|
|k-threshold suppression|reporting-v2.test.ts, data-and-security.test.ts|Fresh Node/SQL tests passed; scope is isolated fixtures, not hosting.|
|Rate limiting / replay / burst|reporting-v2.test.ts|Fresh Node/SQL tests passed; scope is isolated fixtures, not hosting.|
|Admin access control|reporting-v2.test.ts, ui/staff-reporting.spec.ts|Fresh Node unit suite passed; browser coverage exists but the complete fresh browser suite failed, so do not cite it as a pass.|
|RLS|reporting-v2.test.ts, data-and-security.test.ts|Fresh Node/SQL tests passed; scope is isolated fixtures, not hosting.|
|Purge function|reporting-v2.test.ts, data-and-security.test.ts|Fresh Node/SQL tests passed; scope is isolated fixtures, not hosting.|
|Accessibility / keyboard / viewport|ui/evidence.spec.ts, ui/demo-hardening.spec.ts, ui/demo-keyboard.spec.ts, ui/environment.spec.ts|Fresh Node unit suite passed; browser coverage exists but the complete fresh browser suite failed, so do not cite it as a pass.|
|Hosted Auth/MFA|NO TEST of real hosted login/MFA|NOT VERIFIED|
|Actual scheduled purge / daily weather deployment|NO TEST of hosted execution|NOT VERIFIED; function/guard tests do not prove scheduling|
|Human usability / SUS|NO TEST conducted with real users|NOT VERIFIED; template stays blank|

## tests/composite.test.ts

- real-data paired backtest excludes future targets, rejects candidate and records all factors
- suppressed community weeks never become zeros; only complete weeks compare

## tests/data-and-security.test.ts

- real sources: coverage, gaps, anomalies and all six year-pairs
- normalization and strict number/date validation
- rerun is idempotent; citations and unchanged ingestion timestamps survive
- failed verification rolls back the whole import
- public tables are readable but anonymous and ordinary users cannot write
- admin writes work and backtest absolute error is database-derived
- community insert validates consent, status, dates, LGU, and optional contact
- no public raw reads; groups below five suppressed; code withdrawal removes contact
- constraints also protect privileged direct writes
- real-source forecasts persist for all cities and public users cannot change them or collection policy
- collection gate and global daily ceiling apply to direct anonymous RPC calls
- expired rows are suppressed immediately and the owner cleanup removes them

## tests/data-confidence.test.ts

- confidence totals, overlap differences and gaps come from the verified Manila snapshot

## tests/database-tls.test.ts

- CA configuration accepts PEM files and explains directory/missing/invalid paths

## tests/demo-snapshot.test.ts

- verified DB snapshot preserves counts, every official source value, gaps and artifact checksums without community/contact data
- cancelled published reads do not switch the app to snapshot mode

## tests/environment.test.ts

- civil Manila hours align Monday-Sunday without shifting to UTC day
- frozen lag selection ignores test-year cases and weather
- forecast features and training fits never use origin-week or future weather / cases
- cross-source comparison pairs dates, reports disagreement and never fills absent weeks
- public forecast remains persistence when environmental input is absent or rejected
- daily server refresh caches failures too and only accepts delayed complete weeks
- cache fetches cannot target arbitrary services and offline misses give exact destination
- PAGASA season context is explicitly non-predictive in both languages
- saved environmental evidence is paired, uses training-only lag selection and contains no raw reports

## tests/fixture-build-guard.test.ts

- production rejects the test-only fixture flag

## tests/fixtures/DesignPreview.tsx

Fixture/helper only or dynamically registered: no static literal test name found

## tests/fixtures/public-fixtures.ts

Fixture/helper only or dynamically registered: no static literal test name found

## tests/forecast.test.ts

- WMA and interpolated thresholds use the city distribution, not fixed thresholds
- partial, suspect, wrong-source, wrong-city and incomplete months cannot enter a forecast
- insufficient sample and degenerate distributions never invent risk tiers
- date controls and recent community window use Asia/Manila calendar dates

## tests/geography-context.test.py

- test_metric_buffer_and_monotonicity
- test_spearman_ties_and_reverse_ranks
- test_actual_context_has_seventeen_cities_and_bounded_proxies

## tests/launch-gate.test.ts

- retired activation command fails before any database connection

## tests/local-setup.test.ts

- local setup rejects hosted, credential-confusable, non-HTTP and remote database destinations
- staff development mode refuses fallback to hosted configuration

## tests/manila-data.test.ts

- Sunday weeks, ISO year boundaries and leap days are deterministic in UTC
- Z explicitly imputes absence; M preserves missing; zero rows are observed
- all-absent interior weeks differ from partial coverage; no assumption beyond source end
- real immutable sources: join, gaps, audit reconciliation, reproducible weekly sums

## tests/manila-model.test.ts

- fitters cannot see future targets, scalers, tree splits or weather
- exact calendar lags are required and demographics are not features
- threshold uses previous years and cannot depend on the future target count
- calibration waits for outcomes to mature; undefined classification stays unavailable
- MASE, interval coverage, tied AUC and seeded paired bootstrap are verifiable
- episode lead uses observed consecutive weeks and actual pre-onset calendar origins

## tests/measurements.test.ts

- calendar autocorrelation never compresses missing weeks or invents variance

## tests/ncr-colors.test.ts

- NCR boundary strokes exceed 3:1 against every rate fill across normal and simulated color vision

## tests/production/pwa.spec.ts

- production PWA installs public cache, survives offline reload, and never caches staff/report requests
- production serves security headers and rejects fixture pages and legacy report preview

## tests/reporting-v2.test.ts

- new reporting is closed by default; legacy path remains closed even if its old policy opens
- consent, future date, schema, honeypot and unknown area are enforced before storage
- proof replay fails, notes are scrubbed, XSS remains text, duplicate/burst signals quarantine
- public and ordinary authenticated callers cannot enumerate reports or use staff RPCs
- moderation is role checked and audited; only delayed groups >=3 publish; withdrawal has no existence oracle
- validated upload preview, publish and rollback are atomic, audited and separate from frozen data
- retention removes sensitive signals; all new tables have RLS; purge is not public

## tests/research-security.test.ts

- client builds reject private environment names and service-role JWTs
- versioned public research endpoints contain no individual reports and cannot claim live risk
- PWA allowlist contains public assets only and security headers prohibit framing and script injection

## tests/source-metadata.test.ts

- citation metadata reports pending fields without blocking the test or build

## tests/tondo-map.test.ts

- map covers real source shapes and populations with explicit missing records and equal-area units
- map ramp preserves monotonic luminance in three color-vision simulations and absence is distinct from zero
- committed shared topology passes per-polygon validity, winding and five-percent area gates
- invalid or collapsed polygons are rejected rather than drawn

## tests/ui/data-confidence.spec.ts

- confidence leads with checked Manila work and retains closed disclosures and footer

## tests/ui/demo-hardening.spec.ts

- all public routes retain mobile targets, console hygiene and axe
- blocked external services leave static historical pages and closed reporting usable
- warmed routes and validated datasets remain available with the browser fully offline
- slow research reads show loading without inventing a current risk, then resolve

## tests/ui/demo-keyboard.spec.ts

- keyboard skip link, visible focus and reduced motion

## tests/ui/design-system.spec.ts

- preview interactions, consent, focus restoration and desktop accessibility
- responsive layout, mobile menu and mobile accessibility

## tests/ui/environment.spec.ts

- weather failure leaves historical persistence usable and providers stay server-only
- environment ablation and exploratory city context remain accessible at 360px

## tests/ui/evidence.spec.ts

- research pages: mobile/desktop, no overflow, no critical or serious axe issues
- scenario and year changes keep absence explicit; NCR remains historical
- Filipino home/prevention, missing API retry, and legacy forecasts isolated

## tests/ui/grid.spec.ts

- historical NCR map is offline, keyboard accessible and never assigns district case counts
- all 17 city shapes and selected-city details clear navigation at four widths

## tests/ui/legal-print.spec.ts

- legal notices, closed consent, no sensitive browser storage and print-friendly public evidence

## tests/ui/public-app.spec.ts

- Manila stitched history preserves exact recorded values and source boundaries
- consent is opt-in, contact is optional, submission uses only RPC, and withdrawal hides code existence
- closed collection, legacy redirect, service errors and retry have usable states
- historical NCR map distinguishes missing source weeks from zero
- public routes retain disclaimers and legal access on phones
- publishable community aggregates remain delayed, unverified and separate
- loading resolves to an explicit empty snapshot without fabricated values
- historical forecast exposes all horizons and explicit interval uncertainty
- model numbers exactly match saved evidence across scenarios and horizons
- bundled footer dates never become a false live DB coverage claim

## tests/ui/staff-reporting.spec.ts

- unauthenticated staff paths expose only sign-in and no public navigation or queue
- v2 reporting is closed by default, opt-in and bilingual without storing health fields
- v2 open-policy preview collects coarse fields only and strips identifying note patterns

## tests/weekly-forecast.test.ts

- weekly forecasts never read future cases, future training labels, or unobserved multi-step residuals
- weekly gaps and suspect observations never become zero, shifted lags or interpolated training examples
- MAE, RMSE, zero-safe sMAPE, skill and empirical interval coverage match tiny hand-calculated examples
- rolling evaluation compares identical targets and reports COVID by target date; model selection ignores test outcomes
