# Unrun scope

No explicit skips in final local unit or browser suites. Failed attempts are preserved in command logs. Hosted credentials/bootstrap/login/TOTP/scheduler/ZAP, a real usability session and DPO approval were not completed; owner explicitly deferred rotation. No live migration, report activation or production push occurred.
