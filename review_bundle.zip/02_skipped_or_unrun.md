# Skipped/unrun test ledger

Unit explicit skips: 0. Full browser explicit skips: 0. Serial diagnostic explicitly reports 17 did not run; global timeout was 180000ms. The list below is the fresh test-list registrations minus serial-started registrations (computed 17). Every listed case was unrun because the diagnostic was stopped by that suite time limit, not because it passed or was judged unnecessary.

- evidence.spec.ts:85:1 › Filipino home/prevention, missing API retry, and legacy forecasts isolated
- grid.spec.ts:3:1 › historical NCR map is offline, keyboard accessible and never assigns district case counts
- grid.spec.ts:34:1 › all 17 city shapes and selected-city details clear navigation at four widths
- legal-print.spec.ts:3:1 › legal notices, closed consent, no sensitive browser storage and print-friendly public evidence
- public-app.spec.ts:9:1 › Manila stitched history preserves exact recorded values and source boundaries
- public-app.spec.ts:28:1 › consent is opt-in, contact is optional, submission uses only RPC, and withdrawal hides code existence
- public-app.spec.ts:91:1 › closed collection, legacy redirect, service errors and retry have usable states
- public-app.spec.ts:116:1 › historical NCR map distinguishes missing source weeks from zero
- public-app.spec.ts:136:1 › public routes retain disclaimers and legal access on phones
- public-app.spec.ts:167:1 › publishable community aggregates remain delayed, unverified and separate
- public-app.spec.ts:196:1 › loading resolves to an explicit empty snapshot without fabricated values
- public-app.spec.ts:222:1 › historical forecast exposes all horizons and explicit interval uncertainty
- public-app.spec.ts:244:1 › model numbers exactly match saved evidence across scenarios and horizons
- public-app.spec.ts:271:1 › bundled footer dates never become a false live DB coverage claim
- staff-reporting.spec.ts:3:1 › unauthenticated staff paths expose only sign-in and no public navigation or queue
- staff-reporting.spec.ts:32:1 › v2 reporting is closed by default, opt-in and bilingual without storing health fields
- staff-reporting.spec.ts:60:1 › v2 open-policy preview collects coarse fields only and strips identifying note patterns

Production subset selection and all failure names remain visible in its raw log; unselected cases are not counted as successful tests.
