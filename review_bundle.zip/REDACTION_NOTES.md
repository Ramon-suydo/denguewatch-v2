# Review-copy redaction

Credentials, JWT-shaped strings, privileged-role markers, email/phone patterns, owner names and local user paths are replaced by [REDACTED]. Known-exposure fingerprints and private configuration are never included. Source copies may not run unchanged; use the Git branch for executable source. Actual command output is retained with mandatory redaction, including failures. Source/review hashes and changed-file categories are recorded without matched values.

All payloads are below 1,500,000 bytes; logical oversized text files are split with exact byte reconstruction in SPLIT_FILES.json. SHA256SUMS covers every payload except itself. The ZIP transfer container and external archive checksum are excluded from its own member list. Folder plus ZIP must be below 25,000,000 bytes. Archived recordings, full original source datasets, giant per-origin exports, credentials and dependency/build caches are omitted as disclosed.
