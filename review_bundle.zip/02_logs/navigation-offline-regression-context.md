# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: grid.spec.ts >> historical NCR map is offline, keyboard accessible and never assigns district case counts
- Location: tests\ui\grid.spec.ts:3:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 4

- Array []
+ Array [
+   "https://denguewatch-tests.invalid/rest/v1/reporting_v2_policy?select=enabled%2Cconsent_version&id=eq.true",
+   "https://denguewatch-tests.invalid/rest/v1/reporting_v2_policy?select=enabled%2Cconsent_version&id=eq.true",
+ ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: "#main"
  - generic [ref=e4]:
    - banner [ref=e5]:
      - generic [ref=e6]:
        - link "DengueWatch home" [ref=e7] [cursor=pointer]:
          - /url: /
          - generic [ref=e13]: DengueWatch
        - navigation "Main navigation" [ref=e14]:
          - link "Home" [ref=e15] [cursor=pointer]:
            - /url: /
          - link "Trends" [ref=e16] [cursor=pointer]:
            - /url: /trends
          - link "Metro Manila" [ref=e17] [cursor=pointer]:
            - /url: /metro-manila
          - link "Prevention" [ref=e18] [cursor=pointer]:
            - /url: /prevention
          - link "Methodology" [ref=e19] [cursor=pointer]:
            - /url: /methodology
          - link [ref=e20] [cursor=pointer]:
            - /url: /report
            - status [ref=e21]: "Community reports: checking"
    - generic [ref=e25]:
      - text: "Historical estimates, not alerts. Bundled source periods. Data: Jan 2021 (weekly) / Dec 2023 (daily)."
      - link "Details" [ref=e26] [cursor=pointer]:
        - /url: /data-sources
  - main [ref=e27]:
    - paragraph [ref=e28]: Data as of 2023-12-02. Historical Manila case data ends 2023-12-02 and is not live. NCR weekly data ends 2021-01-10; weather has its own date and cannot update case counts.
    - generic [ref=e29]:
      - paragraph [ref=e30]: METRO MANILA / HISTORICAL
      - heading "A city-level historical comparison." [level=1] [ref=e31]
      - note [ref=e32]:
        - strong [ref=e33]: Data ends January 2021.
        - text: No current NCR forecast is shown. Missing weeks are not zero.
      - generic [ref=e34]:
        - heading "Metro Manila context, not a prediction" [level=2] [ref=e35]
        - paragraph [ref=e36]: "Aedes aegypti mainly breeds in small standing-water containers near homes: drums, tires, pots and clogged drains. Flowing rivers are not its principal breeding habitat. Geographic proxies cannot identify a household at risk."
        - button "Show exploratory city context" [ref=e37] [cursor=pointer]
      - generic [ref=e38]:
        - generic [ref=e39]:
          - generic [ref=e40]: Comparison period
          - combobox "Comparison period" [ref=e41] [cursor=pointer]:
            - option "Year totals (available weeks)"
            - option "One source week" [selected]
        - generic [ref=e42]:
          - generic [ref=e43]: Week label
          - combobox "Week label" [ref=e44] [cursor=pointer]:
            - option "2016-01-10"
            - option "2016-01-17"
            - option "2016-01-24"
            - option "2016-01-31"
            - option "2016-02-07"
            - option "2016-02-14"
            - option "2016-02-21"
            - option "2016-02-28"
            - option "2016-03-06"
            - option "2016-03-13"
            - option "2016-03-20"
            - option "2016-03-27"
            - option "2016-04-03"
            - option "2016-04-10"
            - option "2016-04-17"
            - option "2016-04-24"
            - option "2016-05-01"
            - option "2016-05-08"
            - option "2016-05-15"
            - option "2016-05-22"
            - option "2016-05-29"
            - option "2016-06-05"
            - option "2016-06-12"
            - option "2016-06-19"
            - option "2016-06-26"
            - option "2016-07-03"
            - option "2016-07-10"
            - option "2016-07-17"
            - option "2016-07-24"
            - option "2016-07-31"
            - option "2016-08-07"
            - option "2016-08-14"
            - option "2016-08-21"
            - option "2016-08-28"
            - option "2016-09-04"
            - option "2016-09-11"
            - option "2016-09-18"
            - option "2016-09-25"
            - option "2016-10-02"
            - option "2016-10-09"
            - option "2016-10-16"
            - option "2016-10-23"
            - option "2016-10-30"
            - option "2016-11-06"
            - option "2016-11-13"
            - option "2016-11-20"
            - option "2016-11-27"
            - option "2016-12-04"
            - option "2016-12-11"
            - option "2016-12-18"
            - option "2016-12-25"
            - option "2017-01-01"
            - option "2017-01-08"
            - option "2017-01-15"
            - option "2017-01-22"
            - option "2017-01-29"
            - option "2017-02-05"
            - option "2017-02-12"
            - option "2017-02-19"
            - option "2017-02-26"
            - option "2017-03-05"
            - option "2017-03-12"
            - option "2017-03-19"
            - option "2017-03-26"
            - option "2017-04-02"
            - option "2017-04-09"
            - option "2017-04-16"
            - option "2017-04-23"
            - option "2017-04-30"
            - option "2017-05-07"
            - option "2017-05-14"
            - option "2017-05-21"
            - option "2017-05-28"
            - option "2017-06-04"
            - option "2017-06-11"
            - option "2017-06-18"
            - option "2017-06-25"
            - option "2017-07-02"
            - option "2017-07-09"
            - option "2017-07-16"
            - option "2017-07-23"
            - option "2017-07-30"
            - option "2017-08-06"
            - option "2017-08-13"
            - option "2017-08-20"
            - option "2017-08-27"
            - option "2017-09-03"
            - option "2017-09-10"
            - option "2017-09-17"
            - option "2017-09-24"
            - option "2017-10-01"
            - option "2017-10-08"
            - option "2017-10-15"
            - option "2017-10-22"
            - option "2017-10-29"
            - option "2017-11-05"
            - option "2017-11-12"
            - option "2017-11-19"
            - option "2017-11-26"
            - option "2017-12-03"
            - option "2017-12-10"
            - option "2017-12-17"
            - option "2017-12-24"
            - option "2017-12-31"
            - option "2018-01-07"
            - option "2018-01-14"
            - option "2018-01-21"
            - option "2018-01-28"
            - option "2018-02-04"
            - option "2018-02-11"
            - option "2018-02-18"
            - option "2018-02-25"
            - option "2018-03-04"
            - option "2018-03-11"
            - option "2018-03-18"
            - option "2018-03-25"
            - option "2018-04-01"
            - option "2018-04-08"
            - option "2018-04-15"
            - option "2018-04-22"
            - option "2018-04-29"
            - option "2018-05-06"
            - option "2018-05-13"
            - option "2018-05-20"
            - option "2018-05-27"
            - option "2018-06-03"
            - option "2018-06-10"
            - option "2018-06-17"
            - option "2018-06-24"
            - option "2018-07-01"
            - option "2018-07-08"
            - option "2018-07-15"
            - option "2018-07-22"
            - option "2018-07-29"
            - option "2018-08-05"
            - option "2018-08-12"
            - option "2018-08-19"
            - option "2018-08-26"
            - option "2018-09-02"
            - option "2018-09-09"
            - option "2018-09-16"
            - option "2018-09-23"
            - option "2018-09-30"
            - option "2018-10-07"
            - option "2018-10-14"
            - option "2018-10-21"
            - option "2018-10-28"
            - option "2018-11-04"
            - option "2018-11-11"
            - option "2018-11-18"
            - option "2018-11-25"
            - option "2018-12-02"
            - option "2018-12-09"
            - option "2018-12-16"
            - option "2018-12-23"
            - option "2018-12-30"
            - option "2019-01-06"
            - option "2019-01-13"
            - option "2019-01-20"
            - option "2019-01-27"
            - option "2019-02-03"
            - option "2019-02-10"
            - option "2019-02-17"
            - option "2019-02-24"
            - option "2019-03-03"
            - option "2019-03-10"
            - option "2019-03-17"
            - option "2019-03-24"
            - option "2019-03-31"
            - option "2019-04-07"
            - option "2019-04-14"
            - option "2019-04-21"
            - option "2019-04-28"
            - option "2019-05-05"
            - option "2019-05-12"
            - option "2019-05-19"
            - option "2019-05-26"
            - option "2019-06-02"
            - option "2019-06-09"
            - option "2019-06-16"
            - option "2019-06-23"
            - option "2019-06-30"
            - option "2019-07-07"
            - option "2019-07-14"
            - option "2019-07-21"
            - option "2019-07-28"
            - option "2019-08-04"
            - option "2019-08-11"
            - option "2019-08-18"
            - option "2019-08-25"
            - option "2019-09-01"
            - option "2019-09-08" [selected]
            - option "2019-09-15"
            - option "2019-09-22"
            - option "2019-09-29"
            - option "2019-10-06"
            - option "2019-10-13"
            - option "2019-10-20"
            - option "2019-10-27"
            - option "2019-11-03"
            - option "2019-11-10"
            - option "2019-11-17"
            - option "2019-11-24"
            - option "2019-12-01"
            - option "2019-12-08"
            - option "2019-12-15"
            - option "2019-12-22"
            - option "2019-12-29"
            - option "2020-01-05"
            - option "2020-01-12"
            - option "2020-01-19"
            - option "2020-01-26"
            - option "2020-02-02"
            - option "2020-02-09"
            - option "2020-02-16"
            - option "2020-02-23"
            - option "2020-03-01"
            - option "2020-03-08"
            - option "2020-03-15"
            - option "2020-03-22"
            - option "2020-03-29"
            - option "2020-04-05"
            - option "2020-04-12"
            - option "2020-04-19"
            - option "2020-04-26"
            - option "2020-05-03"
            - option "2020-05-10"
            - option "2020-05-17"
            - option "2020-05-24"
            - option "2020-05-31"
            - option "2020-06-07"
            - option "2020-06-14"
            - option "2020-06-21"
            - option "2020-06-28"
            - option "2020-07-05"
            - option "2020-07-12"
            - option "2020-07-19"
            - option "2020-07-26"
            - option "2020-08-02"
            - option "2020-08-09"
            - option "2020-08-16"
            - option "2020-08-23"
            - option "2020-08-30"
            - option "2020-09-06"
            - option "2020-09-13"
            - option "2020-09-20"
            - option "2020-09-27"
            - option "2020-10-04"
            - option "2020-10-11"
            - option "2020-10-18"
            - option "2020-10-25"
            - option "2020-11-01"
            - option "2020-11-08"
            - option "2020-11-15"
            - option "2020-11-22"
            - option "2020-11-29"
            - option "2020-12-06"
            - option "2020-12-13"
            - option "2020-12-20"
            - option "2020-12-27"
            - option "2021-01-03"
            - option "2021-01-10"
      - paragraph [ref=e45]:
        - strong [ref=e46]: Population denominator unverified; confirm against PSA 2020 census.
        - text: All rates use the same supplied 2020 denominator, including earlier years. No district or barangay case counts are inferred.
      - generic [ref=e47]:
        - heading "Recorded incidence per 100,000" [level=2] [ref=e48]
        - paragraph [ref=e49]: Darker blue means a larger historical rate in this selection. It does not identify current risk. Gray means no source observation, not zero. Exact values appear in the ranking table.
        - group "17 NCR city and municipal boundaries" [ref=e50]:
          - 'button "MANILA CITY: 13 per 100,000" [active] [pressed] [ref=e51] [cursor=pointer]'
          - 'button "MANDALUYONG CITY: 8 per 100,000" [ref=e52] [cursor=pointer]'
          - 'button "MARIKINA CITY: 12.1 per 100,000" [ref=e53] [cursor=pointer]'
          - 'button "PASIG CITY: 18.3 per 100,000" [ref=e54] [cursor=pointer]'
          - 'button "QUEZON CITY: 27.4 per 100,000" [ref=e55] [cursor=pointer]'
          - 'button "SAN JUAN CITY: 22.2 per 100,000" [ref=e56] [cursor=pointer]'
          - 'button "CALOOCAN CITY: 13.5 per 100,000" [ref=e57] [cursor=pointer]'
          - 'button "MALABON CITY: 34.2 per 100,000" [ref=e58] [cursor=pointer]'
          - 'button "NAVOTAS CITY: 8.9 per 100,000" [ref=e59] [cursor=pointer]'
          - 'button "VALENZUELA CITY: 14.7 per 100,000" [ref=e60] [cursor=pointer]'
          - 'button "LAS PINAS CITY: 17.6 per 100,000" [ref=e61] [cursor=pointer]'
          - 'button "MAKATI CITY: 9.4 per 100,000" [ref=e62] [cursor=pointer]'
          - 'button "MUNTINLUPA CITY: 19.7 per 100,000" [ref=e63] [cursor=pointer]'
          - 'button "PARANAQUE CITY: 25.8 per 100,000" [ref=e64] [cursor=pointer]'
          - 'button "PASAY CITY: 13.4 per 100,000" [ref=e65] [cursor=pointer]'
          - 'button "PATEROS: 32.2 per 100,000" [ref=e66] [cursor=pointer]'
          - 'button "TAGUIG CITY: 13.6 per 100,000" [ref=e67] [cursor=pointer]'
        - paragraph [ref=e68]:
          - strong [ref=e69]: MANILA CITY
          - text: ": 240 recorded cases; 13 per 100,000; 1 source week(s)."
        - paragraph [ref=e70]:
          - text: "Cases: DOH EPI, 2019-09-08; as of 2021-01-10. Boundaries: NAMRIA/PSA via OCHA HDX, CC BY 3.0 IGO, valid 2025-02-13; not proven historical boundaries."
          - link "Boundary source" [ref=e71] [cursor=pointer]:
            - /url: https://data.humdata.org/dataset/cod-ab-phl
          - text: .
      - generic [ref=e72]:
        - heading "City ranking · 2019-09-08" [level=2] [ref=e73]
        - region "Historical NCR city ranking" [ref=e74]:
          - table [ref=e75]:
            - rowgroup [ref=e76]:
              - row [ref=e77]:
                - columnheader "City / municipality" [ref=e78]
                - columnheader "Recorded cases" [ref=e79]
                - columnheader "Per 100,000" [ref=e80]
                - columnheader "Source weeks" [ref=e81]
            - rowgroup [ref=e82]:
              - row [ref=e83]:
                - rowheader [ref=e84]:
                  - button "MALABON CITY" [ref=e85] [cursor=pointer]
                - cell "130" [ref=e86]
                - cell "34.2" [ref=e87]
                - cell "1" [ref=e88]
              - row [ref=e89]:
                - rowheader [ref=e90]:
                  - button "PATEROS" [ref=e91] [cursor=pointer]
                - cell "21" [ref=e92]
                - cell "32.2" [ref=e93]
                - cell "1" [ref=e94]
              - row [ref=e95]:
                - rowheader [ref=e96]:
                  - button "QUEZON CITY" [ref=e97] [cursor=pointer]
                - cell "812" [ref=e98]
                - cell "27.4" [ref=e99]
                - cell "1" [ref=e100]
              - row [ref=e101]:
                - rowheader [ref=e102]:
                  - button "PARANAQUE CITY" [ref=e103] [cursor=pointer]
                - cell "178" [ref=e104]
                - cell "25.8" [ref=e105]
                - cell "1" [ref=e106]
              - row [ref=e107]:
                - rowheader [ref=e108]:
                  - button "SAN JUAN CITY" [ref=e109] [cursor=pointer]
                - cell "28" [ref=e110]
                - cell "22.2" [ref=e111]
                - cell "1" [ref=e112]
              - row [ref=e113]:
                - rowheader [ref=e114]:
                  - button "MUNTINLUPA CITY" [ref=e115] [cursor=pointer]
                - cell "107" [ref=e116]
                - cell "19.7" [ref=e117]
                - cell "1" [ref=e118]
              - row [ref=e119]:
                - rowheader [ref=e120]:
                  - button "PASIG CITY" [ref=e121] [cursor=pointer]
                - cell "147" [ref=e122]
                - cell "18.3" [ref=e123]
                - cell "1" [ref=e124]
              - row [ref=e125]:
                - rowheader [ref=e126]:
                  - button "LAS PINAS CITY" [ref=e127] [cursor=pointer]
                - cell "107" [ref=e128]
                - cell "17.6" [ref=e129]
                - cell "1" [ref=e130]
              - row [ref=e131]:
                - rowheader [ref=e132]:
                  - button "VALENZUELA CITY" [ref=e133] [cursor=pointer]
                - cell "105" [ref=e134]
                - cell "14.7" [ref=e135]
                - cell "1" [ref=e136]
              - row [ref=e137]:
                - rowheader [ref=e138]:
                  - button "TAGUIG CITY" [ref=e139] [cursor=pointer]
                - cell "121" [ref=e140]
                - cell "13.6" [ref=e141]
                - cell "1" [ref=e142]
              - row [ref=e143]:
                - rowheader [ref=e144]:
                  - button "CALOOCAN CITY" [ref=e145] [cursor=pointer]
                - cell "224" [ref=e146]
                - cell "13.5" [ref=e147]
                - cell "1" [ref=e148]
              - row [ref=e149]:
                - rowheader [ref=e150]:
                  - button "PASAY CITY" [ref=e151] [cursor=pointer]
                - cell "59" [ref=e152]
                - cell "13.4" [ref=e153]
                - cell "1" [ref=e154]
              - row [ref=e155]:
                - rowheader [ref=e156]:
                  - button "MANILA CITY" [ref=e157] [cursor=pointer]
                - cell "240" [ref=e158]
                - cell "13" [ref=e159]
                - cell "1" [ref=e160]
              - row [ref=e161]:
                - rowheader [ref=e162]:
                  - button "MARIKINA CITY" [ref=e163] [cursor=pointer]
                - cell "55" [ref=e164]
                - cell "12.1" [ref=e165]
                - cell "1" [ref=e166]
              - row [ref=e167]:
                - rowheader [ref=e168]:
                  - button "MAKATI CITY" [ref=e169] [cursor=pointer]
                - cell "59" [ref=e170]
                - cell "9.4" [ref=e171]
                - cell "1" [ref=e172]
              - row [ref=e173]:
                - rowheader [ref=e174]:
                  - button "NAVOTAS CITY" [ref=e175] [cursor=pointer]
                - cell "22" [ref=e176]
                - cell "8.9" [ref=e177]
                - cell "1" [ref=e178]
              - row [ref=e179]:
                - rowheader [ref=e180]:
                  - button "MANDALUYONG CITY" [ref=e181] [cursor=pointer]
                - cell "34" [ref=e182]
                - cell "8" [ref=e183]
                - cell "1" [ref=e184]
        - paragraph [ref=e185]: DOH EPI weekly source, ending January 2021. 2021 is January only. Calendar gaps and partial years make totals incomplete.
  - contentinfo [ref=e186]:
    - generic [ref=e188]:
      - complementary [ref=e189]:
        - heading "Estimates, not alerts" [level=2] [ref=e190]
        - paragraph [ref=e191]: Forecasts are statistical estimates from historical published data. They are not medical advice, an emergency or outbreak alert, or a substitute for guidance from the DOH or your local health office. Community reports are unverified and are not part of official data. This app does not provide real-time surveillance.
      - generic [ref=e192]: DengueWatch / Community health, in focus.
      - generic [ref=e193]: Thesis / research · Not an official DOH service
      - generic [ref=e194]: "Data attribution: Source details: Formal citation details unknown; data-owner confirmation required."
      - generic [ref=e195]:
        - text: "Last data period: Dec 2, 2023 (Manila daily workbook)."
        - generic [ref=e196]: "DOH EPI weekly: Jan 10, 2021."
        - text: Source date labels, not real-time data.
      - generic [ref=e197]:
        - link "Data & Sources" [ref=e198] [cursor=pointer]:
          - /url: /data-sources
        - text: ·
        - link "Legal & privacy drafts" [ref=e199] [cursor=pointer]:
          - /url: /legal
        - text: ·
        - link "Terms" [ref=e200] [cursor=pointer]:
          - /url: /terms
        - text: ·
        - link "Privacy & withdrawal" [ref=e201] [cursor=pointer]:
          - /url: /privacy
  - status
```

# Test source

```ts
  1  | ﻿import { test, expect } from "@playwright/test";
  2  | import AxeBuilder from "@axe-core/playwright";
  3  | test("historical NCR map is offline, keyboard accessible and never assigns district case counts", async ({
  4  |   page,
  5  |   context,
  6  | }) => {
  7  |   const external: string[] = [];
  8  |   await context.route("**/*", (r) => {
  9  |     if (
  10 |       ["localhost", "127.0.0.1"].includes(new URL(r.request().url()).hostname)
  11 |     )
  12 |       return r.continue();
  13 |     external.push(r.request().url());
  14 |     return r.abort();
  15 |   });
  16 |   await page.goto("/map");
  17 |   await expect(page.locator(".ncr-city-map path")).toHaveCount(17);
  18 |   const path = page.locator(".ncr-city-map path").first();
  19 |   await path.focus();
  20 |   await page.keyboard.press("Enter");
  21 |   await expect(path).toHaveAttribute("aria-pressed", "true");
  22 |   await expect(page.locator(".evidence-selection")).toContainText(
  23 |     "MANILA CITY",
  24 |   );
  25 |   await page.getByLabel("Comparison period").selectOption("week");
  26 |   await page.getByLabel("Week label").selectOption("2019-09-08");
  27 |   await expect(
  28 |     page
  29 |       .getByRole("region", { name: "Historical NCR city ranking" })
  30 |       .locator("tbody tr"),
  31 |   ).toHaveCount(17);
> 32 |   expect(external).toEqual([]);
     |                    ^ Error: expect(received).toEqual(expected) // deep equality
  33 | });
  34 | test("all 17 city shapes and selected-city details clear navigation at four widths", async ({
  35 |   page,
  36 | }) => {
  37 |   for (const width of [320, 390, 768, 1280]) {
  38 |     await page.setViewportSize({ width, height: 1000 });
  39 |     await page.goto("/map");
  40 |     await expect(page.locator(".ncr-city-map path")).toHaveCount(17);
  41 |     expect(
  42 |       await page.evaluate(() => ({
  43 |         overflow: document.documentElement.scrollWidth > innerWidth,
  44 |         titleClear:
  45 |           document.querySelector("h1")!.getBoundingClientRect().top >=
  46 |           document.querySelector(".top-nav")!.getBoundingClientRect().bottom,
  47 |       })),
  48 |     ).toEqual({ overflow: false, titleClear: true });
  49 |     expect(
  50 |       (await new AxeBuilder({ page }).analyze()).violations.filter((v) =>
  51 |         ["critical", "serious"].includes(v.impact ?? ""),
  52 |       ),
  53 |     ).toEqual([]);
  54 |     await page.screenshot({
  55 |       path: `.artifacts/evidence-ui/ncr-${width}.png`,
  56 |       fullPage: true,
  57 |     });
  58 |   }
  59 | });
  60 | 
```