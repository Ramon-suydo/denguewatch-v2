# Fresh evaluation evidence

Fresh evaluation command and reproduction hashes are in 02_logs/evaluation-final.txt and 04_tables/reproduction.json. Complete aggregate tables:

- main-selection.csv: 2 complete rows
- main-summaries.csv: 756 complete rows
- main-latest.csv: 24 complete rows
- main-episode_leads.csv: 32 complete rows
- main-drivers.csv: 8 complete rows
- environment-summaries.csv: 288 complete rows
- environment-leads.csv: 12 complete rows
- environment-drivers.csv: 10 complete rows
- city-context.csv: 17 complete rows
- geographic-correlations.csv: 6 complete rows
- monthly-profile.csv: 24 complete rows
- lag-correlations.csv: 48 complete rows

All nested CI fields and driver arrays are preserved. Null is unavailable, not zero. Both scenarios, all saved folds/horizons/models and sensitivities are included. Full per-origin arrays are not duplicated under the size budget; first-five profiles and complete aggregate tables are provided. This is not an independent scientific reanalysis. Thermal index and NCR-neighbor forecasts: NOT IMPLEMENTED / NOT VERIFIED.

04_EVALUATION.md and 04_ENVIRONMENT.md are exact source copies unless mandatory redaction is required. COPY_INTEGRITY and DOCUMENT_IDENTITY record hashes. Claim-evidence-matrix.csv inventories every digit-bearing document line. YES marks exact main-table field/rounding comparison now; other narratives are explicitly NOT VERIFIED independently.
