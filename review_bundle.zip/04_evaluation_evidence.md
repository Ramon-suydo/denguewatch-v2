# Fresh evaluation evidence

Fresh complete command output: [02_logs/evaluation.txt](02_logs/evaluation.txt). All tables below are extracted from the newly generated isolated-copy outputs, not copied console output from earlier runs. Original data files are unchanged. Hash comparison: [reproduction.json](04_tables/reproduction.json).

- `main-summaries.csv`: 756 complete rows.
- `environment-summaries.csv`: 288 complete rows.
- `city-context.csv`: 17 complete rows.
- `geographic-correlations.csv`: 6 complete rows.
- `monthly-profile.csv`: 24 complete rows.
- `main-episode_leads.csv`: 32 complete rows.
- `main-drivers.csv`: 8 complete rows.
- `main-selection.csv`: 2 complete rows.
- `main-latest.csv`: 24 complete rows.
- `environment-leads.csv`: 12 complete rows.
- `environment-drivers.csv`: 10 complete rows.
- `lag-correlations.csv`: 48 complete rows.

All scalar metric columns, including nested confidence intervals, are preserved. Null/empty metrics mean unavailable, not zero. Both absent-day scenarios, every model, every recorded fold and horizon, and alternate DOH-source cohorts appear in the complete summaries. Lead episodes, calibration coverage denominators, fixed seeds, thresholds, lag selection and model definitions are in the CSV/metadata files and key source.

Ablations: persistence; case AR; case+season; case+weather; case+season+weather; no-engineered weather; the original leave-rain/temperature/humidity-out ridge and tree variants. Thermal index: NOT IMPLEMENTED / NOT VERIFIED. NCR-neighbor forecasting: NOT IMPLEMENTED / NOT VERIFIED (optional research). Do not substitute missing ablations with a claimed zero effect.

Exact source-document copies: [04_EVALUATION.md](04_EVALUATION.md), [04_ENVIRONMENT.md](04_ENVIRONMENT.md). Mandatory sanitization takes priority if a blocked pattern occurs; final copy/redaction hashes disclose any differences.

Claim → evidence file → verified now: [claim-evidence-matrix.csv](04_tables/claim-evidence-matrix.csv). Every source-document line containing digits is conservatively inventoried, including tables, methods and narrative. YES marks freshly regenerated numeric table rows; it does not validate scientific assumptions. Other quantitative narrative is explicitly NOT VERIFIED independently.

Full per-origin prediction arrays are not duplicated in the review payload (about 10.8MB combined); all aggregate tables and representative records are included under the size cap. Exact reproduction requires the original input/caches described in the docs.
