# NCR classification and map review

Read docs/ML_METHOD.md, docs/ML_EVALUATION.md, docs/MAP_DESIGN.md and docs/evidence/mlux-checks.md. Source, SQL, full aggregate evaluation, runtime tree exports, all new command logs including failures, and eight actual production captures are included. The simple persistence rule wins held-out F1; RF remains validation-selected. Replay is dated historical research; Live needs recent reviewed 17-city counts. Reports remain closed.

The 6.7 MB PMTiles is committed in the feature branch; this compact bundle profiles its SHA and build receipt rather than duplicating it. Raw inputs, dependencies, fit caches, private configuration and browser recordings are omitted. Source review copies undergo mandatory redaction and may not run unchanged. Use Git for executable source. Exact split-file reconstruction and checksums are provided. Main has not been pushed for this task. Hosted operations and real human usability are not certified by local checks.
