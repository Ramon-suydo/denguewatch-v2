# DengueWatch UI review

Start with docs/evidence/manila-focus-checks.md and docs/evidence/ui-overhaul-checks.md, docs/BRAND.md, docs/DESIGN_SYSTEM.md, docs/MOTION.md and docs/UX_DECISIONS.md. Screenshots at 360/1280 px in both themes are under docs/evidence/ui-overhaul/. All 80 baseline hashes are in VISUAL_BASELINES.json; the actual baselines are committed in the repository.

COMMAND_MANIFEST.json contains real final command results. Historical secret rotation, approved contact, photo permission, Filipino review, DPO/hosted/human checks remain owner work. This is not deployment clearance. No push or hosted write occurred.
