# Live Manila review

Start with docs/LIVE_MANILA.md and docs/evidence/live-manila-checks.md. Public UI captures are under docs/evidence/live-manila-ui/. COMMAND_MANIFEST.json contains actual commands and exit codes; earlier failed/superseded attempts remain identified. Baseline hashes are in VISUAL_BASELINES.json; actual baseline images remain in Git.

The new schema is locally tested only. Source post verification, republication permission, adviser/Filipino review and historical credential rotation remain owner actions. Community reporting remains closed. Nothing was pushed or deployed.
