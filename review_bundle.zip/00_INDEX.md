# DengueWatch three-page redesign review

Branch: feat/redesign
Source commit: 54fa3cb0b139fe2d1b9cf1662c0ccacb5690985a
Captured UTC: 2026-10-25T14:02:05.606581+00:00

Read docs/evidence/redesign-checks.md and docs/MAP_METHOD.md first. This archive includes current source, forward SQL migration, full aggregate evaluation tables, explicit crosswalk/unmatched areas, weather receipts/input profiles, every fresh redesign log including failed diagnostics, actual production screenshots at 360/1280, rendered text and numeric provenance. Browser suites run separately from builds/evaluation/scanners.

Only Dashboard, Risk Map and Community Report are in main navigation; About is footer-linked. National colours use historical seasonal count ranks. Weather failed the improvement gate and is excluded. Population/catchment confounding is explicit. Only Manila has a historical case-forecast panel; current risk is unavailable.

NEEDS OWNER: photo source/licence/written permission; about.json team/contact; credential rotation; hosted deployment/Auth/schedules/log retention; DPO review before collection opens; usability test; verified population/catchment mapping. No hosted writes, main push, real participant collection or successful live deployment is claimed.

Source review copies receive mandatory redaction and may not run unchanged; the Git branch is executable source. COPY_INTEGRITY records changes. All payloads are below 1.5MB, with exact reconstruction for split text. Folder plus ZIP is below 25MB. SHA256SUMS covers payloads except itself; ZIP has an external checksum. Original datasets/photo, giant per-origin arrays, dependencies, credentials and private detection state are excluded.
