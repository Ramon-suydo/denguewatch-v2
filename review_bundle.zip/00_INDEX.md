# Independent launch review bundle

Branch: fix/launch
Source commit: d237e92929bfd8e3a9c3f60b51386fd3be0b5052
Captured UTC: 2026-10-25T07:16:37.428185+00:00
OS: Windows-10-10.0.19045-SP0
Runtime: Node 22.23.2; npm 10.8.2; Python 3.12.7

Architecture: React/Vite public SPA serves frozen same-origin research JSON and a tightly scoped PWA cache. Browser clients use public Supabase configuration; reporting and staff moderation call RLS-protected PostgreSQL RPCs, with staff appointment and AAL2 checks. Offline/unknown policy fails closed. Node/Python ingestion/evaluation and hosted-operation scripts use server environment configuration. Local Auth/PostgREST tests use signed disposable sessions and actual embedded PostgreSQL; hosted behavior remains separately unverified.

00-10 follow the requested review structure: repo metadata, complete fresh logs, per-file data profiles, complete model summary tables/claim matrix, current source/SQL/docs, RLS and test inventory, screenshots/text/numeric ledger, and known gaps/owner checklist.

Start with 10_known_gaps.md and 08_docs/LAUNCH_CHECKLIST.md. Current release is blocked by deferred owner rotation and hosted/human gates. No main push or report activation is claimed.

SHA256SUMS.txt covers all payload files except itself. The ZIP transfer container has an external checksum. Every payload member is under 1.5MB; combined folder plus ZIP is under 25MB. Oversized logical files are split with reconstruction instructions. Private config, credential fingerprints, certs, packages, build caches, real community records and the archived recording are excluded. Sanitization takes priority over executable/byte-exact source copies and is fully disclosed.
