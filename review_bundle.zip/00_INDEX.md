# Independent review bundle

Branch: `feat/manila-evidence`. Commit: `6fdf25517c7f8291c3b18b57d976b77c660a1d8d`.
Capture started: 2026-10-25T03:33:03.076518+00:00.
OS: Windows-10-10.0.19045-SP0. Fresh versions: Node v22.23.2; npm 10.8.2; Python 3.12.7. Exact command records are in 02_logs and 02_command_results.md. The working project is unchanged; execution occurs in a disposable source copy inside this folder, removed before delivery. No private environment, certificates, hosted database, real community records or installed dependencies are included.

The app is a React/TypeScript SPA built by Vite. Public historical research data are versioned static JSON exports. Node/TypeScript and Python scripts ingest aggregate Manila/DOH data, run expanding-origin evaluations and publish research snapshots. Supabase SQL provides closed-by-default community reporting, proof-of-work, role-checked moderation, aggregate suppression and retention; public reports stay separate from official counts and forecasts. Public forecasts remain persistence; weather is context/research. A public PWA caches historical assets. Hosted deployment/auth/scheduling are not verified by local SQL fixtures.

- 01_repo_overview.txt and 01_dependencies.json: actual repository and resolved packages.
- 02_command_results.md and 02_logs/: fresh commands, timestamps, exit codes, durations and full output.
- 03_data_report.md and 03_data_profiles/: original raw/processed schemas, counts, nulls, samples and source reconciliation.
- 04_evaluation_evidence.md and 04_tables/: all saved aggregate model/fold/horizon/scenario metrics, methods, claims matrix and fresh reproduction checks.
- 05_key_source/: original-relative application, script, test and config copies.
- 06_database_and_security.md and 06_sql/: migrations, actual isolated RLS catalog and credential-history limits.
- 07_tests_inventory.md: test names and evidence coverage.
- 08_docs/: documentation and saved reports. Oversized files are split with reconstruction instructions.
- 09_ui_evidence/: actual fresh screenshots and visible-text/number ledger. Protected staff screens show the real signed-out gate; authenticated workflows are NOT VERIFIED.
- 10_known_gaps.md: omissions, blockers, missing evidence and source TODOs.
- SANITIZATION_REPORT.json, FILE_LIST.txt and SHA256SUMS.txt: redactions, final file sizes and integrity.

"Verified now" means reproduced locally using current code, not independent scientific validity, live deployment, legal compliance or a complete accessibility certification. Historical copied reports retain their original dates and are not fresh evidence; consult 02_logs for current output. Where redaction conflicts with byte-for-byte copying, secret/privacy removal takes priority and is disclosed.

UI images: 28 base page/width screenshots plus 8 scrolled detail screenshots; actual 900px-high viewports. All original source data/code/docs remain unchanged. See OMISSIONS.json for the one archived video omitted under the combined payload/archive size cap.

Oversized-file reconstruction and row counts: see SPLIT_FILES.json. CSV parts repeat the header; keep one header and append all data rows in numbered order. JSON byte parts concatenate exactly.
